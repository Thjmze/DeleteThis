// Pure geometry for the custom-layout editor — polygon tests, edge snapping,
// chord splitting, bbox math. No DOM, no instance state.

export function pointInPoly(p, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i], [xj, yj] = poly[j];
    if (((yi > p.y) !== (yj > p.y)) &&
        (p.x < (xj - xi) * (p.y - yi) / (yj - yi + 1e-12) + xi)) {
      inside = !inside;
    }
  }
  return inside;
}

export function closestOnSegment(p, a, b) {
  const dx = b[0] - a[0], dy = b[1] - a[1];
  const len2 = dx * dx + dy * dy;
  if (len2 < 1e-9) return [a[0], a[1]];
  let t = ((p.x - a[0]) * dx + (p.y - a[1]) * dy) / len2;
  t = Math.max(0, Math.min(1, t));
  return [a[0] + t * dx, a[1] + t * dy];
}

export function snapToPolyEdge(p, poly) {
  let best = null;
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i], b = poly[(i + 1) % poly.length];
    const pt = closestOnSegment(p, a, b);
    const d = Math.hypot(pt[0] - p.x, pt[1] - p.y);
    if (!best || d < best.dist) best = { pt, edgeIndex: i, dist: d };
  }
  return best;
}

export function dedupePoly(pts) {
  const out = [];
  for (const p of pts) {
    const last = out[out.length - 1];
    if (!last || Math.hypot(p[0] - last[0], p[1] - last[1]) > 0.05) out.push(p);
  }
  if (out.length > 1) {
    const a = out[0], b = out[out.length - 1];
    if (Math.hypot(a[0] - b[0], a[1] - b[1]) < 0.05) out.pop();
  }
  return out;
}

// Split a polygon with a multi-segment polyline. `path` is the full list of
// vertices from the starting edge to the ending edge (at least 2 points).
// Produces two polygons that together cover the original and share the
// polyline as a boundary. Start and end may be on the same edge as long as
// the path has at least one interior vertex (path.length >= 3).
export function splitPolyByPolyline(poly, path, edgeStart, edgeEnd) {
  if (!Array.isArray(path) || path.length < 2) return null;
  const n = poly.length;

  let poly1, poly2;

  if (edgeStart === edgeEnd) {
    // Same-edge split: the path carves a bump out of the polygon.
    if (path.length < 3) return null;
    const E = edgeStart;
    const a = poly[E], b = poly[(E + 1) % n];
    const dx = b[0] - a[0], dy = b[1] - a[1];
    const lenSq = dx * dx + dy * dy;
    if (lenSq < 1e-9) return null;

    const tS = ((path[0][0] - a[0]) * dx + (path[0][1] - a[1]) * dy) / lenSq;
    const tP = ((path[path.length - 1][0] - a[0]) * dx + (path[path.length - 1][1] - a[1]) * dy) / lenSq;

    // Bump = just the path closed on itself.
    poly1 = path.map(p => [p[0], p[1]]);

    // Rest = reversed path + polygon boundary going the long way around.
    poly2 = path.slice().reverse().map(p => [p[0], p[1]]);
    if (tS < tP) {
      // Start is closer to V[E]; walk backwards from V[E] around to V[(E+1)%n].
      let i = E;
      for (let guard = 0; guard <= n; guard++) {
        poly2.push([poly[i][0], poly[i][1]]);
        if (i === (E + 1) % n) break;
        i = (i - 1 + n) % n;
      }
    } else {
      // Start is closer to V[(E+1)%n]; walk forwards from V[(E+1)%n] to V[E].
      let i = (E + 1) % n;
      for (let guard = 0; guard <= n; guard++) {
        poly2.push([poly[i][0], poly[i][1]]);
        if (i === E) break;
        i = (i + 1) % n;
      }
    }
  } else {
    // Different-edge split (original logic).
    // Poly1: path forward, then polygon edges from edgeEnd+1 around to edgeStart.
    poly1 = path.map(p => [p[0], p[1]]);
    let i = (edgeEnd + 1) % n;
    for (let guard = 0; guard <= n; guard++) {
      poly1.push(poly[i]);
      if (i === edgeStart) break;
      i = (i + 1) % n;
    }

    // Poly2: path reversed, then polygon edges from edgeStart+1 around to edgeEnd.
    poly2 = path.slice().reverse().map(p => [p[0], p[1]]);
    i = (edgeStart + 1) % n;
    for (let guard = 0; guard <= n; guard++) {
      poly2.push(poly[i]);
      if (i === edgeEnd) break;
      i = (i + 1) % n;
    }
  }

  const out1 = dedupePoly(poly1);
  const out2 = dedupePoly(poly2);
  if (out1.length < 3 || out2.length < 3) return null;
  if (polyArea(out1) < 20 || polyArea(out2) < 20) return null;
  return [out1, out2];
}

// Back-compat single-chord wrapper. Two-point polyline is just a chord.
export function splitPolyByChord(poly, a, b, edgeA, edgeB) {
  return splitPolyByPolyline(poly, [a, b], edgeA, edgeB);
}

// Find which face a point belongs to. Falls back to the closest boundary
// so clicks exactly on a cell edge still work.
export function findFaceForPoint(cuts, p) {
  for (let i = 0; i < cuts.length; i++) {
    const poly = cuts[i]?.cell?.poly;
    if (poly && pointInPoly(p, poly)) return i;
  }
  let best = -1, bestD = Infinity;
  for (let i = 0; i < cuts.length; i++) {
    const poly = cuts[i]?.cell?.poly;
    if (!poly) continue;
    const s = snapToPolyEdge(p, poly);
    if (s && s.dist < bestD) { bestD = s.dist; best = i; }
  }
  return best;
}

export function polyArea(poly) {
  let s = 0;
  for (let i = 0; i < poly.length; i++) {
    const [x1, y1] = poly[i];
    const [x2, y2] = poly[(i + 1) % poly.length];
    s += x1 * y2 - x2 * y1;
  }
  return Math.abs(s) / 2;
}

export function polyBbox(poly) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const [x, y] of poly) {
    if (x < minX) minX = x;
    if (y < minY) minY = y;
    if (x > maxX) maxX = x;
    if (y > maxY) maxY = y;
  }
  return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
}

// labelX/labelY are stored as percentages of the polygon's bounding box.
// For triangular / concave-looking shapes the bbox is larger than the
// visible polygon, so the label can land outside the real cell. This
// projects any out-of-poly label onto the nearest edge and nudges it
// a bit toward the centroid so it sits cleanly inside.
export function clampLabelToPoly(lx, ly, poly) {
  const bb = polyBbox(poly);
  const ax = bb.x + (lx / 100) * bb.w;
  const ay = bb.y + (ly / 100) * bb.h;
  if (pointInPoly({ x: ax, y: ay }, poly)) {
    return { labelX: lx, labelY: ly };
  }
  const snap = snapToPolyEdge({ x: ax, y: ay }, poly);
  let cx = 0, cy = 0;
  for (const [x, y] of poly) { cx += x; cy += y; }
  cx /= poly.length; cy /= poly.length;
  const nx = snap.pt[0] + (cx - snap.pt[0]) * 0.08;
  const ny = snap.pt[1] + (cy - snap.pt[1]) * 0.08;
  const newLx = bb.w < 1e-6 ? 50 : ((nx - bb.x) / bb.w) * 100;
  const newLy = bb.h < 1e-6 ? 50 : ((ny - bb.y) / bb.h) * 100;
  return {
    labelX: Math.max(0, Math.min(100, newLx)),
    labelY: Math.max(0, Math.min(100, newLy))
  };
}

// Returns a safe starting label position (polygon centroid, in bbox %).
export function labelCentroid(poly) {
  const bb = polyBbox(poly);
  let cx = 0, cy = 0;
  for (const [x, y] of poly) { cx += x; cy += y; }
  cx /= poly.length; cy /= poly.length;
  return {
    labelX: bb.w < 1e-6 ? 50 : ((cx - bb.x) / bb.w) * 100,
    labelY: bb.h < 1e-6 ? 50 : ((cy - bb.y) / bb.h) * 100
  };
}

export function polyToClipPath(poly, bbox) {
  const pts = poly.map(([x, y]) => {
    const rx = bbox.w < 1e-6 ? 0 : ((x - bbox.x) / bbox.w) * 100;
    const ry = bbox.h < 1e-6 ? 0 : ((y - bbox.y) / bbox.h) * 100;
    return `${rx.toFixed(3)}% ${ry.toFixed(3)}%`;
  });
  return `polygon(${pts.join(", ")})`;
}

// Returns t ∈ (0,1) along segment a where segment b meets a, or null if
// b does not touch a's interior. `t` is strict (split point must be
// inside a), but `s` accepts endpoint touches — when a user draws line
// b starting from a point on line a, b's endpoint lies on a at some
// interior t and that's the split we need to record.
export function segIntersectT(a, b) {
  const ax = Number(a.x2) - Number(a.x1);
  const ay = Number(a.y2) - Number(a.y1);
  const bx = Number(b.x2) - Number(b.x1);
  const by = Number(b.y2) - Number(b.y1);
  const denom = ax * by - ay * bx;
  if (Math.abs(denom) < 1e-9) return null;
  const dx = Number(b.x1) - Number(a.x1);
  const dy = Number(b.y1) - Number(a.y1);
  const t = (dx * by - dy * bx) / denom;
  const s = (dx * ay - dy * ax) / denom;
  const tEps = 1e-4;
  const sEps = 1e-3;
  if (t < tEps || t > 1 - tEps) return null;
  if (s < -sEps || s > 1 + sEps) return null;
  return t;
}

// Perpendicular-distance test with segment-bounds slack. Used to decide
// whether a polygon edge lies along a committed line.
export function pointOnLine(px, py, ln) {
  const x1 = Number(ln.x1), y1 = Number(ln.y1);
  const x2 = Number(ln.x2), y2 = Number(ln.y2);
  const dx = x2 - x1, dy = y2 - y1;
  const len2 = dx * dx + dy * dy || 1;
  const cross = (px - x1) * dy - (py - y1) * dx;
  if ((cross * cross) / len2 > 0.25) return false;
  const t = ((px - x1) * dx + (py - y1) * dy) / len2;
  return t >= -0.05 && t <= 1.05;
}

// Extends an infinite line (defined by a point + direction in 0-100
// viewBox space) out to the canvas bounds and returns [tMin, tMax]
// parameter values, or null if the line doesn't cross the canvas.
export function extendToBounds(px, py, vx, vy) {
  const ts = [];
  if (Math.abs(vx) > 1e-9) {
    ts.push(-px / vx);
    ts.push((100 - px) / vx);
  }
  if (Math.abs(vy) > 1e-9) {
    ts.push(-py / vy);
    ts.push((100 - py) / vy);
  }
  const valid = ts.filter(t => {
    const x = px + t * vx;
    const y = py + t * vy;
    return x >= -0.01 && x <= 100.01 && y >= -0.01 && y <= 100.01;
  });
  if (valid.length < 2) return null;
  valid.sort((a, b) => a - b);
  return [valid[0], valid[valid.length - 1]];
}
