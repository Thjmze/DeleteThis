// Number coercion with a default that does NOT fall through on 0.
// `Number(v) || fallback` returns fallback for 0 because 0 is falsy — that
// was clobbering legitimate X/Y values of 0.
export const num = (v, fallback) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
};

export const isVideoPath = (p) =>
  typeof p === "string" && /\.(webm|mp4|ogv|m4v)(\?.*)?$/i.test(p);
