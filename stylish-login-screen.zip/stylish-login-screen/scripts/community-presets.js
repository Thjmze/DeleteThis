// Community preset sharing: export, import, browse, submit.

// The user fills these in after creating the GitHub repo + Cloudflare Worker.
const INDEX_URL = "https://raw.githubusercontent.com/The-Final-Artificer/stylish-login-presets/main/index.json";
const SUBMIT_URL = "https://sls-presets.amer1221415.workers.dev/submit";

// Strip file paths and user assignments from a layout, producing a portable
// JSON that anyone can import without needing the original images.
export function stripForExport(layout, meta = {}) {
  const out = foundry.utils.deepClone(layout);

  // Top-level file references
  out.bgImage = "";
  out.music = "";
  out.entryImage = "";
  out.entrySound = "";
  if (out.entryTextStyle) out.entryTextStyle.bgImage = "";

  // Per-cut: clear user binding + all media paths
  if (Array.isArray(out.cuts)) {
    for (const cut of out.cuts) {
      cut.userId = null;
      delete cut.userName;
      cut.image = "";
      cut.sound = "";
      if (cut.nameStyle) cut.nameStyle.bgImage = "";
    }
  }

  return {
    version: 1,
    name: meta.name || "Untitled",
    author: meta.author || "Anonymous",
    description: meta.description || "",
    mode: out.mode || "grid",
    playerCount: Array.isArray(out.cuts) ? out.cuts.length : 0,
    createdAt: new Date().toISOString(),
    layout: out
  };
}

// Merge a community preset's layout onto the current draft, keeping the
// user's existing images, sounds, and player assignments. Cuts map by index:
// if the preset has more cells than the user has images, the extra cells stay
// blank; if fewer, leftover images are dropped.
export function applyImport(draft, preset) {
  const incoming = preset.layout;
  if (!incoming) return;

  // Snapshot what we need to preserve.
  const files = {
    bgImage: draft.bgImage || "",
    music: draft.music || "",
    entryImage: draft.entryImage || "",
    entrySound: draft.entrySound || "",
    entryTextBgImage: draft.entryTextStyle?.bgImage || ""
  };
  const cutFiles = (draft.cuts || []).map(c => ({
    userId: c.userId ?? null,
    image: c.image || "",
    sound: c.sound || "",
    nameStyleBgImage: c.nameStyle?.bgImage || ""
  }));

  // Overwrite everything with the community layout.
  const keys = Object.keys(incoming);
  for (const k of keys) {
    draft[k] = foundry.utils.deepClone(incoming[k]);
  }

  // Restore file references.
  draft.bgImage = files.bgImage;
  draft.music = files.music;
  draft.entryImage = files.entryImage;
  draft.entrySound = files.entrySound;
  if (draft.entryTextStyle) draft.entryTextStyle.bgImage = files.entryTextBgImage;

  if (Array.isArray(draft.cuts)) {
    for (let i = 0; i < draft.cuts.length; i++) {
      const saved = cutFiles[i];
      draft.cuts[i].userId = saved?.userId ?? null;
      draft.cuts[i].image = saved?.image || "";
      draft.cuts[i].sound = saved?.sound || "";
      if (draft.cuts[i].nameStyle) {
        draft.cuts[i].nameStyle.bgImage = saved?.nameStyleBgImage || "";
      }
    }
  }
}

export async function fetchIndex() {
  const res = await fetch(INDEX_URL, { cache: "no-cache" });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json(); // [{name, author, description, file}, ...]
}

export async function fetchPreset(fileUrl) {
  const res = await fetch(fileUrl, { cache: "no-cache" });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

export async function submitPreset(preset) {
  const res = await fetch(SUBMIT_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(preset)
  });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`HTTP ${res.status}: ${body}`);
  }
  return res.json();
}
