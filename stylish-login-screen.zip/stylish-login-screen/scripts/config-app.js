import { MODULE_ID, SETTING_KEY, DEFAULT_LAYOUT, DEFAULT_NAME_STYLE, DEFAULT_ENTRY_TEXT_STYLE, FONT_CHOICES, PRESETS_KEY, PRESET_COUNT, FONTS_KEY, getAllFontChoices } from "./settings.js";
import { num } from "./util.js";
import { UPLOAD_DIR, writeLayoutFile, worldId } from "./layout-writer.js";
import { loadBrushPaths } from "./brush-assets.js";
import { renderBrushLines } from "./brush-lines.js";
import {
  applyPolygonStyles, applyStyleVars, updatePreviewFit,
  updateLiveCell
} from "./preview-render.js";
import {
  snapToPolyEdge, splitPolyByPolyline, findFaceForPoint,
  clampLabelToPoly, labelCentroid, pointInPoly
} from "./geometry.js";
import {
  stripForExport, applyImport,
  fetchIndex, fetchPreset, submitPreset
} from "./community-presets.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

function loginPath() {
  const r = game.release;
  if (r && (r.generation > 14 || (r.generation === 14 && r.build >= 361)))
    return "/modules/stylish-login-screen/launch.svgz";
  return "/modules/stylish-login-screen/login.html";
}

export class LoginConfig extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: "stylish-login-config",
    tag: "form",
    window: {
      title: "SLS.ConfigTitle",
      icon: "fas fa-user-circle",
      resizable: true
    },
    position: { width: 1320, height: 900 },
    form: {
      handler: LoginConfig.#onSubmit,
      submitOnChange: false,
      closeOnSubmit: true
    },
    actions: {
      addCut: LoginConfig.#onAddCut,
      removeCut: LoginConfig.#onRemoveCut,
      pickImage: LoginConfig.#onPickImage,
      preview: LoginConfig.#onPreview,
      copyUrl: LoginConfig.#onCopyUrl,
      toggleInternet: LoginConfig.#onToggleInternet,
      exitEdit: LoginConfig.#onExitEdit,
      resetLayout: LoginConfig.#onResetLayout,
      resetStyle: LoginConfig.#onResetStyle,
      pickBgImage: LoginConfig.#onPickBgImage,
      pickEntryImage: LoginConfig.#onPickEntryImage,
      pickEntrySound: LoginConfig.#onPickEntrySound,
      pickEntryTextBgImage: LoginConfig.#onPickEntryTextBgImage,
      backToMain: LoginConfig.#onBackToMain,
      pickNameBgImage: LoginConfig.#onPickNameBgImage,
      pickSound: LoginConfig.#onPickSound,
      pickMusic: LoginConfig.#onPickMusic,
      savePreset: LoginConfig.#onSavePreset,
      loadPreset: LoginConfig.#onLoadPreset,
      clearPreset: LoginConfig.#onClearPreset,
      browseCommunity: LoginConfig.#onBrowseCommunity,
      communityBack: LoginConfig.#onCommunityBack,
      communitySelect: LoginConfig.#onCommunitySelect,
      communityImport: LoginConfig.#onCommunityImport,
      communitySubmit: LoginConfig.#onCommunitySubmit,
      communityRefresh: LoginConfig.#onCommunityRefresh,
      editEntryBg: LoginConfig.#onEditEntryBg
    }
  };

  static PARTS = {
    form: { template: "modules/stylish-login-screen/templates/config.hbs" }
  };

  #draft = null;
  #listeners = null;
  #selectedIdx = 0;
  #editMode = false;
  #resizeObs = null;
  #presetSlot = 0;
  #rightView = "main";
  #communityIndex = null;   // fetched index entries
  #communitySelected = -1;  // selected card index
  #communityCache = {};     // url → full preset, avoids re-fetching
  #savedDraft = null;       // draft snapshot before entering community view
  #communityFilterMode = "";
  #communityFilterPlayers = "";

  async _prepareContext() {
    await loadBrushPaths();
    if (!this.#draft) {
      const saved = game.settings.get(MODULE_ID, SETTING_KEY) ?? DEFAULT_LAYOUT;
      this.#draft = foundry.utils.deepClone(saved);
      if (typeof this.#draft.lineColor !== "string") this.#draft.lineColor = "#000000";
      if (!Number.isFinite(Number(this.#draft.lineThick))) this.#draft.lineThick = 4;
      if (typeof this.#draft.hoverColor !== "string") this.#draft.hoverColor = "#f0c040";
      if (!Number.isFinite(Number(this.#draft.hoverZoom))) this.#draft.hoverZoom = 4;
      if (typeof this.#draft.lineStyle !== "string") this.#draft.lineStyle = "solid";
      if (typeof this.#draft.bgImage !== "string") this.#draft.bgImage = "";
      if (this.#draft.showLogo === undefined) this.#draft.showLogo = false;
      if (typeof this.#draft.loginAnimation !== "string") this.#draft.loginAnimation = "none";
      if (this.#draft.muteBackground === undefined) this.#draft.muteBackground = true;
      if (this.#draft.entryScreen === undefined) this.#draft.entryScreen = false;
      if (typeof this.#draft.entryImage !== "string") this.#draft.entryImage = "";
      if (typeof this.#draft.entryImageFit !== "string") this.#draft.entryImageFit = "cover";
      if (!Number.isFinite(this.#draft.entryImageX)) this.#draft.entryImageX = 50;
      if (!Number.isFinite(this.#draft.entryImageY)) this.#draft.entryImageY = 50;
      if (!Number.isFinite(this.#draft.entryImageZoom)) this.#draft.entryImageZoom = 100;
      if (typeof this.#draft.entryFont !== "string") this.#draft.entryFont = "";
      if (typeof this.#draft.entryAnimation !== "string") this.#draft.entryAnimation = "none";
      if (typeof this.#draft.entrySound !== "string") this.#draft.entrySound = "";
      if (!Number.isFinite(this.#draft.entrySoundVolume)) this.#draft.entrySoundVolume = 50;
      if (typeof this.#draft.entryText !== "string") this.#draft.entryText = "";
      if (!this.#draft.entryTextStyle || typeof this.#draft.entryTextStyle !== "object") {
        this.#draft.entryTextStyle = foundry.utils.deepClone(DEFAULT_ENTRY_TEXT_STYLE);
      } else {
        for (const [k, v] of Object.entries(DEFAULT_ENTRY_TEXT_STYLE)) {
          if (this.#draft.entryTextStyle[k] === undefined) this.#draft.entryTextStyle[k] = v;
        }
      }
      if (typeof this.#draft.music !== "string") this.#draft.music = "";
      if (!Number.isFinite(this.#draft.musicVolume)) this.#draft.musicVolume = 50;
      // Backfill zoom boxes when any zoom-based animation is active.
      if (this.#draft.loginAnimation === "zoom" || this.#draft.loginAnimation === "zoomBlack") {
        for (const c of this.#draft.cuts) {
          if (!c.zoomBox) c.zoomBox = { x: 25, y: 25, w: 50, h: 50 };
        }
      }
      // Backfill label fields for cuts saved before these existed.
      const isCustom = this.#draft.mode === "custom";
      const isBackground = this.#draft.mode === "background";
      for (const c of this.#draft.cuts) {
        if (!Number.isFinite(c.soundVolume)) c.soundVolume = 50;
        if (c.labelShow === undefined) c.labelShow = true;
        if (c.labelX === undefined) c.labelX = 50;
        if (c.labelY === undefined) c.labelY = 88;
        if (isCustom && c.cell?.poly) {
          const cl = clampLabelToPoly(c.labelX, c.labelY, c.cell.poly);
          c.labelX = cl.labelX;
          c.labelY = cl.labelY;
        }
        if (isBackground && !c.box) {
          c.box = { x: 40, y: 40, w: 20, h: 20 };
        }
      }
    }

    // Always run per-cut name-style backfill so cuts added after the initial
    // load still pick up sensible defaults.
    for (const c of this.#draft.cuts) {
      if (!c.nameStyle || typeof c.nameStyle !== "object") {
        c.nameStyle = foundry.utils.deepClone(DEFAULT_NAME_STYLE);
      } else {
        for (const [k, v] of Object.entries(DEFAULT_NAME_STYLE)) {
          if (c.nameStyle[k] === undefined) c.nameStyle[k] = v;
        }
      }
    }

    // Grid mode: cut count is fully determined by cols × rows. Normalize on
    // every render so a stale saved layout (or mode switch) ends up with
    // exactly the right number of slots.
    if (this.#draft.mode !== "custom" && this.#draft.mode !== "background") {
      const cols = Math.max(1, Number(this.#draft.cols) || 1);
      const rows = Math.max(1, Number(this.#draft.rows) || 1);
      const target = cols * rows;
      const cuts = this.#draft.cuts;
      while (cuts.length < target) {
        cuts.push({
          userId: null, image: "", sound: "", soundVolume: 50,
          x: 50, y: 50, zoom: 100,
          labelShow: true, labelX: 50, labelY: 88,
          nameStyle: foundry.utils.deepClone(DEFAULT_NAME_STYLE)
        });
      }
      if (cuts.length > target) cuts.length = target;
    }

    if (this.#selectedIdx >= this.#draft.cuts.length) {
      this.#selectedIdx = Math.max(0, this.#draft.cuts.length - 1);
    }

    const userChoices = Object.fromEntries(
      game.users.contents.map(u => [u.id, u.isGM ? `${u.name} (GM)` : u.name])
    );

    const fitChoices = {
      letterbox: game.i18n.localize("SLS.FitLetterbox"),
      fill: game.i18n.localize("SLS.FitFill")
    };

    const lineStyleChoices = {
      solid:  game.i18n.localize("SLS.LineStyleSolid"),
      double: game.i18n.localize("SLS.LineStyleDouble"),
      neon:   game.i18n.localize("SLS.LineStyleNeon"),
      brush:         game.i18n.localize("SLS.LineStyleBrush"),
      brushCrossed:  game.i18n.localize("SLS.LineStyleBrushCrossed"),
      brush2:        game.i18n.localize("SLS.LineStyleBrush2"),
      brush2Crossed: game.i18n.localize("SLS.LineStyleBrush2Crossed"),
      thorns:        game.i18n.localize("SLS.LineStyleThorns"),
      torn:          game.i18n.localize("SLS.LineStyleTorn")
    };

    const loginAnimChoices = {
      none:            game.i18n.localize("SLS.AnimNone"),
      flash:           game.i18n.localize("SLS.AnimFlash"),
      zoom:            game.i18n.localize("SLS.AnimZoom"),
      zoomBlack:       game.i18n.localize("SLS.AnimZoomBlack"),
      ripple:          game.i18n.localize("SLS.AnimRipple"),
      spotlight:       game.i18n.localize("SLS.AnimSpotlight"),
      glitch:          game.i18n.localize("SLS.AnimGlitch"),
      erase:           game.i18n.localize("SLS.AnimErase")
    };

    const nameBgChoices = {
      box: game.i18n.localize("SLS.NameBgBox"),
      image: game.i18n.localize("SLS.NameBgImage"),
      none: game.i18n.localize("SLS.NameBgNone")
    };

    const entryAnimChoices = {
      none:           game.i18n.localize("SLS.EntryAnimNone"),
      fade:           game.i18n.localize("SLS.EntryAnimFade"),
      blurDissolve:   game.i18n.localize("SLS.EntryAnimBlurDissolve"),
      zoom:           game.i18n.localize("SLS.EntryAnimZoom"),
      iris:           game.i18n.localize("SLS.EntryAnimIris"),
      irisOpen:       game.i18n.localize("SLS.EntryAnimIrisOpen"),
      swipe:          game.i18n.localize("SLS.EntryAnimSwipe"),
      slideUp:        game.i18n.localize("SLS.EntryAnimSlideUp"),
      gate:           game.i18n.localize("SLS.EntryAnimGate"),
      elevatorDoors:  game.i18n.localize("SLS.EntryAnimElevatorDoors"),
      pixelDissolve:  game.i18n.localize("SLS.EntryAnimPixelDissolve")
    };

    const rawPresets = game.settings.get(MODULE_ID, PRESETS_KEY) ?? [];
    const presets = Array.from({ length: PRESET_COUNT }, (_, i) => rawPresets[i] ?? null);
    const presetChoices = Object.fromEntries(
      presets.map((p, i) => [i, p ? p.name : `— Slot ${i + 1} —`])
    );

    return {
      layout: this.#draft,
      userChoices,
      fitChoices,
      lineStyleChoices,
      loginAnimChoices,
      nameBgChoices,
      entryAnimChoices,
      entryFitChoices: {
        cover: game.i18n.localize("SLS.EntryFitCover"),
        contain: game.i18n.localize("SLS.EntryFitContain")
      },
      fontChoices: getAllFontChoices(),
      hasCuts: this.#draft.cuts.length > 0,
      isGrid: this.#draft.mode !== "custom" && this.#draft.mode !== "background",
      isCustom: this.#draft.mode === "custom",
      isBackground: this.#draft.mode === "background",
      isEditing: this.#editMode,
      showEntryTextView: this.#rightView === "entryText",
      showCommunityView: this.#rightView === "community",
      showMainView: this.#rightView === "main",
      presetChoices,
      presetSlot: this.#presetSlot,
      currentPresetName: presets[this.#presetSlot]?.name ?? ""
    };
  }

  _onChangeForm(formConfig, event) {
    this.#syncDraftFromDom();
    super._onChangeForm?.(formConfig, event);
  }

  #syncDraftFromDom() {
    const root = this.element;
    if (!root) return;
    const cols = Number(root.querySelector("input[name='cols']")?.value);
    const rows = Number(root.querySelector("input[name='rows']")?.value);
    if (Number.isFinite(cols) && cols > 0) this.#draft.cols = cols;
    if (Number.isFinite(rows) && rows > 0) this.#draft.rows = rows;
    const fit = root.querySelector("select[name='fit']")?.value;
    if (fit === "fill" || fit === "letterbox") this.#draft.fit = fit;

    const lineColor = root.querySelector("input[name='lineColor']")?.value;
    if (lineColor) this.#draft.lineColor = lineColor;
    this.#draft.lineThick = num(root.querySelector("input[name='lineThick']")?.value, 4);
    const hoverColor = root.querySelector("input[name='hoverColor']")?.value;
    if (hoverColor) this.#draft.hoverColor = hoverColor;
    this.#draft.hoverZoom = num(root.querySelector("input[name='hoverZoom']")?.value, 4);
    const lineStyle = root.querySelector("select[name='lineStyle']")?.value;
    if (typeof lineStyle === "string" && lineStyle) this.#draft.lineStyle = lineStyle;
    const loginAnim = root.querySelector("select[name='loginAnimation']")?.value;
    if (typeof loginAnim === "string") this.#draft.loginAnimation = loginAnim || "none";
    const bgImage = root.querySelector("input[name='bgImage']")?.value;
    if (bgImage !== undefined) this.#draft.bgImage = bgImage;
    this.#draft.showLogo = !!root.querySelector("input[name='showLogo']")?.checked;
    const muteCbEl = root.querySelector("input[name='muteBackground']");
    if (muteCbEl) this.#draft.muteBackground = muteCbEl.checked;
    this.#draft.entryScreen = !!root.querySelector("input[name='entryScreen']")?.checked;
    const entryImageEl = root.querySelector("input[name='entryImage']");
    if (entryImageEl) this.#draft.entryImage = entryImageEl.value ?? "";
    const eiFit = root.querySelector("select[name='entryImageFit']")?.value;
    if (eiFit === "cover" || eiFit === "contain") this.#draft.entryImageFit = eiFit;
    this.#draft.entryImageX = num(root.querySelector("input[name='entryImageX']")?.value, 50);
    this.#draft.entryImageY = num(root.querySelector("input[name='entryImageY']")?.value, 50);
    this.#draft.entryImageZoom = num(root.querySelector("input[name='entryImageZoom']")?.value, 100);
    const entryFontEl = root.querySelector("select[name='entryFont']");
    if (entryFontEl) this.#draft.entryFont = entryFontEl.value ?? "";
    const entrySoundEl = root.querySelector("input[name='entrySound']");
    if (entrySoundEl) this.#draft.entrySound = entrySoundEl.value ?? "";
    const entrySoundVolEl = root.querySelector("input[name='entrySoundVolume']");
    if (entrySoundVolEl) this.#draft.entrySoundVolume = num(entrySoundVolEl.value, 50);
    const entryAnimEl = root.querySelector("select[name='entryAnimation']");
    if (entryAnimEl) this.#draft.entryAnimation = entryAnimEl.value || "none";

    // Entry text + its style. Only present when the right column is in the
    // customize-entry-text view. Missing fields are skipped, not reset.
    const entryTextEl = root.querySelector("input[name='entryText']");
    if (entryTextEl) this.#draft.entryText = entryTextEl.value ?? "";
    if (!this.#draft.entryTextStyle) this.#draft.entryTextStyle = {};
    const ets = this.#draft.entryTextStyle;
    const etsColor = root.querySelector("input[name='entryTextStyle.color']");
    if (etsColor) ets.color = etsColor.value || "#eeeeee";
    const etsBg = root.querySelector("select[name='entryTextStyle.bg']");
    if (etsBg) {
      const v = etsBg.value;
      if (v === "box" || v === "image" || v === "none") ets.bg = v;
    }
    const etsBgImg = root.querySelector("input[name='entryTextStyle.bgImage']");
    if (etsBgImg) ets.bgImage = etsBgImg.value ?? "";
    const etsUseImg = root.querySelector("input[name='entryTextStyle.useImage']");
    if (etsUseImg) ets.useImage = !!etsUseImg.checked;
    const etsGlow = root.querySelector("input[name='entryTextStyle.glow']");
    if (etsGlow) ets.glow = !!etsGlow.checked;
    const etsSize = root.querySelector("input[name='entryTextStyle.size']");
    if (etsSize) ets.size = num(etsSize.value, 100);
    const etsBgSize = root.querySelector("input[name='entryTextStyle.bgImageSize']");
    if (etsBgSize) ets.bgImageSize = num(etsBgSize.value, 100);
    const etsX = root.querySelector("input[name='entryTextStyle.x']");
    if (etsX) ets.x = num(etsX.value, 50);
    const etsY = root.querySelector("input[name='entryTextStyle.y']");
    if (etsY) ets.y = num(etsY.value, 50);

    const musicEl = root.querySelector("input[name='music']");
    if (musicEl !== null) this.#draft.music = musicEl.value ?? "";
    const volEl = root.querySelector("input[name='musicVolume']");
    if (volEl) this.#draft.musicVolume = num(volEl.value, 50);

    const fieldsets = root.querySelectorAll(".sls-cut-fieldset");
    fieldsets.forEach((el) => {
      const i = Number(el.dataset.index);
      const cut = this.#draft.cuts[i];
      if (!cut) return;
      cut.userId = el.querySelector("select[name$='.userId']")?.value || null;
      const imgEl = el.querySelector("input[name$='.image']");
      if (imgEl) cut.image = imgEl.value || "";
      const soundEl = el.querySelector("input[name$='.sound']");
      if (soundEl) cut.sound = soundEl.value || "";
      const soundVolEl = el.querySelector("input[name$='.soundVolume']");
      if (soundVolEl) cut.soundVolume = num(soundVolEl.value, 50);
      const xEl = el.querySelector("input[name$='.x']");
      if (xEl) cut.x = num(xEl.value, 50);
      const yEl = el.querySelector("input[name$='.y']");
      if (yEl) cut.y = num(yEl.value, 50);
      const zEl = el.querySelector("input[name$='.zoom']");
      if (zEl) cut.zoom = num(zEl.value, 100);
      const show = el.querySelector("input[name$='.labelShow']");
      if (show) cut.labelShow = show.checked;
      const hoverOverride = el.querySelector("input[name$='.hoverOverride']")?.checked;
      const hoverColorInput = el.querySelector("input[name$='.hoverColor']");
      if (hoverColorInput) hoverColorInput.disabled = !hoverOverride;
      cut.hoverColor = hoverOverride && hoverColorInput?.value ? hoverColorInput.value : null;
      cut.labelX = num(el.querySelector("input[name$='.labelX']")?.value, 50);
      cut.labelY = num(el.querySelector("input[name$='.labelY']")?.value, 88);

      // Name style subsection.
      if (!cut.nameStyle) cut.nameStyle = foundry.utils.deepClone(DEFAULT_NAME_STYLE);
      const ns = cut.nameStyle;
      const nsFont = el.querySelector("select[name$='.nameStyle.font']")?.value;
      if (nsFont !== undefined) ns.font = nsFont;
      const nsColor = el.querySelector("input[name$='.nameStyle.color']")?.value;
      if (nsColor) ns.color = nsColor;
      const nsBg = el.querySelector("select[name$='.nameStyle.bg']")?.value;
      if (nsBg === "box" || nsBg === "image" || nsBg === "none") ns.bg = nsBg;
      ns.bgImage = el.querySelector("input[name$='.nameStyle.bgImage']")?.value ?? ns.bgImage;
      ns.useImage = !!el.querySelector("input[name$='.nameStyle.useImage']")?.checked;
      ns.glow = !!el.querySelector("input[name$='.nameStyle.glow']")?.checked;
      ns.size = num(el.querySelector("input[name$='.nameStyle.size']")?.value, 100);
      ns.bgImageSize = num(el.querySelector("input[name$='.nameStyle.bgImageSize']")?.value, 100);

      // Custom mode: keep the label inside the polygon's visible area.
      if (this.#draft.mode === "custom" && cut.cell?.poly) {
        const clamped = clampLabelToPoly(cut.labelX, cut.labelY, cut.cell.poly);
        cut.labelX = clamped.labelX;
        cut.labelY = clamped.labelY;
      }
    });
  }

  static #fontsLoaded = new Set();
  static #loadCustomFonts() {
    const fonts = game.settings.get(MODULE_ID, FONTS_KEY) ?? [];
    for (const f of fonts) {
      if (!f?.name || !f?.url || LoginConfig.#fontsLoaded.has(f.name)) continue;
      const face = new FontFace(f.name, `url("${foundry.utils.getRoute(f.url)}")`);
      face.load().then(() => document.fonts.add(face)).catch(() => {});
      LoginConfig.#fontsLoaded.add(f.name);
    }
  }

  static async #onSubmit(event, form, formData) {
    this.#syncDraftFromDom();
    await game.settings.set(MODULE_ID, SETTING_KEY, this.#draft);
    try {
      await writeLayoutFile(this.#draft);
      ui.notifications.info(game.i18n.localize("SLS.Saved"));
    } catch (e) {
      console.error(`${MODULE_ID} | failed to write layout.json`, e);
      ui.notifications.error(game.i18n.localize("SLS.WriteFailed"));
    }
  }

  static async #onAddCut(event, target) {
    this.#syncDraftFromDom();
    const base = { userId: null, image: "", sound: "", soundVolume: 50, x: 50, y: 50, zoom: 100, labelShow: true, labelX: 50, labelY: 88 };
    if (this.#draft.mode === "background") {
      // Cascade new boxes so they don't all land on top of each other.
      const n = this.#draft.cuts.length;
      const off = (n * 4) % 40;
      base.box = { x: 30 + off, y: 30 + off, w: 20, h: 20 };
    }
    this.#draft.cuts.push(base);
    this.#selectedIdx = this.#draft.cuts.length - 1;
    this.render();
  }

  static async #onRemoveCut(event, target) {
    event.stopPropagation();
    this.#syncDraftFromDom();
    const idx = Number(target.closest("[data-index]")?.dataset.index);
    if (!Number.isInteger(idx)) return;
    this.#draft.cuts.splice(idx, 1);
    if (this.#selectedIdx >= this.#draft.cuts.length) {
      this.#selectedIdx = Math.max(0, this.#draft.cuts.length - 1);
    }
    this.render();
  }

  static async #onPickImage(event, target) {
    const idx = Number(target.dataset.index);
    const input = this.element.querySelector(`.sls-cut-fieldset[data-index="${idx}"] input[name="cuts.${idx}.image"]`);
    if (!input) return;

    try { await FilePicker.createDirectory("data", UPLOAD_DIR); }
    catch { /* already exists */ }

    const fp = new FilePicker({
      type: "imagevideo",
      current: input.value || `${UPLOAD_DIR}/`,
      callback: (path) => {
        input.value = path;
        this.#syncDraftFromDom();
        this.#updateLiveCell(idx);
      }
    });
    fp.render(true);
  }

  static async #onPickSound(event, target) {
    const idx = Number(target.dataset.index);
    const input = this.element.querySelector(`.sls-cut-fieldset[data-index="${idx}"] input[name="cuts.${idx}.sound"]`);
    if (!input) return;

    const fp = new FilePicker({
      type: "audio",
      current: input.value || `${UPLOAD_DIR}/`,
      callback: (path) => {
        input.value = path;
        this.#syncDraftFromDom();
      }
    });
    fp.render(true);
  }

  static async #onPickMusic(event, target) {
    const fp = new FilePicker({
      type: "audio",
      current: this.#draft.music || `${UPLOAD_DIR}/`,
      callback: (path) => {
        this.#draft.music = path;
        const inp = this.element.querySelector("input[name='music']");
        if (inp) inp.value = path;
        this.#syncEntryState();
      }
    });
    fp.render(true);
  }

  // Checks whether the entry screen must be forced on (and disables the checkbox).
  // Also keeps the sub-panel's visibility in sync so forcing-on via music shows
  // the image/font/animation controls without needing a full re-render.
  #syncEntryState() {
    const muteCb = this.element?.querySelector("input[name='muteBackground']");
    const musicInp = this.element?.querySelector("input[name='music']");
    const entryCb = this.element?.querySelector("input[name='entryScreen']");
    if (!entryCb) return;
    const forced = (muteCb && !muteCb.checked) || !!musicInp?.value?.trim();
    if (forced) entryCb.checked = true;
    entryCb.disabled = forced;
    if (forced) this.#draft.entryScreen = true;
    const sub = this.element?.querySelector(".sls-entry-sub");
    if (sub) sub.hidden = !entryCb.checked;
  }

  #switchRightView(view) {
    this.#rightView = view;
    const root = this.element;
    if (!root) return;
    const community = root.querySelector(".sls-community-panel");
    const entryText = root.querySelector(".sls-entry-text-panel");
    const main = root.querySelector(".sls-main-panel");
    if (community) community.hidden = view !== "community";
    if (entryText) entryText.hidden = view !== "entryText";
    if (main) main.hidden = view !== "main";

    // Animate the revealed panel: forward panels slide from right,
    // going back to main slides from left.
    const panel = view === "community" ? community : view === "entryText" ? entryText : main;
    if (panel) {
      const name = view === "main" ? "sls-slide-back" : "sls-slide-in";
      panel.style.animation = "none";
      panel.offsetHeight;
      panel.style.animation = `${name} 250ms ease-out`;
    }
  }

  #renderCommunityCards(index) {
    const list = this.element?.querySelector(".sls-community-list");
    if (!list) return;
    list.innerHTML = "";

    if (index === null) {
      const p = document.createElement("p");
      p.className = "sls-community-empty";
      p.textContent = game.i18n.localize("SLS.CommunityLoading");
      list.appendChild(p);
      return;
    }

    if (!index.length) {
      const p = document.createElement("p");
      p.className = "sls-community-empty";
      p.textContent = game.i18n.localize("SLS.CommunityEmpty");
      list.appendChild(p);
      return;
    }

    // Apply active filters while keeping original index positions.
    let filtered = index.map((e, i) => ({ ...e, _idx: i }));
    if (this.#communityFilterMode) {
      filtered = filtered.filter(e => e.mode === this.#communityFilterMode);
    }
    if (this.#communityFilterPlayers) {
      filtered = filtered.filter(e => e.playerCount === Number(this.#communityFilterPlayers));
    }

    if (!filtered.length) {
      const p = document.createElement("p");
      p.className = "sls-community-empty";
      p.textContent = game.i18n.localize("SLS.CommunityNoMatch");
      list.appendChild(p);
      const importBtn = this.element?.querySelector("[data-action='communityImport']");
      if (importBtn) importBtn.disabled = true;
      return;
    }

    for (const entry of filtered) {
      const card = document.createElement("div");
      card.className = "sls-community-card";
      card.dataset.action = "communitySelect";
      card.dataset.cidx = entry._idx;
      if (entry._idx === this.#communitySelected) card.classList.add("selected");

      const name = document.createElement("div");
      name.className = "sls-community-name";
      name.textContent = entry.name || "Untitled";
      card.appendChild(name);

      const author = document.createElement("div");
      author.className = "sls-community-author";
      author.textContent = `by ${entry.author || "Anonymous"}`;
      card.appendChild(author);

      const meta = document.createElement("div");
      meta.className = "sls-community-meta";
      const mode = entry.mode || "grid";
      const pc = entry.playerCount;
      meta.textContent = `${mode[0].toUpperCase() + mode.slice(1)} · ${pc ?? "?"} players`;
      card.appendChild(meta);

      if (entry.description) {
        const desc = document.createElement("div");
        desc.className = "sls-community-desc";
        desc.textContent = entry.description;
        card.appendChild(desc);
      }

      list.appendChild(card);
    }

    const importBtn = this.element?.querySelector("[data-action='communityImport']");
    if (importBtn) importBtn.disabled = this.#communitySelected < 0;
  }

  #populatePlayerFilter(index) {
    const sel = this.element?.querySelector(".sls-filter-players");
    if (!sel) return;
    const counts = [...new Set(
      index.map(e => e.playerCount).filter(n => Number.isFinite(n))
    )].sort((a, b) => a - b);

    sel.innerHTML = "";
    const allOpt = document.createElement("option");
    allOpt.value = "";
    allOpt.textContent = game.i18n.localize("SLS.FilterPlayersAll");
    sel.appendChild(allOpt);

    for (const n of counts) {
      const opt = document.createElement("option");
      opt.value = n;
      opt.textContent = n === 1
        ? game.i18n.localize("SLS.FilterPlayers1")
        : game.i18n.format("SLS.FilterPlayersN", { n });
      sel.appendChild(opt);
    }
  }

  static async #onSavePreset() {
    this.#syncDraftFromDom();
    const nameInput = this.element.querySelector(".sls-preset-name");
    const name = nameInput?.value?.trim() || `Slot ${this.#presetSlot + 1}`;
    const raw = game.settings.get(MODULE_ID, PRESETS_KEY) ?? [];
    const presets = Array.from({ length: PRESET_COUNT }, (_, i) => raw[i] ?? null);
    presets[this.#presetSlot] = { name, layout: foundry.utils.deepClone(this.#draft) };
    await game.settings.set(MODULE_ID, PRESETS_KEY, presets);
    this.render();
  }

  static async #onLoadPreset() {
    const raw = game.settings.get(MODULE_ID, PRESETS_KEY) ?? [];
    const preset = raw[this.#presetSlot];
    if (!preset?.layout) return;
    this.#draft = foundry.utils.deepClone(preset.layout);
    this.#editMode = false;
    this.#selectedIdx = 0;
    this.render();
  }

  static async #onClearPreset() {
    const raw = game.settings.get(MODULE_ID, PRESETS_KEY) ?? [];
    const presets = Array.from({ length: PRESET_COUNT }, (_, i) => raw[i] ?? null);
    presets[this.#presetSlot] = null;
    await game.settings.set(MODULE_ID, PRESETS_KEY, presets);
    this.render();
  }

  // -------- community presets --------

  static async #onBrowseCommunity() {
    this.#syncDraftFromDom();
    this.#savedDraft = foundry.utils.deepClone(this.#draft);
    this.#communitySelected = -1;
    this.#communityFilterMode = "";
    this.#communityFilterPlayers = "";

    this.#switchRightView("community");

    // Reset filter dropdowns.
    const modeSel = this.element.querySelector(".sls-filter-mode");
    const playerSel = this.element.querySelector(".sls-filter-players");
    if (modeSel) modeSel.value = "";
    if (playerSel) playerSel.value = "";

    this.#renderCommunityCards(null);

    try {
      const index = await fetchIndex();
      this.#communityIndex = Array.isArray(index) ? index : [];
    } catch (e) {
      console.error(`${MODULE_ID} | community fetch failed`, e);
      this.#communityIndex = [];
      ui.notifications.warn(game.i18n.localize("SLS.CommunityFetchFailed"));
    }
    this.#populatePlayerFilter(this.#communityIndex);
    this.#renderCommunityCards(this.#communityIndex);
  }

  static async #onCommunityRefresh(event, target) {
    const btn = target.closest("button") || target;
    const icon = btn.querySelector("i");
    const origClass = icon?.className;
    btn.disabled = true;
    if (icon) icon.className = "fas fa-spinner sls-spin";

    try {
      const index = await fetchIndex();
      this.#communityIndex = Array.isArray(index) ? index : [];
    } catch (e) {
      console.error(`${MODULE_ID} | community refresh failed`, e);
      this.#communityIndex = [];
      ui.notifications.warn(game.i18n.localize("SLS.CommunityFetchFailed"));
    } finally {
      btn.disabled = false;
      if (icon) icon.className = origClass;
    }

    // Preserve current filter selection but rebuild the player options
    // in case new presets introduced different counts.
    const prevPlayer = this.#communityFilterPlayers;
    this.#populatePlayerFilter(this.#communityIndex);
    const sel = this.element?.querySelector(".sls-filter-players");
    if (sel) sel.value = prevPlayer;
    // If the old value no longer exists, the select resets to "All".
    this.#communityFilterPlayers = sel?.value || "";

    this.#communitySelected = -1;
    this.#renderCommunityCards(this.#communityIndex);
  }

  static async #onCommunityBack() {
    const hadPreview = this.#communitySelected >= 0;
    if (this.#savedDraft) {
      this.#draft = this.#savedDraft;
      this.#savedDraft = null;
    }
    this.#communitySelected = -1;
    this.#editMode = false;
    this.#selectedIdx = 0;

    if (hadPreview) {
      // Grid structure may have changed from the preview, so rebuild.
      this.#rightView = "main";
      this.render();
    } else {
      this.#switchRightView("main");
    }
  }

  static async #onCommunitySelect(event, target) {
    const idx = Number(target.closest("[data-cidx]")?.dataset.cidx);
    if (!Number.isFinite(idx) || !this.#communityIndex?.[idx]) return;

    const entry = this.#communityIndex[idx];
    const fileUrl = entry.file || entry.url;
    if (!fileUrl) return;

    // Fetch the full preset (cached).
    let preset = this.#communityCache[fileUrl];
    if (!preset) {
      try {
        preset = await fetchPreset(fileUrl);
        this.#communityCache[fileUrl] = preset;
      } catch (e) {
        console.error(`${MODULE_ID} | preset fetch failed`, e);
        ui.notifications.warn(game.i18n.localize("SLS.CommunityFetchFailed"));
        return;
      }
    }

    // Apply it to a fresh copy of the saved draft so the preview updates.
    this.#draft = foundry.utils.deepClone(this.#savedDraft);
    applyImport(this.#draft, preset);
    this.#communitySelected = idx;
    this.#editMode = false;
    this.#selectedIdx = 0;
    this.render();
  }

  static async #onCommunityImport() {
    if (this.#communitySelected < 0) {
      ui.notifications.warn(game.i18n.localize("SLS.CommunitySelectFirst"));
      return;
    }
    // The draft already has the community preset applied from #onCommunitySelect.
    // Just exit community view and keep it.
    this.#savedDraft = null;
    this.#rightView = "main";
    this.#communitySelected = -1;
    this.render();
    ui.notifications.info(game.i18n.localize("SLS.CommunityImported"));
  }

  static async #onCommunitySubmit(event, target) {
    const nameEl = this.element.querySelector(".sls-submit-name");
    const authorEl = this.element.querySelector(".sls-submit-author");
    const descEl = this.element.querySelector(".sls-submit-desc");
    const name = nameEl?.value?.trim();
    const author = authorEl?.value?.trim();
    if (!name) { nameEl?.focus(); return; }
    if (!author) { authorEl?.focus(); return; }

    const btn = target.closest("button") || target;
    const icon = btn.querySelector("i");
    const origClass = icon?.className;
    btn.disabled = true;
    if (icon) icon.className = "fas fa-spinner sls-spin";

    // Use the savedDraft (the actual user layout, not a preview-applied one).
    const source = this.#savedDraft || this.#draft;
    const preset = stripForExport(source, {
      name, author, description: descEl?.value?.trim() || ""
    });

    try {
      await submitPreset(preset);
      ui.notifications.info(game.i18n.localize("SLS.SubmitSuccess"));
      if (nameEl) nameEl.value = "";
      if (descEl) descEl.value = "";
    } catch (e) {
      console.error(`${MODULE_ID} | submit failed`, e);
      ui.notifications.error(game.i18n.localize("SLS.SubmitFailed"));
    } finally {
      btn.disabled = false;
      if (icon) icon.className = origClass;
    }
  }

  static async #onPreview(event, target) {
    this.#syncDraftFromDom();
    await game.settings.set(MODULE_ID, SETTING_KEY, this.#draft);
    try {
      await writeLayoutFile(this.#draft);
    } catch (e) {
      console.error(`${MODULE_ID} | failed to write layout.json`, e);
      ui.notifications.error(game.i18n.localize("SLS.WriteFailed"));
      return;
    }

    const url = foundry.utils.getRoute(loginPath()) + `?world=${encodeURIComponent(worldId())}`;
    const win = window.open(url, "sls-preview", "width=1024,height=720");
    if (!win) ui.notifications.warn(game.i18n.localize("SLS.PopupBlocked"));
    else ui.notifications.info(game.i18n.localize("SLS.PreviewOpened"));
  }

  static async #onCopyUrl(event, target) {
    const row = target.closest("[data-url]");
    const url = row?.dataset.url;
    if (!url) return;
    try {
      await navigator.clipboard.writeText(url);
      ui.notifications.info(game.i18n.format("SLS.UrlCopied", { url }));
    } catch {
      ui.notifications.info(url);
    }
  }

  static async #onToggleInternet(event, target) {
    const row = target.closest(".sls-internet-row");
    if (!row) return;
    const code = row.querySelector(".sls-internet-code");
    const icon = target.querySelector("i");
    const revealed = row.dataset.revealed === "true";

    if (revealed) {
      code.textContent = "•".repeat(28);
      row.dataset.revealed = "false";
      icon?.classList.remove("fa-eye-slash");
      icon?.classList.add("fa-eye");
    } else {
      code.textContent = row.dataset.url;
      row.dataset.revealed = "true";
      icon?.classList.remove("fa-eye");
      icon?.classList.add("fa-eye-slash");
    }
  }

  // -------- custom layout --------

  static async #onEditLayout(event, target) {
    this.#syncDraftFromDom();
    // Start from a blank canvas: one full-window cell, no players, no lines.
    this.#draft.mode = "custom";
    this.#draft.cuts = [{
      userId: null, image: "", x: 50, y: 50, zoom: 100, labelShow: true, labelX: 50, labelY: 88,
      cell: { poly: [[0, 0], [100, 0], [100, 100], [0, 100]] }
    }];
    this.#draft.lines = [];
    this.#selectedIdx = 0;
    this.#editMode = true;
    this.render();
  }

  static async #onExitEdit(event, target) {
    this.#editMode = false;
    this.render();
  }

  static async #onResetLayout(event, target) {
    // Collapse to a single full-size cell so the GM can start over.
    this.#draft.cuts = [{
      userId: null, image: "", x: 50, y: 50, zoom: 100, labelShow: true, labelX: 50, labelY: 88,
      cell: { poly: [[0, 0], [100, 0], [100, 100], [0, 100]] }
    }];
    this.#draft.lines = [];
    this.#draft.mode = "custom";
    this.#selectedIdx = 0;
    this.render();
  }

  static async #onBackgroundLayout(event, target) {
    this.#syncDraftFromDom();
    this.#draft.mode = "background";
    this.#draft.fit = "letterbox";
    this.#draft.cuts = [{
      userId: null, image: "", x: 50, y: 50, zoom: 100,
      labelShow: true, labelX: 50, labelY: 88,
      box: { x: 40, y: 40, w: 20, h: 20 }
    }];
    this.#editMode = false;
    delete this.#draft.lines;
    this.#selectedIdx = 0;
    this.render();
  }

  static async #onPickNameAsset(target, field) {
    const idx = Number(target.dataset.index);
    const cut = this.#draft.cuts[idx];
    if (!cut) return;
    if (!cut.nameStyle) cut.nameStyle = foundry.utils.deepClone(DEFAULT_NAME_STYLE);
    try { await FilePicker.createDirectory("data", UPLOAD_DIR); }
    catch { /* already exists */ }
    const fp = new FilePicker({
      type: "image",
      current: cut.nameStyle[field] || `${UPLOAD_DIR}/`,
      callback: (path) => {
        cut.nameStyle[field] = path;
        const input = this.element.querySelector(
          `.sls-cut-fieldset[data-index="${idx}"] input[name="cuts.${idx}.nameStyle.${field}"]`
        );
        if (input) input.value = path;
        this.#updateLiveCell(idx);
      }
    });
    fp.render(true);
  }

  static async #onPickNameBgImage(event, target) {
    return LoginConfig.#onPickNameAsset.call(this, target, "bgImage");
  }

  static async #onPickBgImage(event, target) {
    try { await FilePicker.createDirectory("data", UPLOAD_DIR); }
    catch { /* already exists */ }
    const fp = new FilePicker({
      type: "imagevideo",
      current: this.#draft.bgImage || `${UPLOAD_DIR}/`,
      callback: (path) => {
        this.#draft.bgImage = path;
        this.render();
      }
    });
    fp.render(true);
  }

  static async #onPickEntryImage(event, target) {
    this.#syncDraftFromDom();
    try { await FilePicker.createDirectory("data", UPLOAD_DIR); }
    catch { /* already exists */ }
    const fp = new FilePicker({
      type: "imagevideo",
      current: this.#draft.entryImage || `${UPLOAD_DIR}/`,
      callback: (path) => {
        this.#draft.entryImage = path;
        const inp = this.element.querySelector("input[name='entryImage']");
        if (inp) inp.value = path;
        this.#updateEntryPreview();
      }
    });
    fp.render(true);
  }

  static async #onPickEntrySound(event, target) {
    this.#syncDraftFromDom();
    const fp = new FilePicker({
      type: "audio",
      current: this.#draft.entrySound || `${UPLOAD_DIR}/`,
      callback: (path) => {
        this.#draft.entrySound = path;
        const inp = this.element.querySelector("input[name='entrySound']");
        if (inp) inp.value = path;
      }
    });
    fp.render(true);
  }

  static async #onPickEntryTextBgImage(event, target) {
    this.#syncDraftFromDom();
    try { await FilePicker.createDirectory("data", UPLOAD_DIR); }
    catch { /* already exists */ }
    const fp = new FilePicker({
      type: "image",
      current: this.#draft.entryTextStyle?.bgImage || `${UPLOAD_DIR}/`,
      callback: (path) => {
        this.#draft.entryTextStyle.bgImage = path;
        const inp = this.element.querySelector("input[name='entryTextStyle.bgImage']");
        if (inp) inp.value = path;
        this.#updateEntryPreview();
      }
    });
    fp.render(true);
  }

  static async #onEditEntryBg(event, target) {
    this.#syncDraftFromDom();
    this.#switchRightView("entryText");
    // Show the entry preview overlay, hide the normal grid.
    const preview = this.element.querySelector(".sls-entry-preview");
    const livePreview = this.element.querySelector(".sls-live-preview");
    if (preview) preview.hidden = false;
    if (livePreview) livePreview.hidden = true;
    this.#updateEntryPreview();
  }

  #updateEntryPreview() {
    const el = this.element?.querySelector(".sls-entry-preview");
    if (!el || el.hidden) return;
    const src = this.#draft.entryImage;
    const fit = this.#draft.entryImageFit || "cover";
    const x = this.#draft.entryImageX ?? 50;
    const y = this.#draft.entryImageY ?? 50;
    const zoom = this.#draft.entryImageZoom ?? 100;
    const isVid = src && /\.(webm|mp4|ogv|m4v)(\?.*)?$/i.test(src);

    let vid = el.querySelector(".sls-entry-preview-video");
    if (isVid) {
      el.style.backgroundImage = "none";
      if (!vid) {
        vid = document.createElement("video");
        vid.className = "sls-entry-preview-video";
        vid.autoplay = true;
        vid.muted = true;
        vid.loop = true;
        vid.playsInline = true;
        vid.style.cssText = "position:absolute;inset:0;width:100%;height:100%;pointer-events:none;";
        el.insertBefore(vid, el.firstChild);
      }
      vid.style.objectFit = zoom > 100 ? "cover" : fit;
      vid.style.objectPosition = `${x}% ${y}%`;
      vid.style.transform = zoom > 100 ? `scale(${zoom / 100})` : "";
      const route = foundry.utils.getRoute(src);
      if (vid.getAttribute("src") !== route) vid.src = route;
    } else {
      if (vid) vid.remove();
      el.style.backgroundImage = src ? `url("${foundry.utils.getRoute(src)}")` : "none";
      el.style.backgroundSize = zoom > 100 ? `${zoom}%` : fit;
      el.style.backgroundPosition = `${x}% ${y}%`;
    }
    this.#updateEntryTextLabel();
  }

  #updateEntryTextLabel() {
    const el = this.element?.querySelector(".sls-entry-preview");
    if (!el || el.hidden) return;
    let lbl = el.querySelector(".sls-entry-preview-label");
    if (!lbl) {
      lbl = document.createElement("span");
      lbl.className = "sls-entry-preview-label";
      el.appendChild(lbl);
    }
    const ts = this.#draft.entryTextStyle || {};
    const text = (this.#draft.entryText || "").trim() || "Enter";
    const font = this.#draft.entryFont || "";
    const size = (+ts.size || 100) / 100;
    const bgScale = (+ts.bgImageSize || 100) / 100;

    // Position
    lbl.style.position = "absolute";
    lbl.style.left = `${Number.isFinite(+ts.x) ? +ts.x : 50}%`;
    lbl.style.top = `${Number.isFinite(+ts.y) ? +ts.y : 50}%`;
    lbl.style.transform = "translate(-50%, -50%)";
    lbl.style.setProperty("--sls-entry-scale", String(size));

    // Clear previous styles
    lbl.textContent = "";
    lbl.querySelector("img")?.remove();
    for (const p of ["backgroundImage", "backgroundColor", "backgroundSize",
                     "backgroundPosition", "backgroundRepeat", "padding",
                     "borderRadius", "textShadow", "fontFamily", "color"]) {
      lbl.style[p] = "";
    }

    const bgImgUrl = ts.bgImage || "";
    // Scale absolute sizes so they match the proportions on the real login screen.
    // Use the actual viewport width as reference, not a hardcoded 1920.
    const pw = el.clientWidth || 400;
    const pxRatio = pw / (window.innerWidth || 1920);
    lbl.style.fontSize = `${26 * size * pxRatio}px`;

    if (ts.useImage && bgImgUrl) {
      const img = lbl.querySelector("img") || document.createElement("img");
      img.alt = text;
      img.src = bgImgUrl;
      img.style.display = "block";
      img.style.maxWidth = `${300 * size * bgScale * pxRatio}px`;
      img.style.height = "auto";
      lbl.appendChild(img);
    } else {
      lbl.textContent = text;
      if (font) lbl.style.fontFamily = `"${font}", "Signika", "Segoe UI", sans-serif`;
      if (ts.color) lbl.style.color = ts.color;
      const bg = ts.bg || "none";
      if (bg === "box") {
        lbl.style.backgroundColor = "rgba(0, 0, 0, 0.5)";
        lbl.style.padding = "0.4em 1em";
        lbl.style.borderRadius = "3px";
      } else if (bg === "image" && bgImgUrl) {
        lbl.style.backgroundImage = `url("${bgImgUrl}")`;
        lbl.style.backgroundSize = `${100 * bgScale}% ${100 * bgScale}%`;
        lbl.style.backgroundPosition = "center center";
        lbl.style.backgroundRepeat = "no-repeat";
        lbl.style.padding = "0.6em 1.4em";
      }
    }

    if (ts.glow) {
      const c = ts.color || "#eeeeee";
      lbl.style.textShadow = `0 0 8px ${c}, 0 0 16px ${c}`;
    }
  }

  static async #onBackToMain(event, target) {
    this.#syncDraftFromDom();
    // Hide entry preview, restore normal grid.
    const preview = this.element.querySelector(".sls-entry-preview");
    const livePreview = this.element.querySelector(".sls-live-preview");
    if (preview) preview.hidden = true;
    if (livePreview) livePreview.hidden = false;
    this.#switchRightView("main");
  }

  static async #onResetStyle(event, target) {
    this.#syncDraftFromDom();
    this.#draft.lineColor = DEFAULT_LAYOUT.lineColor;
    this.#draft.lineThick = DEFAULT_LAYOUT.lineThick;
    this.#draft.hoverColor = DEFAULT_LAYOUT.hoverColor;
    this.#draft.hoverZoom = DEFAULT_LAYOUT.hoverZoom;
    this.render();
  }

  static async #onRevertGrid(event, target) {
    this.#draft.mode = "grid";
    for (const c of this.#draft.cuts) {
      delete c.cell;
      delete c.box;
    }
    delete this.#draft.lines;
    this.#editMode = false;
    this.render();
  }

  #seedCustomFromGrid() {
    const cols = Math.max(1, Number(this.#draft.cols) || 1);
    const rows = Math.max(1, Number(this.#draft.rows) || 1);
    const total = cols * rows;
    const cw = 100 / cols;
    const ch = 100 / rows;

    while (this.#draft.cuts.length < total) {
      this.#draft.cuts.push({ userId: null, image: "", x: 50, y: 50, zoom: 100, labelShow: true, labelX: 50, labelY: 88 });
    }
    if (this.#draft.cuts.length > total) this.#draft.cuts.length = total;

    for (let i = 0; i < total; i++) {
      const col = i % cols;
      const row = Math.floor(i / cols);
      const x = col * cw, y = row * ch;
      this.#draft.cuts[i].cell = {
        poly: [[x, y], [x + cw, y], [x + cw, y + ch], [x, y + ch]]
      };
    }
    // Seed any internal grid dividers as committed lines so they show up
    // on top of the cells (matches the drawn-line rendering).
    this.#draft.lines = [];
    for (let c = 1; c < cols; c++) {
      const x = c * cw;
      this.#draft.lines.push({ x1: x, y1: 0, x2: x, y2: 100 });
    }
    for (let r = 1; r < rows; r++) {
      const y = r * ch;
      this.#draft.lines.push({ x1: 0, y1: y, x2: 100, y2: y });
    }
    this.#draft.mode = "custom";
  }

  // Commits a multi-segment polyline as a single cut through the given cell.
  // path[0] is on edgeStart, path[last] is on edgeEnd. Intermediate points
  // are free-space vertices inside the polygon.
  #commitDrawnPolyline(cutIdx, path, edgeStart, edgeEnd) {
    const cut = this.#draft.cuts[cutIdx];
    if (!cut?.cell?.poly) return;
    const poly = cut.cell.poly;

    const split = splitPolyByPolyline(poly, path, edgeStart, edgeEnd);
    if (!split) return;

    const [polyA, polyB] = split;
    const first = { ...cut, cell: { poly: polyA } };
    const cA = clampLabelToPoly(num(first.labelX, 50), num(first.labelY, 88), polyA);
    first.labelX = cA.labelX;
    first.labelY = cA.labelY;
    const centroidB = labelCentroid(polyB);
    const second = {
      userId: null, image: "", x: 50, y: 50, zoom: 100,
      labelShow: true, labelX: centroidB.labelX, labelY: centroidB.labelY,
      cell: { poly: polyB }
    };
    this.#draft.cuts.splice(cutIdx, 1, first, second);

    // Record each segment of the polyline as its own committed line so the
    // existing line-rendering (solid/double/neon/brush) picks them up as
    // individual strokes.
    if (!Array.isArray(this.#draft.lines)) this.#draft.lines = [];
    for (let i = 0; i < path.length - 1; i++) {
      this.#draft.lines.push({
        x1: path[i][0],   y1: path[i][1],
        x2: path[i + 1][0], y2: path[i + 1][1]
      });
    }
    this.#selectedIdx = cutIdx;
    this.render();
  }

  // -------- zoom box --------

  // Builds (or tears down) the draggable zoom-box overlay on each live cell.
  // Active for any zoom-based login animation.
  #applyZoomBoxes() {
    const preview = this.element?.querySelector?.(".sls-live-preview");
    if (!preview) return;
    preview.querySelectorAll(".sls-zoom-box").forEach(el => el.remove());
    // Remove any clip-path we pinned to cells in a previous call.
    if (this.#draft.mode !== "custom") {
      preview.querySelectorAll(".sls-live-cell").forEach(c => {
        if (c.style.clipPath === "inset(0)") c.style.clipPath = "";
      });
    }
    const anim = this.#draft.loginAnimation;
    if (anim !== "zoom" && anim !== "zoomBlack") return;

    preview.querySelectorAll(".sls-live-cell").forEach(cell => {
      const idx = Number(cell.dataset.index);
      const cut = this.#draft.cuts[idx];
      if (!cut) return;

      // h% = w% × (9 × cellW_px) / (16 × cellH_px) keeps the box 16:9 in screen space.
      const cr = cell.getBoundingClientRect();
      const hFromW = w => (cr.width > 0 && cr.height > 0)
        ? w * (9 * cr.width) / (16 * cr.height)
        : w * 9 / 16;

      if (!cut.zoomBox) {
        const w = 50;
        const h = Math.min(100, hFromW(w));
        cut.zoomBox = { x: 25, y: Math.max(0, (100 - h) / 2), w, h };
        if (this.#draft.mode === "custom" && cut.cell?.poly) {
          const zb = cut.zoomBox;
          const { labelX: ncx, labelY: ncy } = clampLabelToPoly(50, 50, cut.cell.poly);
          zb.x = Math.max(0, Math.min(100 - w, ncx - w / 2));
          zb.y = Math.max(0, Math.min(100 - h, ncy - h / 2));
        }
      } else {
        // Re-enforce 16:9 on any existing box (e.g. loaded from save or old format).
        // Keep the centre fixed — only changing h shifts the centre, which makes the
        // zoom animation aim at the wrong spot.
        const zb = cut.zoomBox;
        const cy = zb.y + zb.h / 2;
        zb.h = hFromW(zb.w);
        zb.y = Math.max(0, Math.min(100 - zb.h, cy - zb.h / 2));
        if (zb.y + zb.h > 100) zb.h = 100 - zb.y;
      }

      const box = document.createElement("div");
      box.className = "sls-zoom-box";
      box.style.left   = cut.zoomBox.x + "%";
      box.style.top    = cut.zoomBox.y + "%";
      box.style.width  = cut.zoomBox.w + "%";
      box.style.height = cut.zoomBox.h + "%";

      const label = document.createElement("span");
      label.className = "sls-zoom-box-label";
      label.textContent = anim === "zoomBlack" ? "place on the eye" : "zoom area";
      box.appendChild(label);

      for (const corner of ["tl", "tr", "bl", "br"]) {
        const handle = document.createElement("div");
        handle.className = "sls-zoom-handle";
        handle.dataset.corner = corner;
        box.appendChild(handle);
      }
      cell.appendChild(box);

      // clip-path: inset(0) guarantees visual clipping to the cell's border-box
      // for all children including absolutely-positioned ones — more reliable than
      // overflow:hidden alone on flex/grid items across browser versions.
      // Custom mode already has a polygon clip-path set by applyPolygonStyles;
      // don't override that here.
      if (this.#draft.mode !== "custom") {
        cell.style.clipPath = "inset(0)";
      }
    });
  }

  #wireZoomBoxHandlers(signal) {
    const anim = this.#draft.loginAnimation;
    if (anim !== "zoom" && anim !== "zoomBlack") return;
    const preview = this.element?.querySelector?.(".sls-live-preview");
    if (!preview) return;

    const MIN = 5;

    preview.querySelectorAll(".sls-live-cell").forEach(cell => {
      const idx = Number(cell.dataset.index);
      const cut = this.#draft.cuts[idx];
      const boxEl = cell.querySelector(".sls-zoom-box");
      if (!boxEl || !cut?.zoomBox) return;

      const syncBox = () => {
        const zb = cut.zoomBox;
        boxEl.style.left   = zb.x + "%";
        boxEl.style.top    = zb.y + "%";
        boxEl.style.width  = zb.w + "%";
        boxEl.style.height = zb.h + "%";
      };

      // Resize — 16:9 locked. Width drives size; height is always derived.
      // Cell rect captured once at mousedown so bounds stay stable.
      boxEl.querySelectorAll(".sls-zoom-handle").forEach(handle => {
        handle.addEventListener("mousedown", (e) => {
          if (e.button !== 0) return;
          e.preventDefault(); e.stopPropagation();
          const corner = handle.dataset.corner;
          const sx = e.clientX;
          const start = { ...cut.zoomBox };
          const cr = cell.getBoundingClientRect();
          const pctX = dx => cr.width > 0 ? dx / cr.width * 100 : 0;
          const hFromW = w => (cr.width > 0 && cr.height > 0)
            ? w * (9 * cr.width) / (16 * cr.height) : w * 9 / 16;
          const wFromH = h => (cr.width > 0 && cr.height > 0)
            ? h * (16 * cr.height) / (9 * cr.width) : h * 16 / 9;

          const onMove = (ev) => {
            const dx = pctX(ev.clientX - sx);
            const zb = cut.zoomBox;

            if (corner === "br") {
              // x, y fixed. Right + bottom edges move together.
              let nw = Math.max(MIN, Math.min(100 - start.x, start.w + dx));
              let nh = hFromW(nw);
              if (start.y + nh > 100) { nh = 100 - start.y; nw = Math.max(MIN, wFromH(nh)); }
              zb.w = nw; zb.h = nh;

            } else if (corner === "tl") {
              // Right + bottom edges fixed; x, y, w, h all move.
              const right = start.x + start.w, bottom = start.y + start.h;
              let nx = Math.max(0, Math.min(right - MIN, start.x + dx));
              let nw = right - nx;
              let nh = hFromW(nw);
              let ny = bottom - nh;
              if (ny < 0) { ny = 0; nh = bottom; nw = Math.max(MIN, wFromH(nh)); nx = Math.max(0, right - nw); }
              zb.x = nx; zb.w = nw; zb.y = ny; zb.h = nh;

            } else if (corner === "tr") {
              // x, bottom edge fixed; right + top edges move.
              const bottom = start.y + start.h;
              let nw = Math.max(MIN, Math.min(100 - start.x, start.w + dx));
              let nh = hFromW(nw);
              let ny = bottom - nh;
              if (ny < 0) { ny = 0; nh = bottom; nw = Math.max(MIN, Math.min(100 - start.x, wFromH(nh))); }
              zb.w = nw; zb.y = ny; zb.h = nh;

            } else { // bl
              // Right edge + y fixed; x, bottom, w, h move.
              const right = start.x + start.w;
              let nx = Math.max(0, Math.min(right - MIN, start.x + dx));
              let nw = right - nx;
              let nh = hFromW(nw);
              if (start.y + nh > 100) { nh = 100 - start.y; nw = Math.max(MIN, wFromH(nh)); nx = Math.max(0, right - nw); }
              zb.x = nx; zb.w = nw; zb.h = nh;
            }
            syncBox();
          };
          const onUp = () => { window.removeEventListener("mousemove", onMove); window.removeEventListener("mouseup", onUp); };
          window.addEventListener("mousemove", onMove, { signal });
          window.addEventListener("mouseup", onUp, { signal });
        }, { signal });
      });

      // Move — cell rect and starting size both captured once at mousedown.
      boxEl.addEventListener("mousedown", (e) => {
        if (e.button !== 0 || e.target.classList.contains("sls-zoom-handle")) return;
        e.preventDefault(); e.stopPropagation();
        const sx = e.clientX, sy = e.clientY;
        const sbx = cut.zoomBox.x, sby = cut.zoomBox.y;
        const sw  = cut.zoomBox.w, sh  = cut.zoomBox.h;
        const cr  = cell.getBoundingClientRect();
        const pctX = dx => cr.width  > 0 ? dx / cr.width  * 100 : 0;
        const pctY = dy => cr.height > 0 ? dy / cr.height * 100 : 0;
        const poly = (this.#draft.mode === "custom") ? cut.cell?.poly : null;

        const onMove = (ev) => {
          const zb = cut.zoomBox;
          zb.x = Math.max(0, Math.min(100 - sw, sbx + pctX(ev.clientX - sx)));
          zb.y = Math.max(0, Math.min(100 - sh, sby + pctY(ev.clientY - sy)));
          // In custom mode, keep the box centre inside the polygon — same
          // constraint the name labels use via clampLabelToPoly.
          if (poly) {
            const cx = zb.x + sw / 2;
            const cy = zb.y + sh / 2;
            const { labelX: ncx, labelY: ncy } = clampLabelToPoly(cx, cy, poly);
            zb.x = Math.max(0, Math.min(100 - sw, ncx - sw / 2));
            zb.y = Math.max(0, Math.min(100 - sh, ncy - sh / 2));
          }
          syncBox();
        };
        const onUp = () => { window.removeEventListener("mousemove", onMove); window.removeEventListener("mouseup", onUp); };
        window.addEventListener("mousemove", onMove, { signal });
        window.addEventListener("mouseup", onUp, { signal });
      }, { signal });
    });
  }

  // -------- rendering --------

  #updateLiveCell(idx) {
    updateLiveCell(this.element, this.#draft, idx);
  }

  #applyStyleVars() {
    applyStyleVars(this.element, this.#draft);
  }

  #updatePreviewFit() {
    updatePreviewFit(this.element, this.#draft);
  }

  #updateAllLiveCells() {
    this.#draft.cuts.forEach((_, i) => this.#updateLiveCell(i));
  }

  #applyCutStateToUI(idx) {
    const cut = this.#draft.cuts[idx];
    if (!cut) return;
    this.#updateLiveCell(idx);
    const fs = this.element?.querySelector?.(`.sls-cut-fieldset[data-index="${idx}"]`);
    if (!fs) return;
    for (const key of ["x", "y", "zoom"]) {
      const range = fs.querySelector(`input[type='range'][name="cuts.${idx}.${key}"]`);
      if (range) range.value = Math.round(cut[key]);
      const valEl = fs.querySelector(`.sls-range-val[data-val="${key}"]`);
      if (valEl) valEl.textContent = `${Math.round(cut[key])}%`;
    }
  }

  #updateRowName(idx) {
    const cut = this.#draft.cuts[idx];
    const nameEl = this.element?.querySelector?.(`.sls-cut-row[data-index="${idx}"] .sls-cut-name`);
    if (!nameEl || !cut) return;
    nameEl.textContent = "";
    if (cut.userId) {
      const user = game.users.get(cut.userId);
      nameEl.textContent = user?.name || "(unknown user)";
    } else {
      const em = document.createElement("em");
      em.textContent = game.i18n.localize("SLS.Unassigned");
      nameEl.appendChild(em);
    }
  }

  #setSelected(idx) {
    if (idx < 0 || idx >= this.#draft.cuts.length) return;
    this.#selectedIdx = idx;
    this.#reflectSelection();
  }

  #reflectSelection() {
    const root = this.element;
    if (!root) return;
    root.querySelectorAll(".sls-cut-row").forEach(el => {
      el.classList.toggle("selected", Number(el.dataset.index) === this.#selectedIdx);
    });
    root.querySelectorAll(".sls-cut-fieldset").forEach(el => {
      el.classList.toggle("active", Number(el.dataset.index) === this.#selectedIdx);
    });
    root.querySelectorAll(".sls-live-cell").forEach(el => {
      el.classList.toggle("selected", Number(el.dataset.index) === this.#selectedIdx);
    });
    root.querySelectorAll(".sls-outline-svg polygon").forEach(el => {
      el.classList.toggle("selected", Number(el.dataset.index) === this.#selectedIdx);
    });
  }

  // Tags the preview with `sls-line-style-<name>` so CSS rules hook in, and
  // rebuilds the brush-line overlay for styles that need per-line SVG placement.
  #applyGridLineOverlay() {
    const preview = this.element?.querySelector?.(".sls-live-preview");
    if (!preview) return;
    for (const cls of Array.from(preview.classList)) {
      if (cls.startsWith("sls-line-style-")) preview.classList.remove(cls);
    }
    const style = this.#draft.lineStyle || "solid";
    preview.classList.add(`sls-line-style-${style}`);
    this.#applyBrushLines();
  }

  #applyBrushLines() {
    const preview = this.element?.querySelector?.(".sls-live-preview");
    if (!preview) return;
    renderBrushLines(preview, this.#draft);
  }

  #applyPolygonStyles() {
    applyPolygonStyles(this.element, this.#draft);
  }

  // Background mode: drag to move a box, drag its corner handle to resize.
  // Box coordinates are percentages of the preview rect.
  #wireBackgroundBoxHandlers(signal) {
    if (this.#draft.mode !== "background") return;
    const preview = this.element?.querySelector?.(".sls-live-preview");
    if (!preview) return;

    const pctDelta = (dx, dy) => {
      const r = preview.getBoundingClientRect();
      return {
        x: r.width > 0 ? (dx / r.width) * 100 : 0,
        y: r.height > 0 ? (dy / r.height) * 100 : 0
      };
    };

    preview.querySelectorAll(".sls-live-cell").forEach(cell => {
      const idx = Number(cell.dataset.index);
      const cut = this.#draft.cuts[idx];
      if (!cut?.box) return;

      // Inject a resize handle in the bottom-right corner if not present.
      if (!cell.querySelector(".sls-bg-handle")) {
        const h = document.createElement("div");
        h.className = "sls-bg-handle";
        cell.appendChild(h);
      }

      const handle = cell.querySelector(".sls-bg-handle");

      // Resize: starts on the handle, swallows the event so the move handler
      // on the cell body doesn't kick in.
      handle.addEventListener("mousedown", (e) => {
        if (e.button !== 0) return;
        e.preventDefault();
        e.stopPropagation();
        this.#setSelected(idx);
        const startX = e.clientX, startY = e.clientY;
        const startW = cut.box.w, startH = cut.box.h;
        cell.classList.add("sls-bg-resizing");

        const onMove = (ev) => {
          const d = pctDelta(ev.clientX - startX, ev.clientY - startY);
          cut.box.w = Math.max(3, Math.min(100 - cut.box.x, startW + d.x));
          cut.box.h = Math.max(3, Math.min(100 - cut.box.y, startH + d.y));
          cell.style.width = cut.box.w + "%";
          cell.style.height = cut.box.h + "%";
        };
        const onUp = () => {
          cell.classList.remove("sls-bg-resizing");
          window.removeEventListener("mousemove", onMove);
          window.removeEventListener("mouseup", onUp);
        };
        window.addEventListener("mousemove", onMove, { signal });
        window.addEventListener("mouseup", onUp, { signal });
      }, { signal });

      // Move: drag anywhere inside the box (but not on the handle).
      cell.addEventListener("mousedown", (e) => {
        if (e.button !== 0) return;
        if (e.target.classList.contains("sls-bg-handle")) return;
        e.preventDefault();
        this.#setSelected(idx);
        const startX = e.clientX, startY = e.clientY;
        const startBX = cut.box.x, startBY = cut.box.y;
        cell.classList.add("sls-bg-moving");

        const onMove = (ev) => {
          const d = pctDelta(ev.clientX - startX, ev.clientY - startY);
          cut.box.x = Math.max(0, Math.min(100 - cut.box.w, startBX + d.x));
          cut.box.y = Math.max(0, Math.min(100 - cut.box.h, startBY + d.y));
          cell.style.left = cut.box.x + "%";
          cell.style.top = cut.box.y + "%";
        };
        const onUp = () => {
          cell.classList.remove("sls-bg-moving");
          window.removeEventListener("mousemove", onMove);
          window.removeEventListener("mouseup", onUp);
        };
        window.addEventListener("mousemove", onMove, { signal });
        window.addEventListener("mouseup", onUp, { signal });
      }, { signal });
    });
  }

  // Multi-segment polyline drawing. Starts on mousedown inside a cell, auto-
  // snaps the first vertex to the nearest edge of that cell. After that, every
  // mouseup either CLOSES the path (if the cursor is within SNAP_THRESHOLD of
  // a different edge of the same cell) or DROPS a vertex in free space and
  // keeps drawing — with the live-preview tail following the cursor even
  // while the mouse button isn't held.
  //
  // Right-click or Escape cancels the in-progress path.
  #wireDrawingHandlers(signal) {
    if (!this.#editMode) return;
    const preview = this.element?.querySelector?.(".sls-live-preview");
    const svg = preview?.querySelector(".sls-edit-svg");
    const ghost = svg?.querySelector(".sls-ghost-line");
    if (!preview || !svg || !ghost) return;

    const SVG_NS = "http://www.w3.org/2000/svg";
    const SNAP_THRESHOLD = 1.5; // % of the 0-100 viewBox — roughly 4-6 px on a typical preview.

    const pctFromEvent = (e) => {
      const r = preview.getBoundingClientRect();
      return {
        x: Math.max(0, Math.min(100, ((e.clientX - r.left) / r.width) * 100)),
        y: Math.max(0, Math.min(100, ((e.clientY - r.top) / r.height) * 100))
      };
    };

    // All state for an in-progress draw. null when idle.
    let draw = null;
    // draw = {
    //   faceIdx, poly,           // the cell being cut
    //   startEdge,               // edge index of the first vertex (on the polygon)
    //   path: [[x, y], ...],     // committed vertices, path[0] on startEdge
    //   cursor: { x, y },        // current mouse position (for the trailing ghost)
    //   pendingFaceLock          // true when the start hit a shared edge and we
    //                            // still need to disambiguate which cell the
    //                            // GM is drawing into (probe on first drag).
    // }

    // Container for in-progress draw (committed segments + vertex dots). Created
    // lazily so we can wipe and rebuild it cheaply on every frame.
    let group = svg.querySelector(".sls-draw-path");
    if (!group) {
      group = document.createElementNS(SVG_NS, "g");
      group.setAttribute("class", "sls-draw-path");
      svg.appendChild(group);
    }

    const clearPreview = () => {
      while (group.firstChild) group.removeChild(group.firstChild);
      ghost.style.display = "none";
    };

    const renderPreview = () => {
      while (group.firstChild) group.removeChild(group.firstChild);
      if (!draw) { ghost.style.display = "none"; return; }

      // Solid segments between committed vertices.
      for (let i = 0; i < draw.path.length - 1; i++) {
        const ln = document.createElementNS(SVG_NS, "line");
        ln.setAttribute("class", "sls-draw-seg");
        ln.setAttribute("x1", draw.path[i][0]);
        ln.setAttribute("y1", draw.path[i][1]);
        ln.setAttribute("x2", draw.path[i + 1][0]);
        ln.setAttribute("y2", draw.path[i + 1][1]);
        group.appendChild(ln);
      }
      // Dot at each committed vertex.
      for (const [vx, vy] of draw.path) {
        const c = document.createElementNS(SVG_NS, "circle");
        c.setAttribute("class", "sls-draw-vertex");
        c.setAttribute("cx", vx);
        c.setAttribute("cy", vy);
        c.setAttribute("r", 0.6);
        group.appendChild(c);
      }

      // Ghost tail from last committed vertex to cursor.
      const last = draw.path[draw.path.length - 1];
      ghost.setAttribute("x1", last[0]);
      ghost.setAttribute("y1", last[1]);
      ghost.setAttribute("x2", draw.cursor.x);
      ghost.setAttribute("y2", draw.cursor.y);
      ghost.style.display = "block";
    };

    const cancel = () => { draw = null; clearPreview(); };

    // Starts a fresh draw. Requires the mousedown to land inside some cell AND
    // for the nearest polygon edge to be within 2× the snap threshold — that
    // way a click well inside free space doesn't accidentally start a draw.
    const start = (p) => {
      const faceIdx = findFaceForPoint(this.#draft.cuts, p);
      if (faceIdx < 0) return false;
      const poly = this.#draft.cuts[faceIdx].cell?.poly;
      if (!poly) return false;
      const snap = snapToPolyEdge(p, poly);
      if (!snap || snap.dist > SNAP_THRESHOLD * 2) return false;
      draw = {
        faceIdx, poly,
        startEdge: snap.edgeIndex,
        path: [[snap.pt[0], snap.pt[1]]],
        cursor: { x: p.x, y: p.y },
        pendingFaceLock: snap.dist < 0.3
      };
      renderPreview();
      return true;
    };

    // When the mousedown lands exactly on a line shared between two cells,
    // findFaceForPoint picks one arbitrarily. Once the GM has pulled the
    // cursor far enough from the start to have a direction, re-probe a short
    // way along that direction and re-pick the face if the probe lands in a
    // different cell. Runs only once per draw.
    const maybeLockFace = (cursor) => {
      if (!draw || !draw.pendingFaceLock) return;
      const start = draw.path[0];
      const dx = cursor.x - start[0];
      const dy = cursor.y - start[1];
      const d  = Math.hypot(dx, dy);
      if (d < 0.8) return; // not enough direction yet
      const probe = { x: start[0] + dx / d * 0.5, y: start[1] + dy / d * 0.5 };
      const newFaceIdx = findFaceForPoint(this.#draft.cuts, probe);
      if (newFaceIdx >= 0 && newFaceIdx !== draw.faceIdx) {
        const newPoly = this.#draft.cuts[newFaceIdx].cell?.poly;
        const newSnap = newPoly && snapToPolyEdge({ x: start[0], y: start[1] }, newPoly);
        if (newSnap) {
          draw.faceIdx   = newFaceIdx;
          draw.poly      = newPoly;
          draw.startEdge = newSnap.edgeIndex;
          draw.path[0]   = [newSnap.pt[0], newSnap.pt[1]];
        }
      }
      draw.pendingFaceLock = false;
    };

    // On a release, either close the path (if near an edge) or drop a new
    // vertex in free space.
    const releaseAt = (p) => {
      if (!draw) return;
      maybeLockFace(p);
      const snap = snapToPolyEdge(p, draw.poly);

      // Can we close? Different edge always works. Same edge needs at least
      // one interior vertex and enough distance from the start point so the
      // carved region isn't degenerate.
      let canClose = false;
      if (snap && snap.dist < SNAP_THRESHOLD) {
        if (snap.edgeIndex !== draw.startEdge) {
          canClose = true;
        } else if (draw.path.length >= 2) {
          const start = draw.path[0];
          canClose = Math.hypot(snap.pt[0] - start[0], snap.pt[1] - start[1]) >= 3;
        }
      }

      if (canClose) {
        const path = [...draw.path, [snap.pt[0], snap.pt[1]]];
        // Reject a close that sits right on top of the most recent vertex.
        const last = draw.path[draw.path.length - 1];
        if (Math.hypot(snap.pt[0] - last[0], snap.pt[1] - last[1]) < 0.5) return;
        const faceIdx = draw.faceIdx, startEdge = draw.startEdge, endEdge = snap.edgeIndex;
        draw = null;
        clearPreview();
        this.#commitDrawnPolyline(faceIdx, path, startEdge, endEdge);
        return;
      }
      // Drop a vertex — but only if it sits inside the starting polygon. This
      // prevents the path from wandering out of the cell it's cutting.
      if (!pointInPoly(p, draw.poly)) return;
      // And skip drops that coincide with the previous vertex (noise-guard).
      const last = draw.path[draw.path.length - 1];
      if (Math.hypot(p.x - last[0], p.y - last[1]) < 0.5) return;
      draw.path.push([p.x, p.y]);
      renderPreview();
    };

    // --- listeners ---

    preview.addEventListener("mousedown", (e) => {
      if (!this.#editMode) return;
      if (e.target.closest(".sls-edit-bar")) return;
      if (e.button === 2 && draw) { e.preventDefault(); cancel(); return; }
      if (e.button !== 0) return;
      e.preventDefault();
      const p = pctFromEvent(e);
      if (!draw) {
        // Fresh draw: snap the first vertex to the edge under the cursor.
        if (!start(p)) return;
      } else {
        // Already drawing — mousedown is just "mouse is now held"; wait for
        // mouseup to decide what to do with the cursor position.
        draw.cursor = p;
        renderPreview();
      }
    }, { signal });

    // While drawing (dragging OR extending), track the cursor globally so the
    // ghost tail stays glued to the mouse even when moving off the preview.
    window.addEventListener("mousemove", (e) => {
      if (!draw) return;
      draw.cursor = pctFromEvent(e);
      maybeLockFace(draw.cursor);
      renderPreview();
    }, { signal });

    window.addEventListener("mouseup", (e) => {
      if (!draw) return;
      if (e.button !== 0) return;
      releaseAt(pctFromEvent(e));
    }, { signal });

    // Right-click cancels without dropping a final vertex.
    preview.addEventListener("contextmenu", (e) => {
      if (!draw) return;
      e.preventDefault();
      cancel();
    }, { signal });

    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && draw) cancel();
    }, { signal });
  }

  _onRender(context, options) {
    super._onRender?.(context, options);

    this.#listeners?.abort();
    this.#listeners = new AbortController();
    const signal = this.#listeners.signal;

    // Load any user-added fonts so the preview and dropdowns render them.
    LoginConfig.#loadCustomFonts();

    // Match the preview grid's aspect ratio to the real login viewport so the
    // same X/Y/zoom values produce the same crop the players will see.
    this.#updatePreviewFit();
    this.#applyStyleVars();
    // First pass runs before layout settles; re-apply once the preview has
    // its real width so the scaled thickness is correct.
    requestAnimationFrame(() => this.#applyStyleVars());

    this.#resizeObs?.disconnect();
    const preview = this.element?.querySelector?.(".sls-live-preview");
    if (preview && typeof ResizeObserver !== "undefined") {
      this.#resizeObs = new ResizeObserver(() => {
        this.#applyStyleVars();
        this.#applyBrushLines();
      });
      this.#resizeObs.observe(preview);
    }

    this.#applyPolygonStyles();
    this.#applyGridLineOverlay();
    // Font <select>s can't be pre-selected in the template because each
    // option carries an inline font-family; sync them here from draft state.
    this.element.querySelectorAll(".sls-cut-fieldset").forEach(fs => {
      const i = Number(fs.dataset.index);
      const sel = fs.querySelector("select.sls-font-select");
      const font = this.#draft.cuts[i]?.nameStyle?.font || "";
      if (sel) sel.value = font;
    });
    const entryFontSel = this.element.querySelector("select.sls-entry-font-select");
    if (entryFontSel) entryFontSel.value = this.#draft.entryFont || "";
    this.#updateAllLiveCells();
    this.#reflectSelection();
    this.#wireDrawingHandlers(signal);
    this.#wireBackgroundBoxHandlers(signal);
    this.#applyZoomBoxes();
    this.#wireZoomBoxHandlers(signal);

    // Name background mode: image-only controls ("Use only bg image" + bg size
    // slider) are only relevant when bg === "image". Hide them otherwise, and
    // toggle in real time when the select changes.
    this.element.querySelectorAll(".sls-cut-fieldset").forEach(fs => {
      const bgSel = fs.querySelector("select[name$='.nameStyle.bg']");
      if (!bgSel) return;
      const syncImgOnly = () => {
        const show = bgSel.value === "image";
        fs.querySelectorAll(".sls-name-bg-image-only").forEach(el => { el.hidden = !show; });
      };
      syncImgOnly();
      bgSel.addEventListener("change", syncImgOnly, { signal });
    });

    // Same image-only toggle logic for the entry-text panel's bg select.
    const entryBgSel = this.element.querySelector("select.sls-entry-text-bg-select");
    if (entryBgSel) {
      const syncEntryImgOnly = () => {
        const show = entryBgSel.value === "image";
        this.element.querySelectorAll(".sls-entry-text-image-only").forEach(el => { el.hidden = !show; });
      };
      syncEntryImgOnly();
      entryBgSel.addEventListener("change", syncEntryImgOnly, { signal });
    }

    // Sliders in the entry-text panel need their % label kept in sync as the
    // user drags, and should update the live entry preview.
    this.element.querySelectorAll(".sls-entry-text-panel input[type='range']").forEach(range => {
      const valEl = range.parentElement.querySelector(".sls-range-val");
      range.addEventListener("input", () => {
        this.#syncDraftFromDom();
        if (valEl) valEl.textContent = `${Math.round(Number(range.value))}%`;
        this.#updateEntryPreview();
      }, { signal });
    });

    // Text inputs, color pickers, checkboxes, and selects in the entry panel
    // should also update the preview in real time.
    const entryPanel = this.element.querySelector(".sls-entry-text-panel");
    if (entryPanel) {
      entryPanel.querySelectorAll("input[type='text'], input[type='color'], select").forEach(inp => {
        const handler = () => { this.#syncDraftFromDom(); this.#updateEntryPreview(); };
        inp.addEventListener("input", handler, { signal });
        inp.addEventListener("change", handler, { signal });
      });
      entryPanel.querySelectorAll("input[type='checkbox']").forEach(cb => {
        cb.addEventListener("change", () => {
          this.#syncDraftFromDom();
          this.#updateEntryPreview();
        }, { signal });
      });
    }

    // Sliders → live cell + value label.
    this.element.querySelectorAll(".sls-cut-fieldset").forEach(fs => {
      const idx = Number(fs.dataset.index);
      fs.querySelectorAll("input[type='range']").forEach(range => {
        const valEl = range.parentElement.querySelector(".sls-range-val");
        range.addEventListener("input", () => {
          this.#syncDraftFromDom();
          // If sync clamped the label, reflect the clamped value in the slider.
          const key = range.name.split(".").pop();
          const cut = this.#draft.cuts[idx];
          if (cut && (key === "labelX" || key === "labelY")) {
            range.value = Math.round(cut[key]);
          }
          if (valEl) valEl.textContent = `${Math.round(Number(range.value))}%`;
          this.#updateLiveCell(idx);
        }, { signal });
      });

      // Per-cut checkboxes + color input (label visibility, hover override).
      fs.querySelectorAll("input[type='checkbox'], input[type='color']").forEach(inp => {
        inp.addEventListener("input", () => {
          this.#syncDraftFromDom();
          this.#updateLiveCell(idx);
        }, { signal });
        inp.addEventListener("change", () => {
          this.#syncDraftFromDom();
          this.#updateLiveCell(idx);
        }, { signal });
      });

      // User select and image path updates.
      fs.querySelectorAll("select, input[type='text']").forEach(inp => {
        const handler = () => {
          this.#syncDraftFromDom();
          this.#updateLiveCell(idx);
          this.#updateRowName(idx);
        };
        inp.addEventListener("input", handler, { signal });
        inp.addEventListener("change", handler, { signal });
      });
    });

    // Custom mode: hovering a cell lights up its polygon outline.
    // Query the polygon fresh each time so rebuilt outline SVGs still work.
    this.element.querySelectorAll(".sls-live-cell").forEach(cell => {
      const idx = cell.dataset.index;
      cell.addEventListener("mouseenter", () => {
        this.element.querySelector(`.sls-outline-svg polygon[data-index="${idx}"]`)?.classList.add("hover");
      }, { signal });
      cell.addEventListener("mouseleave", () => {
        this.element.querySelector(`.sls-outline-svg polygon[data-index="${idx}"]`)?.classList.remove("hover");
      }, { signal });
    });

    // Live preview: mouse drag pans the image, wheel zooms it.
    this.element.querySelectorAll(".sls-live-cell").forEach(cell => {
      const idx = Number(cell.dataset.index);

      cell.addEventListener("mousedown", (e) => {
        if (e.button !== 0) return;
        if (this.#editMode) return; // preview-level handler takes over
        if (this.#draft.mode === "background") return; // bg box drag handler owns this
        const cut = this.#draft.cuts[idx];
        this.#setSelected(idx);
        if (!cut?.image) return;
        e.preventDefault();

        const rect = cell.getBoundingClientRect();
        const startX = e.clientX;
        const startY = e.clientY;
        const startXPct = num(cut.x, 50);
        const startYPct = num(cut.y, 50);
        cell.classList.add("sls-dragging");

        const onMove = (ev) => {
          const scale = num(cut.zoom, 100) / 100;
          if (scale < 1) {
            // Sub-100%: image is shrunk, drag moves it around the cell.
            const panW = Math.max(20, rect.width * (1 - scale));
            const panH = Math.max(20, rect.height * (1 - scale));
            const dxPct = (ev.clientX - startX) * 100 / panW;
            const dyPct = (ev.clientY - startY) * 100 / panH;
            cut.x = Math.max(0, Math.min(100, startXPct + dxPct));
            cut.y = Math.max(0, Math.min(100, startYPct + dyPct));
          } else {
            // Cover mode: drag pans the crop window.
            const panW = Math.max(20, rect.width * Math.max(0.1, scale - 1));
            const panH = Math.max(20, rect.height * Math.max(0.1, scale - 1));
            const dxPct = (ev.clientX - startX) * 100 / panW;
            const dyPct = (ev.clientY - startY) * 100 / panH;
            cut.x = Math.max(0, Math.min(100, startXPct - dxPct));
            cut.y = Math.max(0, Math.min(100, startYPct - dyPct));
          }
          this.#applyCutStateToUI(idx);
        };

        const onUp = () => {
          cell.classList.remove("sls-dragging");
          window.removeEventListener("mousemove", onMove);
          window.removeEventListener("mouseup", onUp);
        };

        window.addEventListener("mousemove", onMove, { signal });
        window.addEventListener("mouseup", onUp, { signal });
      }, { signal });

      cell.addEventListener("wheel", (e) => {
        if (this.#editMode) return;
        const cut = this.#draft.cuts[idx];
        if (!cut?.image) return;
        e.preventDefault();
        this.#setSelected(idx);
        const step = e.shiftKey ? 25 : 10;
        const current = num(cut.zoom, 100);
        const next = current + (-Math.sign(e.deltaY) * step);
        cut.zoom = Math.max(40, Math.min(400, next));
        this.#applyCutStateToUI(idx);
      }, { signal, passive: false });
    });

    // Click a cut row to select it (but not when clicking a button inside).
    this.element.querySelectorAll(".sls-cut-row").forEach(row => {
      row.addEventListener("click", (e) => {
        if (e.target.closest("button")) return;
        this.#setSelected(Number(row.dataset.index));
      }, { signal });
    });

    // Cols/rows live-update the grid template on the preview.
    const liveGrid = this.element.querySelector(".sls-live-preview");
    const colsInp = this.element.querySelector("input[name='cols']");
    const rowsInp = this.element.querySelector("input[name='rows']");
    const updateGrid = () => {
      const c = Math.max(1, Number(colsInp?.value) || 1);
      const r = Math.max(1, Number(rowsInp?.value) || 1);
      if (liveGrid) {
        liveGrid.style.gridTemplateColumns = `repeat(${c}, 1fr)`;
        liveGrid.style.gridTemplateRows = `repeat(${r}, 1fr)`;
      }
      this.#syncDraftFromDom();
      // In grid mode the cut count is purely cols × rows — auto-resize so the
      // user doesn't have to click an add button for every slot.
      if (this.#draft.mode !== "custom" && this.#draft.mode !== "background") {
        const target = c * r;
        const cuts = this.#draft.cuts;
        while (cuts.length < target) {
          cuts.push({ userId: null, image: "", x: 50, y: 50, zoom: 100, labelShow: true, labelX: 50, labelY: 88 });
        }
        if (cuts.length > target) cuts.length = target;
        this.render();
        return;
      }
      this.#applyGridLineOverlay();
    };
    colsInp?.addEventListener("input", updateGrid, { signal });
    rowsInp?.addEventListener("input", updateGrid, { signal });

    const fitSel = this.element.querySelector("select[name='fit']");
    fitSel?.addEventListener("change", () => {
      this.#syncDraftFromDom();
      this.#updatePreviewFit();
      this.#updateAllLiveCells();
    }, { signal });

    this.element.querySelector(".sls-mode-select")?.addEventListener("change", (e) => {
      const mode = e.target.value;
      if (mode === this.#draft.mode) return;
      if (mode === "custom") LoginConfig.#onEditLayout.call(this);
      else if (mode === "background") LoginConfig.#onBackgroundLayout.call(this);
      else LoginConfig.#onRevertGrid.call(this);
    }, { signal });

    const bgInp = this.element.querySelector("input[name='bgImage']");
    bgInp?.addEventListener("change", () => {
      this.#syncDraftFromDom();
      this.#applyPolygonStyles();
    }, { signal });

    // Live update the styling vars as the GM tweaks them.
    ["lineColor", "lineThick", "hoverColor", "hoverZoom"].forEach(name => {
      const inp = this.element.querySelector(`input[name='${name}']`);
      inp?.addEventListener("input", () => {
        this.#syncDraftFromDom();
        this.#applyStyleVars();
      }, { signal });
    });

    const lineStyleSel = this.element.querySelector("select[name='lineStyle']");
    lineStyleSel?.addEventListener("change", () => {
      this.#syncDraftFromDom();
      this.#applyGridLineOverlay();
    }, { signal });

    // Re-render when animation switches to/from zoom so boxes appear/disappear.
    const loginAnimSel = this.element.querySelector("select[name='loginAnimation']");
    loginAnimSel?.addEventListener("change", () => {
      this.#syncDraftFromDom();
      this.render();
    }, { signal });

    const presetSel = this.element.querySelector(".sls-preset-select");
    presetSel?.addEventListener("change", () => {
      this.#presetSlot = Number(presetSel.value);
      const raw = game.settings.get(MODULE_ID, PRESETS_KEY) ?? [];
      const nameInput = this.element.querySelector(".sls-preset-name");
      if (nameInput) nameInput.value = raw[this.#presetSlot]?.name ?? "";
    }, { signal });

    // Community view: inject cards since the template just has an empty container.
    if (this.#rightView === "community") {
      this.#populatePlayerFilter(this.#communityIndex ?? []);
      this.#renderCommunityCards(this.#communityIndex);
    }

    // Community filter dropdowns (always in DOM).
    const filterMode = this.element.querySelector(".sls-filter-mode");
    const filterPlayers = this.element.querySelector(".sls-filter-players");
    const onFilter = () => {
      this.#communityFilterMode = filterMode?.value || "";
      this.#communityFilterPlayers = filterPlayers?.value || "";
      this.#renderCommunityCards(this.#communityIndex);
    };
    filterMode?.addEventListener("change", onFilter, { signal });
    filterPlayers?.addEventListener("change", onFilter, { signal });

    this.element.querySelector("input[name='showLogo']")?.addEventListener("change", () => {
      this.#syncDraftFromDom();
      this.#applyPolygonStyles();
    }, { signal });

    // Hint icon tooltips — positioned via fixed coords to escape overflow clipping.
    this.element.querySelectorAll(".sls-hint-icon").forEach(icon => {
      const bubble = icon.querySelector(".sls-hint-bubble");
      if (!bubble) return;
      icon.addEventListener("mouseenter", () => {
        const r = icon.getBoundingClientRect();
        bubble.style.top = (r.bottom + 6) + "px";
        bubble.style.left = Math.max(8, r.left) + "px";
        bubble.classList.add("sls-hint-visible");
      }, { signal });
      icon.addEventListener("mouseleave", () => {
        bubble.classList.remove("sls-hint-visible");
      }, { signal });
    });

    // Entry screen dependency: forced on when audio would play without a gesture.
    const muteCb = this.element.querySelector("input[name='muteBackground']");
    const musicInp = this.element.querySelector("input[name='music']");
    muteCb?.addEventListener("change", () => {
      this.#syncDraftFromDom();
      this.#syncEntryState();
    }, { signal });
    musicInp?.addEventListener("input", () => this.#syncEntryState(), { signal });
    const volRange = this.element.querySelector("input[name='musicVolume']");
    const volVal = this.element.querySelector(".sls-range-val[data-val='musicVolume']");
    volRange?.addEventListener("input", () => {
      if (volVal) volVal.textContent = `${volRange.value}%`;
    }, { signal });
    const esvRange = this.element.querySelector("input[name='entrySoundVolume']");
    const esvVal = this.element.querySelector(".sls-range-val[data-val='entrySoundVolume']");
    esvRange?.addEventListener("input", () => {
      if (esvVal) esvVal.textContent = `${esvRange.value}%`;
    }, { signal });

    // After a full render, make sure the entry preview matches the view.
    // If we're on the entry editor panel, show the preview; otherwise hide it.
    const entryPrev = this.element.querySelector(".sls-entry-preview");
    const liveP = this.element.querySelector(".sls-live-preview");
    if (this.#rightView === "entryText") {
      if (entryPrev) entryPrev.hidden = false;
      if (liveP) liveP.hidden = true;
      this.#updateEntryPreview();
    } else {
      if (entryPrev) entryPrev.hidden = true;
      if (liveP) liveP.hidden = false;
    }

    this.#syncEntryState();

    // Toggling the entry checkbox shows/hides its sub-controls inline.
    const entryCb = this.element.querySelector("input[name='entryScreen']");
    entryCb?.addEventListener("change", () => {
      this.#syncDraftFromDom();
      const sub = this.element.querySelector(".sls-entry-sub");
      if (sub) sub.hidden = !entryCb.checked;
    }, { signal });
  }

  _onClose(options) {
    this.#listeners?.abort();
    this.#listeners = null;
    this.#resizeObs?.disconnect();
    this.#resizeObs = null;
    return super._onClose?.(options);
  }
}
