// Brush-style line rendering for custom mode. Builds one pixel-space <svg>
// per sub-segment of each committed line, rotated to sit along it, so hover
// highlighting can target the exact cells each sub-segment borders.

import { num } from "./util.js";
import { brushInfoFor } from "./brush-assets.js";
import { pointInPoly, segIntersectT } from "./geometry.js";

// Renders the "brush" line style: for each committed line in custom mode,
// builds a pixel-space <svg> overlay containing the brush paths, rotated
// and scaled to sit along the line. Uses HTML positioning instead of SVG
// viewBox transforms so angles stay correct despite the stretched 0-100
// preview viewBox.
export function renderBrushLines(preview, draft) {
  if (!preview) return;

  let layer = preview.querySelector(".sls-brush-layer");
  const style = draft.lineStyle;
  const isBrush = style === "brush" || style === "brushCrossed"
    || style === "brush2" || style === "brush2Crossed"
    || style === "thorns" || style === "torn";
  const crossed = style === "brushCrossed" || style === "brush2Crossed";
  const brushInfo = brushInfoFor(style);
  const wantBrush = isBrush
    && draft.mode === "custom"
    && Array.isArray(draft.lines)
    && draft.lines.length > 0
    && brushInfo && brushInfo.html;

  if (!wantBrush) {
    layer?.remove();
    return;
  }
  if (!layer) {
    layer = document.createElement("div");
    layer.className = "sls-brush-layer";
    preview.appendChild(layer);
  }
  layer.innerHTML = "";

  const rect = preview.getBoundingClientRect();
  const W = rect.width, H = rect.height;
  if (W < 2 || H < 2) return;

  // lineThick is stored in REAL screen pixels (what the player sees on the
  // full login page). The preview is a fraction of the window, so every
  // pixel-based line metric has to be scaled by (previewWidth / windowWidth)
  // — the same correction applyStyleVars applies to regular lines. Without
  // this the brush looks chunky in the preview but thin on the login page.
  const winW = window.innerWidth || 1;
  const scale = W / winW;
  const thick = num(draft.lineThick, 4) * 5 * scale;
  const color = draft.lineColor || "#000";

  // "brushCrossed" style: same sub-segment splitting as plain brush so
  // hover is per-cell, but the first and last sub-segments of each
  // drawn line extend OVERSHOOT units past the stored endpoints along
  // the line's own direction. That overshoot crosses visually past any
  // other line that happens to touch at those endpoints, producing the
  // "lines cross each other" look without the whole-line hover glow.
  if (crossed) {
    const OVERSHOOT = style === "brush2Crossed" ? 8 : 12;
    const linesC = draft.lines;
    const cutsC = draft.cuts;
    linesC.forEach((ln, lnIdx) => {
      const Lx1 = num(ln.x1, 0), Ly1 = num(ln.y1, 0);
      const Lx2 = num(ln.x2, 0), Ly2 = num(ln.y2, 0);
      const vx = Lx2 - Lx1, vy = Ly2 - Ly1;
      const vLen = Math.hypot(vx, vy);
      if (vLen < 0.5) return;
      const ux = vx / vLen, uy = vy / vLen;

      const ts = [0, 1];
      for (let j = 0; j < linesC.length; j++) {
        if (j === lnIdx) continue;
        const hit = segIntersectT(ln, linesC[j]);
        if (hit != null) ts.push(hit);
      }
      ts.sort((a, b) => a - b);

      const nx = -vy / vLen, ny = vx / vLen;
      const probeEps = 0.3;

      for (let k = 0; k < ts.length - 1; k++) {
        const t0 = ts[k], t1 = ts[k + 1];
        if (t1 - t0 < 1e-4) continue;
        const mt = (t0 + t1) / 2;
        const mx = Lx1 + mt * vx;
        const my = Ly1 + mt * vy;
        const probes = [
          { x: mx + nx * probeEps, y: my + ny * probeEps },
          { x: mx - nx * probeEps, y: my - ny * probeEps }
        ];
        const cells = new Set();
        for (const p of probes) {
          for (let ci = 0; ci < cutsC.length; ci++) {
            const poly = cutsC[ci]?.cell?.poly;
            if (poly && pointInPoly(p, poly)) { cells.add(ci); break; }
          }
        }
        if (!cells.size) continue;

        // Sub-segment endpoints, then overshoot on the outer ends.
        let sx = Lx1 + t0 * vx, sy = Ly1 + t0 * vy;
        let ex = Lx1 + t1 * vx, ey = Ly1 + t1 * vy;
        if (k === 0) { sx -= ux * OVERSHOOT; sy -= uy * OVERSHOOT; }
        if (k === ts.length - 2) { ex += ux * OVERSHOOT; ey += uy * OVERSHOOT; }

        const x1 = (sx / 100) * W;
        const y1 = (sy / 100) * H;
        const x2 = (ex / 100) * W;
        const y2 = (ey / 100) * H;
        const dx = x2 - x1, dy = y2 - y1;
        const len = Math.hypot(dx, dy);
        if (len < 1) continue;
        const angle = Math.atan2(dy, dx) * 180 / Math.PI;

        const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        svg.setAttribute("viewBox", brushInfo.viewBox);
        svg.setAttribute("preserveAspectRatio", "none");
        svg.classList.add("sls-brush-line");
        svg.dataset.cells = Array.from(cells).join(" ");
        svg.style.left = `${x1}px`;
        svg.style.top = `${y1 - thick / 2}px`;
        svg.style.width = `${len}px`;
        svg.style.height = `${thick}px`;
        svg.style.transform = `rotate(${angle}deg)`;
        svg.style.setProperty("--sls-brush-fill", color);
        svg.innerHTML = brushInfo.html;
        layer.appendChild(svg);
      }
    });

    wireBrushHover(preview, layer);
    return;
  }

  // "brush" style: split each committed line at its intersections with
  // other committed lines, then for every sub-segment ask point-in-poly
  // which cells sit on either side (probing a hair off the midpoint in
  // each perpendicular direction). Each sub-segment becomes one brush
  // tagged with exactly the cells it actually borders — this is the only
  // way to get correct partial-glow hover when a single drawn line runs
  // along the boundary of multiple cells, since adjacent cells' polygons
  // don't always share matching vertex pairs along the line.
  const lines = draft.lines;
  const cuts = draft.cuts;
  lines.forEach((ln, lnIdx) => {
    const Lx1 = num(ln.x1, 0), Ly1 = num(ln.y1, 0);
    const Lx2 = num(ln.x2, 0), Ly2 = num(ln.y2, 0);
    const vx = Lx2 - Lx1, vy = Ly2 - Ly1;
    const vLen = Math.hypot(vx, vy);
    if (vLen < 0.5) return;

    const ts = [0, 1];
    for (let j = 0; j < lines.length; j++) {
      if (j === lnIdx) continue;
      const hit = segIntersectT(ln, lines[j]);
      if (hit != null) ts.push(hit);
    }
    ts.sort((a, b) => a - b);

    // Unit perpendicular in viewBox (0-100) space; 0.3 units is about a
    // third of a percent of the canvas — enough to land inside a cell
    // without reaching into the neighbor across any realistic line.
    const nx = -vy / vLen, ny = vx / vLen;
    const eps = 0.3;

    for (let k = 0; k < ts.length - 1; k++) {
      const t0 = ts[k], t1 = ts[k + 1];
      if (t1 - t0 < 1e-4) continue;
      const mt = (t0 + t1) / 2;
      const mx = Lx1 + mt * vx;
      const my = Ly1 + mt * vy;
      const probes = [
        { x: mx + nx * eps, y: my + ny * eps },
        { x: mx - nx * eps, y: my - ny * eps }
      ];
      const cells = new Set();
      for (const p of probes) {
        for (let ci = 0; ci < cuts.length; ci++) {
          const poly = cuts[ci]?.cell?.poly;
          if (poly && pointInPoly(p, poly)) {
            cells.add(ci);
            break;
          }
        }
      }
      if (!cells.size) continue;

      const x1 = ((Lx1 + t0 * vx) / 100) * W;
      const y1 = ((Ly1 + t0 * vy) / 100) * H;
      const x2 = ((Lx1 + t1 * vx) / 100) * W;
      const y2 = ((Ly1 + t1 * vy) / 100) * H;
      const dx = x2 - x1, dy = y2 - y1;
      const len = Math.hypot(dx, dy);
      if (len < 1) continue;
      const angle = Math.atan2(dy, dx) * 180 / Math.PI;

      const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
      svg.setAttribute("viewBox", brushInfo.viewBox);
      svg.setAttribute("preserveAspectRatio", "none");
      svg.classList.add("sls-brush-line");
      svg.dataset.cells = Array.from(cells).join(" ");
      svg.style.left = `${x1}px`;
      svg.style.top = `${y1 - thick / 2}px`;
      svg.style.width = `${len}px`;
      svg.style.height = `${thick}px`;
      svg.style.transform = `rotate(${angle}deg)`;
      svg.style.setProperty("--sls-brush-fill", color);
      svg.innerHTML = brushInfo.html;
      layer.appendChild(svg);
    }
  });

  wireBrushHover(preview, layer);
}

// Attach per-cell hover listeners that light only brushes tagged with
// the hovered cell's index. Listeners attach once per cell; handlers
// re-query on every fire so resize rebuilds still hit fresh brushes.
function wireBrushHover(preview, layer) {
  preview.querySelectorAll(".sls-live-cell").forEach(cell => {
    const idx = cell.dataset.index;
    if (idx == null || cell.dataset.brushWired === "1") return;
    cell.dataset.brushWired = "1";
    const sel = `.sls-brush-line[data-cells~="${idx}"]`;
    cell.addEventListener("mouseenter", () => {
      const override = cell.style.getPropertyValue("--sls-hover-color");
      layer.querySelectorAll(sel).forEach(m => {
        if (override) m.style.setProperty("--sls-hover-color", override);
        m.classList.add("sls-glow");
      });
    });
    cell.addEventListener("mouseleave", () => {
      layer.querySelectorAll(sel).forEach(m => {
        m.style.removeProperty("--sls-hover-color");
        m.classList.remove("sls-glow");
      });
    });
  });
}
