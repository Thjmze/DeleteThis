import { registerSettings, BASE_URL_KEY, FONTS_KEY } from "./settings.js";
import { LoginConfig } from "./config-app.js";
import { worldId } from "./layout-writer.js";

const MODULE_ID = "stylish-login-screen";
function loginPath() {
  const r = game.release;
  if (r && (r.generation > 14 || (r.generation === 14 && r.build >= 361)))
    return "/modules/stylish-login-screen/launch.svgz";
  return "/modules/stylish-login-screen/login.html";
}

// Strip trailing slashes and protocol schemes a user might accidentally
// paste twice. Empty string means "no override, use Foundry's auto-detect".
function normalizeBase(base) {
  if (typeof base !== "string") return "";
  const trimmed = base.trim().replace(/\/+$/, "");
  return trimmed;
}

function buildShareUrl(base) {
  const wq = `?world=${encodeURIComponent(worldId())}`;
  return normalizeBase(base) + foundry.utils.getRoute(loginPath()) + wq;
}

Hooks.once("init", () => {
  registerSettings();

  game.settings.registerMenu(MODULE_ID, "configMenu", {
    name: "SLS.ConfigMenuName",
    label: "SLS.ConfigMenuLabel",
    hint: "SLS.ConfigMenuHint",
    icon: "fas fa-user-circle",
    type: LoginConfig,
    restricted: true
  });
});

// Injects the player login URLs + a custom-base-URL editor as rows right
// after the module's menu button on the Configure Settings page.
Hooks.on("renderSettingsConfig", (_app, html) => {
  const root = html instanceof HTMLElement ? html : html?.[0];
  if (!root) return;

  // Foundry renders module menus inside the module's section; the menu row
  // is wrapped in .form-group.submenu and carries a button with data-key.
  const button = root.querySelector(`button[data-key="${MODULE_ID}.configMenu"]`);
  const anchor = button?.closest(".form-group");
  if (!anchor || anchor.querySelector(".sls-urls-inline")) return;

  const addresses = game.data?.addresses ?? {};
  const autoLocal = (addresses.local || location.origin).replace(/\/$/, "");
  const autoRemote = (addresses.remote || "").replace(/\/$/, "");
  const customBase = normalizeBase(game.settings.get(MODULE_ID, BASE_URL_KEY));

  // When a custom base is set, both "Local" and "Internet" rows use it —
  // the user is deliberately overriding everything to go through their proxy.
  const localUrl = buildShareUrl(customBase || autoLocal);
  const internetUrl = customBase
    ? buildShareUrl(customBase)
    : (autoRemote ? buildShareUrl(autoRemote) : "");

  const wrap = document.createElement("div");
  wrap.className = "sls-urls-inline";

  // Custom base URL editor — sits above the URL rows. Typing updates the
  // rows below live; Save commits it to world settings so it persists.
  const customRow = document.createElement("div");
  customRow.className = "form-group sls-share sls-custom-base";
  customRow.innerHTML = `
    <label>${game.i18n.localize("SLS.CustomBaseUrl")}</label>
    <div class="form-fields">
      <input type="text" class="sls-custom-base-input"
             placeholder="https://foundry.mydomain.com"
             value="${customBase}">
      <button type="button" data-action="saveBase" title="${game.i18n.localize("SLS.Save")}">
        <i class="fas fa-save"></i>
      </button>
    </div>
  `;
  wrap.appendChild(customRow);

  const hintRow = document.createElement("p");
  hintRow.className = "sls-share-hint";
  hintRow.textContent = game.i18n.localize("SLS.CustomBaseHint");
  wrap.appendChild(hintRow);

  // Local URL row.
  const localRow = document.createElement("div");
  localRow.className = "form-group sls-share";
  localRow.dataset.url = localUrl;
  localRow.innerHTML = `
    <label>${game.i18n.localize("SLS.ShareUrlLocal")}</label>
    <div class="form-fields">
      <input type="text" class="sls-url-input" value="${localUrl}" readonly>
      <button type="button" data-action="copy" title="${game.i18n.localize("SLS.CopyUrl")}">
        <i class="fas fa-copy"></i>
      </button>
    </div>
  `;
  wrap.appendChild(localRow);

  if (internetUrl) {
    const inetRow = document.createElement("div");
    inetRow.className = "form-group sls-share sls-internet-row";
    inetRow.dataset.url = internetUrl;
    inetRow.dataset.revealed = "false";
    inetRow.innerHTML = `
      <label>${game.i18n.localize("SLS.ShareUrlInternet")}</label>
      <div class="form-fields">
        <input type="text" class="sls-url-input sls-internet-code" value="${"•".repeat(28)}" readonly>
        <button type="button" data-action="reveal" title="${game.i18n.localize("SLS.RevealInternet")}">
          <i class="fas fa-eye"></i>
        </button>
        <button type="button" data-action="copy" title="${game.i18n.localize("SLS.CopyUrl")}">
          <i class="fas fa-copy"></i>
        </button>
      </div>
    `;
    wrap.appendChild(inetRow);
  } else {
    const hint = document.createElement("p");
    hint.className = "sls-share-hint";
    hint.textContent = game.i18n.localize("SLS.NoInternetUrl");
    wrap.appendChild(hint);
  }

  anchor.after(wrap);

  // Live update: as the user types in the custom base field, rebuild the
  // displayed share URLs so they can see what players will get.
  const baseInput = wrap.querySelector(".sls-custom-base-input");
  baseInput?.addEventListener("input", () => {
    const typed = normalizeBase(baseInput.value);
    const newLocal = buildShareUrl(typed || autoLocal);
    const newInet = typed ? buildShareUrl(typed) : (autoRemote ? buildShareUrl(autoRemote) : "");
    localRow.dataset.url = newLocal;
    const localInput = localRow.querySelector(".sls-url-input");
    if (localInput) localInput.value = newLocal;
    const inetRow = wrap.querySelector(".sls-internet-row");
    if (inetRow && newInet) {
      inetRow.dataset.url = newInet;
      // Only refresh the displayed value if it's currently revealed; otherwise
      // keep the dots so the user's reveal state isn't lost.
      if (inetRow.dataset.revealed === "true") {
        const inetInput = inetRow.querySelector(".sls-url-input");
        if (inetInput) inetInput.value = newInet;
      }
    }
  });

  wrap.addEventListener("click", async (ev) => {
    const btn = ev.target.closest("button[data-action]");
    if (!btn) return;
    ev.preventDefault();

    if (btn.dataset.action === "saveBase") {
      const val = normalizeBase(baseInput?.value || "");
      await game.settings.set(MODULE_ID, BASE_URL_KEY, val);
      ui.notifications.info(game.i18n.localize("SLS.BaseUrlSaved"));
      return;
    }

    const row = btn.closest("[data-url]");
    if (!row) return;
    const url = row.dataset.url;

    if (btn.dataset.action === "copy") {
      try {
        await navigator.clipboard.writeText(url);
        ui.notifications.info(game.i18n.format("SLS.UrlCopied", { url }));
      } catch {
        ui.notifications.info(url);
      }
      return;
    }

    if (btn.dataset.action === "reveal") {
      const input = row.querySelector(".sls-internet-code");
      const icon = btn.querySelector("i");
      const revealed = row.dataset.revealed === "true";
      if (revealed) {
        input.value = "•".repeat(28);
        row.dataset.revealed = "false";
        icon?.classList.replace("fa-eye-slash", "fa-eye");
      } else {
        input.value = url;
        row.dataset.revealed = "true";
        icon?.classList.replace("fa-eye", "fa-eye-slash");
      }
    }
  });

  // --- Font management section ---
  const fontSection = document.createElement("div");
  fontSection.className = "sls-fonts-inline";

  const fontHeader = document.createElement("div");
  fontHeader.className = "form-group sls-share";
  fontHeader.innerHTML = `<label>${game.i18n.localize("SLS.ManageFonts")}</label>`;
  fontSection.appendChild(fontHeader);

  const fontList = document.createElement("div");
  fontList.className = "sls-font-list";
  fontSection.appendChild(fontList);

  const addRow = document.createElement("div");
  addRow.className = "sls-font-add-row";
  addRow.innerHTML = `
    <input type="text" class="sls-font-name-input" placeholder="${game.i18n.localize("SLS.FontName")}" />
    <input type="text" class="sls-font-url-input" placeholder="path/to/font.woff2" />
    <button type="button" class="sls-font-browse" title="${game.i18n.localize("SLS.Browse")}"><i class="fas fa-folder-open"></i></button>
    <button type="button" class="sls-font-add-btn" title="${game.i18n.localize("SLS.FontAdd")}"><i class="fas fa-plus"></i></button>
  `;
  fontSection.appendChild(addRow);

  wrap.after(fontSection);

  function renderFontList() {
    const fonts = game.settings.get(MODULE_ID, FONTS_KEY) ?? [];
    fontList.innerHTML = "";
    for (let i = 0; i < fonts.length; i++) {
      const f = fonts[i];
      const row = document.createElement("div");
      row.className = "sls-font-entry";
      row.innerHTML = `
        <span class="sls-font-entry-name" style="font-family: '${f.name}', sans-serif;">${f.name}</span>
        <span class="sls-font-entry-url">${f.url}</span>
        <button type="button" class="sls-font-remove" data-idx="${i}" title="${game.i18n.localize("SLS.Remove")}"><i class="fas fa-trash"></i></button>
      `;
      fontList.appendChild(row);
    }
  }
  renderFontList();

  fontSection.addEventListener("click", async (ev) => {
    const addBtn = ev.target.closest(".sls-font-add-btn");
    const removeBtn = ev.target.closest(".sls-font-remove");
    const browseBtn = ev.target.closest(".sls-font-browse");

    if (browseBtn) {
      const urlInput = addRow.querySelector(".sls-font-url-input");
      const fp = new FilePicker({
        type: "any",
        current: urlInput.value || "",
        callback: (path) => { urlInput.value = path; }
      });
      fp.render(true);
      return;
    }

    if (addBtn) {
      const nameInput = addRow.querySelector(".sls-font-name-input");
      const urlInput = addRow.querySelector(".sls-font-url-input");
      const name = nameInput.value.trim();
      const url = urlInput.value.trim();
      if (!name || !url) {
        ui.notifications.warn(game.i18n.localize("SLS.FontMissingFields"));
        return;
      }
      const fonts = game.settings.get(MODULE_ID, FONTS_KEY) ?? [];
      fonts.push({ name, url });
      await game.settings.set(MODULE_ID, FONTS_KEY, fonts);
      nameInput.value = "";
      urlInput.value = "";
      renderFontList();
      ui.notifications.info(game.i18n.format("SLS.FontAdded", { name }));
      return;
    }

    if (removeBtn) {
      const idx = Number(removeBtn.dataset.idx);
      const fonts = game.settings.get(MODULE_ID, FONTS_KEY) ?? [];
      const removed = fonts.splice(idx, 1)[0];
      await game.settings.set(MODULE_ID, FONTS_KEY, fonts);
      renderFontList();
      if (removed) ui.notifications.info(game.i18n.format("SLS.FontRemoved", { name: removed.name }));
    }
  });
});
