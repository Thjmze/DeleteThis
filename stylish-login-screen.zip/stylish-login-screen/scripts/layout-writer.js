import { num } from "./util.js";
import { MODULE_ID, FONTS_KEY } from "./settings.js";

export const UPLOAD_DIR = "stylish-login-screen-images";
export const LAYOUT_FILE = "layout.json";

export function worldId() {
  return game.world?.id || "default";
}

export async function writeLayoutFile(layout) {
  // Denormalize user names so the standalone login page (which has no access
  // to game data) can render labels without another request.
  const mode = layout.mode === "custom" ? "custom"
    : layout.mode === "background" ? "background"
    : "grid";
  const enriched = {
    cols: layout.cols,
    rows: layout.rows,
    mode,
    fit: layout.fit === "fill" ? "fill" : "letterbox",
    lineColor: typeof layout.lineColor === "string" ? layout.lineColor : "#000000",
    lineThick: num(layout.lineThick, 4),
    lineStyle: typeof layout.lineStyle === "string" ? layout.lineStyle : "solid",
    hoverColor: typeof layout.hoverColor === "string" ? layout.hoverColor : "#f0c040",
    hoverZoom: num(layout.hoverZoom, 4),
    bgImage: typeof layout.bgImage === "string" ? layout.bgImage : "",
    showLogo: !!layout.showLogo,
    loginAnimation: typeof layout.loginAnimation === "string" ? layout.loginAnimation : "none",
    muteBackground: layout.muteBackground !== false,
    entryScreen: !!layout.entryScreen,
    entryImage: typeof layout.entryImage === "string" ? layout.entryImage : "",
    entryImageFit: layout.entryImageFit === "contain" ? "contain" : "cover",
    entryImageX: num(layout.entryImageX, 50),
    entryImageY: num(layout.entryImageY, 50),
    entryImageZoom: num(layout.entryImageZoom, 100),
    entryFont: typeof layout.entryFont === "string" ? layout.entryFont : "",
    entryAnimation: typeof layout.entryAnimation === "string" ? layout.entryAnimation : "none",
    entrySound: typeof layout.entrySound === "string" ? layout.entrySound : "",
    entrySoundVolume: num(layout.entrySoundVolume, 50),
    entryText: typeof layout.entryText === "string" ? layout.entryText : "",
    entryTextStyle: (() => {
      const ts = layout.entryTextStyle || {};
      return {
        color: typeof ts.color === "string" && /^#[0-9a-f]{6}$/i.test(ts.color) ? ts.color : "#eeeeee",
        bg: ts.bg === "box" || ts.bg === "image" ? ts.bg : "none",
        bgImage: typeof ts.bgImage === "string" ? ts.bgImage : "",
        useImage: !!ts.useImage,
        glow: !!ts.glow,
        size: num(ts.size, 100),
        bgImageSize: num(ts.bgImageSize, 100),
        x: num(ts.x, 50),
        y: num(ts.y, 50)
      };
    })(),
    music: typeof layout.music === "string" ? layout.music : "",
    musicVolume: num(layout.musicVolume, 50),
    customFonts: (game.settings.get(MODULE_ID, FONTS_KEY) ?? [])
      .filter(f => f?.name && f?.url)
      .map(f => ({ name: f.name, url: f.url })),
    lines: Array.isArray(layout.lines) ? layout.lines.map(l => ({
      x1: num(l.x1, 0), y1: num(l.y1, 0), x2: num(l.x2, 0), y2: num(l.y2, 0)
    })) : [],
    cuts: layout.cuts.map(c => {
      const u = c.userId ? game.users.get(c.userId) : null;
      const out = {
        userId: c.userId || null,
        userName: u?.name ?? null,
        image: c.image || "",
        sound: typeof c.sound === "string" ? c.sound : "",
        soundVolume: num(c.soundVolume, 50),
        x: Number.isFinite(Number(c.x)) ? Number(c.x) : 50,
        y: Number.isFinite(Number(c.y)) ? Number(c.y) : 50,
        zoom: Number.isFinite(Number(c.zoom)) ? Number(c.zoom) : 100,
        labelShow: c.labelShow !== false,
        labelX: num(c.labelX, 50),
        labelY: num(c.labelY, 88),
        hoverColor: typeof c.hoverColor === "string" && /^#[0-9a-f]{6}$/i.test(c.hoverColor) ? c.hoverColor : null
      };
      if (c.cell?.poly) {
        out.cell = { poly: c.cell.poly.map(([x, y]) => [num(x, 0), num(y, 0)]) };
      }
      if (c.box) {
        out.box = {
          x: num(c.box.x, 40), y: num(c.box.y, 40),
          w: num(c.box.w, 20), h: num(c.box.h, 20)
        };
      }
      if (c.zoomBox) {
        out.zoomBox = {
          x: num(c.zoomBox.x, 25), y: num(c.zoomBox.y, 25),
          w: num(c.zoomBox.w, 50), h: num(c.zoomBox.h, 50)
        };
      }
      const ns = c.nameStyle || {};
      out.nameStyle = {
        font: typeof ns.font === "string" ? ns.font : "",
        color: typeof ns.color === "string" && /^#[0-9a-f]{6}$/i.test(ns.color) ? ns.color : "#ffffff",
        bg: ns.bg === "image" || ns.bg === "none" ? ns.bg : "box",
        bgImage: typeof ns.bgImage === "string" ? ns.bgImage : "",
        useImage: !!ns.useImage,
        glow: !!ns.glow,
        size: num(ns.size, 100),
        bgImageSize: num(ns.bgImageSize, 100)
      };
      return out;
    })
  };

  const json = JSON.stringify(enriched, null, 2);
  const file = new File([json], LAYOUT_FILE, { type: "application/json" });

  const dir = `${UPLOAD_DIR}/${worldId()}`;
  try { await FilePicker.createDirectory("data", UPLOAD_DIR); } catch { /* exists */ }
  try { await FilePicker.createDirectory("data", dir); } catch { /* exists */ }

  await FilePicker.upload("data", dir, file, {}, { notify: false });
}
