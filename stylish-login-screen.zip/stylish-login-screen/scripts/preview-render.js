// Read-only preview rendering: takes the app's root element and the current
// draft state, mutates the preview DOM to match. No instance state, no class
// closure — config-app.js keeps thin wrappers that forward `this.element` and
// `this.#draft` in.

import { num, isVideoPath } from "./util.js";
import { DEFAULT_NAME_STYLE } from "./settings.js";
import { polyBbox, polyToClipPath } from "./geometry.js";

// Apply per-cut name-style rules to a .sls-live-label element. Resets all
// style bits each call so switching modes cleans up after itself.
export function applyLabelStyle(label, cut, text) {
  const ns = cut.nameStyle || DEFAULT_NAME_STYLE;

  label.classList.remove(
    "sls-name-bg-none", "sls-name-bg-box", "sls-name-bg-image",
    "sls-name-glow", "sls-name-image-only"
  );
  label.style.fontFamily = "";
  label.style.color = "";
  label.style.backgroundImage = "";
  label.textContent = "";
  label.querySelector(".sls-name-img")?.remove();

  label.style.setProperty("--sls-name-scale", String(num(ns.size, 100) / 100));
  label.style.setProperty("--sls-bg-scale", String(num(ns.bgImageSize, 100) / 100));

  if (ns.useImage && ns.bgImage) {
    // Image-only mode: drop the text and render the background image as an
    // actual <img> so it can size naturally instead of stretching a box.
    const img = document.createElement("img");
    img.className = "sls-name-img";
    img.alt = text || "";
    img.src = foundry.utils.getRoute(ns.bgImage);
    label.appendChild(img);
    label.classList.add("sls-name-image-only");
  } else {
    label.textContent = text || "";
    if (ns.font) label.style.fontFamily = `"${ns.font}", "Signika", "Segoe UI", sans-serif`;
    if (ns.color) label.style.color = ns.color;
    const bg = ns.bg || "box";
    label.classList.add(`sls-name-bg-${bg}`);
    if (bg === "image" && ns.bgImage) {
      label.style.backgroundImage = `url("${foundry.utils.getRoute(ns.bgImage)}")`;
    }
  }

  if (ns.glow) label.classList.add("sls-name-glow");
}

export function updateLiveCell(root, draft, idx) {
  const cut = draft.cuts[idx];
  const cell = root?.querySelector?.(`.sls-live-cell[data-index="${idx}"]`);
  if (!cell || !cut) return;

  const img = cell.querySelector(".sls-live-img");
  const label = cell.querySelector(".sls-live-label");

  cell.querySelector(".sls-live-err")?.remove();

  if (label) {
    const userName = cut.userId ? game.users.get(cut.userId)?.name : "";
    const show = cut.labelShow !== false && !!userName;
    label.style.display = show ? "" : "none";
    label.style.left = `${num(cut.labelX, 50)}%`;
    label.style.top = `${num(cut.labelY, 88)}%`;
    applyLabelStyle(label, cut, userName);
  }

  if (cut.hoverColor) {
    cell.style.setProperty("--sls-hover-color", cut.hoverColor);
    label?.style.setProperty("--sls-hover-color", cut.hoverColor);
  } else {
    cell.style.removeProperty("--sls-hover-color");
    label?.style.removeProperty("--sls-hover-color");
  }
  const pgon = root?.querySelector?.(`.sls-outline-svg polygon[data-index="${idx}"]`);
  if (pgon) {
    if (cut.hoverColor) {
      pgon.style.setProperty("--sls-hover-color", cut.hoverColor);
    } else {
      pgon.style.removeProperty("--sls-hover-color");
    }
  }

  if (!cut.image) {
    img.removeAttribute("src");
    img.style.objectFit = "";
    img.style.objectPosition = "";
    img.style.transform = "";
    // Remove any video that was swapped in previously.
    cell.querySelector(".sls-live-video")?.remove();
    return;
  }

  const url = foundry.utils.getRoute(cut.image);
  const wantVideo = isVideoPath(cut.image);

  // If switching between img/video, swap the element.
  const wrap = cell.querySelector(".sls-live-img-wrap");
  let media = img;
  if (wantVideo) {
    img.removeAttribute("src");
    img.style.display = "none";
    let vid = cell.querySelector(".sls-live-video");
    if (!vid) {
      vid = document.createElement("video");
      vid.className = "sls-live-video";
      vid.autoplay = true;
      vid.muted = true;
      vid.loop = true;
      vid.playsInline = true;
      wrap.appendChild(vid);
    }
    media = vid;
  } else {
    img.style.display = "";
    cell.querySelector(".sls-live-video")?.remove();
  }

  const applyPosition = () => {
    const x = num(cut.x, 50), y = num(cut.y, 50);
    const s = num(cut.zoom, 100) / 100;
    if (s < 1) {
      media.style.objectFit = "contain";
      media.style.objectPosition = "center center";
      media.style.transformOrigin = "center center";
      const tx = (x - 50) * (1 - s);
      const ty = (y - 50) * (1 - s);
      media.style.transform = `translate(${tx}%, ${ty}%) scale(${s})`;
    } else {
      media.style.objectFit = "cover";
      media.style.objectPosition = `${x}% ${y}%`;
      media.style.transformOrigin = `${x}% ${y}%`;
      media.style.transform = `scale(${s})`;
    }
  };

  if (wantVideo) {
    media.onloadeddata = applyPosition;
    if (media.getAttribute("src") !== url) media.src = url;
    else applyPosition();
  } else {
    media.onload = applyPosition;
    media.onerror = () => {
      media.removeAttribute("src");
      const err = document.createElement("div");
      err.className = "sls-live-err";
      err.textContent = "Can't load:\n" + cut.image;
      cell.appendChild(err);
    };
    media.src = url;
  }
}

export function applyStyleVars(root, draft) {
  const preview = root?.querySelector?.(".sls-live-preview");
  if (!preview) return;
  const rawThick = num(draft.lineThick, 4);
  const lineColor = draft.lineColor || "#000";
  preview.style.setProperty("--sls-line-color", rawThick > 0 ? lineColor : "transparent");
  preview.style.setProperty("--sls-hover-color", draft.hoverColor || "#f0c040");
  preview.style.setProperty("--sls-hover-zoom", String(num(draft.hoverZoom, 4)));
  // Brush svgs cache their fill as a per-element CSS var at build time, so
  // push the new color through to them immediately instead of waiting for
  // a full rebuild.
  preview.querySelectorAll(".sls-brush-line").forEach(svg => {
    svg.style.setProperty("--sls-brush-fill", lineColor);
  });
  // Line thickness scales relative to the GM's window (matches what they drew).
  // Name size scales relative to a fixed 1920px reference, the width the login
  // page's 20px base was tuned against; using the GM's window width would make
  // preview names drift whenever the window isn't maximised.
  const rect = preview.getBoundingClientRect();
  const winW = window.innerWidth || 1;
  const thickScale = rect.width > 0 ? rect.width / winW : 1;
  const thick = rawThick * thickScale;
  preview.style.setProperty("--sls-line-thick", thick.toFixed(3));
  const nameScale = rect.width > 0 ? rect.width / 1600 : 1;
  preview.style.setProperty("--sls-name-base", (20 * nameScale).toFixed(3) + "px");
}

export function updatePreviewFit(root, draft) {
  const preview = root?.querySelector?.(".sls-live-preview");
  if (!preview) return;
  // letterbox → lock to 16:9 (matches login.html). fill → use the GM's own
  // window ratio as a best-effort approximation of the player's viewport.
  // Background mode always runs letterboxed so WYSIWYG is exact.
  const ar = (draft.fit === "fill" && draft.mode !== "background")
    ? window.innerWidth / window.innerHeight
    : 16 / 9;
  preview.style.setProperty("--ar", ar.toFixed(4));
}

// Walks the preview cells and applies clip-path + bbox positioning in custom
// mode, or absolute box positioning in background mode. Also rebuilds the
// polygon outline overlay used for hover glow.
export function applyPolygonStyles(root, draft) {
  const preview = root?.querySelector?.(".sls-live-preview");
  if (!preview) return;
  const isCustom = draft.mode === "custom";
  const isBackground = draft.mode === "background";

  // Preview background for background mode — image via CSS, video via a
  // dedicated <video> element layered underneath the cells.
  const existingVideo = preview.querySelector(":scope > .sls-bg-video");
  if (isBackground && draft.bgImage) {
    const url = foundry.utils.getRoute(draft.bgImage);
    if (isVideoPath(draft.bgImage)) {
      preview.style.backgroundImage = "";
      preview.style.backgroundSize = "";
      preview.style.backgroundPosition = "";
      preview.style.backgroundRepeat = "";
      let vid = existingVideo;
      if (!vid) {
        vid = document.createElement("video");
        vid.className = "sls-bg-video";
        vid.autoplay = true;
        vid.muted = true;
        vid.loop = true;
        vid.playsInline = true;
        preview.insertBefore(vid, preview.firstChild);
      }
      if (vid.getAttribute("src") !== url) vid.src = url;
    } else {
      if (existingVideo) existingVideo.remove();
      preview.style.backgroundImage = `url("${url}")`;
      preview.style.backgroundSize = "cover";
      preview.style.backgroundPosition = "center center";
      preview.style.backgroundRepeat = "no-repeat";
    }
  } else {
    if (existingVideo) existingVideo.remove();
    preview.style.backgroundImage = "";
    preview.style.backgroundSize = "";
    preview.style.backgroundPosition = "";
    preview.style.backgroundRepeat = "";
  }

  preview.querySelectorAll(".sls-live-cell").forEach(cell => {
    const idx = Number(cell.dataset.index);
    const cut = draft.cuts[idx];
    if (isCustom && cut?.cell?.poly) {
      const bb = polyBbox(cut.cell.poly);
      cell.style.position = "absolute";
      cell.style.left = bb.x + "%";
      cell.style.top = bb.y + "%";
      cell.style.width = bb.w + "%";
      cell.style.height = bb.h + "%";
      cell.style.clipPath = polyToClipPath(cut.cell.poly, bb);
    } else if (isBackground && cut?.box) {
      cell.style.position = "absolute";
      cell.style.left = cut.box.x + "%";
      cell.style.top = cut.box.y + "%";
      cell.style.width = cut.box.w + "%";
      cell.style.height = cut.box.h + "%";
      cell.style.clipPath = "";
    } else {
      cell.style.position = "";
      cell.style.left = "";
      cell.style.top = "";
      cell.style.width = "";
      cell.style.height = "";
      cell.style.clipPath = "";
    }
  });

  // Foundry logo in top-left when enabled.
  let logo = preview.querySelector(".sls-foundry-logo");
  if (draft.showLogo) {
    if (!logo) {
      logo = document.createElement("img");
      logo.className = "sls-foundry-logo";
      logo.src = foundry.utils.getRoute("/icons/fvtt.png");
      logo.alt = "Foundry Virtual Tabletop";
      preview.appendChild(logo);
    }
  } else {
    logo?.remove();
  }

  // Build (or tear down) the outline overlay that draws the golden hover
  // stroke along each polygon's actual edges.
  preview.querySelector(".sls-outline-svg")?.remove();
  if (!isCustom) return;
  const svgNS = "http://www.w3.org/2000/svg";
  const outline = document.createElementNS(svgNS, "svg");
  outline.setAttribute("class", "sls-outline-svg");
  outline.setAttribute("viewBox", "0 0 100 100");
  outline.setAttribute("preserveAspectRatio", "none");
  draft.cuts.forEach((c, i) => {
    if (!c.cell?.poly) return;
    const pgon = document.createElementNS(svgNS, "polygon");
    pgon.setAttribute("points", c.cell.poly.map(p => p.join(",")).join(" "));
    pgon.dataset.index = i;
    if (c.hoverColor) pgon.style.setProperty("--sls-hover-color", c.hoverColor);
    outline.appendChild(pgon);
  });
  preview.appendChild(outline);
}
