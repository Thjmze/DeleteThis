// Brush source paths + viewBox per brush, loaded once and cached.
// Keys are logical brush ids ("brush1", "brush2"); style names map to these
// via brushInfoFor.
const brushCache = {
  brush1: { html: "", viewBox: "175 25 875 95", file: "brush-1.svg" },
  brush2: { html: "", viewBox: "70 140 940 56", file: "brush-2.svg" },
  thorns: { html: "", viewBox: "0 0 1000 60",   file: "thorns.svg" },
  torn:   { html: "", viewBox: "0 0 1000 60",   file: "torn.svg" }
};

export function brushInfoFor(style) {
  if (style === "brush" || style === "brushCrossed") return brushCache.brush1;
  if (style === "brush2" || style === "brush2Crossed") return brushCache.brush2;
  if (style === "thorns") return brushCache.thorns;
  if (style === "torn")   return brushCache.torn;
  return null;
}

export async function loadBrushPaths() {
  const entries = Object.values(brushCache);
  await Promise.all(entries.map(async info => {
    if (info.html) return;
    try {
      const resp = await fetch(`modules/stylish-login-screen/assets/${info.file}`);
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const text = await resp.text();
      const doc = new DOMParser().parseFromString(text, "image/svg+xml");
      info.html = Array.from(doc.querySelectorAll("path")).map(p => p.outerHTML).join("");
    } catch (e) {
      console.error(`Stylish Login Screen: failed to load ${info.file}`, e);
    }
  }));
}
