export const MODULE_ID = "stylish-login-screen";
export const SETTING_KEY = "layout";
export const BASE_URL_KEY = "customBaseUrl";
export const PRESETS_KEY = "presets";
export const PRESET_COUNT = 8;
export const FONTS_KEY = "customFonts";

export const DEFAULT_LAYOUT = {
  cols: 2,
  rows: 1,
  fit: "letterbox",
  lineColor: "#000000",
  lineThick: 4,
  lineStyle: "solid",
  hoverColor: "#f0c040",
  hoverZoom: 4,
  bgImage: "",
  showLogo: false,
  loginAnimation: "none",
  muteBackground: true,
  entryScreen: false,
  entryImage: "",
  entryFont: "",
  entryAnimation: "none",
  entrySound: "",
  entryText: "",
  entryTextStyle: {
    color: "#eeeeee",
    bg: "none",
    bgImage: "",
    useImage: false,
    glow: false,
    size: 100,
    bgImageSize: 100,
    x: 50,
    y: 50
  },
  music: "",
  cuts: []
};

export const DEFAULT_ENTRY_TEXT_STYLE = {
  color: "#eeeeee",
  bg: "none",
  bgImage: "",
  useImage: false,
  glow: false,
  size: 100,
  bgImageSize: 100,
  x: 50,
  y: 50
};

export const DEFAULT_NAME_STYLE = {
  font: "",
  color: "#ffffff",
  bg: "box",        // "box" | "image" | "none"
  bgImage: "",
  useImage: false,  // show the background image alone, no text
  glow: false,
  size: 100,        // % — scales text + box together
  bgImageSize: 100  // % — scales the bg image relative to the text box
};

// Curated font list for the name-style dropdown. Each entry is rendered in
// its own font in the picker so the GM can preview choices at a glance.
export const FONT_CHOICES = [
  "Signika",
  "Arial",
  "Verdana",
  "Tahoma",
  "Trebuchet MS",
  "Georgia",
  "Times New Roman",
  "Palatino",
  "Garamond",
  "Courier New",
  "Lucida Console",
  "Impact",
  "Comic Sans MS",
  "Brush Script MT",
  "Copperplate",
  "Papyrus"
];

export function registerSettings() {
  game.settings.register(MODULE_ID, SETTING_KEY, {
    scope: "world",
    config: false,
    type: Object,
    default: DEFAULT_LAYOUT
  });

  game.settings.register(MODULE_ID, PRESETS_KEY, {
    scope: "world",
    config: false,
    type: Array,
    default: []
  });

  // Optional override for the share URL base. Foundry auto-detects the server
  // address, but that breaks for people running behind a reverse proxy
  // (Cloudflare, nginx, a custom domain). When set, this replaces the
  // auto-detected host in both the displayed share URLs and the preview URL.
  game.settings.register(MODULE_ID, BASE_URL_KEY, {
    scope: "world",
    config: false,
    type: String,
    default: ""
  });

  // User-added fonts: array of {name, url} objects.
  game.settings.register(MODULE_ID, FONTS_KEY, {
    scope: "world",
    config: false,
    type: Array,
    default: []
  });
}

// Returns the built-in list merged with any user-added fonts.
export function getAllFontChoices() {
  const custom = game.settings.get(MODULE_ID, FONTS_KEY) ?? [];
  const names = custom.filter(f => f && f.name).map(f => f.name);
  return [...FONT_CHOICES, ...names];
}
