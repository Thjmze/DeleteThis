# Changelog - Narrator's Jukebox

## Version 4.2.1 - 2026-05-21

### Fixed

- **Uploaded music files playing silently on cross-origin hosts (e.g. The Forge).** Remote music tracks were being routed through the Web Audio visualizer path, which silently dropped audio when the source lived on a different origin. Remote music playback now bypasses the visualizer entirely so The Forge and similar hosted setups play normally.
- **YouTube playback reliability on hosted worlds.** Embedded YouTube players sometimes stayed muted after volume changes on hosted setups. The player is now explicitly unmuted whenever volume is adjusted, and any autoplay block from the browser or host is reported clearly instead of failing silently.

### Changed

- **Music and ambience master volume are now per-listener controls.** Changing the GM volume no longer overwrites each player's saved volume preferences — every connected user keeps their own listening level.

---

## Version 4.2.0 - 2026-05-04

### Compatibility

- **Foundry VTT v14 verified.** Narrator's Jukebox now runs on Foundry v14 alongside v13 (and v11/v12) without changes to your library, settings, or playlists.

### Fixed

- **Tags filter dropdown styling.** The "All Filters → Tag" dropdown in the Music Library was rendering with the default Foundry/system look instead of the module's dark theme. Now matches the rest of the Spotify-inspired UI.

---

## Version 4.1.0 - 2026-05-02

### New

- **Automatic Favorites playlist.** Click the heart on any track to add or remove it. The Favorites playlist updates itself, keeps your saved tracks together in one place, and cannot be deleted by accident.
- **Random interval Soundboard cues.** Sounds can now be configured to fire automatically at random intervals between a minimum and maximum delay. Perfect for distant screams, occasional thunder, ambient stingers, and other unpredictable atmospheric cues — the cue plays once, waits a randomized delay, plays again, and so on, until you stop it.
- **Folder filters in Mini Mode.** The Mini Mode Music, Ambience, and Soundboard tabs now respect folder filtering, so compact-window setups can drill into a single folder the same way the full window does.

### Fixed

- **Mood Boards now match tracks regardless of tag capitalization.** The default mood tags shipped with capital letters (Combat, Social, Mystery, etc.) while track tags are saved lowercase, so out-of-the-box mood cards reported "no playable tracks". Existing mood data is normalized to lowercase automatically on first load — Mood Boards just work now.
- Fixed the file browser sometimes opening behind other windows when choosing a music thumbnail.

### Changed

- **Player bar mode indicator is clearer.** The headphone icon now turns green when broadcasting, with refreshed tooltips that spell out who is hearing the audio and that clicking the icon switches modes.
- Polished the Favorites button active state for a cleaner playing/saved look.
- Folder panels in Music, Ambience, and Soundboard now scroll inside their own panel when you have many folders, instead of pushing the window taller.

---

## Version 4.0.1 - 2026-04-29

- **Fixed a Preview mode leak.** Tracks played while the GM was in Preview mode could reach players whenever a sync event fired (player tab focus, window visibility change, manual resync, soft reset, etc.). The first track previewed stayed silent, but every subsequent track change — Next, clicking another track in the library, clicking on the timeline — would start playing for everyone. Sync now respects Preview mode at every entry point: the GM's private preview never propagates over the wire.
- **Fixed clicking near the end of a track on the playbar timeline occasionally starting a second track before the current one finished.** Manual seeks were entering the crossfade window and triggering the next-track logic immediately. Manual seeking now suppresses the early crossfade trigger until the track actually ends or changes, so dragging the playhead never causes overlapping playback.
- **Clarified Repeat Queue behavior and fixed it occasionally jumping outside the selected Music Library folder.** The playback engine now tracks the active source context (playlist, folder, filtered library, or full library), so Repeat Queue loops only the source you're playing from. Tooltips and UI text were also tightened to better distinguish Repeat Queue from Repeat Track.
- **Fixed Edit Track / Edit Ambience / Edit Soundboard incorrectly blocking saves with a "duplicate in library" warning.** When a track had an intentional duplicate elsewhere in the library (created via Duplicate Track, bulk import, or simply two manually added entries with the same URL), trying to edit metadata like tags or name on the original would fail with the duplicate notification — even if the URL wasn't being changed. The duplicate check now only runs when the URL/identity actually changes, so editing tags or name on existing tracks always works.
- **Fixed Foundry's built-in window minimize (double-click on the titlebar) leaving a large empty rectangle instead of collapsing.** The CSS rule applying the premium 1680×760 minimum to the module's window was missing an opt-out for Foundry's `.minimized` class — so even though Foundry hid the window content, the outer frame stayed forced to the premium size. The minimum rule now skips minimized/mini/micro/fullscreen states, and the premium dimensions are reasserted automatically when the window is restored.
- **Fixed the embedded Music Library panel inside the Session Queue view becoming too narrow on smaller screens**, where track names were squeezed into ellipses. When the queue is open, the playlist rail now slims down, the queue library panel claims more horizontal space, the queue action buttons shift to icon-only, and track names can wrap to two lines before truncating. Long names also get a tooltip on hover.
- **Fixed track tags being squished into tiny illegible circles when a track had many tags**, and added a **"+N" overflow indicator** so you can see at a glance when tags are hidden. Tag pills now keep their natural readable size; when there are more than fit in the column, the extras are replaced by a discrete "+N" pill — hover it to see the full list of hidden tags in a tooltip. The indicator updates live when you resize the window.
- Removed the custom SVG scene control icon. The token controls toolbar now uses Foundry's default Font Awesome record icon, matching the rest of the Foundry UI. This also resolves a visibility issue some users were seeing where the custom icon failed to render correctly.
- Removed the now-unused "Use SVG Scene Control Icon" client setting.

---

## Version 4.0.0 - 2026-04-28

### Highlights

**Complete Visual Redesign**
- Every view rebuilt around a premium, Spotify-inspired look.
- New hero sections with cover art, live stats, and richer color treatment.
- Cleaner typography and a consistent dark theme throughout.

**Session Queue (new)**
- A real, interactive queue: add tracks as "Next" or to "Later" and drag to reorder.
- See what's coming up, where each queued track came from, and clear it anytime.
- After your queue plays out, playback returns to whatever was running before.

**Session Health (new)**
- Connection dots for each online player — green when they're receiving broadcasts, yellow/red when something's off.
- Click a dot to resend the current state to that player. Right-click for a full audio reset on their end.
- Automatic recovery when a player drops out of sync during a broadcast.

**Right-Click Context Menus**
- Right-click any track, ambience layer, or soundboard cue for quick actions: play, edit, move, duplicate, hide, copy URL, delete.
- Each tab keeps its own color identity (green for Music, blue for Ambience, orange for Soundboard).

**Drag and Drop in the Music Library**
- Drag tracks straight into folders. Multi-select with Ctrl/Shift+click works as expected.
- New keyboard shortcuts: Ctrl+A to select all visible, M to move, Delete for bulk delete.

**Mini Mode and Micro Mode, Reimagined**
- Mini Mode: a polished compact cockpit with library, queue, ambience, and soundboard access.
- Micro Mode: a tiny floating capsule that opens into a full transport rail when you hover or click.

**Premium Player Widget for Players**
- Non-GM users now see a beautiful broadcast panel with music/ambience tabs, live status, and player-side volume controls.

**Mood Boards Editor**
- Reworked into a focused master-detail editor: compact list on the left, full detail on the right.
- Live preview, gradient presets, color picker, icon presets, and image browsing.

### Behavior Changes — Worth Knowing

- **The Jukebox window is GM-only now.** Players can no longer open the main app from the sidebar or scene controls — preventing accidental broadcast interruptions. They keep their floating Player Widget with a new **Suggest a Track** button so they can still submit song requests to the GM.
- **Broadcasting by default.** Starting music, ambience, or soundboard cues now plays for everyone right away. (You can switch to Preview anytime.)
- **New repeat mode.** The old Loop button is now Off / Repeat Track / Repeat Queue, and your choice is remembered.
- **Ambience layers loop automatically.** Beds stay beds — no more silently ending mid-scene.
- **Soundboard cue loop is saved per cue.** Set it once on rain or fire and it stays.

### Other Improvements

- Premium custom dialogs replace Foundry's default chrome for Rename, Delete, Edit, and Move.
- Music Library hero uses real artwork from your library.
- Active/playing track shows an animated equalizer indicator.
- Mood cards show track counts and warn when a mood has no playable tracks.
- Stickier toolbars and folder rails so controls stay in reach when scrolling long libraries.

### Bug Fixes

- Local files with `#` in the filename now play correctly (e.g. `Boss #1.mp3` no longer fails silently).
- Hidden tracks behave consistently across Library, Playlists, and Player views.
- Mood Boards no longer crash when a board has no tag or no matching tracks — clearer notifications instead.
- Ambience volume sliders stay in sync everywhere, and the active mix no longer restarts on focus.
- Player Suggestions correctly handle approve/reject after the list changes.
- YouTube ambience layers restore their loop state correctly after sync.

---

## Version 3.0.2 - 2026-02-10 (Hotfix)

### Bug Fixes
- **Critical: Fixed module breaking character sheets from other systems (PF2e, D&D5e, etc.)**. The module was overwriting Foundry's native Handlebars helpers (`eq`, `ne`, `gt`, `lt`) which caused `blockParams[0] is undefined` errors when rendering sheets from other game systems. All custom helpers are now namespaced with `njb-` prefix.
- **Fixed: Player suggestions not playing after GM approval**. When a player suggested a YouTube link and the GM approved it, the track was saved without a URL (`suggestion.path` instead of `suggestion.url`) and without a `source` field, causing "Invalid track" errors on playback.
- **Fixed: Bulk Import from Foundry Data folders not working**. The "Foundry Data" source mode in the Bulk Import dialog crashed with `scanFolderFn is not a function` because the folder scanning function was never passed to the dialog. Implemented `scanFoundryDataFolder()` directly in the dialog using Foundry's FilePicker API.

---

## English Summary - Version 3.0.0

### Highlights
- **Ambience Layer Mixer**: Stack up to 8 ambience tracks simultaneously with independent volume controls. Save and load presets for your favorite soundscapes.
- **Player Widget Modes**: New Mini Mode (compact floating player) and Micro Mode (tiny draggable icon with hover controls).
- **Multi-Track Selection**: Select multiple tracks in the library and add them to playlists at once. Ctrl+Click, Shift+Click, and Ctrl+A supported.
- **Redesigned Player Bar**: Full-width player bar with larger controls, progress bar, and broadcast/preview indicator.
- **Smart Shuffle**: Shuffle mode now avoids playing the same track twice in a row.
- **Debug Mode**: Enable detailed console logging for troubleshooting (disabled by default).
- **Multi-Language Support (i18n)**: Full internationalization with 400+ strings. Ships with English, Portuguese (Brazil), German, Spanish, French, Japanese, and Polish translations.
- **Public API**: Comprehensive API for integration with other modules (`game.modules.get('narrator-jukebox').api`).
- **Complete Refactoring**: Codebase restructured from ~7,000 lines in one file to ~35 modular ES6 files.

### Bug Fixes
- Fixed socket not connecting to SyncService (players couldn't hear music)
- Fixed loop button not repeating the track
- Fixed false "Failed to play" error on Soundboard
- Fixed scroll position resetting on Soundboard
- Fixed search not working in Soundboard and Ambience tabs
- Fixed search bar losing focus while typing

---

*Detailed changelog in Portuguese below / Changelog detalhado em português abaixo*

---

Este documento registra todas as alterações feitas no módulo. Mantenha-o atualizado a cada mudança.

---

## Versão 3.0.0 - 2026-01-31

### Destaque da Versão: Ambience Layer Mixer

O **Ambience Layer Mixer** é a grande novidade desta versão! Um sistema completo de mixagem de ambiências que transforma a experiência sonora das suas sessões de RPG.

#### O que é?
Antes, você podia tocar apenas uma ambiência por vez. Agora, você pode **combinar até 8 camadas de som simultâneas** para criar soundscapes ricos e imersivos. Imagine uma cena de taverna com:
- 🍺 Sons de taverna (conversas, copos)
- 🌧️ Chuva lá fora
- ⚡ Trovões ocasionais
- 🔥 Lareira crepitando

Tudo isso tocando ao mesmo tempo, com volumes individuais ajustáveis!

#### Features Principais
- **Até 8 layers simultâneas**: Combine múltiplas ambiências para criar atmosferas únicas
- **Volume individual por layer**: Controle preciso de cada camada de som
- **Master volume**: Controle geral para todas as layers de ambience
- **Sistema de Presets**: Salve suas combinações favoritas (ex: "Taverna Chuvosa", "Floresta Noturna") e carregue com um clique
- **Sincronização multiplayer completa**: Todos os jogadores ouvem exatamente as mesmas ambiências com os mesmos volumes
- **Interface intuitiva**: Grid visual de cards com toggle on/off para cada layer

#### Suporte Completo em Todos os Modos
- **Janela Normal**: Aba Ambience completamente redesenhada
- **Mini Mode**: Grid compacto de layers
- **Micro Mode**: Indicador de layers ativos
- **Player Widget**: Jogadores podem ver e controlar as layers ativas

#### API Pública Expandida
Novos métodos para desenvolvedores e integrações:
- `playAmbienceLayer()`, `stopAmbienceLayer()`, `toggleAmbienceLayer()`
- `setAmbienceLayerVolume()`, `getActiveAmbienceLayers()`, `stopAllAmbienceLayers()`
- `setAmbienceMasterVolume()`, `getAmbienceMasterVolume()`, `toggleAmbienceMasterMute()`
- `getAmbiencePresets()`, `loadAmbiencePreset()`, `saveAmbiencePreset()`, `deleteAmbiencePreset()`

#### Hooks para Integrações
- `narratorJukebox.ambienceLayer.play`, `narratorJukebox.ambienceLayer.stop`
- `narratorJukebox.ambienceLayer.volumeChanged`, `narratorJukebox.ambienceLayer.stopAll`
- `narratorJukebox.ambienceMaster.volumeChanged`, `narratorJukebox.ambienceMaster.muteChanged`
- `narratorJukebox.ambiencePreset.loaded`, `narratorJukebox.ambiencePreset.saved`, `narratorJukebox.ambiencePreset.deleted`

#### UX Polish e Acessibilidade
- Animações suaves de entrada/saída ao ativar/desativar layers
- Feedback visual (shake + toast) ao tentar adicionar mais de 8 layers
- Cards inativos ficam visualmente desabilitados quando no limite
- Badge de contagem fica vermelho pulsante quando no limite
- Navegação completa por teclado (Tab, Enter, Space, Arrow keys)
- Atributos ARIA completos para leitores de tela
- Estados de foco visíveis para navegação por teclado
- Suporte a `prefers-reduced-motion` (desativa animações)
- Suporte a `prefers-contrast` (modo alto contraste)

#### Arquivos Modificados
`scripts/core/ambience-layer-manager.js`, `scripts/services/playback-service.js`, `scripts/services/sync-service.js`, `scripts/api/narrator-jukebox-api.js`, `scripts/ui/jukebox-app.js`, `scripts/ui/listeners/ambience-listeners.js`, `scripts/dialogs/save-preset-dialog.js`, `templates/jukebox-app.html`, `templates/mini-player.html`, `templates/micro-player.html`, `styles/narrator-jukebox-v2.css`

---

### Testes Realizados (QA Completo)

O Ambience Layer Mixer passou por uma bateria completa de testes:

| Categoria | Teste | Status |
|-----------|-------|--------|
| **Básico** | Criar layers, ajustar volume, mute individual | ✅ Passou |
| **Básico** | Limite de 8 camadas (rejeita 9ª) | ✅ Passou |
| **Master Controls** | Volume master, mute global | ✅ Passou |
| **Presets** | Salvar, carregar, deletar presets | ✅ Passou |
| **Sync Multiplayer** | GM → Player sincronização | ✅ Passou |
| **UI Modes** | Mini Mode, Micro Mode | ✅ Passou |
| **API** | Todos os métodos via Console F12 | ✅ Passou |
| **Edge Case** | Player entrando mid-session (deferred state) | ✅ Passou |
| **Edge Case** | GM reload com layers ativos | ✅ Passou |
| **Edge Case** | Deletar ambience que está tocando | ✅ Passou |
| **UI** | Área de clique do botão delete | ✅ Passou |
| **Performance** | 8 layers simultâneas (CPU/memória) | ✅ Passou |
| **Performance** | Start/stop repetido (memory leaks) | ✅ Passou |

**Resultados de Performance:**
- 8 layers simultâneas: +0.47MB heap após 30 segundos (excelente)
- Stress test (20 ciclos de add/remove): +6.64MB growth (sem memory leaks)
- 0 elementos órfãos no DOM após cleanup

---

### Outras Melhorias

- **Persistência de Volume entre Sessões**: O módulo agora lembra o volume configurado pelo usuário mesmo após fechar o Foundry. Volumes de música e ambience são salvos separadamente por usuário (scope: client). O estado de mute também é persistido - se você deixou mutado, ao reabrir o Foundry ele continuará mutado. (scripts/core/constants.js, scripts/narrator-jukebox.js, scripts/core/jukebox-state.js, scripts/services/playback-service.js)

- **API Pública para Integração com Outros Módulos**: Nova API completa e bem documentada que permite que outros módulos controlem o Narrator's Jukebox programaticamente. Ideal para integração com módulos como Exalted Scenes. Características:
  - **Acesso padrão Foundry**: `game.modules.get('narrator-jukebox').api`
  - **Playback Control**: `playMusic()`, `playPlaylist()`, `playRandomByTag()`, `stop()`, `next()`, `prev()`, `togglePlayPause()`, `seek()`
  - **Busca por Nome**: `playPlaylistByName()`, `playTrackByName()`, `findPlaylistByName()`, `findTrackByName()` com fuzzy search
  - **Volume Control**: `setVolume()`, `getVolume()`, `mute()`, `unmute()`, `toggleMute()`
  - **Opções de Playback**: `setShuffle()`, `setLoop()`, `setPreviewMode()`
  - **Soundboard**: `playSoundboardSound()`, `playSoundboardSoundByName()`, `stopSoundboardSound()`, `stopAllSoundboardSounds()`
  - **Acesso a Dados**: `getAllMusic()`, `getAllAmbience()`, `getAllPlaylists()`, `getTracksByTag()`, `getAllTags()`
  - **Estado Completo**: `getState()` retorna snapshot completo do estado atual
  - **Sistema de Hooks**: Eventos para reagir a mudanças (`narratorJukebox.ready`, `narratorJukebox.play`, `narratorJukebox.trackChanged`, `narratorJukebox.stop`, etc.)
  - **Validação de Inputs**: Erros claros e úteis para parâmetros inválidos
  - **JSDoc Completo**: Documentação inline para TypeScript-friendly development
  - (scripts/api/narrator-jukebox-api.js, scripts/narrator-jukebox.js, scripts/core/constants.js)

- **Player Widget para Jogadores**: Novo widget compacto e arrastável que aparece automaticamente para jogadores (não-GMs) quando o narrador inicia música ou ambience. Resolve o problema de jogadores não saberem como controlar o volume. Características:
  - **Dois modos de visualização**: Modo expandido (com artwork, nome, progresso e volume) e modo compacto (micro bar só com indicadores)
  - **Controle de volume local**: Jogadores podem ajustar o volume da música e ambience independentemente, sem afetar os outros jogadores
  - **Tabs Music/Ambience**: Alterna entre controles de música e ambience
  - **Indicadores de status**: Ícones pulsantes mostram qual canal está tocando (verde para música, roxo para ambience)
  - **Arrastável**: Widget inteiro pode ser arrastado para qualquer lugar da tela
  - **Posição persistente**: A posição é salva no localStorage e restaurada entre sessões
  - **Barra de progresso**: Mostra o tempo atual da música em reprodução
  - **Auto-show**: Aparece automaticamente quando o GM dá play, pode ser fechado ou minimizado
  - **Botão minimizar/expandir**: Alterna entre modo expandido e micro bar compacta
  - (scripts/ui/player-widget.js, styles/narrator-jukebox-v2.css, scripts/narrator-jukebox.js)

- **Seleção Múltipla de Faixas**: Agora você pode selecionar múltiplas músicas na biblioteca e adicioná-las a uma playlist de uma só vez. Funcionalidades incluem:
  - Botão "Select" no header da biblioteca ativa o modo de seleção
  - Checkboxes aparecem em cada faixa quando o modo está ativo
  - Ctrl+Click para selecionar individualmente (ativa o modo automaticamente)
  - Shift+Click para selecionar um range de faixas
  - Ctrl+A para selecionar todas as faixas visíveis
  - ESC para sair do modo de seleção
  - Checkbox "Select All" no header da lista
  - Toolbar flutuante aparece com contador e botão "Add to Playlist"
  - Diálogo mostra preview das faixas e indica quantas já existem na playlist
  - (scripts/ui/jukebox-app.js, scripts/ui/listeners/selection-listeners.js, scripts/dialogs/add-selected-to-playlist-dialog.js, scripts/services/data-service.js, templates/jukebox-app.html, styles/narrator-jukebox-v2.css)

- **Adicionar Faixas Filtradas à Playlist**: Quando você usa a busca ou filtro de tags na biblioteca, aparece um botão "Add All Visible" que permite adicionar todas as faixas filtradas a uma playlist com um clique. Ideal para criar playlists baseadas em tags como "combat", "exploration", etc. (scripts/ui/jukebox-app.js, scripts/ui/listeners/selection-listeners.js, templates/jukebox-app.html)

- **Mini Mode: Toggle Library/Queue**: Na aba Music do Mini Mode, agora há sub-tabs para alternar entre "Library" (biblioteca completa) e "Queue" (fila da playlist atual). A view de Queue mostra a posição de cada faixa, destaca a faixa atual, e indica faixas já tocadas. O tab Queue só fica disponível quando há uma playlist em reprodução. (scripts/ui/jukebox-app.js, scripts/ui/listeners/mini-listeners.js, templates/mini-player.html, styles/narrator-jukebox-v2.css)

- **Player Bar Redesenhada (Full Width)**: A player bar foi completamente redesenhada para ocupar toda a largura do footer. Com a migração dos controles de ambience para o Layer Mixer, a barra de música agora tem mais espaço e elementos maiores:
  - **Artwork maior**: Aumentada de 50x50 para 56x56px
  - **Controles maiores**: Botões de 32px (antes 24px), botão play/pause de 40px (antes 32px)
  - **Progress bar expandida**: Mais grossa (5px) e mais fácil de clicar para seek
  - **Volume slider maior**: 80px de largura (antes 50px) para ajuste mais preciso
  - **Indicador de fonte**: Subtítulo mostra "Library" ou o nome da playlist atual
  - **Indicador de Broadcast/Preview**: Badge visual (apenas GM) mostra se está em modo Preview (laranja, headphones) ou Broadcast (verde pulsante, torre)
  - (templates/jukebox-app.html, styles/narrator-jukebox-v2.css, scripts/ui/listeners/player-listeners.js)

- **Shuffle Inteligente (Sem Repetição Consecutiva)**: O modo shuffle agora evita tocar a mesma música duas vezes seguidas. Antes, com playlists pequenas, era comum a mesma música repetir imediatamente. Agora o algoritmo garante que a próxima música seja sempre diferente da atual (exceto quando há apenas 1 música). (scripts/services/playback-service.js)

- **Ícone de Volume Dinâmico**: O ícone do botão de volume agora muda em tempo real conforme você ajusta o slider - mostra volume alto, médio, baixo ou mudo. Antes o ícone só mudava ao reabrir a janela. (scripts/ui/listeners/player-listeners.js)

- **Tooltip de Título Melhorado**: A tooltip que aparece ao passar o mouse sobre títulos longos na player bar agora suporta textos maiores (até 450px) e permite quebra de linha, garantindo que nomes muito longos sejam sempre legíveis por completo. (styles/narrator-jukebox-v2.css)

- **Debug Mode**: Nova opção "Debug Mode" nas configurações do módulo que permite ativar logs detalhados no console do navegador para troubleshooting. Útil para usuários reportando problemas - basta ativar o modo debug, reproduzir o problema e compartilhar os logs. Por padrão, o módulo não exibe nenhuma mensagem no console, mantendo-o limpo. (scripts/utils/debug.js, scripts/core/constants.js, scripts/narrator-jukebox.js)

- **README: Seção "What's New in v3.0.0"**: Adicionada seção destacada no README para usuários vindos da v2, apresentando as principais novidades: Ambience Layer Mixer, Player Widget Modes (Mini/Micro), Debug Mode e a refatoração completa do código. (README.md)

- **Suporte Multi-Idioma (i18n)**: O módulo agora suporta múltiplos idiomas! Toda a interface foi internacionalizada usando o sistema padrão do Foundry VTT (`game.i18n.localize()`). Características:
  - **400+ strings traduzíveis**: Todos os textos da interface (diálogos, botões, mensagens, tooltips) estão centralizados em arquivos JSON
  - **7 idiomas incluídos**: Inglês, Português (Brasil), Alemão, Espanhol, Francês, Japonês e Polonês
  - **Helper utility**: Novo módulo `scripts/utils/i18n.js` com funções `localize()` e `format()` para facilitar a tradução
  - **Strings com parâmetros**: Suporte a interpolação de variáveis (ex: `"Added {count} tracks"`)
  - **Pronto para contribuição**: Basta copiar `en.json` para seu idioma e traduzir
  - (lang/*.json, scripts/utils/i18n.js, module.json)

- **CHANGELOG: Resumo em Inglês**: Adicionado resumo em inglês no topo do CHANGELOG com os principais highlights e bug fixes da v3.0.0, tornando o documento mais acessível para a comunidade internacional. (CHANGELOG.md)

### Corrigido
- **Socket não conectado ao SyncService**: Corrigido bug crítico onde o socket do socketlib era registrado mas não era passado para o syncService, impedindo que os comandos de broadcast (play, pause, volume) fossem enviados aos jogadores. Agora o socket é corretamente atribuído ao syncService após o registro. (scripts/narrator-jukebox.js)

- **Botão Loop não repetia a música**: Corrigido bug onde ativar o botão de loop não fazia a música repetir - em vez disso, avançava para a próxima música da playlist ou biblioteca. O problema ocorria porque o handler de fim de faixa sempre chamava `next()` ignorando o estado do loop. Agora, quando o loop está ativo, a mesma música é reproduzida novamente. (scripts/core/jukebox-state.js)

- **Erro "Failed to play" falso no Soundboard**: Corrigido bug onde ao parar um som do soundboard ou quando ele terminava naturalmente, aparecia uma mensagem de erro "Failed to play". O problema ocorria porque o método `stopSoundboardSound` limpava o `src` do áudio, disparando o handler de erro. Agora o handler de erro é removido antes de limpar o src. (scripts/services/playback-service.js)

- **Scroll voltava ao topo no Soundboard**: Corrigido bug onde ao clicar em um item do soundboard (ou qualquer ação que causasse re-render), a lista rolava automaticamente para o topo. Agora a posição do scroll é preservada durante re-renders. (scripts/ui/jukebox-app.js)

- **Busca não funcionava no Soundboard e Ambience**: Corrigido bug onde a barra de busca no header só filtrava música, ignorando as views de Soundboard e Ambience. Agora a busca filtra o conteúdo da view ativa (música, ambience ou soundboard). (scripts/ui/jukebox-app.js, scripts/ui/listeners/main-listeners.js)

- **Barra de busca perdia o foco ao digitar**: Corrigido bug onde a barra de busca perdia o foco enquanto o usuário digitava, interrompendo a digitação. O problema ocorria porque o re-render da UI removia o foco. Agora o estado de foco e a posição do cursor são preservados durante re-renders. (scripts/ui/jukebox-app.js)

### Refatoração Completa da Arquitetura

**Resumo:** Código monolítico de 7,014 linhas transformado em ~35 módulos ES6.

#### Estrutura Nova
```
scripts/
├── narrator-jukebox.js      # Entry point (~300 linhas)
├── core/                    # Estado, constantes, AudioChannel
├── services/                # Playback, dados, sync, validação
├── ui/                      # App, listeners, modes, progress
├── dialogs/                 # Cada diálogo isolado
└── utils/                   # Utilitários (debounce, time, youtube)
```

#### Benefícios
- Arquivos pequenos e focados (maioria < 300 linhas)
- Mudanças cirúrgicas sem efeitos colaterais
- Separação clara de responsabilidades
- Mais fácil debugar e manter

#### Arquivos de Referência
- `narrator-jukebox-legacy.js` - Versão original (backup)
- `ARCHITECTURE.md` - Documentação da arquitetura

---

## Versão 2.0.1

### Correções

- **Crash ao importar bibliotecas muito grandes (500+ arquivos)**: Corrigido problema crítico de performance onde o módulo travava ou causava crash do Foundry ao tentar carregar bibliotecas com muitos arquivos (ex: 600 músicas). O problema ocorria porque todas as faixas eram renderizadas simultaneamente na interface, sobrecarregando o navegador. Agora o módulo utiliza um sistema de paginação inteligente que exibe apenas 50 faixas por vez, com um botão "Load More" para carregar mais. A busca e filtros continuam funcionando normalmente, e o limite é resetado automaticamente ao fazer uma nova busca. Isso permite que bibliotecas de qualquer tamanho sejam utilizadas sem problemas de performance.

---

## Versão 2.0.0

### Correções

- **Barra de busca apagava o texto digitado**: Corrigido bug onde o texto digitado na barra de busca desaparecia após filtrar os resultados, impossibilitando limpar a busca sem fechar e reabrir o módulo. Agora a busca funciona como no Spotify: o texto permanece visível, há um botão (X) para limpar a busca, e pressionar ESC também limpa o filtro. A barra de busca agora tem visual melhorado com destaque quando há busca ativa.

- **Playlists não visíveis na sidebar em janelas menores**: Corrigido bug onde a seção "Music Playlists" na sidebar ficava invisível quando a janela do Jukebox não estava em tela cheia. O problema ocorria porque os elementos da sidebar não tinham área scrollável, cortando o conteúdo quando não havia espaço suficiente. Agora toda a área de navegação da sidebar possui scroll, permitindo visualizar e acessar todas as seções e playlists independente do tamanho da janela.

- **Socketlib marcado como dependência obrigatória**: O módulo socketlib agora é listado como requisito essencial. Isso resolve o problema onde players não conseguiam ouvir as músicas tocadas pelo GM quando o socketlib não estava instalado. Agora o Foundry VTT avisará automaticamente caso o socketlib não esteja presente ao tentar ativar o Narrator's Jukebox.

- **Soundboard não sincronizava com players**: Corrigido bug onde os sons do Soundboard não eram reproduzidos nos clientes dos players. O problema ocorria porque os dados do soundboard não eram recarregados quando um som novo era adicionado. Agora o módulo recarrega automaticamente os dados quando um som não é encontrado localmente, garantindo que os players sempre ouçam os sons do soundboard corretamente.

- **Soundboard enviava 'stop' em preview mode**: Corrigido bug onde ao tocar um som do Soundboard em modo preview (sem broadcast), o comando de 'stop' ainda era enviado para os players quando o som terminava. Agora o módulo armazena se o som foi tocado em preview mode e só envia o 'stop' para os players se o som estava em modo broadcast.

- **Compatibilidade com Foundry v13 (FilePicker)**: Corrigido aviso de deprecação do FilePicker no Foundry v13. O módulo agora usa o novo namespace `foundry.applications.apps.FilePicker` quando disponível, mantendo compatibilidade com versões anteriores (v11/v12).

- **Bulk Import criação automática de pastas**: Corrigido erro onde o upload falhava se a pasta de destino não existisse. Agora o módulo cria automaticamente todas as pastas necessárias (ex: `audio/music`) antes de fazer o upload dos arquivos.

- **Bulk Import não atualizava status ao selecionar pasta de destino**: Corrigido bug onde a mensagem de status permanecia vermelha ("Required: Select or type a destination folder") mesmo após selecionar uma pasta de destino via FilePicker. Agora o status é atualizado corretamente para cinza ("Destination folder set") ou verde ("Ready to import!") assim que a pasta é selecionada.

- **Bulk Import checkboxes não reconhecidos após scan**: Corrigido bug onde os checkboxes dos arquivos apareciam visualmente marcados, mas o sistema não os reconhecia como selecionados. Isso impedia que o status mudasse para "Ready to import!" até clicar em "Select All". Agora os checkboxes são configurados corretamente após a inserção no DOM.

- **Música tocando não era destacada na Library**: Corrigido bug onde a música em reprodução não recebia destaque visual na lista da Library e nas Playlists. O problema ocorria por uma inconsistência de nomenclatura interna. Agora a música tocando aparece corretamente destacada em verde, com o ícone de ondas sonoras animado, facilitando identificar qual faixa está sendo reproduzida.

- **Clique na música atual agora pausa/retoma corretamente**: Corrigido bug onde clicar na música que está tocando reiniciava a reprodução do início em vez de pausar. Agora o comportamento é intuitivo: clicar na música atual alterna entre pausar e retomar a reprodução, enquanto clicar em outra música inicia sua reprodução normalmente.

- **Shuffle em playlists agora funciona corretamente**: Corrigido bug onde ao clicar no botão Shuffle de uma playlist, a reprodução sempre começava pela primeira música. Agora o shuffle escolhe uma música aleatória da playlist para iniciar a reprodução.

- **Textos "Music" e "Ambience" cortados no player bar**: Corrigido bug onde os rótulos "Music" e "Ambience" que aparecem abaixo do nome da faixa no player bar eram cortados visualmente. Agora os textos são sempre exibidos por completo.

- **Toggle de Broadcast não afetava o Soundboard no Mini Player**: Corrigido bug onde o toggle de Preview/Broadcast no Mini Player controlava apenas a música, mas não os sons do Soundboard. O problema ocorria porque os dois sistemas usavam estados internos separados que podiam ficar dessincronizados. Agora o toggle principal (tanto na janela normal quanto no Mini Player) controla ambos os sistemas simultaneamente, garantindo que ao ativar "Broadcast", tanto a música quanto os sons do Soundboard sejam transmitidos para os players.

### Melhorias

- **Preenchimento automático do nome para arquivos locais**: Ao selecionar um arquivo de áudio local nos diálogos de Add Music, Add Ambience ou Add Soundboard Sound, o campo "Nome" agora é preenchido automaticamente com o nome do arquivo (sem a extensão). O nome é processado para melhor legibilidade: caracteres codificados em URL são decodificados (ex: `%20` vira espaço), e hífens/underscores são convertidos em espaços. Isso facilita a adição de novas tracks e torna o campo de nome obrigatório mais intuitivo.

- **Tag "Supported Formats" nos diálogos de importação**: Adicionada uma tag elegante nos diálogos de Add Music, Add Ambience e Add Soundboard Sound que mostra os formatos de áudio suportados por cada navegador. Ao passar o mouse sobre a tag, uma tooltip exibe a compatibilidade detalhada (Chrome/Edge suportam mp3, wav, ogg, webm, flac, m4a; Firefox suporta mp3, wav, ogg, webm, flac; Safari suporta mp3, wav, m4a, aac). O navegador atual do usuário é destacado na lista.

- **Aviso de compatibilidade de formato**: Quando o usuário tenta reproduzir um arquivo em formato não suportado pelo navegador (ex: .ogg no Safari), o módulo agora exibe um aviso informando quais formatos são compatíveis com o navegador atual.

- **Toggle global de Preview/Broadcast no Soundboard**: Substituído o sistema de botões de broadcast individuais por card por um toggle global no header da aba Soundboard. Agora o GM pode alternar entre "Preview" (só ele ouve) e "Broadcast" (todos os players ouvem) com um único clique, aplicando a todos os sons. Isso evita a confusão de esquecer de ativar o broadcast em sons individuais.

- **Aviso informativo na aba Soundboard**: Adicionado um hint visual na aba do Soundboard informando que o toggle de Preview/Broadcast é independente do toggle de Music, lembrando o GM de ativar o Broadcast para que os players ouçam os sons.

- **Bulk Import de arquivos**: Nova funcionalidade que permite importar múltiplos arquivos de áudio de uma só vez. Disponível nas abas Music, Ambience e Soundboard através do botão "Bulk Import". Características:
  - **Importar do Computador**: Selecione uma pasta diretamente do seu PC - os arquivos serão automaticamente enviados para o Foundry e adicionados à biblioteca
  - **Importar do Foundry**: Para arquivos já existentes no servidor, selecione a pasta e importe direto
  - **Upload automático**: Ao importar do computador, os arquivos são copiados para uma pasta de destino que você escolhe
  - **Validação de pastas**: O botão "Import" só é habilitado após selecionar a pasta de origem E a pasta de destino (quando importando do computador)
  - **Feedback visual dinâmico**: Mensagem de status que muda conforme o progresso - vermelho "Required" quando falta o destino, cinza "Destination folder set" quando preenchido, verde "Ready to import!" quando tudo está pronto
  - **Detecção de duplicatas**: Se um arquivo já existir no destino, você pode escolher entre Pular, Sobrescrever ou Pular Todos os duplicados
  - **Scan recursivo de pastas**: Opção para incluir todas as subpastas automaticamente
  - **Tags automáticas**: Os nomes das pastas são convertidos em tags, facilitando a organização de bibliotecas grandes (ex: arquivos em `/music/combat/boss/` recebem as tags "combat" e "boss")
  - **Preview antes de importar**: Lista todos os arquivos encontrados com checkboxes para selecionar quais deseja importar
  - **Detecção de formatos não suportados**: Arquivos em formatos incompatíveis com o navegador são destacados com aviso
  - **Cor padrão para Soundboard**: Ao importar sons para o Soundboard, é possível escolher uma cor que será aplicada a todos os cards
  - **Barra de progresso**: Acompanhe o andamento do upload e importação em tempo real

- **Thumbnails quadradas na seção "Recently Added"**: Os cards de música na tela inicial agora têm tamanho fixo com thumbnails sempre quadradas. Isso garante que o botão de play (que aparece no hover) seja sempre visível, independente da proporção da janela. O layout também é mais responsivo, criando múltiplas linhas automaticamente conforme necessário.

- **Toggle de Preview/Broadcast redesenhado**: O controle de modo Preview/Broadcast foi movido da sidebar para o header principal, tornando-o sempre visível mesmo ao rolar a página. O novo design apresenta um elegante switch estilo interruptor que desliza suavemente entre os modos, com cores distintas (laranja para Preview, verde para Broadcast) e uma animação pulsante quando em modo Broadcast para indicar que o áudio está sendo transmitido para os players.

- **Indicador "Up Next" na lista de músicas**: Agora você pode ver qual será a próxima música a tocar! Um badge discreto "NEXT" aparece ao lado do nome da faixa que será reproduzida em seguida, tanto na Library quanto nas Playlists. O indicador só aparece quando o shuffle está desativado (já que no modo aleatório a próxima música é imprevisível). Ao passar o mouse sobre a faixa, o badge ganha destaque em verde. O badge agora também não é mais cortado quando o nome da música é muito longo.

- **Ícones de controle mais intuitivos na lista de músicas**: Os ícones da coluna de reprodução agora refletem melhor o estado atual da música:
  - **Tocando**: Mostra o ícone animado de ondas sonoras. Ao passar o mouse, mostra o ícone de pause (indicando que clicar irá pausar)
  - **Pausado**: Mostra o ícone de pause estático. Ao passar o mouse, mostra o ícone de play (indicando que clicar irá retomar)
  - **Outras músicas**: Mostra o número da faixa. Ao passar o mouse, mostra o ícone de play

- **Aba Playlists completamente redesenhada**: A aba Playlists agora oferece uma experiência completa e autossuficiente, inspirada no Spotify. O novo layout de dois painéis mostra todas as suas playlists à esquerda com mini capas (mosaico 2x2 das thumbnails das músicas) e contagem de tracks, enquanto o painel direito exibe os detalhes e músicas da playlist selecionada. Você pode trocar rapidamente entre playlists sem perder o contexto. A primeira playlist é selecionada automaticamente ao abrir a aba. A seção duplicada de playlists que existia na sidebar foi removida para uma interface mais limpa e organizada.
  - **Botão Play/Pause inteligente**: Ao passar o mouse sobre uma playlist, aparece um botão de play verde. Quando a playlist está tocando, o botão fica sempre visível com ícone de pause. Quando pausada, mostra o ícone de play. Clicar alterna entre tocar e pausar, permitindo controle rápido sem precisar ir ao player bar.

- **Sidebar reorganizada e com cores por seção**: A sidebar foi reestruturada para melhor organização visual:
  - **Home agora é independente**: O item "Home" foi movido para fora do grupo Music, ficando no topo como entrada principal
  - **Nomenclatura padronizada**: "Library" foi renomeado para "Music Library" e "Soundboard" para "Soundboard Library", seguindo o padrão de "Ambience Library"
  - **Cores por categoria**: Cada seção agora tem sua cor característica - verde para Music, roxo/azul para Ambience, laranja para Soundboard e dourado para GM Tools
  - **Interface mais limpa**: Os botões "Add Music" e "Add Ambience" foram removidos do rodapé da sidebar (essas funções continuam disponíveis dentro de cada Library)

- **Tamanho mínimo da janela ajustado**: O tamanho mínimo da janela foi aumentado de 800x600 para 950x650 pixels. Isso garante que o player bar com os controles de Music e Ambience seja sempre exibido corretamente, evitando sobreposição de elementos quando a janela é redimensionada.

- **Mini Player Mode**: Nova funcionalidade que permite usar o Jukebox em modo compacto (400x500px), ideal para manter o controle de áudio sem ocupar muito espaço na tela. Ao clicar no botão amarelo de minimizar, a janela agora se transforma em um mini player completo estilo Spotify:
  - **Três abas integradas**: Alterne rapidamente entre Music, Ambience e Soundboard com um clique
  - **Busca instantânea**: Encontre tracks digitando - a busca filtra em tempo real conforme você digita, com suporte a ESC para limpar
  - **Lista compacta de tracks**: Visualize suas músicas e ambiences com artwork, nome, tags e duração em formato otimizado
  - **Grid de Soundboard**: Acesse seus sons favoritos em um grid compacto com indicador visual de sons tocando
  - **Player bar sempre visível**: Controles de música (play/pause, anterior, próximo, volume) e ambience (play, stop) sempre à mão
  - **Navegação fluida**: Clique em qualquer track para tocar imediatamente, sem precisar expandir a janela

- **Micro Mode (Ícone Flutuante)**: Modo ainda mais compacto onde o Jukebox se transforma em um ícone circular flutuante de 60x60px - perfeito para quando você quer controle mínimo sem distrações:
  - **Artwork da música atual**: Exibe a capa da música tocando com animação pulsante verde
  - **Anel indicador de reprodução**: Um anel verde gira ao redor do ícone quando há música tocando
  - **Controles no hover**: Passe o mouse para revelar botões de anterior, play/pause e próximo
  - **Posição personalizável**: Arraste o ícone para qualquer lugar da tela - a posição é lembrada mesmo após recarregar
  - **Expansão rápida**: Clique para voltar ao Mini Mode, duplo-clique para abrir a janela completa
  - **Indicador de Ambience**: Um pequeno ícone aparece quando há ambience tocando junto com a música

- **Transições suaves entre modos**: Ao alternar entre os três modos de visualização (Normal, Mini e Micro), a janela agora faz uma transição animada suave, proporcionando uma experiência visual mais polida e profissional.
