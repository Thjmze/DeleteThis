# Narrator's Jukebox

A complete, elegant music and sound management system for Foundry VTT. Features a Spotify-inspired dark interface with dual audio channels, soundboard, YouTube support, and glassmorphism design.

---

## 🎉 What's New in v3.0.0

**Coming from v2?** Here's what's new:

### Ambience Layer Mixer
Stack multiple ambience tracks simultaneously! Create rich soundscapes by layering rain, thunder, tavern chatter, and more - each with independent volume controls.

### Player Widget Modes
Access your music without the full window:
- **Mini Mode**: Compact floating player with essential controls
- **Micro Mode**: Tiny draggable icon - click to expand, right-click for quick actions

### Debug Mode
Troubleshooting issues? Enable Debug Mode in module settings to see detailed console logs. Disabled by default for a clean console.

### Under the Hood
Complete code refactoring from ~7,000 lines in one file to ~35 modular ES6 files. Better performance, easier maintenance, and a foundation for future features.

---

## Features

### Dual Audio Channels
Play **Music** and **Ambience** simultaneously! Set the mood with epic battle music while rain sounds play in the background - each with independent volume controls.

- **Music Channel**: For soundtracks, battle themes, and scene music
- **Ambience Channel**: For background sounds like rain, tavern noise, forest ambience
- **Independent Controls**: Separate play/pause, volume, and loop settings for each channel

### Soundboard
Quick-trigger sound effects during your sessions! Perfect for:
- Door creaks and footsteps
- Thunder and weather effects
- Monster roars and growls
- Magic spell sounds
- Any short sound effect you need on demand

**Soundboard Features:**
- **Customizable Cards**: Set colors and icons for easy identification
- **Multiple Sounds**: Play several sounds simultaneously
- **In/Out Trim Points**: Set start and end times to play only the part you need (great for YouTube clips!)
- **Per-Card Controls**: Loop, Preview, or Broadcast each sound individually
- **Quick Stop**: Stop all sounds with one click

### Music Library
- **Multiple Sources**: YouTube videos and local files (MP3, OGG, WAV)
- **Tag Organization**: Categorize by mood, scene type, or custom tags
- **Search & Filter**: Quickly find tracks by name or tags
- **Batch Import**: Import multiple YouTube URLs at once
- **Auto-Thumbnails**: Automatic thumbnail extraction from YouTube

### Ambience Library
Separate library dedicated to ambient sounds:
- **Looping by Default**: Ambience tracks loop automatically
- **Tag Filtering**: Organize by environment type (forest, city, dungeon, etc.)
- **Independent from Music**: Switch ambience without affecting your music

### Mood Boards
Quick-access cards on the home screen for instant mood changes:
- **Combat** - Battle-ready music
- **Social** - Tavern and conversation themes
- **Mystery** - Suspenseful and investigative
- **Sorcery** - Magical and arcane
- **Travel** - Journey and exploration
- **Tavern** - Festive and relaxed

Click any mood to instantly filter your library!

### Playlist Management
- **Create Unlimited Playlists**: Organize by campaign, scene, or mood
- **Shuffle & Loop**: Random or sequential playback
- **Visual Indicators**: See which playlist is currently playing
- **Easy Management**: Drag tracks, rename, delete with ease

### Preview & Broadcast Modes
- **Preview Mode**: Only the GM hears - perfect for testing tracks
- **Broadcast Mode**: All players hear the music in sync
- **Per-Sound Control**: Soundboard cards can be preview or broadcast individually

### Player Suggestions
Players can suggest tracks to the GM!
- Players submit YouTube URLs or track ideas
- GM receives suggestions in a dedicated panel
- Approve to add directly to library, or reject

### Beautiful Interface
- **Spotify-Inspired Design**: Dark theme with modern aesthetics
- **Glassmorphism Effects**: Elegant blur and transparency
- **Smooth Animations**: Fluid transitions throughout
- **Responsive Layout**: Works on various screen sizes
- **Unified Player Bar**: Always-visible controls at the bottom

## Installation

### For Patreon Supporters

1. Download the latest release from the Patreon post
2. Extract the `narrator-jukebox` folder to your Foundry VTT `Data/modules/` directory
3. Enable the module in your world's Module Management
4. Refresh your browser

### Opening the Jukebox

- **Keyboard Shortcut**: `Ctrl + Shift + M`
- **Scene Controls**: Click the music note icon in the toolbar
- **Journal Sidebar**: Click the Jukebox button

## Usage Guide

### Adding Music

1. Click **"Add Music"** in the sidebar
2. Choose source: **YouTube** or **Local File**
3. Paste URL or browse for file
4. Add tags for organization
5. Set default volume
6. Click **"Add"**

### Adding Ambience

1. Click **"Add Ambience"** in the sidebar
2. Same process as music
3. Ambience appears in the dedicated Ambience Library

### Using the Soundboard

1. Navigate to **Soundboard** in the sidebar
2. Click **"Add Sound"**
3. Configure:
   - **Name**: Easy identifier
   - **Source**: YouTube or local file
   - **Volume**: Default playback volume
   - **Color**: Card background color
   - **Icon**: Visual identifier (bolt for thunder, paw for animals, etc.)
   - **Trim (In/Out)**: Optional start/end times (format: `0:05` or `1:30`)
4. Click the card to play!

**Card Controls:**
- **Play/Stop**: Main button to trigger sound
- **Loop**: Toggle continuous playback
- **Broadcast**: Toggle between preview (only you) and broadcast (all players)

### Creating Playlists

1. Click the **"+"** button in the Playlists section
2. Name your playlist
3. Add tracks via the **"+"** button on any track
4. Click playlist name to view and play

### Switching Modes

Use the mode buttons in the sidebar footer:
- **Headphones Icon**: Preview Mode (GM only)
- **Broadcast Tower Icon**: Broadcast Mode (all players)

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl + Shift + M` | Open/Close Jukebox |

## Tips & Best Practices

### Organizing Your Library

Use consistent tags:
- **Mood**: `epic`, `tense`, `calm`, `mysterious`, `sad`, `happy`
- **Scene**: `combat`, `exploration`, `social`, `tavern`, `dungeon`
- **Intensity**: `boss`, `ambient`, `background`, `intense`

### YouTube Tips

- Use videos without mid-roll ads
- For soundboard, use the **In/Out trim** to skip intros
- High-quality audio uploads sound best

### Volume Balance

- Keep ambience lower than music (30-50%)
- Soundboard effects can be louder for impact
- Use per-track volume for consistent levels

## Technical Details

### Supported Formats

- **YouTube**: Any public YouTube video URL
- **Local Files**: MP3, OGG, WAV

### Browser Support

- **Chrome/Edge**: Full support
- **Firefox**: Full support
- **Safari**: Full support (may require interaction for autoplay)

### Data Storage

All data stored in Foundry world settings:
- Music library
- Ambience library
- Soundboard sounds
- Playlists
- Mood configurations

## Troubleshooting

**Music won't play:**
- Check browser autoplay policies
- Ensure YouTube videos aren't region-blocked
- Verify local file paths

**Players can't hear:**
- Confirm you're in Broadcast mode
- Check player browser audio settings
- Verify socketlib module is installed

**Soundboard trim not working:**
- Use format `m:ss` (e.g., `0:05`, `1:30`)
- For YouTube, times are approximate (±1 second)

## Credits

Created by **Wand & Widgets** for the Foundry VTT community.

Design inspired by Spotify's modern UI/UX.

## Support

This is a premium module available to Patreon supporters.

For support, feature requests, or bug reports, please contact through Patreon.

---

**Enjoy your sessions with the perfect soundtrack!**
