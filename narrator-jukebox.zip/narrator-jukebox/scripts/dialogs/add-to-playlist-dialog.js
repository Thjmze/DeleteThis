/**
 * Add to Playlist Dialog
 * Dialog for adding tracks to existing playlists
 */

import { createModuleModal } from './base-dialog.js';
import { debugError } from '../utils/debug.js';
import { localize, format } from '../utils/i18n.js';

const MUSIC_ADD_PLAYLIST_CLASSES = [
  'narrator-jukebox-dialog',
  'add-track-dialog-window',
  'music-theme',
  'music-context-dialog',
  'music-add-playlist-dialog'
];

/**
 * Shows the Add to Playlist dialog
 * @param {Object} options - Dialog options
 * @param {string} options.musicId - The music track ID to add
 * @param {Object} options.jukebox - The NarratorJukebox instance
 * @param {Function} options.onSuccess - Callback on successful add
 * @returns {Dialog|null} The dialog instance or null if no playlists/track not found
 */
export function showAddToPlaylistDialog({ musicId, jukebox, onSuccess }) {
  const track = jukebox.music.find(m => m.id === musicId);
  if (!track) {
    ui.notifications.error(localize('Notifications.TrackNotFound'));
    return null;
  }

  const playlists = jukebox.playlists;

  if (!playlists || playlists.length === 0) {
    ui.notifications.warn(localize('Notifications.NoPlaylistsAvailable'));
    return null;
  }

  const defaultPlaylist = playlists.find(pl => !pl.system) || playlists[0];
  const playlistOptions = playlists.map(pl => `
    <div class="playlist-option" data-playlist-id="${escapeAttribute(pl.id)}" role="button" tabindex="0">
      <div class="playlist-option-icon">
        <i class="fas ${pl.systemType === 'favorites' ? 'fa-heart' : 'fa-list'}"></i>
      </div>
      <div class="playlist-option-info">
        <span class="playlist-option-name">${escapeHtml(pl.name)}</span>
        <span class="playlist-option-count">${format('Dialog.Playlist.TracksCount', { count: (pl.musicIds || pl.tracks || []).length })}</span>
      </div>
      <div class="playlist-option-check">
        <i class="fas fa-plus"></i>
      </div>
    </div>
  `).join('');

  const content = `
    <div class="add-track-dialog playlist-select-dialog">
      <div class="dialog-header">
        <div class="header-icon music-icon">
          <i class="fas fa-plus"></i>
        </div>
        <div class="header-info">
          <h2>${localize('Dialog.Playlist.AddToTitle')}</h2>
          <p>${format('Dialog.Playlist.AddToSubtitle', { name: escapeHtml(track.name) })}</p>
        </div>
      </div>

      <div class="playlist-options-container">
        ${playlistOptions}
      </div>

      <input type="hidden" id="playlist-select" value="${escapeAttribute(defaultPlaylist?.id || '')}">

      <div class="music-premium-actions playlist-select-actions">
        <button type="button" class="music-premium-btn secondary playlist-dialog-cancel">
          ${localize('Common.Cancel')}
        </button>
        <button type="button" class="music-premium-btn primary playlist-dialog-add">
          <i class="fas fa-plus"></i>
          ${localize('Dialog.Playlist.AddToButton')}
        </button>
      </div>
    </div>
  `;

  return createModuleModal({
    title: localize('Dialog.Playlist.AddToTitle'),
    content,
    classes: MUSIC_ADD_PLAYLIST_CLASSES,
    overlayClasses: ['music-context-modal-overlay'],
    closeLabel: localize('Header.Close'),
    initialFocus: '.playlist-option',
    onRender: ({ body, close }) => {
      bindPlaylistSelection({ html: body, playlists, musicId, track, jukebox, onSuccess, close, defaultPlaylistId: defaultPlaylist?.id || '' });
    }
  });
}

function bindPlaylistSelection({ html, playlists, musicId, track, jukebox, onSuccess, close, defaultPlaylistId }) {
  let isAdding = false;
  const playlistOptionsEl = html.find('.playlist-option');
  const hiddenInput = html.find('#playlist-select');
  const addButton = html.find('.playlist-dialog-add');

  hiddenInput.val(defaultPlaylistId || playlists[0]?.id || '');
  const selectedOption = playlistOptionsEl
    .filter((_, el) => String($(el).data('playlist-id')) === String(hiddenInput.val()))
    .first();
  (selectedOption.length ? selectedOption : playlistOptionsEl.first()).addClass('selected');

  playlistOptionsEl.on('keydown', event => {
    if (event.key !== 'Enter' && event.key !== ' ') return;
    event.preventDefault();
    event.currentTarget.click();
  });

  playlistOptionsEl.on('click', (event) => {
    const option = $(event.currentTarget);
    playlistOptionsEl.removeClass('selected');
    option.addClass('selected');
    hiddenInput.val(option.data('playlist-id'));
  });

  html.find('.playlist-dialog-cancel').on('click', () => close());

  addButton.on('click', async () => {
    if (isAdding) return;
    const playlistId = hiddenInput.val();
    if (!playlistId) return;

    isAdding = true;
    addButton.prop('disabled', true).addClass('is-loading');

    try {
      await jukebox.addToPlaylist(playlistId, musicId);
      const playlist = playlists.find(p => p.id === playlistId);
      ui.notifications.info(format('Notifications.AddedToPlaylist', { track: track.name, playlist: playlist?.name || 'playlist' }));
      close();
      if (onSuccess) onSuccess();
    } catch (err) {
      isAdding = false;
      addButton.prop('disabled', false).removeClass('is-loading');
      debugError("Failed to add to playlist:", err);
      ui.notifications.error(format('Notifications.FailedToAddToPlaylist', { error: err.message }));
    }
  });
}

/**
 * Escape HTML special characters
 * @param {string} str - String to escape
 * @returns {string} Escaped string
 */
function escapeHtml(str) {
  if (!str) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function escapeAttribute(str) {
  return escapeHtml(str).replace(/"/g, '&quot;');
}

export default showAddToPlaylistDialog;
