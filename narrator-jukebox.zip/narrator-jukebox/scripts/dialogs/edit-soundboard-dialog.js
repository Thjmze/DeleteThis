/**
 * Edit Soundboard Dialog
 * Dialog for editing existing soundboard sounds
 */

import {
  JUKEBOX,
  SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MAX,
  SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MIN
} from '../core/constants.js';
import { formatTimeForInput } from '../utils/time-format.js';
import { createModuleModal, DIALOG_CLASSES } from './base-dialog.js';
import { validateField, validateUrl } from '../services/validation-service.js';
import { findDuplicateTrack, normalizeTrackData } from '../services/track-data-service.js';
import { debugLog, debugError } from '../utils/debug.js';
import { localize, format } from '../utils/i18n.js';
import { extractYouTubeVideoId } from '../utils/youtube-utils.js';

/**
 * Color presets for soundboard cards
 */
const COLOR_PRESETS = [
  { color: '#ff6b35', titleKey: 'Colors.Orange' },
  { color: '#e74c3c', titleKey: 'Colors.Red' },
  { color: '#9b59b6', titleKey: 'Colors.Purple' },
  { color: '#3498db', titleKey: 'Colors.Blue' },
  { color: '#1abc9c', titleKey: 'Colors.Teal' },
  { color: '#2ecc71', titleKey: 'Colors.Green' },
  { color: '#f39c12', titleKey: 'Colors.Yellow' },
  { color: '#e91e63', titleKey: 'Colors.Pink' }
];

/**
 * Icon presets for soundboard cards
 */
const ICON_PRESETS = [
  { icon: 'fas fa-volume-up', titleKey: 'Icons.Sound' },
  { icon: 'fas fa-bolt', titleKey: 'Icons.Thunder' },
  { icon: 'fas fa-wind', titleKey: 'Icons.Wind' },
  { icon: 'fas fa-water', titleKey: 'Icons.Water' },
  { icon: 'fas fa-fire', titleKey: 'Icons.Fire' },
  { icon: 'fas fa-door-open', titleKey: 'Icons.Door' },
  { icon: 'fas fa-skull', titleKey: 'Icons.Skull' },
  { icon: 'fas fa-paw', titleKey: 'Icons.Animal' },
  { icon: 'fas fa-sword', titleKey: 'Icons.Sword' },
  { icon: 'fas fa-magic', titleKey: 'Icons.Magic' },
  { icon: 'fas fa-bell', titleKey: 'Icons.Bell' },
  { icon: 'fas fa-ghost', titleKey: 'Icons.Ghost' },
  { icon: 'fas fa-heart-broken', titleKey: 'Icons.Heartbreak' },
  { icon: 'fas fa-bomb', titleKey: 'Icons.Explosion' },
  { icon: 'fas fa-crow', titleKey: 'Icons.Bird' },
  { icon: 'fas fa-clock', titleKey: 'Icons.Clock' }
];

const SOUND_EDIT_DIALOG_CLASSES = [...DIALOG_CLASSES.soundboard, 'soundboard-context-dialog', 'soundboard-edit-details-dialog'];

/**
 * Shows the Edit Soundboard dialog
 * @param {Object} options - Dialog options
 * @param {string} options.soundId - The sound ID to edit
 * @param {Object} options.jukebox - The NarratorJukebox instance
 * @param {Function} options.onSuccess - Callback on successful save
 * @returns {Object|null} The modal controller or null if sound not found
 */
export function showEditSoundboardDialog({ soundId, jukebox, onSuccess }) {
  const sound = jukebox.soundboard.find(s => s.id === soundId);
  if (!sound) {
    ui.notifications.error(localize('Notifications.SoundNotFound'));
    return null;
  }

  const startTimeValue = formatTimeForInputLocal(sound.startTime);
  const endTimeValue = formatTimeForInputLocal(sound.endTime);
  const randomIntervalMinValue = formatTimeForInputLocal(sound.randomIntervalMin ?? SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MIN);
  const randomIntervalMaxValue = formatTimeForInputLocal(sound.randomIntervalMax ?? SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MAX);

  const colorPresetsHtml = COLOR_PRESETS.map(p =>
    `<button type="button" class="color-preset" data-color="${p.color}" style="background: ${p.color};" title="${localize(p.titleKey)}"></button>`
  ).join('');

  const iconPresetsHtml = ICON_PRESETS.map(p =>
    `<button type="button" class="icon-preset" data-icon="${p.icon}" title="${localize(p.titleKey)}"><i class="${p.icon}"></i></button>`
  ).join('');

  const accent = sound.color || '#ff6b35';
  const sourceLabel = sound.source === 'youtube' ? localize('Labels.YouTube') : localize('Labels.LocalFile');
  const headerPreview = sound.thumbnail
    ? `<img src="${escapeAttribute(sound.thumbnail)}" alt="">`
    : `<i class="${escapeAttribute(sound.icon || 'fas fa-volume-up')}"></i>`;

  const content = `
    <div class="add-track-dialog soundboard-dialog">
      <div class="dialog-header soundboard-dialog-header" style="--soundboard-dialog-accent: ${escapeAttribute(accent)};">
        <div class="header-icon soundboard-icon">
          ${headerPreview}
        </div>
        <div class="header-info">
          <h2>${localize('Dialog.Soundboard.EditTitle')}</h2>
          <p>${escapeHtml(sound.name || localize('Common.ThisSound'))} / ${escapeHtml(sourceLabel)}</p>
        </div>
      </div>
      <form class="track-form">
        <div class="form-section">
          <div class="form-group">
            <label><i class="fas fa-heading"></i> ${localize('Labels.SoundName')}</label>
            <input type="text" name="name" value="${escapeAttribute(sound.name)}" spellcheck="false">
          </div>

          <div class="form-group url-group">
            <label><i class="fas fa-link"></i> ${localize('Labels.URL')}</label>
            <input type="text" name="url" value="${escapeAttribute(sound.url)}" spellcheck="false">
          </div>

          <div class="form-group">
            <label><i class="fas fa-volume-up"></i> ${localize('Labels.DefaultVolume')}</label>
            <div class="volume-input-wrapper">
              <input type="range" name="volume" min="0" max="100" value="${Math.round((sound.volume || 0.8) * 100)}" class="volume-range">
              <span class="volume-value">${Math.round((sound.volume || 0.8) * 100)}%</span>
            </div>
          </div>

          <div class="form-group soundboard-loop-default-group">
            <label><i class="fas fa-redo-alt"></i> Default Playback</label>
            <label class="soundboard-loop-default-row">
              <input type="checkbox" name="loop" ${sound.loop && !sound.randomIntervalEnabled ? 'checked' : ''}>
              <span class="soundboard-loop-default-switch" aria-hidden="true"></span>
              <span class="soundboard-loop-default-copy">
                <strong>Loop by default</strong>
                <small>Use for rain, fire, engines, and other sustained cues.</small>
              </span>
            </label>
          </div>

          <div class="form-group soundboard-interval-default-group">
            <label><i class="fas fa-clock"></i> Random Interval</label>
            <label class="soundboard-loop-default-row soundboard-interval-default-row">
              <input type="checkbox" name="randomIntervalEnabled" ${sound.randomIntervalEnabled ? 'checked' : ''}>
              <span class="soundboard-loop-default-switch" aria-hidden="true"></span>
              <span class="soundboard-loop-default-copy">
                <strong>Play at random intervals</strong>
                <small>Use for occasional stingers, distant screams, and other surprise cues.</small>
              </span>
            </label>
            <div class="soundboard-interval-fields ${sound.randomIntervalEnabled ? '' : 'inactive'}">
              <div class="trim-input-group">
                <label>Minimum delay</label>
                <div class="time-input-wrapper">
                  <input type="text" name="randomIntervalMin" value="${escapeAttribute(randomIntervalMinValue)}" class="time-input" spellcheck="false">
                  <span class="time-hint">${localize('Hints.TimeFormat')}</span>
                </div>
              </div>
              <div class="trim-input-group">
                <label>Maximum delay</label>
                <div class="time-input-wrapper">
                  <input type="text" name="randomIntervalMax" value="${escapeAttribute(randomIntervalMaxValue)}" class="time-input" spellcheck="false">
                  <span class="time-hint">${localize('Hints.TimeFormat')}</span>
                </div>
              </div>
            </div>
            <small class="trim-help">When active, the cue plays once, then waits a random delay between these values.</small>
          </div>

          <div class="form-group trim-group">
            <label><i class="fas fa-cut"></i> ${localize('Dialog.Soundboard.TrimLabel')} <span class="optional">${localize('Common.Optional')}</span></label>
            <div class="trim-inputs">
              <div class="trim-input-group">
                <label>${localize('Dialog.Soundboard.StartIn')}</label>
                <div class="time-input-wrapper">
                  <input type="text" name="startTime" value="${escapeAttribute(startTimeValue)}" placeholder="0:00" class="time-input" spellcheck="false">
                  <span class="time-hint">${localize('Hints.TimeFormat')}</span>
                </div>
              </div>
              <div class="trim-input-group">
                <label>${localize('Dialog.Soundboard.EndOut')}</label>
                <div class="time-input-wrapper">
                  <input type="text" name="endTime" value="${escapeAttribute(endTimeValue)}" placeholder="${escapeAttribute(localize('Dialog.Soundboard.EndPlaceholder'))}" class="time-input" spellcheck="false">
                  <span class="time-hint">${localize('Hints.TimeFormat')}</span>
                </div>
              </div>
            </div>
            <small class="trim-help">${localize('Hints.TrimHelpShort')}</small>
          </div>

          <div class="form-group">
            <label><i class="fas fa-palette"></i> ${localize('Labels.CardColor')}</label>
            <div class="color-picker-wrapper">
              <input type="color" name="color" value="${escapeAttribute(accent)}" class="color-picker">
              <div class="color-presets">
                ${colorPresetsHtml}
              </div>
            </div>
          </div>

          <div class="form-group">
            <label><i class="fas fa-icons"></i> ${localize('Labels.Icon')}</label>
            <div class="icon-picker-wrapper">
              <input type="hidden" name="icon" value="${escapeAttribute(sound.icon || 'fas fa-volume-up')}">
              <div class="icon-preview">
                <i class="${escapeAttribute(sound.icon || 'fas fa-volume-up')}"></i>
              </div>
              <div class="icon-presets">
                ${iconPresetsHtml}
              </div>
            </div>
          </div>

          <div class="form-group">
            <label><i class="fas fa-image"></i> ${localize('Labels.Thumbnail')}</label>
            <input type="text" name="thumbnail" value="${escapeAttribute(sound.thumbnail || '')}" spellcheck="false">
          </div>
        </div>
        <div class="soundboard-premium-actions soundboard-edit-actions">
          <button type="button" class="soundboard-premium-btn secondary soundboard-dialog-cancel">
            ${localize('Common.Cancel')}
          </button>
          <button type="submit" class="soundboard-premium-btn primary">
            <i class="fas fa-save"></i>
            ${localize('Common.Save')}
          </button>
        </div>
      </form>
    </div>
  `;

  let isSaving = false;
  const modal = createModuleModal({
    title: localize('Dialog.Soundboard.EditTitle'),
    content,
    classes: SOUND_EDIT_DIALOG_CLASSES,
    closeLabel: localize('Header.Close'),
    initialFocus: 'input[name="name"]',
    onRender: ({ body, close }) => {
      setupEditSoundboardListeners(body);
      body.find('.soundboard-dialog-cancel').on('click', () => close());
      body.find('.track-form').on('submit', async (event) => {
        event.preventDefault();
        if (isSaving) return;

        isSaving = true;
        const submitButton = body.find('button[type="submit"]');
        submitButton.prop('disabled', true);

        try {
          const result = await handleEditSoundboardSubmit(body, soundId, sound, jukebox);
          if (result === false) return;
          if (onSuccess) onSuccess();
          close();
        } catch (err) {
          debugError("Failed to update sound:", err);
          ui.notifications.error(format('Notifications.FailedToUpdate', { error: err.message }));
        } finally {
          if (!modal?.isClosed) {
            isSaving = false;
            submitButton.prop('disabled', false);
          }
        }
      });
    }
  });

  return modal;
}

/**
 * Escape HTML special characters
 * @param {string} str - String to escape
 * @returns {string} Escaped string
 */
function escapeHtml(str) {
  if (!str) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function escapeAttribute(str) {
  return escapeHtml(str).replace(/"/g, '&quot;');
}

/**
 * Format seconds to mm:ss for input fields
 * @param {number|null} seconds - Seconds to format
 * @returns {string} Formatted time string
 */
function formatTimeForInputLocal(seconds) {
  if (seconds === null || seconds === undefined) return '';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

/**
 * Parse time string (mm:ss or hh:mm:ss) to seconds
 * @param {string} timeStr - Time string to parse
 * @returns {number|null} Seconds or null if empty/invalid
 */
function parseTime(timeStr) {
  if (!timeStr || !timeStr.trim()) return null;
  const parts = timeStr.trim().split(':');
  if (parts.length === 1) {
    return parseFloat(parts[0]) || null;
  } else if (parts.length === 2) {
    const mins = parseInt(parts[0]) || 0;
    const secs = parseFloat(parts[1]) || 0;
    return mins * 60 + secs;
  } else if (parts.length === 3) {
    const hours = parseInt(parts[0]) || 0;
    const mins = parseInt(parts[1]) || 0;
    const secs = parseFloat(parts[2]) || 0;
    return hours * 3600 + mins * 60 + secs;
  }
  return null;
}

/**
 * Sets up event listeners for the edit soundboard dialog
 * @param {jQuery} html - Dialog HTML
 */
function setupEditSoundboardListeners(html) {
  const volumeRange = html.find('input[name="volume"]');
  const volumeValue = html.find('.volume-value');
  const colorPicker = html.find('input[name="color"]');
  const iconHidden = html.find('input[name="icon"]');
  const iconPreview = html.find('.icon-preview i');
  const loopInput = html.find('input[name="loop"]');
  const intervalInput = html.find('input[name="randomIntervalEnabled"]');
  const intervalFields = html.find('.soundboard-interval-fields');

  const syncIntervalFields = () => {
    intervalFields.toggleClass('inactive', !intervalInput.prop('checked'));
  };
  syncIntervalFields();

  loopInput.on('change', () => {
    if (loopInput.prop('checked')) {
      intervalInput.prop('checked', false);
      syncIntervalFields();
    }
  });

  intervalInput.on('change', () => {
    if (intervalInput.prop('checked')) {
      loopInput.prop('checked', false);
    }
    syncIntervalFields();
  });

  // Volume slider update
  volumeRange.on('input', (e) => {
    volumeValue.text(`${e.target.value}%`);
  });

  // Color presets
  html.find('.color-preset').click((e) => {
    e.preventDefault();
    const color = $(e.currentTarget).data('color');
    colorPicker.val(color);
  });

  // Icon presets
  html.find('.icon-preset').click((e) => {
    e.preventDefault();
    const icon = $(e.currentTarget).data('icon');
    iconHidden.val(icon);
    iconPreview.attr('class', icon);
    html.find('.icon-preset').removeClass('active');
    $(e.currentTarget).addClass('active');
  });
}

function getIntervalDelayValue(input, fallback) {
  const parsed = parseTime(input?.value);
  return parsed && parsed > 0 ? parsed : fallback;
}

/**
 * Handles the edit soundboard form submission
 * @param {jQuery} html - Dialog HTML
 * @param {string} soundId - The sound ID being edited
 * @param {Object} sound - The original sound data
 * @param {Object} jukebox - The NarratorJukebox instance
 * @returns {boolean|void} - Returns false to prevent dialog from closing
 */
async function handleEditSoundboardSubmit(html, soundId, sound, jukebox) {
  const form = html.find('form')[0];

  const nameInput = form.name;
  const urlInput = form.url;

  let isValid = true;

  if (!validateField(nameInput, localize('Validation.SoundNameRequired'))) {
    isValid = false;
  }

  const validationSource = extractYouTubeVideoId(form.url.value.trim()) ? 'youtube' : 'local';

  if (!validateUrl(urlInput.value, validationSource)) {
    if (!validateField(urlInput, localize('Validation.ValidURLRequired'))) {
      isValid = false;
    }
  }

  if (!isValid) {
    ui.notifications.warn(localize('Validation.FixValidationErrorsSave'));
    return false;
  }

  const randomIntervalEnabled = form.randomIntervalEnabled.checked;
  const randomIntervalMin = getIntervalDelayValue(form.randomIntervalMin, SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MIN);
  const randomIntervalMax = getIntervalDelayValue(form.randomIntervalMax, SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MAX);

  if (randomIntervalEnabled && randomIntervalMax < randomIntervalMin) {
    ui.notifications.warn('Random interval maximum must be greater than or equal to the minimum.');
    return false;
  }

  const data = normalizeTrackData({
    source: validationSource,
    name: form.name.value,
    url: form.url.value,
    volume: parseInt(form.volume.value, 10) / 100,
    loop: randomIntervalEnabled ? false : form.loop.checked,
    randomIntervalEnabled,
    randomIntervalMin,
    randomIntervalMax,
    color: form.color.value,
    icon: form.icon.value,
    thumbnail: form.thumbnail.value,
    startTime: parseTime(form.startTime.value),
    endTime: parseTime(form.endTime.value)
  }, { partial: true });

  // Only flag as duplicate if URL or trim points actually changed. Otherwise
  // an intentional duplicate elsewhere in the library would block all edits.
  // Soundboard duplicate identity is url + startTime + endTime.
  const originalSound = jukebox.soundboard.find(s => s.id === soundId);
  const originalKey = `${(originalSound?.url ?? '').trim()}|${originalSound?.startTime ?? ''}|${originalSound?.endTime ?? ''}`;
  const newKey = `${(data.url ?? '').trim()}|${data.startTime ?? ''}|${data.endTime ?? ''}`;
  if (originalKey !== newKey) {
    const duplicate = findDuplicateTrack(jukebox, 'soundboard', data, { excludeId: soundId });
    if (duplicate) {
      ui.notifications.warn(format('Notifications.DuplicateInLibrary', { name: duplicate.name || data.name }));
      return false;
    }
  }

  try {
    await jukebox.updateSoundboardSound(soundId, data);
    ui.notifications.info(format('Notifications.Updated', { name: data.name }));
  } catch (err) {
    debugError("Failed to update sound:", err);
    ui.notifications.error(format('Notifications.FailedToUpdate', { error: err.message }));
    return false;
  }
}

export default showEditSoundboardDialog;
