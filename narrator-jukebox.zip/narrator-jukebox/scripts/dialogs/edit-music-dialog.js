/**
 * Edit Music Dialog
 * Dialog for editing existing music tracks
 */

import { browseFilePicker } from '../utils/file-picker-compat.js';
import { createModuleModal } from './base-dialog.js';
import { validateField, validateUrl } from '../services/validation-service.js';
import { findDuplicateTrack, normalizeTrackData } from '../services/track-data-service.js';
import { debugError } from '../utils/debug.js';
import { localize, format } from '../utils/i18n.js';
import { extractYouTubeVideoId, isYouTubeUrl } from '../utils/youtube-utils.js';

const MUSIC_EDIT_DIALOG_CLASSES = [
  'narrator-jukebox-dialog',
  'add-track-dialog-window',
  'music-theme',
  'music-context-dialog',
  'music-edit-details-dialog'
];

/**
 * Shows the Edit Music dialog
 * @param {Object} options - Dialog options
 * @param {string} options.trackId - The track ID to edit
 * @param {Object} options.jukebox - The NarratorJukebox instance
 * @param {Function} options.onSuccess - Callback on successful save
 * @returns {Dialog|null} The dialog instance or null if track not found
 */
export function showEditMusicDialog({ trackId, jukebox, onSuccess }) {
  const track = jukebox.music.find(m => m.id === trackId);
  if (!track) {
    ui.notifications.error(localize('Notifications.TrackNotFound'));
    return null;
  }
  const effectiveSource = extractYouTubeVideoId(track.url || track.path || '') ? 'youtube' : (track.source || 'local');

  const thumbnailPreview = track.thumbnail
    ? `<img src="${escapeAttribute(track.thumbnail)}" alt="Thumbnail">`
    : '<i class="fas fa-music"></i>';

  const content = `
    <div class="add-track-dialog music-dialog">
      <div class="dialog-header">
        <div class="header-icon music-icon">
          <i class="fas fa-edit"></i>
        </div>
        <div class="header-info">
          <h2>${localize('Dialog.Music.EditHeader')}</h2>
          <p>${format('Dialog.Music.EditSubtitle', { name: escapeHtml(track.name) })}</p>
        </div>
      </div>

      <form class="track-form">
        <div class="form-section">
          <div class="form-group">
            <label><i class="fas fa-heading"></i> ${localize('Labels.TrackName')}</label>
            <input type="text" name="name" value="${escapeAttribute(track.name)}" placeholder="${escapeAttribute(localize('Placeholders.EnterTrackName'))}" spellcheck="false">
          </div>

          <div class="form-group url-group">
            <label><i class="fas fa-link"></i> ${effectiveSource === 'youtube' ? localize('Labels.YouTubeURL') : localize('Labels.FilePath')}</label>
            <div class="url-input-wrapper">
              <input type="text" name="url" value="${escapeAttribute(track.url)}" placeholder="${escapeAttribute(effectiveSource === 'youtube' ? localize('Placeholders.PasteYouTubeURL') : localize('Placeholders.SelectFileOrPastePath'))}" spellcheck="false">
              ${effectiveSource !== 'youtube' ? '<button type="button" class="browse-btn file-picker-btn"><i class="fas fa-folder-open"></i></button>' : ''}
            </div>
          </div>

          <div class="form-group">
            <label><i class="fas fa-tags"></i> ${localize('Labels.Tags')}</label>
            <input type="text" name="tags" value="${escapeAttribute((track.tags || []).join(', '))}" placeholder="${escapeAttribute(localize('Placeholders.MusicTags'))}" spellcheck="false">
            <span class="field-hint">${localize('Hints.TagsHelpOrganize')}</span>
          </div>

          <div class="form-group thumbnail-group">
            <label><i class="fas fa-image"></i> ${localize('Labels.Thumbnail')} <span class="optional">${localize('Common.Optional')}</span></label>
            <div class="thumbnail-wrapper">
              <div class="thumbnail-preview">
                ${thumbnailPreview}
              </div>
              <div class="thumbnail-input">
                <input type="text" name="thumbnail" value="${escapeAttribute(track.thumbnail || '')}" placeholder="${escapeAttribute(localize('Placeholders.ImageURL'))}" spellcheck="false">
                <button type="button" class="browse-btn thumbnail-picker-btn">
                  <i class="fas fa-folder-open"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </form>

      <div class="music-premium-actions">
        <button type="button" class="music-premium-btn secondary music-edit-cancel">
          ${localize('Common.Cancel')}
        </button>
        <button type="button" class="music-premium-btn primary music-edit-save">
          <i class="fas fa-save"></i>
          ${localize('Common.SaveChanges')}
        </button>
      </div>
    </div>
  `;

  return createModuleModal({
    title: localize('Dialog.Music.EditTitle'),
    content,
    classes: MUSIC_EDIT_DIALOG_CLASSES,
    overlayClasses: ['music-context-modal-overlay'],
    closeLabel: localize('Header.Close'),
    initialFocus: 'input[name="name"]',
    onRender: ({ body, close }) => {
      setupEditMusicListeners(body);
      body.find('.music-edit-cancel').on('click', () => close());
      body.find('form').on('submit', event => {
        event.preventDefault();
        body.find('.music-edit-save').trigger('click');
      });
      body.find('.music-edit-save').on('click', async event => {
        const button = event.currentTarget;
        button.disabled = true;
        button.classList.add('is-loading');

        const result = await handleEditMusicSubmit(body, trackId, track, jukebox);
        if (result === false) {
          button.disabled = false;
          button.classList.remove('is-loading');
          return;
        }

        if (onSuccess) onSuccess();
        close();
      });
    }
  });
}

/**
 * Escape HTML special characters
 * @param {string} str - String to escape
 * @returns {string} Escaped string
 */
function escapeHtml(str) {
  if (!str) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function escapeAttribute(str) {
  return escapeHtml(str).replace(/"/g, '&quot;');
}

/**
 * Sets up event listeners for the edit music dialog
 * @param {jQuery} html - Dialog HTML
 */
function setupEditMusicListeners(html) {
  const thumbnailPreview = html.find('.thumbnail-preview');

  // File Picker for URL (if local)
  html.find('.file-picker-btn').click(() => {
    browseFilePicker({
      type: "audio",
      current: html.find('input[name="url"]').val(),
      callback: (path) => {
        html.find('input[name="url"]').val(path);
      }
    });
  });

  // Thumbnail Picker
  html.find('.thumbnail-picker-btn').click(() => {
    browseFilePicker({
      type: "image",
      current: html.find('input[name="thumbnail"]').val(),
      callback: (path) => {
        html.find('input[name="thumbnail"]').val(path);
        thumbnailPreview.html(`<img src="${escapeAttribute(path)}" alt="Thumbnail">`);
      }
    });
  });

  // Update thumbnail preview on input
  html.find('input[name="thumbnail"]').on('input', (e) => {
    const url = e.target.value;
    if (url) {
      thumbnailPreview.html(`<img src="${escapeAttribute(url)}" alt="Thumbnail">`);
    } else {
      thumbnailPreview.html('<i class="fas fa-music"></i>');
    }
  });
}

/**
 * Handles the edit music form submission
 * @param {jQuery} html - Dialog HTML
 * @param {string} trackId - The track ID being edited
 * @param {Object} track - The original track data
 * @param {Object} jukebox - The NarratorJukebox instance
 * @returns {boolean|void} - Returns false to prevent dialog from closing
 */
async function handleEditMusicSubmit(html, trackId, track, jukebox) {
  const form = html.find('form')[0];

  // Validate required fields
  const nameInput = form.name;
  const urlInput = form.url;

  let isValid = true;

  // Validate name
  if (!validateField(nameInput, localize('Validation.TrackNameRequired'))) {
    isValid = false;
  }

  // Validate URL
  const validationSource = isYouTubeUrl(urlInput.value) ? 'youtube' : 'local';
  if (!validateUrl(urlInput.value, validationSource)) {
    if (!validateField(urlInput, localize('Validation.ValidURLRequired'))) {
      isValid = false;
    }
  }

  if (!isValid) {
    ui.notifications.warn(localize('Validation.FixValidationErrorsSave'));
    return false; // Prevent dialog from closing
  }

  const data = normalizeTrackData({
    name: form.name.value,
    url: form.url.value,
    tags: form.tags.value,
    thumbnail: form.thumbnail.value
  }, { partial: true });

  // Only flag as duplicate if the URL actually changed. Otherwise an
  // intentional duplicate elsewhere in the library (created via Duplicate
  // Track, bulk import, etc.) would block all edits to the original track.
  const originalTrack = jukebox.music.find(m => m.id === trackId);
  const originalUrl = (originalTrack?.url ?? '').trim();
  const newUrl = (data.url ?? '').trim();
  if (originalUrl !== newUrl) {
    const duplicate = findDuplicateTrack(jukebox, 'music', data, { excludeId: trackId });
    if (duplicate) {
      ui.notifications.warn(format('Notifications.DuplicateInLibrary', { name: duplicate.name || data.name }));
      return false;
    }
  }

  try {
    await jukebox.updateMusic(trackId, data);
    ui.notifications.info(format('Notifications.Updated', { name: data.name }));
    return true;
  } catch (err) {
    debugError("Failed to update music:", err);
    ui.notifications.error(format('Notifications.FailedToUpdate', { error: err.message }));
    return false;
  }
}

export default showEditMusicDialog;
