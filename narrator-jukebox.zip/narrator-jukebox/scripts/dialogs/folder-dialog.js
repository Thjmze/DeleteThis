/**
 * Folder Dialog
 * Dialog for creating and editing library folders
 */

import { FOLDER_COLORS, FOLDER_ICONS } from '../core/constants.js';
import { applyDarkTheme, applyDialogClasses, DIALOG_CLASSES, escapeHtml } from './base-dialog.js';
import { localize, format } from '../utils/i18n.js';
import { debugError } from '../utils/debug.js';

const FOLDER_DIALOG_CLASSES = ['narrator-jukebox-dialog', 'add-track-dialog-window', 'folder-theme'];

/**
 * Shows the Create/Edit Folder dialog
 * @param {Object} options
 * @param {Object|null} options.folder - Existing folder to edit, or null for create
 * @param {string} options.library - 'music', 'ambience', or 'soundboard'
 * @param {Object} options.jukebox - The NarratorJukebox instance
 * @param {Function} options.onSuccess - Callback on successful save
 */
export function showFolderDialog({ folder = null, library, jukebox, onSuccess }) {
  const isEdit = !!folder;
  const currentName = folder?.name || '';
  const currentColor = folder?.color || FOLDER_COLORS[0].color;
  const currentIcon = folder?.icon || FOLDER_ICONS[0];

  const colorPresetsHtml = FOLDER_COLORS.map(p =>
    `<button type="button" class="color-preset ${p.color === currentColor ? 'active' : ''}" data-color="${p.color}" style="background: ${p.color};" title="${p.name}"></button>`
  ).join('');

  const iconPresetsHtml = FOLDER_ICONS.map(icon =>
    `<button type="button" class="icon-preset ${icon === currentIcon ? 'active' : ''}" data-icon="${icon}" title="${icon.replace('fas fa-', '')}"><i class="${icon}"></i></button>`
  ).join('');

  const title = isEdit ? localize('Folder.EditTitle') : localize('Folder.CreateTitle');
  const subtitle = isEdit
    ? format('Folder.EditSubtitle', { name: currentName })
    : localize('Folder.CreateSubtitle');

  const content = `
    <div class="add-track-dialog folder-dialog">
      <div class="dialog-header">
        <div class="header-icon">
          <i class="fas fa-folder-plus"></i>
        </div>
        <div class="header-info">
          <h2>${title}</h2>
          <p>${subtitle}</p>
        </div>
      </div>
      <form class="track-form">
        <div class="form-section">
          <div class="form-group">
            <label><i class="fas fa-heading"></i> ${localize('Folder.Name')}</label>
            <input type="text" name="name" value="${escapeHtml(currentName)}" placeholder="${localize('Folder.NamePlaceholder')}" spellcheck="false" autofocus>
          </div>

          <div class="form-group">
            <label><i class="fas fa-palette"></i> ${localize('Folder.Color')}</label>
            <div class="color-picker-wrapper">
              <input type="color" name="color" value="${currentColor}" class="color-picker">
              <div class="color-presets">
                ${colorPresetsHtml}
              </div>
            </div>
          </div>

          <div class="form-group">
            <label><i class="fas fa-icons"></i> ${localize('Folder.Icon')}</label>
            <div class="icon-picker-wrapper">
              <input type="hidden" name="icon" value="${currentIcon}">
              <div class="icon-preview" style="color: ${currentColor};">
                <i class="${currentIcon}"></i>
              </div>
              <div class="icon-presets folder-icon-grid">
                ${iconPresetsHtml}
              </div>
            </div>
          </div>

          <div class="form-group">
            <label><i class="fas fa-eye"></i> ${localize('Folder.Preview')}</label>
            <div class="folder-preview" style="--folder-color: ${currentColor};">
              <div class="folder-preview-header">
                <i class="fas fa-chevron-down folder-chevron"></i>
                <i class="${currentIcon} folder-icon" style="color: ${currentColor};"></i>
                <span class="folder-name">${escapeHtml(currentName) || localize('Folder.Name')}</span>
                <span class="folder-count">0</span>
              </div>
            </div>
          </div>
        </div>

        ${isEdit ? `
        <div class="form-section danger-zone">
          <button type="button" class="delete-folder-btn">
            <i class="fas fa-trash"></i> ${localize('Folder.DeleteTitle')}
          </button>
          <small class="danger-hint">${format('Folder.DeleteConfirm', { name: currentName })}</small>
        </div>
        ` : ''}
      </form>
    </div>
  `;

  const dialog = new Dialog({
    title: title,
    content: content,
    classes: FOLDER_DIALOG_CLASSES,
    default: 'save',
    render: (html) => {
      applyDialogClasses(html, FOLDER_DIALOG_CLASSES);
      applyDarkTheme(html);
      setupFolderDialogListeners(html);

      // Delete folder handler
      if (isEdit) {
        html.find('.delete-folder-btn').click(async (e) => {
          e.preventDefault();
          const confirmed = await Dialog.confirm({
            title: localize('Folder.DeleteTitle'),
            content: `<p>${format('Folder.DeleteConfirm', { name: folder.name })}</p>`,
            yes: () => true,
            no: () => false
          });
          if (confirmed) {
            try {
              await jukebox.deleteFolder(library, folder.id);
              ui.notifications.info(format('Notifications.FolderDeleted', { name: folder.name }));
              dialog.close();
              if (onSuccess) onSuccess();
            } catch (err) {
              debugError("Failed to delete folder:", err);
            }
          }
        });
      }
    },
    buttons: {
      save: {
        icon: '<i class="fas fa-save"></i>',
        label: localize('Common.Save'),
        callback: async (html) => {
          const form = html.find('form')[0];
          const name = form.name.value.trim();

          if (!name) {
            ui.notifications.warn(localize('Validation.FolderNameRequired'));
            return false;
          }

          const data = {
            name,
            color: form.color.value,
            icon: form.icon.value
          };

          try {
            if (isEdit) {
              await jukebox.updateFolder(library, folder.id, data);
              ui.notifications.info(format('Notifications.FolderUpdated', { name: data.name }));
            } else {
              await jukebox.createFolder(library, data);
              ui.notifications.info(format('Notifications.FolderCreated', { name: data.name }));
            }
            if (onSuccess) onSuccess();
          } catch (err) {
            debugError("Failed to save folder:", err);
            return false;
          }
        }
      }
    }
  });

  dialog.render(true);
  return dialog;
}

/**
 * Sets up event listeners for the folder dialog
 * @param {jQuery} html - Dialog HTML
 */
function setupFolderDialogListeners(html) {
  const colorPicker = html.find('input[name="color"]');
  const iconHidden = html.find('input[name="icon"]');
  const iconPreview = html.find('.icon-preview i');
  const iconPreviewWrapper = html.find('.icon-preview');
  const folderPreview = html.find('.folder-preview');
  const folderPreviewIcon = folderPreview.find('.folder-icon');
  const folderPreviewName = folderPreview.find('.folder-name');
  const nameInput = html.find('input[name="name"]');

  function updatePreview() {
    const color = colorPicker.val();
    const icon = iconHidden.val();
    const name = nameInput.val().trim() || html.find('input[name="name"]').attr('placeholder');

    folderPreview.css('--folder-color', color);
    folderPreviewIcon.attr('class', `${icon} folder-icon`).css('color', color);
    folderPreviewName.text(name);
    iconPreview.attr('class', icon);
    iconPreviewWrapper.css('color', color);

    // Update icon preset colors
    html.find('.icon-preset').css('color', '');
    html.find('.icon-preset.active').css('color', color);
  }

  // Color presets
  html.find('.color-preset').click((e) => {
    e.preventDefault();
    const color = $(e.currentTarget).data('color');
    colorPicker.val(color);
    html.find('.color-preset').removeClass('active');
    $(e.currentTarget).addClass('active');
    updatePreview();
  });

  // Color picker change
  colorPicker.on('input', () => {
    html.find('.color-preset').removeClass('active');
    updatePreview();
  });

  // Icon presets
  html.find('.icon-preset').click((e) => {
    e.preventDefault();
    const icon = $(e.currentTarget).data('icon');
    iconHidden.val(icon);
    html.find('.icon-preset').removeClass('active');
    $(e.currentTarget).addClass('active');
    updatePreview();
  });

  // Name input
  nameInput.on('input', () => {
    updatePreview();
  });
}

export default showFolderDialog;
