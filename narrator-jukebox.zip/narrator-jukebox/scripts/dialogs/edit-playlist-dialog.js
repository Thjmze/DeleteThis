/**
 * Edit Playlist Dialog
 * Dialog for renaming playlists and customizing playlist covers
 */

import { getFilePicker } from '../utils/file-picker-compat.js';
import { applyDarkTheme, applyDialogClasses, DIALOG_CLASSES, escapeHtml } from './base-dialog.js';
import { validateField } from '../services/validation-service.js';
import { debugError } from '../utils/debug.js';
import { localize, format, has } from '../utils/i18n.js';

/**
 * Shows the Edit Playlist dialog
 * @param {Object} options - Dialog options
 * @param {string} options.playlistId - The playlist ID to edit
 * @param {Object} options.jukebox - The NarratorJukebox instance
 * @param {Function} options.onSuccess - Callback on successful save
 * @returns {Dialog|null} The dialog instance or null if playlist not found
 */
export function showEditPlaylistDialog({ playlistId, jukebox, onSuccess }) {
  const playlist = jukebox.playlists.find(p => p.id === playlistId);
  if (!playlist) {
    ui.notifications.warn(has('Notifications.PlaylistNotFound') ? localize('Notifications.PlaylistNotFound') : 'Playlist not found');
    return null;
  }

  if (playlist.system) {
    ui.notifications.info('Favorites is managed automatically.');
    return null;
  }

  const title = has('Dialog.Playlist.EditTitle')
    ? localize('Dialog.Playlist.EditTitle')
    : 'Edit Playlist';
  const header = has('Dialog.Playlist.EditHeader')
    ? localize('Dialog.Playlist.EditHeader')
    : 'Playlist Details';
  const subtitle = has('Dialog.Playlist.EditSubtitle')
    ? format('Dialog.Playlist.EditSubtitle', { name: playlist.name })
    : `Update "${playlist.name}"`;
  const coverLabel = has('Labels.CoverImage')
    ? localize('Labels.CoverImage')
    : 'Cover Image';
  const coverHint = has('Dialog.Playlist.CoverHint')
    ? localize('Dialog.Playlist.CoverHint')
    : 'Leave this blank to build the cover automatically from playlist tracks.';
  const coverPreview = playlist.coverImage
    ? `<img src="${escapeHtml(playlist.coverImage)}" alt="${escapeHtml(playlist.name)}">`
    : '<i class="fas fa-image"></i>';

  const content = `
    <div class="add-track-dialog playlist-dialog playlist-edit-dialog">
      <div class="dialog-header">
        <div class="header-icon playlist-icon">
          <i class="fas fa-edit"></i>
        </div>
        <div class="header-info">
          <h2>${header}</h2>
          <p>${escapeHtml(subtitle)}</p>
        </div>
      </div>

      <form class="track-form">
        <div class="form-section">
          <div class="form-group">
            <label><i class="fas fa-heading"></i> ${localize('Labels.PlaylistName')}</label>
            <input type="text" name="name" value="${escapeHtml(playlist.name)}" placeholder="${localize('Placeholders.MyAwesomePlaylist')}" spellcheck="false">
          </div>

          <div class="form-group thumbnail-group">
            <label><i class="fas fa-image"></i> ${coverLabel} <span class="optional">${localize('Common.Optional')}</span></label>
            <div class="thumbnail-wrapper">
              <div class="thumbnail-preview playlist-cover-preview">
                ${coverPreview}
              </div>
              <div class="thumbnail-input">
                <input type="text" name="coverImage" value="${escapeHtml(playlist.coverImage || '')}" placeholder="${localize('Placeholders.ImageURL')}" spellcheck="false">
                <button type="button" class="browse-btn cover-picker-btn">
                  <i class="fas fa-folder-open"></i>
                </button>
                <span class="field-hint">${coverHint}</span>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  `;

  const dialog = new Dialog({
    title,
    content,
    classes: DIALOG_CLASSES.playlist,
    default: 'save',
    render: (html) => {
      applyDialogClasses(html, DIALOG_CLASSES.playlist);
      applyDarkTheme(html);
      setupEditPlaylistListeners(html, playlist);
    },
    buttons: {
      save: {
        label: localize('Common.SaveChanges'),
        callback: async (html) => {
          const result = await handleEditPlaylistSubmit(html, playlistId, jukebox);
          if (result === false) return false;
          if (onSuccess) onSuccess();
        }
      },
      cancel: {
        label: localize('Common.Cancel')
      }
    }
  });

  dialog.render(true);
  return dialog;
}

/**
 * Set up interactive controls for the edit playlist dialog
 * @param {jQuery} html - Dialog HTML
 * @param {Object} playlist - Playlist data
 */
function setupEditPlaylistListeners(html, playlist) {
  const coverInput = html.find('input[name="coverImage"]');
  const coverPreview = html.find('.playlist-cover-preview');
  const nameInput = html.find('input[name="name"]');

  nameInput.trigger('focus');

  html.find('.cover-picker-btn').click(() => {
    new (getFilePicker())({
      type: 'image',
      current: coverInput.val(),
      callback: (path) => {
        coverInput.val(path);
        renderCoverPreview(coverPreview, path, playlist.name);
      }
    }).browse();
  });

  coverInput.on('input', (event) => {
    renderCoverPreview(coverPreview, event.target.value, nameInput.val() || playlist.name);
  });
}

/**
 * Render the playlist cover preview state
 * @param {jQuery} previewElement - Preview element
 * @param {string} coverImage - Selected image URL
 * @param {string} playlistName - Playlist name for alt text
 */
function renderCoverPreview(previewElement, coverImage, playlistName) {
  const trimmed = coverImage?.trim() || '';
  if (trimmed) {
    previewElement.html(`<img src="${escapeHtml(trimmed)}" alt="${escapeHtml(playlistName || 'Playlist cover')}">`);
    return;
  }

  previewElement.html('<i class="fas fa-image"></i>');
}

/**
 * Handle edit playlist form submission
 * @param {jQuery} html - Dialog HTML
 * @param {string} playlistId - Playlist being edited
 * @param {Object} jukebox - The NarratorJukebox instance
 * @returns {boolean|void}
 */
async function handleEditPlaylistSubmit(html, playlistId, jukebox) {
  const form = html.find('form')[0];
  const nameInput = form.name;

  if (!validateField(nameInput, localize('Validation.PlaylistNameRequired'))) {
    ui.notifications.warn(localize('Validation.FixValidationErrorsSave'));
    return false;
  }

  const data = {
    name: form.name.value.trim(),
    coverImage: form.coverImage.value.trim()
  };

  try {
    await jukebox.updatePlaylist(playlistId, data);
    ui.notifications.info(format('Notifications.Updated', { name: data.name }));
  } catch (error) {
    debugError('Failed to update playlist:', error);
    ui.notifications.error(format('Notifications.FailedToUpdate', { error: error.message }));
  }
}

export default showEditPlaylistDialog;
