/**
 * Move to Folder Dialog
 * Dialog for moving selected tracks into a folder
 */

import { applyDarkTheme, applyDialogClasses, createModuleModal, escapeHtml } from './base-dialog.js';
import { localize, format } from '../utils/i18n.js';
import { debugError } from '../utils/debug.js';

const MOVE_DIALOG_CLASSES = ['narrator-jukebox-dialog', 'add-track-dialog-window', 'folder-theme'];

/**
 * Shows the Move to Folder dialog
 * @param {Object} options
 * @param {string[]} options.trackIds - Array of track IDs to move
 * @param {string} options.library - 'music', 'ambience', or 'soundboard'
 * @param {Object} options.jukebox - The NarratorJukebox instance
 * @param {Function} options.onSuccess - Callback on successful move
 */
export function showMoveToFolderDialog({ trackIds, library, jukebox, onSuccess }) {
  const folders = jukebox.getFolders(library);
  const isSoundboard = library === 'soundboard';
  const isMusic = library === 'music';
  const isAmbience = library === 'ambience';
  const usesCustomModal = isSoundboard || isMusic || isAmbience;
  const defaultFolderColor = getDefaultFolderColor(library);
  const dialogClasses = getMoveDialogClasses(library);

  const folderListHtml = folders.map(f => `
    <div class="move-folder-option" data-folder-id="${escapeAttribute(f.id)}" style="--folder-color: ${escapeAttribute(f.color || defaultFolderColor)};" role="button" tabindex="0">
      <div class="move-folder-color" style="background: ${escapeAttribute(f.color || defaultFolderColor)};"></div>
      <i class="${escapeAttribute(f.icon || 'fas fa-folder')} move-folder-icon" style="color: ${escapeAttribute(f.color || defaultFolderColor)};"></i>
      <span class="move-folder-name">${escapeHtml(f.name)}</span>
    </div>
  `).join('');

  const content = `
    <div class="add-track-dialog folder-dialog move-to-folder-dialog ${isSoundboard ? 'soundboard-folder-dialog' : ''} ${isMusic ? 'music-folder-dialog' : ''} ${isAmbience ? 'ambience-folder-dialog' : ''}">
      <div class="dialog-header">
        <div class="header-icon ${isSoundboard ? 'soundboard-icon' : ''} ${isMusic ? 'music-icon' : ''} ${isAmbience ? 'ambience-icon' : ''}">
          <i class="${isSoundboard || isMusic || isAmbience ? 'fas fa-folder-open' : 'fas fa-folder'}"></i>
        </div>
        <div class="header-info">
          <h2>${localize('Folder.MoveToTitle')}</h2>
          <p>${format('Folder.MoveToSubtitle', { count: trackIds.length })}</p>
        </div>
      </div>
      <div class="move-folder-list">
        <div class="move-folder-option no-folder-option" data-folder-id="" style="--folder-color: ${escapeAttribute(defaultFolderColor)};" role="button" tabindex="0">
          <div class="move-folder-color" style="background: rgba(255,255,255,0.15);"></div>
          <i class="fas fa-times-circle move-folder-icon" style="color: rgba(255,255,255,0.5);"></i>
          <span class="move-folder-name">${localize('Folder.NoFolder')}</span>
        </div>
        ${folderListHtml}
      </div>
    </div>
  `;

  if (usesCustomModal) {
    return createModuleModal({
      title: localize('Folder.MoveToTitle'),
      content,
      classes: dialogClasses,
      overlayClasses: isMusic ? ['music-context-modal-overlay'] : isAmbience ? ['ambience-context-modal-overlay'] : [],
      closeLabel: localize('Header.Close'),
      initialFocus: '.move-folder-option',
      onRender: ({ body, close }) => {
        bindMoveToFolderOptions({ html: body, library, trackIds, jukebox, onSuccess, close });
      }
    });
  }

  const dialog = new Dialog({
    title: localize('Folder.MoveToTitle'),
    content: content,
    classes: dialogClasses,
    render: (html) => {
      applyDialogClasses(html, dialogClasses);
      applyDarkTheme(html);
      bindMoveToFolderOptions({ html, library, trackIds, jukebox, onSuccess, close: () => dialog.close() });
    },
    buttons: {}
  });

  dialog.render(true);
  return dialog;
}

function getMoveDialogClasses(library) {
  return [
    ...MOVE_DIALOG_CLASSES,
    library ? `${library}-theme` : null,
    library === 'soundboard' ? 'soundboard-move-dialog' : null,
    library === 'music' ? 'music-context-dialog' : null,
    library === 'music' ? 'music-move-dialog' : null,
    library === 'ambience' ? 'ambience-context-dialog' : null,
    library === 'ambience' ? 'ambience-move-dialog' : null
  ].filter(Boolean);
}

function getDefaultFolderColor(library) {
  if (library === 'music') return '#1ed760';
  if (library === 'soundboard') return '#ff6b35';
  if (library === 'ambience') return '#667eea';
  return '#ffffff';
}

function bindMoveToFolderOptions({ html, library, trackIds, jukebox, onSuccess, close }) {
  let isMoving = false;
  const options = html.find('.move-folder-option');

  options.on('keydown', event => {
    if (event.key !== 'Enter' && event.key !== ' ') return;
    event.preventDefault();
    event.currentTarget.click();
  });

  options.on('click', async (event) => {
    if (isMoving) return;
    isMoving = true;
    options.attr('aria-disabled', 'true');

    const folderId = event.currentTarget.dataset.folderId || null;
    try {
      await jukebox.moveTracksToFolder(library, trackIds, folderId);
      if (folderId) {
        const folder = jukebox.getFolders(library).find(f => f.id === folderId);
        ui.notifications.info(format('Notifications.TracksMovedToFolder', {
          count: trackIds.length,
          folder: folder?.name || ''
        }));
      } else {
        ui.notifications.info(format('Notifications.TracksUnfiled', { count: trackIds.length }));
      }
      close();
      if (onSuccess) onSuccess();
    } catch (err) {
      debugError("Failed to move tracks to folder:", err);
      ui.notifications.error(format('Notifications.FailedToUpdate', { error: err.message }));
      isMoving = false;
      options.removeAttr('aria-disabled');
    }
  });
}

function escapeAttribute(value) {
  return escapeHtml(value).replace(/"/g, '&quot;');
}

export default showMoveToFolderDialog;
