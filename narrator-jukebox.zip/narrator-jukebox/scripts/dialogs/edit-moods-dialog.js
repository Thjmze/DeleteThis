/**
 * Edit Moods Dialog
 * Master-detail editor for managing mood boards (visual tag filters)
 */

import { JUKEBOX } from '../core/constants.js';
import { getFilePicker } from '../utils/file-picker-compat.js';
import { applyMoodEditorTheme, applyDialogClasses, escapeHtml } from './base-dialog.js';
import { localize, format } from '../utils/i18n.js';

/**
 * Default preset gradients organized by category
 */
const PRESET_GRADIENTS = [
  // Combat & Action
  { nameKey: 'Gradients.Fire', value: 'linear-gradient(135deg, #f12711, #f5af19)', category: 'combat' },
  { nameKey: 'Gradients.Ember', value: 'linear-gradient(135deg, #ff416c, #ff4b2b)', category: 'combat' },
  { nameKey: 'Gradients.Blood', value: 'linear-gradient(135deg, #8E0E00, #1F1C18)', category: 'combat' },
  { nameKey: 'Gradients.Inferno', value: 'linear-gradient(135deg, #ff0844, #ffb199)', category: 'combat' },
  { nameKey: 'Gradients.Rage', value: 'linear-gradient(135deg, #ED213A, #93291E)', category: 'combat' },

  // Mystery & Magic
  { nameKey: 'Gradients.PurpleHaze', value: 'linear-gradient(135deg, #667eea, #764ba2)', category: 'magic' },
  { nameKey: 'Gradients.Mystic', value: 'linear-gradient(135deg, #41295a, #2F0743)', category: 'magic' },
  { nameKey: 'Gradients.Arcane', value: 'linear-gradient(135deg, #8E2DE2, #4A00E0)', category: 'magic' },
  { nameKey: 'Gradients.Enchanted', value: 'linear-gradient(135deg, #c471f5, #fa71cd)', category: 'magic' },
  { nameKey: 'Gradients.Nebula', value: 'linear-gradient(135deg, #E040FB, #536DFE)', category: 'magic' },

  // Nature & Exploration
  { nameKey: 'Gradients.Forest', value: 'linear-gradient(135deg, #11998e, #38ef7d)', category: 'nature' },
  { nameKey: 'Gradients.Mint', value: 'linear-gradient(135deg, #00b09b, #96c93d)', category: 'nature' },
  { nameKey: 'Gradients.Leaf', value: 'linear-gradient(135deg, #134E5E, #71B280)', category: 'nature' },
  { nameKey: 'Gradients.Jungle', value: 'linear-gradient(135deg, #0F2027, #203A43, #2C5364)', category: 'nature' },
  { nameKey: 'Gradients.Spring', value: 'linear-gradient(135deg, #00d2ff, #3a7bd5)', category: 'nature' },

  // Ocean & Water
  { nameKey: 'Gradients.Ocean', value: 'linear-gradient(135deg, #4facfe, #00f2fe)', category: 'water' },
  { nameKey: 'Gradients.DeepSea', value: 'linear-gradient(135deg, #1A2980, #26D0CE)', category: 'water' },
  { nameKey: 'Gradients.Tidal', value: 'linear-gradient(135deg, #0052D4, #65C7F7, #9CECFB)', category: 'water' },
  { nameKey: 'Gradients.Arctic', value: 'linear-gradient(135deg, #74ebd5, #ACB6E5)', category: 'water' },
  { nameKey: 'Gradients.Frozen', value: 'linear-gradient(135deg, #c2e9fb, #a1c4fd)', category: 'water' },

  // Dark & Horror
  { nameKey: 'Gradients.Night', value: 'linear-gradient(135deg, #0f0c29, #302b63, #24243e)', category: 'dark' },
  { nameKey: 'Gradients.Midnight', value: 'linear-gradient(135deg, #232526, #414345)', category: 'dark' },
  { nameKey: 'Gradients.Shadow', value: 'linear-gradient(135deg, #000000, #434343)', category: 'dark' },
  { nameKey: 'Gradients.Abyss', value: 'linear-gradient(135deg, #0f0f0f, #2d2d2d)', category: 'dark' },
  { nameKey: 'Gradients.Void', value: 'linear-gradient(135deg, #16222A, #3A6073)', category: 'dark' },

  // Romantic & Calm
  { nameKey: 'Gradients.Rose', value: 'linear-gradient(135deg, #ee9ca7, #ffdde1)', category: 'calm' },
  { nameKey: 'Gradients.Dusk', value: 'linear-gradient(135deg, #a18cd1, #fbc2eb)', category: 'calm' },
  { nameKey: 'Gradients.Peach', value: 'linear-gradient(135deg, #ffecd2, #fcb69f)', category: 'calm' },
  { nameKey: 'Gradients.Blossom', value: 'linear-gradient(135deg, #f6d365, #fda085)', category: 'calm' },
  { nameKey: 'Gradients.Serenity', value: 'linear-gradient(135deg, #89f7fe, #66a6ff)', category: 'calm' },

  // Sunset & Dawn
  { nameKey: 'Gradients.Sunset', value: 'linear-gradient(135deg, #f093fb, #f5576c)', category: 'sky' },
  { nameKey: 'Gradients.Dawn', value: 'linear-gradient(135deg, #ffecd2, #fcb69f)', category: 'sky' },
  { nameKey: 'Gradients.Twilight', value: 'linear-gradient(135deg, #544a7d, #ffd452)', category: 'sky' },
  { nameKey: 'Gradients.Aurora', value: 'linear-gradient(135deg, #00c6ff, #0072ff)', category: 'sky' },
  { nameKey: 'Gradients.GoldenHour', value: 'linear-gradient(135deg, #f7971e, #ffd200)', category: 'sky' },

  // Storm & Weather
  { nameKey: 'Gradients.Storm', value: 'linear-gradient(135deg, #373b44, #4286f4)', category: 'weather' },
  { nameKey: 'Gradients.Lightning', value: 'linear-gradient(135deg, #f7ff00, #db36a4)', category: 'weather' },
  { nameKey: 'Gradients.Fog', value: 'linear-gradient(135deg, #606c88, #3f4c6b)', category: 'weather' },
  { nameKey: 'Gradients.Sandstorm', value: 'linear-gradient(135deg, #c79081, #dfa579)', category: 'weather' },

  // Royal & Noble
  { nameKey: 'Gradients.Crown', value: 'linear-gradient(135deg, #F7971E, #FFD200)', category: 'royal' },
  { nameKey: 'Gradients.Imperial', value: 'linear-gradient(135deg, #360033, #0b8793)', category: 'royal' },
  { nameKey: 'Gradients.Majestic', value: 'linear-gradient(135deg, #5f2c82, #49a09d)', category: 'royal' },
  { nameKey: 'Gradients.Regal', value: 'linear-gradient(135deg, #1a2a6c, #b21f1f, #fdbb2d)', category: 'royal' }
];

/**
 * Popular FontAwesome icons organized by category
 */
const POPULAR_ICONS = {
  combat: ['fas fa-sword', 'fas fa-shield-alt', 'fas fa-axe', 'fas fa-bow-arrow', 'fas fa-fist-raised', 'fas fa-skull-crossbones', 'fas fa-skull', 'fas fa-khanda', 'fas fa-bomb', 'fas fa-crosshairs', 'fas fa-bullseye', 'fas fa-chess-knight'],
  magic: ['fas fa-magic', 'fas fa-hat-wizard', 'fas fa-wand-magic', 'fas fa-fire-alt', 'fas fa-bolt', 'fas fa-star', 'fas fa-moon', 'fas fa-sun', 'fas fa-hand-sparkles', 'fas fa-scroll', 'fas fa-book-spells', 'fas fa-crystal-ball'],
  creatures: ['fas fa-dragon', 'fas fa-spider', 'fas fa-ghost', 'fas fa-cat', 'fas fa-crow', 'fas fa-horse', 'fas fa-wolf-pack-battalion', 'fas fa-bat', 'fas fa-snake', 'fas fa-fish', 'fas fa-bug', 'fas fa-paw'],
  nature: ['fas fa-leaf', 'fas fa-tree', 'fas fa-seedling', 'fas fa-mountain', 'fas fa-water', 'fas fa-wind', 'fas fa-snowflake', 'fas fa-cloud', 'fas fa-feather', 'fas fa-flower', 'fas fa-sun', 'fas fa-rainbow'],
  places: ['fas fa-dungeon', 'fas fa-castle', 'fas fa-church', 'fas fa-home', 'fas fa-campground', 'fas fa-landmark', 'fas fa-monument', 'fas fa-torii-gate', 'fas fa-archway', 'fas fa-store', 'fas fa-warehouse', 'fas fa-city'],
  emotions: ['fas fa-heart', 'fas fa-heart-broken', 'fas fa-grin-tears', 'fas fa-sad-tear', 'fas fa-angry', 'fas fa-surprise', 'fas fa-meh', 'fas fa-laugh', 'fas fa-tired', 'fas fa-dizzy', 'fas fa-grimace', 'fas fa-grin-stars'],
  objects: ['fas fa-gem', 'fas fa-coins', 'fas fa-crown', 'fas fa-key', 'fas fa-lock', 'fas fa-hourglass', 'fas fa-compass', 'fas fa-map', 'fas fa-chess', 'fas fa-dice-d20', 'fas fa-ring', 'fas fa-trophy'],
  music: ['fas fa-music', 'fas fa-guitar', 'fas fa-drum', 'fas fa-headphones', 'fas fa-volume-up', 'fas fa-microphone', 'fas fa-record-vinyl', 'fas fa-bell', 'fas fa-broadcast-tower', 'fas fa-radio', 'fas fa-sliders-h', 'fas fa-wave-square'],
  spiritual: ['fas fa-cross', 'fas fa-pray', 'fas fa-bible', 'fas fa-church', 'fas fa-dove', 'fas fa-hand-holding-heart', 'fas fa-yin-yang', 'fas fa-om', 'fas fa-ankh', 'fas fa-peace', 'fas fa-star-of-david', 'fas fa-menorah'],
  misc: ['fas fa-fire', 'fas fa-anchor', 'fas fa-flask', 'fas fa-eye', 'fas fa-binoculars', 'fas fa-search', 'fas fa-cog', 'fas fa-flag', 'fas fa-hammer', 'fas fa-wrench', 'fas fa-quill', 'fas fa-pen-fancy']
};

/**
 * Gradient category definitions
 */
const GRADIENT_CATEGORIES = {
  combat: { nameKey: 'GradientCategories.Combat', icon: 'fa-fire' },
  magic: { nameKey: 'GradientCategories.Magic', icon: 'fa-magic' },
  nature: { nameKey: 'GradientCategories.Nature', icon: 'fa-leaf' },
  water: { nameKey: 'GradientCategories.Water', icon: 'fa-water' },
  dark: { nameKey: 'GradientCategories.Dark', icon: 'fa-moon' },
  calm: { nameKey: 'GradientCategories.Calm', icon: 'fa-heart' },
  sky: { nameKey: 'GradientCategories.Sky', icon: 'fa-sun' },
  weather: { nameKey: 'GradientCategories.Weather', icon: 'fa-cloud' },
  royal: { nameKey: 'GradientCategories.Royal', icon: 'fa-crown' }
};

/**
 * Icon category labels
 */
const ICON_CATEGORY_KEYS = {
  combat: 'IconCategories.Combat',
  magic: 'IconCategories.Magic',
  creatures: 'IconCategories.Creatures',
  nature: 'IconCategories.Nature',
  places: 'IconCategories.Places',
  emotions: 'IconCategories.Emotions',
  objects: 'IconCategories.Objects',
  music: 'IconCategories.Music',
  spiritual: 'IconCategories.Spiritual',
  misc: 'IconCategories.Misc'
};

const ICON_CATEGORY_ICONS = {
  combat: 'fa-khanda',
  magic: 'fa-magic',
  creatures: 'fa-dragon',
  nature: 'fa-leaf',
  places: 'fa-dungeon',
  emotions: 'fa-heart',
  objects: 'fa-gem',
  music: 'fa-music',
  spiritual: 'fa-ankh',
  misc: 'fa-cog'
};

const DEFAULT_GRADIENT = 'linear-gradient(135deg, #667eea, #764ba2)';
const DEFAULT_ICON = 'fas fa-music';

function normalizeMoodTag(value) {
  return String(value || '').trim().toLowerCase();
}

/**
 * Shows the Edit Moods dialog
 * @param {Object} options - Dialog options
 * @param {Array} options.music - Music library for extracting tags
 * @param {Object} options.jukebox - Jukebox service fallback for music data
 * @param {Function} options.onSuccess - Callback on successful save
 * @returns {Dialog} The dialog instance
 */
export function showEditMoodsDialog({ music = [], jukebox = null, onSuccess } = {}) {
  const moods = game.settings.get(JUKEBOX.ID, "moods") || [];
  const library = Array.isArray(music) && music.length ? music : (jukebox?.music || []);
  const allTags = getAllTags(library);
  const trackCounts = getTrackCountsByTag(library);

  const content = buildMoodsDialogContent(moods, allTags, trackCounts);

  const dialog = new Dialog({
    title: localize('Dialog.Moods.EditTitle'),
    content,
    classes: ['narrator-jukebox-dialog', 'mood-editor-dialog-v2'],
    render: (html) => {
      applyDialogClasses(html, ['narrator-jukebox-dialog', 'mood-editor-dialog-v2']);
      applyMoodEditorTheme(html);
      setupMoodEditorListeners(html, allTags, trackCounts);
    },
    buttons: {
      save: {
        icon: '<i class="fas fa-check"></i>',
        label: localize('Common.SaveChanges'),
        callback: async (html) => {
          const updatedMoods = [];
          html.find('.mood-card-item').each((i, el) => {
            const $card = $(el);
            updatedMoods.push({
              label: String($card.find('.mood-input-label').val() || '').trim(),
              tag: normalizeMoodTag($card.find('.mood-input-tag').val()),
              color: String($card.find('.mood-input-color').val() || DEFAULT_GRADIENT).trim(),
              icon: String($card.find('.mood-input-icon').val() || DEFAULT_ICON).trim()
            });
          });
          await game.settings.set(JUKEBOX.ID, "moods", updatedMoods);
          ui.notifications.info(localize('Notifications.MoodBoardsSaved'));
          if (onSuccess) onSuccess();
        }
      },
      cancel: {
        icon: '<i class="fas fa-times"></i>',
        label: localize('Common.Cancel')
      }
    },
    default: "save"
  }, {
    width: 1120,
    height: 'auto',
    resizable: true
  });

  dialog.render(true);
  return dialog;
}

/**
 * Build the moods dialog content
 */
function buildMoodsDialogContent(moods, allTags, trackCounts) {
  const selectedMood = moods[0] || null;

  return `
    <div class="mood-editor-v2">
      <header class="mood-editor-header">
        <div class="header-title">
          <i class="fas fa-palette"></i>
          <div>
            <h2>${localize('Dialog.Moods.Header')}</h2>
            <p>${localize('Dialog.Moods.Subtitle')}</p>
          </div>
        </div>
        <div class="header-stats">
          <span class="stat"><i class="fas fa-th-large"></i> <span data-mood-count>${format('Dialog.Moods.MoodsCount', { count: moods.length })}</span></span>
          <span class="stat"><i class="fas fa-tags"></i> <span data-tag-count>${format('Dialog.Moods.TagsCount', { count: allTags.length })}</span></span>
        </div>
      </header>

      <div class="mood-editor-workspace">
        <aside class="mood-board-sidebar">
          <div class="mood-board-sidebar-header">
            <div>
              <span class="mood-board-kicker">Boards</span>
              <strong>${localize('Dialog.Moods.Header')}</strong>
            </div>
            <button type="button" class="mood-add-btn" id="add-mood-btn" title="${localize('Dialog.Moods.AddMood')}">
              <i class="fas fa-plus"></i>
              <span>${localize('Dialog.Moods.AddMood')}</span>
            </button>
          </div>

          <label class="mood-board-search">
            <i class="fas fa-search"></i>
            <input type="search" id="mood-board-search" placeholder="Search moods" spellcheck="false">
          </label>

          <div class="mood-board-list" id="mood-board-list">
            ${moods.map((m, i) => renderMoodRow(m, i, trackCounts, i === 0)).join('')}
          </div>

          <div class="mood-board-list-empty ${moods.length ? 'hidden' : ''}">
            <i class="fas fa-palette"></i>
            <strong>No mood boards yet</strong>
            <span>Add a mood to create a visual tag shortcut.</span>
          </div>

          <div class="mood-board-no-results hidden">
            <i class="fas fa-search"></i>
            <span>No matching mood boards</span>
          </div>
        </aside>

        <section class="mood-detail-panel ${selectedMood ? '' : 'empty'}">
          ${renderMoodDetail(selectedMood, allTags, trackCounts)}
        </section>
      </div>

      <footer class="mood-editor-footer">
        <div class="footer-hint">
          <i class="fas fa-info-circle"></i>
          <span>${localize('Hints.MoodTip')}</span>
        </div>
      </footer>
    </div>
  `;
}

/**
 * Render a compact row in the master list
 */
function renderMoodRow(mood, index, trackCounts, selected = false) {
  const label = getMoodLabel(mood);
  const tag = normalizeMoodTag(mood.tag);
  const color = getMoodColor(mood);
  const icon = getMoodIcon(mood);
  const trackCount = getTrackCount(trackCounts, tag);

  return `
    <div class="mood-board-row mood-card-item ${selected ? 'active' : ''}" data-index="${index}" role="button" tabindex="0">
      <input type="hidden" class="mood-input-label" value="${escapeAttribute(mood.label || '')}">
      <input type="hidden" class="mood-input-tag" value="${escapeAttribute(tag)}">
      <input type="hidden" class="mood-input-color" value="${escapeAttribute(color)}">
      <input type="hidden" class="mood-input-icon" value="${escapeAttribute(icon)}">

      <div class="mood-row-swatch" style="background: ${escapeAttribute(color)};">
        ${renderIconMarkup(icon)}
      </div>

      <div class="mood-row-main">
        <span class="mood-row-name">${escapeHtml(label)}</span>
        <span class="mood-row-tag">${escapeHtml(tag || 'No tag')}</span>
      </div>

      <span class="mood-row-count">${formatTrackCount(trackCount)}</span>

      <button type="button" class="mood-delete-btn" title="${localize('Dialog.Moods.DeleteMoodTooltip')}">
        <i class="fas fa-trash-alt"></i>
      </button>
    </div>
  `;
}

/**
 * Render the detail editor for the selected mood.
 */
function renderMoodDetail(mood, allTags, trackCounts) {
  const hasMood = !!mood;
  const safeMood = mood || {};
  const label = getMoodLabel(safeMood);
  const tag = normalizeMoodTag(safeMood.tag);
  const color = getMoodColor(safeMood);
  const icon = getMoodIcon(safeMood);
  const colors = parseGradientColors(color);
  const selectedGradientCategory = getGradientCategory(color);
  const selectedIconCategory = getIconCategory(icon);
  const trackCount = getTrackCount(trackCounts, tag);

  return `
    <div class="mood-detail-empty-state">
      <i class="fas fa-palette"></i>
      <strong>Select a mood board</strong>
      <span>Choose a board from the left, or add a new one.</span>
    </div>

    <div class="mood-detail-editor ${hasMood ? '' : 'disabled'}">
      <div class="mood-detail-preview mood-preview" style="background: ${escapeAttribute(color)};">
        <div class="preview-icon">
          ${renderIconMarkup(icon)}
        </div>
        <div class="mood-detail-preview-copy">
          <span class="preview-kicker">Home card preview</span>
          <div class="preview-label">${escapeHtml(label)}</div>
          <div class="mood-detail-preview-meta">
            <span class="mood-detail-preview-tag">${escapeHtml(tag || 'No tag')}</span>
            <span class="mood-detail-track-count">${formatTrackCount(trackCount)}</span>
          </div>
        </div>
      </div>

      <div class="mood-detail-form">
        <div class="field-group">
          <label><i class="fas fa-tag"></i> ${localize('Labels.Name')}</label>
          <input type="text" class="mood-detail-label" value="${escapeAttribute(safeMood.label || '')}" placeholder="${localize('Placeholders.MoodNameExample')}" spellcheck="false">
        </div>

        <div class="field-group">
          <label><i class="fas fa-filter"></i> ${localize('Labels.FilterTag')}</label>
          <input type="text" class="mood-detail-tag" value="${escapeAttribute(tag)}" placeholder="${localize('Placeholders.MoodTagExample')}" spellcheck="false" list="mood-tag-suggestions">
          <datalist id="mood-tag-suggestions">
            ${allTags.map(t => `<option value="${escapeAttribute(t)}"></option>`).join('')}
          </datalist>
        </div>
      </div>

      <section class="mood-editor-panel gradient-field-group">
        <div class="mood-panel-heading">
          <div>
            <span>Visual style</span>
            <strong><i class="fas fa-fill-drip"></i> ${localize('Labels.Background')}</strong>
          </div>
        </div>

        <div class="gradient-tabs">
          ${Object.entries(GRADIENT_CATEGORIES).map(([catKey, cat]) => `
            <button type="button" class="gradient-category-tab ${catKey === selectedGradientCategory ? 'active' : ''}" data-category="${catKey}" title="${localize(cat.nameKey)}">
              <i class="fas ${cat.icon}"></i>
              <span>${localize(cat.nameKey)}</span>
            </button>
          `).join('')}
        </div>

        <div class="gradient-preset-panels">
          ${Object.keys(GRADIENT_CATEGORIES).map(catKey => `
            <div class="gradient-preset-panel ${catKey === selectedGradientCategory ? 'active' : ''}" data-category="${catKey}">
              ${PRESET_GRADIENTS.filter(g => g.category === catKey).map(g => `
                <button type="button" class="gradient-preset ${g.value === color ? 'selected' : ''}" style="background: ${escapeAttribute(g.value)};" data-gradient="${escapeAttribute(g.value)}" title="${localize(g.nameKey)}"></button>
              `).join('')}
            </div>
          `).join('')}
        </div>

        <div class="custom-gradient-builder">
          <div class="gradient-builder-preview" style="background: ${escapeAttribute(color)};">
            <span class="gradient-preview-label">Custom</span>
          </div>
          <div class="gradient-builder-controls">
            <div class="color-picker-group">
              <label>${localize('Dialog.Moods.Color1')}</label>
              <input type="color" class="gradient-color-1" value="${escapeAttribute(colors[0])}">
            </div>
            <div class="color-picker-group">
              <label>${localize('Dialog.Moods.Color2')}</label>
              <input type="color" class="gradient-color-2" value="${escapeAttribute(colors[1])}">
            </div>
            <button type="button" class="apply-gradient-btn" title="${localize('Dialog.Moods.ApplyGradientTooltip')}">
              <i class="fas fa-check"></i> ${localize('Common.Apply')}
            </button>
          </div>
        </div>
      </section>

      <section class="mood-editor-panel icon-field-group">
        <div class="mood-panel-heading">
          <div>
            <span>Identity</span>
            <strong><i class="fas fa-icons"></i> ${localize('Labels.Icon')}</strong>
          </div>
        </div>

        <div class="icon-input-wrapper">
          <input type="text" class="mood-detail-icon" value="${escapeAttribute(icon)}" placeholder="${localize('Placeholders.IconClassExample')}" spellcheck="false">
          <button type="button" class="icon-browse-btn" title="${localize('Dialog.Moods.BrowseImagestooltip')}">
            <i class="fas fa-folder-open"></i>
          </button>
        </div>

        <div class="icon-categories">
          <div class="icon-category-tabs">
            ${Object.entries(ICON_CATEGORY_KEYS).map(([catKey, catNameKey]) => `
              <button type="button" class="icon-category-tab ${catKey === selectedIconCategory ? 'active' : ''}" data-category="${catKey}" title="${localize(catNameKey)}">
                <i class="fas ${ICON_CATEGORY_ICONS[catKey] || 'fa-circle'}"></i>
              </button>
            `).join('')}
          </div>
          <div class="icon-category-content">
            ${Object.entries(POPULAR_ICONS).map(([catKey, icons]) => `
              <div class="icon-category-panel ${catKey === selectedIconCategory ? 'active' : ''}" data-category="${catKey}">
                ${icons.map(ic => `
                  <button type="button" class="icon-preset ${ic === icon ? 'selected' : ''}" data-icon="${escapeAttribute(ic)}" title="${escapeAttribute(ic)}">
                    <i class="${escapeAttribute(ic)}"></i>
                  </button>
                `).join('')}
              </div>
            `).join('')}
          </div>
        </div>
      </section>
    </div>
  `;
}

/**
 * Setup mood editor event listeners
 */
function setupMoodEditorListeners(html, allTags, trackCounts) {
  const allIcons = Object.values(POPULAR_ICONS).flat();

  html.find('#add-mood-btn').click(() => {
    const newMood = {
      label: "New Mood",
      tag: "",
      color: PRESET_GRADIENTS[Math.floor(Math.random() * PRESET_GRADIENTS.length)].value,
      icon: allIcons[Math.floor(Math.random() * allIcons.length)]
    };

    const newIndex = html.find('.mood-card-item').length;
    const $row = $(renderMoodRow(newMood, newIndex, trackCounts, false));

    html.find('#mood-board-search').val('');
    html.find('#mood-board-list').append($row.hide());
    attachCardListeners($row, html, allTags, trackCounts);
    updateMoodListState(html, allTags);
    $row.fadeIn(160);
    selectMoodRow($row, html, trackCounts);
    filterMoodRows(html);
    $row[0]?.scrollIntoView({ block: 'nearest' });
  });

  html.find('#mood-board-search').on('input', () => filterMoodRows(html));

  html.find('.mood-card-item').each((i, el) => {
    attachCardListeners($(el), html, allTags, trackCounts);
  });

  setupDetailListeners(html, trackCounts);
}

/**
 * Attach event listeners to a mood row
 */
function attachCardListeners($card, html, allTags, trackCounts) {
  $card.on('click', (e) => {
    if ($(e.target).closest('button, input').length) return;
    selectMoodRow($card, html, trackCounts);
  });

  $card.on('keydown', (e) => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    e.preventDefault();
    selectMoodRow($card, html, trackCounts);
  });

  $card.find('.mood-delete-btn').click((e) => {
    e.stopPropagation();
    const wasActive = $card.hasClass('active');
    const $fallback = $card.nextAll('.mood-card-item').first().length
      ? $card.nextAll('.mood-card-item').first()
      : $card.prevAll('.mood-card-item').first();

    $card.addClass('deleting');
    setTimeout(() => {
      $card.slideUp(200, () => {
        $card.remove();
        reindexMoodRows(html);
        updateMoodListState(html, allTags);
        filterMoodRows(html);
        if (wasActive && $fallback.length) selectMoodRow($fallback, html, trackCounts);
        if (!html.find('.mood-card-item').length) clearMoodDetail(html);
      });
    }, 100);
  });
}

/**
 * Setup detail pane listeners.
 */
function setupDetailListeners(html, trackCounts) {
  html.find('.mood-detail-label').on('input', (e) => {
    const value = e.target.value;
    const label = value || 'Untitled';
    const $row = getSelectedMoodRow(html);
    $row.find('.mood-input-label').val(value);
    $row.find('.mood-row-name').text(label);
    html.find('.preview-label').text(label);
  });

  html.find('.mood-detail-tag').on('input', (e) => {
    const value = normalizeMoodTag(e.target.value);
    if (e.target.value !== value) e.target.value = value;
    const tag = value || 'No tag';
    const count = getTrackCount(trackCounts, value);
    const $row = getSelectedMoodRow(html);
    $row.find('.mood-input-tag').val(value);
    $row.find('.mood-row-tag').text(tag);
    $row.find('.mood-row-count').text(formatTrackCount(count));
    html.find('.mood-detail-preview-tag').text(tag);
    html.find('.mood-detail-track-count').text(formatTrackCount(count));
  });

  html.find('.mood-detail-icon').on('input', (e) => {
    setSelectedMoodIcon(html, e.target.value || DEFAULT_ICON);
  });

  const updateGradientPreview = () => {
    const color1 = html.find('.gradient-color-1').val();
    const color2 = html.find('.gradient-color-2').val();
    const gradient = `linear-gradient(135deg, ${color1}, ${color2})`;
    html.find('.gradient-builder-preview').css('background', gradient);
  };

  html.find('.gradient-color-1, .gradient-color-2').on('input', updateGradientPreview);

  html.find('.apply-gradient-btn').click(() => {
    const color1 = html.find('.gradient-color-1').val();
    const color2 = html.find('.gradient-color-2').val();
    const gradient = `linear-gradient(135deg, ${color1}, ${color2})`;
    setSelectedMoodColor(html, gradient, false);
  });

  html.find('.gradient-category-tab').click((e) => {
    setActiveGradientCategory(html, e.currentTarget.dataset.category);
  });

  html.find('.gradient-preset').click((e) => {
    const gradient = e.currentTarget.dataset.gradient;
    setSelectedMoodColor(html, gradient, true);
  });

  html.find('.icon-category-tab').click((e) => {
    setActiveIconCategory(html, e.currentTarget.dataset.category);
  });

  html.find('.icon-preset').click((e) => {
    const icon = e.currentTarget.dataset.icon || DEFAULT_ICON;
    html.find('.mood-detail-icon').val(icon);
    setSelectedMoodIcon(html, icon);
  });

  html.find('.icon-browse-btn').click(() => {
    const input = html.find('.mood-detail-icon');
    new (getFilePicker())({
      type: "image",
      current: input.val(),
      callback: (path) => {
        input.val(path);
        setSelectedMoodIcon(html, path);
      }
    }).browse();
  });
}

function selectMoodRow($row, html, trackCounts) {
  if (!$row.length) return;

  html.find('.mood-card-item').removeClass('active');
  $row.addClass('active');
  html.find('.mood-detail-panel').removeClass('empty');
  html.find('.mood-detail-editor').removeClass('disabled');

  const mood = readMoodFromRow($row);
  const label = mood.label || 'Untitled';
  const tag = normalizeMoodTag(mood.tag);
  const trackCount = getTrackCount(trackCounts, tag);

  html.find('.mood-detail-label').val(mood.label);
  html.find('.mood-detail-tag').val(tag);
  html.find('.mood-detail-icon').val(mood.icon);
  html.find('.preview-label').text(label);
  html.find('.mood-detail-preview-tag').text(tag || 'No tag');
  html.find('.mood-detail-track-count').text(formatTrackCount(trackCount));
  setSelectedMoodColor(html, mood.color, true);
  setSelectedMoodIcon(html, mood.icon);
}

function readMoodFromRow($row) {
  return {
    label: $row.find('.mood-input-label').val() || '',
    tag: normalizeMoodTag($row.find('.mood-input-tag').val()),
    color: $row.find('.mood-input-color').val() || DEFAULT_GRADIENT,
    icon: $row.find('.mood-input-icon').val() || DEFAULT_ICON
  };
}

function getSelectedMoodRow(html) {
  return html.find('.mood-card-item.active').first();
}

function setSelectedMoodColor(html, gradient, updatePickers = true) {
  const value = gradient || DEFAULT_GRADIENT;
  const $row = getSelectedMoodRow(html);
  if (!$row.length) return;

  $row.find('.mood-input-color').val(value);
  $row.find('.mood-row-swatch').css('background', value);
  html.find('.mood-detail-preview').css('background', value);
  html.find('.gradient-builder-preview').css('background', value);
  html.find('.gradient-preset').removeClass('selected');
  html.find('.gradient-preset').filter((i, el) => el.dataset.gradient === value).addClass('selected');
  setActiveGradientCategory(html, getGradientCategory(value));

  if (updatePickers) {
    const colors = parseGradientColors(value);
    html.find('.gradient-color-1').val(colors[0]);
    html.find('.gradient-color-2').val(colors[1]);
  }
}

function setSelectedMoodIcon(html, icon, syncCategory = true) {
  const value = icon || DEFAULT_ICON;
  const $row = getSelectedMoodRow(html);
  if (!$row.length) return;

  $row.find('.mood-input-icon').val(value);
  $row.find('.mood-row-swatch').html(renderIconMarkup(value));
  html.find('.preview-icon').html(renderIconMarkup(value));
  html.find('.icon-preset').removeClass('selected');
  html.find('.icon-preset').filter((i, el) => el.dataset.icon === value).addClass('selected');

  if (syncCategory) setActiveIconCategory(html, getIconCategory(value));
}

function setActiveGradientCategory(html, category) {
  html.find('.gradient-category-tab').removeClass('active');
  html.find('.gradient-preset-panel').removeClass('active');
  html.find(`.gradient-category-tab[data-category="${category}"]`).addClass('active');
  html.find(`.gradient-preset-panel[data-category="${category}"]`).addClass('active');
}

function setActiveIconCategory(html, category) {
  html.find('.icon-category-tab').removeClass('active');
  html.find('.icon-category-panel').removeClass('active');
  html.find(`.icon-category-tab[data-category="${category}"]`).addClass('active');
  html.find(`.icon-category-panel[data-category="${category}"]`).addClass('active');
}

function clearMoodDetail(html) {
  html.find('.mood-detail-panel').addClass('empty');
  html.find('.mood-detail-editor').addClass('disabled');
  html.find('.mood-detail-label, .mood-detail-tag, .mood-detail-icon').val('');
  html.find('.preview-label').text('Untitled');
  html.find('.mood-detail-preview-tag').text('No tag');
  html.find('.mood-detail-track-count').text(formatTrackCount(0));
}

function updateMoodListState(html, allTags) {
  const count = html.find('.mood-card-item').length;
  html.find('[data-mood-count]').text(format('Dialog.Moods.MoodsCount', { count }));
  html.find('[data-tag-count]').text(format('Dialog.Moods.TagsCount', { count: allTags.length }));
  html.find('.mood-board-list-empty').toggleClass('hidden', count > 0);
}

function reindexMoodRows(html) {
  html.find('.mood-card-item').each((i, el) => {
    $(el).attr('data-index', i);
  });
}

function filterMoodRows(html) {
  const query = (html.find('#mood-board-search').val() || '').toString().trim().toLowerCase();
  let visibleCount = 0;

  html.find('.mood-card-item').each((i, el) => {
    const $row = $(el);
    const mood = readMoodFromRow($row);
    const haystack = `${mood.label} ${mood.tag}`.toLowerCase();
    const isVisible = !query || haystack.includes(query);
    $row.toggleClass('is-filtered', !isVisible);
    if (isVisible) visibleCount += 1;
  });

  const hasRows = html.find('.mood-card-item').length > 0;
  html.find('.mood-board-no-results').toggleClass('hidden', !hasRows || visibleCount > 0);
}

function getAllTags(music) {
  return [...new Set((music || []).flatMap(track => {
    if (!Array.isArray(track.tags)) return [];
    return track.tags.map(normalizeMoodTag).filter(Boolean);
  }))].sort((a, b) => a.localeCompare(b));
}

function getTrackCountsByTag(music) {
  const counts = new Map();
  (music || []).forEach(track => {
    if (!Array.isArray(track.tags)) return;
    track.tags.forEach(tag => {
      const key = normalizeMoodTag(tag);
      if (!key) return;
      counts.set(key, (counts.get(key) || 0) + 1);
    });
  });
  return counts;
}

function getTrackCount(trackCounts, tag) {
  return trackCounts.get(normalizeMoodTag(tag)) || 0;
}

function formatTrackCount(count) {
  return `${count} ${count === 1 ? 'Track' : 'Tracks'}`;
}

function getMoodLabel(mood) {
  return String(mood?.label || '').trim() || 'Untitled';
}

function getMoodColor(mood) {
  return String(mood?.color || '').trim() || DEFAULT_GRADIENT;
}

function getMoodIcon(mood) {
  return String(mood?.icon || '').trim() || DEFAULT_ICON;
}

function parseGradientColors(gradient) {
  const colors = String(gradient || '').match(/#[a-fA-F0-9]{6}/g);
  return colors && colors.length >= 2 ? [colors[0], colors[1]] : ['#667eea', '#764ba2'];
}

function getGradientCategory(gradient) {
  const match = PRESET_GRADIENTS.find(g => g.value === gradient);
  return match?.category || 'combat';
}

function getIconCategory(icon) {
  for (const [category, icons] of Object.entries(POPULAR_ICONS)) {
    if (icons.includes(icon)) return category;
  }
  return 'combat';
}

function renderIconMarkup(icon) {
  const value = icon || DEFAULT_ICON;
  if (isImageIcon(value)) return `<img src="${escapeAttribute(value)}" alt="">`;
  return `<i class="${escapeAttribute(value)}"></i>`;
}

function isImageIcon(icon) {
  const value = String(icon || '');
  return value.includes('/') || /\.(avif|gif|jpe?g|png|svg|webp)$/i.test(value);
}

function escapeAttribute(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

export default showEditMoodsDialog;
