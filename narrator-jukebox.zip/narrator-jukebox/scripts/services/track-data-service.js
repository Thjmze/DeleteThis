import { normalizeTags } from './validation-service.js';
import { extractYouTubeVideoId, getYouTubeThumbnail, normalizeYouTubeUrl } from '../utils/youtube-utils.js';
import {
  SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MAX,
  SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MIN
} from '../core/constants.js';

const AUDIO_EXTENSION_PATTERN = /\.(mp3|ogg|wav|webm|flac|m4a|aac)(?:$|[?#])/i;

function requireTrackString(value, label) {
  if (value == null || String(value).trim() === '') {
    throw new Error(`${label} is required.`);
  }
  return String(value).trim();
}

function getLibraryTracks(jukebox, library) {
  switch (library) {
    case 'music':
      return Array.isArray(jukebox?.music) ? jukebox.music : (jukebox?.getAllMusic?.() ?? []);
    case 'ambience':
      return Array.isArray(jukebox?.ambience) ? jukebox.ambience : (jukebox?.getAllAmbience?.() ?? []);
    case 'soundboard':
      return Array.isArray(jukebox?.soundboard) ? jukebox.soundboard : (jukebox?.getAllSoundboardSounds?.() ?? []);
    default:
      return [];
  }
}

function getDuplicateKey(trackData, library) {
  const rawUrl = trackData?.url || trackData?.path || '';
  if (!rawUrl) return '';

  let normalizedUrl = '';
  try {
    normalizedUrl = normalizeTrackUrl(rawUrl, trackData?.source ?? null);
  } catch {
    normalizedUrl = String(rawUrl).trim();
  }

  if (library === 'soundboard') {
    const startTime = trackData?.startTime ?? '';
    const endTime = trackData?.endTime ?? '';
    return `${normalizedUrl}|${startTime}|${endTime}`;
  }

  return normalizedUrl;
}

function hasAudioExtension(value) {
  return AUDIO_EXTENSION_PATTERN.test(String(value || ''));
}

function safeDecodeURIComponent(value) {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

function encodePathSegment(segment) {
  if (!segment) return segment;
  return encodeURIComponent(safeDecodeURIComponent(segment));
}

function encodePath(path) {
  return String(path || '')
    .split('/')
    .map(encodePathSegment)
    .join('/');
}

function findFirstUrlDelimiter(value) {
  const queryIndex = value.indexOf('?');
  const hashIndex = value.indexOf('#');

  if (queryIndex === -1) return hashIndex;
  if (hashIndex === -1) return queryIndex;
  return Math.min(queryIndex, hashIndex);
}

function splitLocalPathAndSuffix(value) {
  const delimiterIndex = findFirstUrlDelimiter(value);
  if (delimiterIndex === -1) return { path: value, suffix: '' };

  const path = value.slice(0, delimiterIndex);
  const suffix = value.slice(delimiterIndex);

  // If the delimiter appears before the audio extension, it is part of the
  // folder or file name and must be encoded instead of treated as query/hash.
  if (hasAudioExtension(value) && !hasAudioExtension(path)) {
    return { path: value, suffix: '' };
  }

  return { path, suffix };
}

function getUrlAuthority(url) {
  const username = url.username || '';
  const password = url.password ? `:${url.password}` : '';
  const auth = username ? `${username}${password}@` : '';
  return `${url.protocol}//${auth}${url.host}`;
}

function fragmentLooksLikeFilenameRemainder(url) {
  if (!url.hash) return false;
  const pathWithHash = `${url.pathname}${url.hash}`;
  return hasAudioExtension(pathWithHash) && !hasAudioExtension(url.pathname);
}

function searchLooksLikeFilenameRemainder(url) {
  if (!url.search) return false;
  const pathWithSearch = `${url.pathname}${url.search}${url.hash || ''}`;
  return hasAudioExtension(pathWithSearch) && !hasAudioExtension(url.pathname);
}

function normalizeLocalTrackUrl(url) {
  const trimmed = String(url || '').trim();

  if (/^(data|blob):/i.test(trimmed)) {
    return trimmed;
  }

  if (/^[a-z][a-z\d+.-]*:\/\//i.test(trimmed)) {
    try {
      const parsed = new URL(trimmed);
      const searchIsFilename = searchLooksLikeFilenameRemainder(parsed);
      const hashIsFilename = !searchIsFilename && fragmentLooksLikeFilenameRemainder(parsed);
      const rawPath = searchIsFilename
        ? `${parsed.pathname}${parsed.search}${parsed.hash || ''}`
        : hashIsFilename
          ? `${parsed.pathname}${parsed.hash}`
          : parsed.pathname;
      const search = searchIsFilename ? '' : parsed.search;
      const hash = searchIsFilename || hashIsFilename ? '' : parsed.hash;
      return `${getUrlAuthority(parsed)}${encodePath(rawPath)}${search}${hash}`;
    } catch {
      return encodePath(trimmed);
    }
  }

  const { path, suffix } = splitLocalPathAndSuffix(trimmed);
  return `${encodePath(path)}${suffix}`;
}

export function normalizeTrackUrl(url, source = null) {
  const trimmed = requireTrackString(url, 'Track URL');
  const youtubeId = extractYouTubeVideoId(trimmed);

  if (source === 'youtube' || youtubeId) {
    return youtubeId ? normalizeYouTubeUrl(trimmed) : trimmed;
  }

  return normalizeLocalTrackUrl(trimmed);
}

export function normalizeTrackTags(tags) {
  if (tags == null || tags === '') return [];

  const values = Array.isArray(tags)
    ? tags.join(',')
    : String(tags);

  return [...new Set(normalizeTags(values))];
}

export function normalizeBooleanFlag(value) {
  if (typeof value === 'string') {
    const normalized = value.trim().toLowerCase();
    if (['true', '1', 'yes', 'on'].includes(normalized)) return true;
    if (['false', '0', 'no', 'off', ''].includes(normalized)) return false;
  }

  return !!value;
}

function normalizePositiveSeconds(value, label, fallback) {
  if (value === '' || value == null) return fallback;

  const seconds = Number(value);
  if (!Number.isFinite(seconds) || seconds <= 0) {
    throw new Error(`${label} must be a number greater than 0.`);
  }

  return seconds;
}

export function normalizeTrackData(trackData, options = {}) {
  const { partial = false } = options;

  if (!trackData || typeof trackData !== 'object' || Array.isArray(trackData)) {
    throw new Error('Track data must be an object.');
  }

  const normalized = { ...trackData };

  if (normalized.path && !normalized.url) {
    normalized.url = normalized.path;
  }

  if (!partial || Object.hasOwn(normalized, 'name')) {
    normalized.name = requireTrackString(normalized.name, 'Track name');
  }

  const hasUrlInput = Object.hasOwn(normalized, 'url') || Object.hasOwn(normalized, 'path');
  if (!partial || hasUrlInput) {
    normalized.url = normalizeTrackUrl(normalized.url, normalized.source ?? null);
  }

  const youtubeId = normalized.url ? extractYouTubeVideoId(normalized.url) : null;

  if (Object.hasOwn(normalized, 'source') && normalized.source != null && normalized.source !== '') {
    normalized.source = String(normalized.source).toLowerCase().trim();
    if (!['local', 'youtube'].includes(normalized.source)) {
      throw new Error(`Invalid track source: "${normalized.source}". Must be 'local' or 'youtube'.`);
    }
  } else if (normalized.url) {
    normalized.source = youtubeId ? 'youtube' : 'local';
  } else if (!partial) {
    normalized.source = 'local';
  }

  if (youtubeId) {
    normalized.source = 'youtube';
  }

  if (!partial || Object.hasOwn(normalized, 'tags')) {
    normalized.tags = normalizeTrackTags(normalized.tags);
  }

  if (Object.hasOwn(normalized, 'thumbnail')) {
    normalized.thumbnail = normalized.thumbnail ? String(normalized.thumbnail).trim() : '';
  }

  if (normalized.source === 'youtube' && normalized.url && !normalized.thumbnail && youtubeId) {
    normalized.thumbnail = getYouTubeThumbnail(youtubeId, 'high');
  }

  if (Object.hasOwn(normalized, 'volume')) {
    if (normalized.volume === '' || normalized.volume == null) {
      delete normalized.volume;
    } else {
      const volume = Number(normalized.volume);
      if (Number.isNaN(volume) || volume < 0 || volume > 1) {
        throw new Error(`Invalid volume: "${normalized.volume}". Must be a number between 0 and 1.`);
      }
      normalized.volume = volume;
    }
  }

  if (Object.hasOwn(normalized, 'loop')) {
    normalized.loop = !!normalized.loop;
  }

  const hasRandomIntervalInput =
    Object.hasOwn(normalized, 'randomIntervalEnabled') ||
    Object.hasOwn(normalized, 'randomIntervalMin') ||
    Object.hasOwn(normalized, 'randomIntervalMax');

  if (hasRandomIntervalInput) {
    const hasRandomIntervalMin = Object.hasOwn(normalized, 'randomIntervalMin');
    const hasRandomIntervalMax = Object.hasOwn(normalized, 'randomIntervalMax');
    const enabled = Object.hasOwn(normalized, 'randomIntervalEnabled')
      ? normalizeBooleanFlag(normalized.randomIntervalEnabled)
      : !!normalized.randomIntervalEnabled;
    normalized.randomIntervalEnabled = enabled;

    if (enabled || hasRandomIntervalMin || hasRandomIntervalMax) {
      const min = normalizePositiveSeconds(
        normalized.randomIntervalMin,
        'randomIntervalMin',
        SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MIN
      );
      const max = normalizePositiveSeconds(
        normalized.randomIntervalMax,
        'randomIntervalMax',
        SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MAX
      );

      if (max < min) {
        throw new Error('randomIntervalMax must be greater than or equal to randomIntervalMin.');
      }

      normalized.randomIntervalMin = min;
      normalized.randomIntervalMax = max;
    }

    if (enabled) {
      normalized.loop = false;
    }
  }

  if (Object.hasOwn(normalized, 'hidden')) {
    normalized.hidden = normalizeBooleanFlag(normalized.hidden);
  }

  for (const key of ['startTime', 'endTime']) {
    if (!Object.hasOwn(normalized, key)) continue;
    if (normalized[key] === '' || normalized[key] == null) {
      delete normalized[key];
      continue;
    }

    const value = Number(normalized[key]);
    if (Number.isNaN(value) || value < 0) {
      throw new Error(`${key} must be a number greater than or equal to 0.`);
    }
    normalized[key] = value;
  }

  if (normalized.startTime != null && normalized.endTime != null && normalized.endTime < normalized.startTime) {
    throw new Error('endTime must be greater than or equal to startTime.');
  }

  if (Object.hasOwn(normalized, 'id')) {
    if (normalized.id === '' || normalized.id == null) {
      delete normalized.id;
    } else {
      normalized.id = String(normalized.id).trim();
    }
  }

  delete normalized.path;

  return normalized;
}

export function findDuplicateTrack(jukebox, library, trackData, options = {}) {
  const { excludeId = null } = options;
  const normalized = normalizeTrackData(trackData, { partial: true });
  const duplicateKey = getDuplicateKey(normalized, library);
  if (!duplicateKey) return null;

  const tracks = getLibraryTracks(jukebox, library);

  return tracks.find(track => {
    if (!track) return false;
    if (excludeId && track.id === excludeId) return false;

    return getDuplicateKey(track, library) === duplicateKey;
  }) || null;
}

export function partitionUniqueTrackEntries(jukebox, library, entries = [], options = {}) {
  const { excludeId = null } = options;
  const knownUrls = new Map();
  const uniqueEntries = [];
  const duplicates = [];

  for (const track of getLibraryTracks(jukebox, library)) {
    if (!track || (excludeId && track.id === excludeId)) continue;

    const duplicateKey = getDuplicateKey(track, library);
    if (!duplicateKey) continue;
    knownUrls.set(duplicateKey, track);
  }

  for (const entry of entries) {
    const normalized = normalizeTrackData(entry);
    const duplicateKey = getDuplicateKey(normalized, library);

    if (duplicateKey && knownUrls.has(duplicateKey)) {
      duplicates.push({
        entry: normalized,
        existingTrack: knownUrls.get(duplicateKey)
      });
      continue;
    }

    if (duplicateKey) {
      knownUrls.set(duplicateKey, normalized);
    }

    uniqueEntries.push(normalized);
  }

  return { uniqueEntries, duplicates };
}
