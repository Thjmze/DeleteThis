/**
 * Narrator's Jukebox - Sync Service
 * Handles multiplayer synchronization via socketlib
 */

import { JUKEBOX } from '../core/constants.js';
import { ambienceLayerManager } from '../core/ambience-layer-manager.js';
import { debugLog, debugWarn, debugError } from '../utils/debug.js';
import { extractYouTubeVideoId, normalizeYouTubeUrl } from '../utils/youtube-utils.js';
import { normalizeBooleanFlag, normalizeTrackUrl } from './track-data-service.js';

const HEALTH_POLL_INTERVAL = 5000;
const HEALTH_PROBE_INTERVAL = 15000;
const CLIENT_HEARTBEAT_INTERVAL = 12000;
const HEALTH_WARN_AFTER = 10000;
const HEALTH_ERROR_AFTER = 22000;
const HEALTH_AUTO_RESYNC_COOLDOWN = 30000;

const HEALTH_STATUS = Object.freeze({
  IDLE: 'idle',
  OK: 'ok',
  PENDING: 'pending',
  WARNING: 'warning',
  ERROR: 'error',
  OFFLINE: 'offline'
});

/**
 * SyncService - Manages socket communication for multiplayer sync
 */
class SyncService {
  constructor() {
    this.socket = null;
    this.playbackService = null;  // Injected
    this.dataService = null;      // Injected
    this._initialized = false;
    this._commandCounter = 0;
    this._health = new Map();
    this._healthInterval = null;
    this._clientHealthInterval = null;
    this._lastHealthSignature = '';
    this._lastProbeAt = 0;
    this._lastClientReportAt = 0;
    this._lastClientIssue = null;
    this._autoResyncAt = new Map();
    this._healthHooksRegistered = false;
  }

  /**
   * Initialize the sync service with dependencies
   * @param {object} playbackService - PlaybackService instance
   * @param {object} dataService - DataService instance
   */
  initialize(playbackService, dataService) {
    this.playbackService = playbackService;
    this.dataService = dataService;
  }

  /**
   * Initialize socket connection with socketlib
   * Should be called when socketlib.ready hook fires
   */
  initializeSocket() {
    if (typeof socketlib === 'undefined') {
      debugWarn(' socketlib not available');
      return false;
    }

    this.socket = socketlib.registerModule(JUKEBOX.ID);
    this.socket.register('suggestTrack', this._handleSuggestTrack.bind(this));
    this.socket.register('handleRemoteCommand', this._handleRemoteCommand.bind(this));

    this._initialized = true;
    debugLog(' SyncService socket initialized');
    return true;
  }

  /**
   * Check if socket is available
   */
  isAvailable() {
    return this.socket !== null;
  }

  /**
   * Start lightweight health monitoring. GM tracks player status; players
   * periodically report while they have active or expected audio.
   */
  startHealthMonitor() {
    if (this._healthInterval || this._clientHealthInterval) return;

    this._registerHealthHooks();

    if (game.user?.isGM) {
      this._ensurePlayerHealthEntries();
      this._notifyHealthChanged(true);
      this._healthInterval = setInterval(() => this._runGMHealthTick(), HEALTH_POLL_INTERVAL);
      return;
    }

    this.reportClientHealth({ status: HEALTH_STATUS.IDLE, action: 'ready' });
    this._clientHealthInterval = setInterval(() => {
      if (this._clientShouldReportHealth()) {
        this.reportClientHealth({ action: 'heartbeat' });
      }
    }, CLIENT_HEARTBEAT_INTERVAL);
  }

  _registerHealthHooks() {
    if (this._healthHooksRegistered) return;
    this._healthHooksRegistered = true;

    Hooks.on('userConnected', () => {
      if (!game.user?.isGM) return;
      this._ensurePlayerHealthEntries();
      this._notifyHealthChanged(true);
    });

    if (!game.user?.isGM) {
      Hooks.on('narratorJukeboxPlaybackError', payload => {
        const message = payload?.classifiedError?.message || payload?.error?.message || 'Playback error on this client.';
        this._lastClientIssue = {
          message,
          channel: payload?.channel || null,
          timestamp: Date.now()
        };
        this.reportClientHealth({
          status: HEALTH_STATUS.ERROR,
          action: 'playbackError',
          message
        });
      });

      Hooks.on('narratorJukeboxAutoplayBlocked', payload => {
        const count = payload?.count ?? payload?.expected ?? 0;
        const message = count > 0
          ? `${count} ambience layer${count === 1 ? '' : 's'} waiting for audio unlock.`
          : 'Audio is waiting for player interaction.';
        this._lastClientIssue = {
          message,
          channel: 'ambienceLayers',
          timestamp: Date.now()
        };
        this.reportClientHealth({
          status: HEALTH_STATUS.WARNING,
          action: 'autoplayBlocked',
          message
        });
      });

      Hooks.on('narratorJukeboxDeferredStateApplied', () => {
        this.reportClientHealth({
          status: HEALTH_STATUS.OK,
          action: 'audioUnlocked',
          message: 'Deferred ambience state applied.'
        });
      });
    }
  }

  _createCommandId(action = 'command') {
    this._commandCounter += 1;
    return `${Date.now()}-${this._commandCounter}-${action}`;
  }

  _getUsersArray() {
    if (!game.users) return [];
    if (Array.isArray(game.users.contents)) return [...game.users.contents];
    if (typeof game.users.values === 'function') return Array.from(game.users.values());
    return Array.from(game.users || []);
  }

  _getOnlinePlayerUsers() {
    return this._getUsersArray().filter(user => user && user.active && !user.isGM);
  }

  _getInitials(name = '?') {
    const parts = String(name || '?').trim().split(/\s+/).filter(Boolean);
    if (!parts.length) return '?';
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return `${parts[0][0] || ''}${parts[parts.length - 1][0] || ''}`.toUpperCase();
  }

  _hasActiveBroadcastState() {
    if (!game.user?.isGM || this.playbackService?.isPreviewMode) return false;
    const hasMusic = !!(this.playbackService?.isPlaying && this.playbackService?.getCurrentMusicTrack?.());
    const hasLegacyAmbience = !!(this.playbackService?.isAmbiencePlaying && this.playbackService?.getCurrentAmbienceTrack?.());
    const hasLayers = (ambienceLayerManager.getLayersState()?.layers || []).length > 0;
    const hasLoopingSoundboard = Array.from(this.playbackService?.activeSoundboardSounds?.values?.() || [])
      .some(sound => !!sound?.isLooping && !sound?.isPreview);
    return hasMusic || hasLegacyAmbience || hasLayers || hasLoopingSoundboard;
  }

  _ensurePlayerHealthEntries() {
    if (!game.user?.isGM) return;

    const users = this._getUsersArray().filter(user => user && !user.isGM);
    const seen = new Set();

    for (const user of users) {
      seen.add(user.id);
      const existing = this._health.get(user.id) || {};
      this._health.set(user.id, {
        ...existing,
        userId: user.id,
        userName: user.name || existing.userName || 'Player',
        active: !!user.active,
        status: user.active ? (existing.status || HEALTH_STATUS.IDLE) : HEALTH_STATUS.OFFLINE,
        updatedAt: existing.updatedAt || 0
      });
    }

    for (const [userId, entry] of this._health.entries()) {
      if (!seen.has(userId)) {
        this._health.delete(userId);
      } else {
        const user = game.users.get(userId);
        if (user && !user.active && entry.status !== HEALTH_STATUS.OFFLINE) {
          this._health.set(userId, {
            ...entry,
            active: false,
            status: HEALTH_STATUS.OFFLINE,
            message: 'Player offline.'
          });
        }
      }
    }
  }

  _normalizeHealthStatus(status) {
    if (Object.values(HEALTH_STATUS).includes(status)) return status;
    if (status === 'blocked' || status === 'drift' || status === 'loading') return HEALTH_STATUS.WARNING;
    if (status === 'missing' || status === 'failed') return HEALTH_STATUS.ERROR;
    return HEALTH_STATUS.OK;
  }

  _markCommandPending(payload, recipients = null) {
    if (!game.user?.isGM || !payload?.commandId) return;

    const users = recipients
      ? recipients.map(userId => game.users.get(userId)).filter(Boolean)
      : this._getOnlinePlayerUsers();

    for (const user of users) {
      const existing = this._health.get(user.id) || {};
      this._health.set(user.id, {
        ...existing,
        userId: user.id,
        userName: user.name || existing.userName || 'Player',
        active: !!user.active,
        status: user.active ? HEALTH_STATUS.PENDING : HEALTH_STATUS.OFFLINE,
        message: user.active ? 'Waiting for playback confirmation.' : 'Player offline.',
        lastCommandId: payload.commandId,
        lastCommandAction: payload.action,
        lastCommandAt: Date.now(),
        updatedAt: Date.now()
      });
    }

    this._notifyHealthChanged(true);
  }

  _stampPayload(payload, { track = true, recipients = null } = {}) {
    const stamped = {
      ...payload,
      commandId: payload.commandId || this._createCommandId(payload.action),
      sentBy: game.user?.id || null,
      timestamp: payload.timestamp || Date.now()
    };

    if (track) this._markCommandPending(stamped, recipients);
    return stamped;
  }

  _executeForOthers(payload, options = {}) {
    if (!this.socket) return;
    const stamped = this._stampPayload(payload, options);
    this.socket.executeForOthers('handleRemoteCommand', stamped);
  }

  _executeForUsers(userIds, payload, options = {}) {
    if (!this.socket) return;
    const recipients = Array.isArray(userIds) ? userIds.filter(Boolean) : [userIds].filter(Boolean);
    if (!recipients.length) return;
    const stamped = this._stampPayload(payload, { ...options, recipients });
    this.socket.executeForUsers('handleRemoteCommand', recipients, stamped);
  }

  /**
   * Normalize legacy track payloads received over socket sync.
   * Older suggestion flows could send `path` instead of `url` or omit `source`.
   * @param {object} track
   * @param {string} channel
   * @returns {object|null}
   */
  _normalizeTrackData(track, channel = 'music') {
    if (!track) return null;

    const normalized = { ...track };
    normalized.url = normalized.url || normalized.path || '';
    const youtubeId = normalized.url ? extractYouTubeVideoId(normalized.url) : null;

    if (youtubeId) {
      normalized.source = 'youtube';
      normalized.url = normalizeYouTubeUrl(normalized.url);
    } else if (!normalized.source) {
      normalized.source = 'local';
    }

    if (normalized.url) {
      try {
        normalized.url = normalizeTrackUrl(normalized.url, normalized.source);
      } catch (error) {}
    }

    if (!normalized.id && track.id) {
      normalized.id = track.id;
    }

    if (Object.hasOwn(normalized, 'hidden')) {
      normalized.hidden = normalizeBooleanFlag(normalized.hidden);
    }

    normalized._channel = channel;
    return normalized;
  }

  /**
   * Cache embedded track data locally so later sync/seek/pause paths can resolve it.
   * @param {object} track
   * @param {string} channel
   */
  _cacheTrackData(track, channel = 'music') {
    const normalized = this._normalizeTrackData(track, channel);
    if (!normalized?.id) return;

    const collection = channel === 'ambience' ? this.dataService.ambience : this.dataService.music;
    const index = collection.findIndex(entry => entry.id === normalized.id);

    if (index >= 0) {
      collection[index] = { ...collection[index], ...normalized };
    } else {
      collection.push(normalized);
    }
  }

  /**
   * Serialize track data for socket payloads using the same normalization
   * rules as incoming sync messages.
   * @param {object} track
   * @param {string} channel
   * @returns {object|null}
   */
  _serializeTrackData(track, channel = 'music') {
    const normalized = this._normalizeTrackData(track, channel);
    if (!normalized?.id) return null;

    return {
      id: normalized.id,
      name: normalized.name,
      url: normalized.url,
      source: normalized.source,
      tags: normalized.tags,
      thumbnail: normalized.thumbnail,
      volume: normalized.volume,
      startTime: normalized.startTime,
      endTime: normalized.endTime,
      hidden: normalized.hidden || false
    };
  }

  /**
   * Build a lookup table of ambience layer track data for sync payloads.
   * @param {object} layersState
   * @returns {Record<string, object>}
   */
  _serializeAmbienceLayerTrackData(layersState = null) {
    const state = layersState || ambienceLayerManager.getLayersState();
    const activeLayers = new Map(
      ambienceLayerManager.getActiveLayers().map(layer => [layer.trackId, layer.track])
    );

    return (state.layers || []).reduce((acc, layerState) => {
      const track = activeLayers.get(layerState.trackId) ||
        this.dataService.getAmbience(layerState.trackId) ||
        this.dataService.findTrack(layerState.trackId, 'ambience');
      const serialized = this._serializeTrackData(track, 'ambience');
      if (serialized) {
        acc[layerState.trackId] = serialized;
      }
      return acc;
    }, {});
  }

  /**
   * Cache a lookup table of embedded track data locally.
   * @param {Record<string, object>} trackDataMap
   * @param {string} channel
   */
  _cacheTrackDataMap(trackDataMap = {}, channel = 'ambience') {
    Object.values(trackDataMap || {}).forEach(trackData => {
      this._cacheTrackData(trackData, channel);
    });
  }

  _normalizeSoundboardData(sound) {
    if (!sound) return null;
    const normalized = { ...sound };
    normalized.url = normalized.url || normalized.path || '';
    const youtubeId = normalized.url ? extractYouTubeVideoId(normalized.url) : null;

    if (youtubeId) {
      normalized.source = 'youtube';
      normalized.url = normalizeYouTubeUrl(normalized.url);
    } else if (!normalized.source) {
      normalized.source = 'local';
    }

    if (normalized.url) {
      try {
        normalized.url = normalizeTrackUrl(normalized.url, normalized.source);
      } catch (error) {}
    }

    return normalized;
  }

  _serializeSoundboardData(sound) {
    const normalized = this._normalizeSoundboardData(sound);
    if (!normalized?.id) return null;

    return {
      id: normalized.id,
      name: normalized.name,
      url: normalized.url,
      source: normalized.source,
      volume: normalized.volume,
      loop: !!normalized.loop,
      randomIntervalEnabled: !!normalized.randomIntervalEnabled,
      randomIntervalMin: normalized.randomIntervalMin,
      randomIntervalMax: normalized.randomIntervalMax,
      startTime: normalized.startTime,
      endTime: normalized.endTime,
      color: normalized.color,
      icon: normalized.icon,
      thumbnail: normalized.thumbnail
    };
  }

  _cacheSoundboardData(soundData) {
    const normalized = this._normalizeSoundboardData(soundData);
    if (!normalized?.id) return;

    const collection = this.dataService.soundboard || [];
    const index = collection.findIndex(entry => entry.id === normalized.id);
    if (index >= 0) {
      collection[index] = { ...collection[index], ...normalized };
    } else {
      collection.push(normalized);
    }
  }

  _getActiveSoundboardState() {
    const activeSounds = [];

    for (const [soundId, active] of this.playbackService?.activeSoundboardSounds || []) {
      if (!active?.isLooping || active?.isPreview) continue;

      const sound = this.dataService.getSoundboardSound(soundId);
      let currentTime = 0;
      try {
        currentTime = active.audio?.currentTime || active.player?.getCurrentTime?.() || 0;
      } catch (error) {}

      activeSounds.push({
        soundId,
        loop: true,
        startTime: active.startTime || sound?.startTime || 0,
        endTime: active.endTime ?? sound?.endTime ?? null,
        currentTime,
        soundData: this._serializeSoundboardData(sound)
      });
    }

    return { activeSounds };
  }

  _buildStatePayload(options = {}) {
    if (!this.playbackService) return null;

    // While GM is in preview mode, do not leak the local playback state to
    // players via any path (heartbeat, resync, player-request, soft reset).
    // Players keep whatever was actually broadcast last; the GM's private
    // preview never propagates over the wire.
    if (game.user?.isGM && this.playbackService.isPreviewMode) return null;

    const musicTrack = this.playbackService.getCurrentMusicTrack();
    const ambienceTrack = this.playbackService.getCurrentAmbienceTrack();

    const state = {
      action: 'syncState',
      musicTrackId: musicTrack?.id,
      musicTime: this.playbackService.channels?.music?.currentTime || 0,
      isPlaying: this.playbackService.isPlaying,
      ambienceTrackId: ambienceTrack?.id,
      isAmbiencePlaying: this.playbackService.isAmbiencePlaying,
      volume: this.playbackService.channels?.music?.volume || 0.8,
      ambienceVolume: this.playbackService.channels?.ambience?.volume || 0.5,
      ambienceLayersState: ambienceLayerManager.getLayersState(),
      ambienceLayersTrackData: this._serializeAmbienceLayerTrackData(),
      soundboardState: this._getActiveSoundboardState(),
      reason: options.reason || 'state',
      timestamp: Date.now()
    };

    if (musicTrack) {
      state.musicTrackData = this._serializeTrackData(musicTrack, 'music');
    }
    if (ambienceTrack) {
      state.ambienceTrackData = this._serializeTrackData(ambienceTrack, 'ambience');
    }

    return state;
  }

  resyncUser(userId, reason = 'manual') {
    if (!game.user?.isGM) return false;
    const user = game.users.get(userId);
    if (!user?.active) {
      ui.notifications.warn('Narrator Jukebox: Player is not connected.');
      return false;
    }

    this.broadcastState(userId, { reason: `${reason}-resync` });
    ui.notifications.info(`Narrator Jukebox: resync sent to ${user.name}.`);
    return true;
  }

  softResetUser(userId, reason = 'manual') {
    if (!game.user?.isGM || !this.socket) return false;
    const user = game.users.get(userId);
    if (!user?.active) {
      ui.notifications.warn('Narrator Jukebox: Player is not connected.');
      return false;
    }

    const payload = {
      action: 'softReset',
      targetUserId: userId,
      reason,
      state: this._buildStatePayload({ reason: `${reason}-soft-reset` })
    };

    this._executeForUsers([userId], payload);
    ui.notifications.info(`Narrator Jukebox: audio reset sent to ${user.name}.`);
    return true;
  }

  requestUserStatus(userId, reason = 'manual') {
    if (!game.user?.isGM || !this.socket) return false;
    const user = game.users.get(userId);
    if (!user?.active) return false;

    this._executeForUsers([userId], {
      action: 'healthProbe',
      targetUserId: userId,
      reason
    }, { track: false });
    return true;
  }

  requestAllPlayerStatus(reason = 'manual') {
    if (!game.user?.isGM || !this.socket) return false;
    const recipients = this._getOnlinePlayerUsers().map(user => user.id);
    if (!recipients.length) return false;

    this._executeForUsers(recipients, {
      action: 'healthProbe',
      reason
    }, { track: false });
    return true;
  }

  // ==========================================
  // Broadcast Commands (GM -> Players)
  // ==========================================

  /**
   * Broadcast play command
   * @param {string} trackId - Track ID to play
   * @param {string} channel - 'music' or 'ambience'
   * @param {number} volume - Current volume level (0-1)
   * @param {object} [trackData] - Full track data as fallback for clients that haven't synced yet
   */
  broadcastPlay(trackId, channel = 'music', volume = 0.8, trackData = null) {
    if (!this.socket) return;
    const payload = {
      action: 'play',
      trackId,
      channel,
      volume,
      timestamp: Date.now()
    };
    // Include track data so players can play even if their settings haven't synced yet
    // (e.g. GM just approved a suggestion and immediately hit play)
    if (trackData) {
      payload.trackData = this._serializeTrackData(trackData, channel);
    }
    this._executeForOthers(payload);
  }

  /**
   * Broadcast pause command
   * @param {string} channel - 'music' or 'ambience'
   */
  broadcastPause(channel = 'music') {
    if (!this.socket) return;
    const payload = {
      action: 'pause',
      channel,
      timestamp: Date.now()
    };
    this._executeForOthers(payload);
  }

  /**
   * Broadcast resume command
   * @param {string} channel - 'music' or 'ambience'
   */
  broadcastResume(channel = 'music') {
    if (!this.socket) return;
    const payload = {
      action: 'resume',
      channel,
      timestamp: Date.now()
    };
    this._executeForOthers(payload);
  }

  /**
   * Broadcast stop command
   * @param {string} channel - 'music' or 'ambience'
   */
  broadcastStop(channel = 'music') {
    if (!this.socket) return;
    const payload = {
      action: 'stop',
      channel,
      timestamp: Date.now()
    };
    this._executeForOthers(payload);
  }

  /**
   * Broadcast volume change
   * @param {string} channel - 'music' or 'ambience'
   * @param {number} volume - Volume level (0-1)
   */
  broadcastVolume(channel, volume) {
    if (!this.socket) return;
    const payload = {
      action: 'volume',
      channel,
      volume,
      timestamp: Date.now()
    };
    this._executeForOthers(payload, { track: false });
  }

  /**
   * Broadcast seek/scrub position
   * @param {string} channel - 'music' or 'ambience'
   * @param {number} percent - Seek position (0-100)
   */
  broadcastSeek(channel, percent) {
    if (!this.socket) return;
    const payload = {
      action: 'seek',
      channel,
      percent,
      timestamp: Date.now()
    };
    this._executeForOthers(payload);
  }

  /**
   * Broadcast soundboard play
   * @param {string} soundId - Soundboard sound ID
   * @param {boolean} loop - Whether to loop
   */
  broadcastSoundboardPlay(soundId, loop = false, soundData = null) {
    if (!this.socket) return;
    const payload = {
      action: 'soundboard',
      subAction: 'play',
      soundId,
      loop,
      timestamp: Date.now()
    };
    if (soundData) {
      payload.soundData = this._serializeSoundboardData(soundData);
    }
    this._executeForOthers(payload);
  }

  /**
   * Broadcast soundboard stop
   * @param {string} soundId - Soundboard sound ID
   */
  broadcastSoundboardStop(soundId) {
    if (!this.socket) return;
    const payload = {
      action: 'soundboard',
      subAction: 'stop',
      soundId,
      timestamp: Date.now()
    };
    this._executeForOthers(payload);
  }

  /**
   * Broadcast stop all soundboard sounds
   */
  broadcastSoundboardStopAll() {
    if (!this.socket) return;
    const payload = {
      action: 'soundboard',
      subAction: 'stopAll',
      timestamp: Date.now()
    };
    this._executeForOthers(payload);
  }

  // ==========================================
  // Ambience Layers Broadcast (Incremental)
  // ==========================================

  /**
   * Broadcast adding a single ambience layer
   * @param {string} trackId - Track ID to add
   * @param {number} volume - Initial volume (0-1)
   */
  broadcastAmbienceLayerAdd(trackId, volume = 0.8, trackData = null) {
    if (!this.socket) return;
    const payload = {
      action: 'ambienceLayers',
      subAction: 'addLayer',
      trackId,
      volume,
      timestamp: Date.now()
    };
    if (trackData) {
      payload.trackData = this._serializeTrackData(trackData, 'ambience');
    }
    debugLog(' Broadcasting add layer:', trackId);
    this._executeForOthers(payload);
  }

  /**
   * Broadcast removing a single ambience layer
   * @param {string} trackId - Track ID to remove
   */
  broadcastAmbienceLayerRemove(trackId) {
    if (!this.socket) return;
    const payload = {
      action: 'ambienceLayers',
      subAction: 'removeLayer',
      trackId,
      timestamp: Date.now()
    };
    debugLog(' Broadcasting remove layer:', trackId);
    this._executeForOthers(payload, { track: false });
  }

  /**
   * Broadcast volume change for a single layer
   * @param {string} trackId - Track ID
   * @param {number} volume - New volume (0-1)
   */
  broadcastAmbienceLayerVolume(trackId, volume) {
    if (!this.socket) return;
    const payload = {
      action: 'ambienceLayers',
      subAction: 'layerVolume',
      trackId,
      volume,
      timestamp: Date.now()
    };
    this._executeForOthers(payload, { track: false });
  }

  /**
   * Broadcast master volume change
   * @param {number} volume - New master volume (0-1)
   */
  broadcastAmbienceMasterVolume(volume) {
    if (!this.socket) return;
    const payload = {
      action: 'ambienceLayers',
      subAction: 'masterVolume',
      volume,
      timestamp: Date.now()
    };
    this._executeForOthers(payload);
  }

  /**
   * Broadcast master mute toggle
   * @param {boolean} muted - New mute state
   */
  broadcastAmbienceMasterMute(muted) {
    if (!this.socket) return;
    const payload = {
      action: 'ambienceLayers',
      subAction: 'masterMute',
      muted,
      timestamp: Date.now()
    };
    this._executeForOthers(payload);
  }

  /**
   * Broadcast stop all ambience layers
   */
  broadcastAmbienceLayersStopAll() {
    if (!this.socket) return;
    const payload = {
      action: 'ambienceLayers',
      subAction: 'stopAll',
      timestamp: Date.now()
    };
    debugLog(' Broadcasting stop all layers');
    this._executeForOthers(payload);
  }

  /**
   * Broadcast full ambience layers state (for initial sync when player joins)
   * @param {object} layersState - State from ambienceLayerManager.getLayersState()
   */
  broadcastAmbienceLayers(layersState) {
    if (!this.socket) return;
    const payload = {
      action: 'ambienceLayers',
      subAction: 'fullSync',
      layersState,
      trackDataMap: this._serializeAmbienceLayerTrackData(layersState),
      timestamp: Date.now()
    };
    debugLog(' Broadcasting full ambience state:', layersState);
    this._executeForOthers(payload);
  }

  /**
   * Broadcast current state to all players
   */
  broadcastState(targetUserId = null, options = {}) {
    if (!this.socket || !this.playbackService) return;

    const state = this._buildStatePayload(options);
    if (!state) return;

    if (targetUserId) {
      state.targetUserId = targetUserId;
      this._executeForUsers([targetUserId], state);
      return;
    }

    const stamped = this._stampPayload(state);
    this.socket.executeForEveryone('handleRemoteCommand', stamped);
  }

  /**
   * Request current state from GM (for players joining)
   */
  requestState() {
    if (!this.socket) return;
    this.socket.executeForEveryone('handleRemoteCommand', {
      action: 'requestState',
      requestingUserId: game.user?.id || null,
      timestamp: Date.now()
    });
  }

  reportClientHealth(extra = {}) {
    if (!this.socket || game.user?.isGM) return;

    const now = Date.now();
    if (extra.action === 'heartbeat' && (now - this._lastClientReportAt) < CLIENT_HEARTBEAT_INTERVAL - 1000) {
      return;
    }
    this._lastClientReportAt = now;

    const report = this._buildClientHealthReport(extra);
    this.socket.executeAsGM('handleRemoteCommand', {
      action: 'healthReport',
      report,
      userId: game.user?.id || null,
      timestamp: now
    }).catch(error => {
      debugWarn('Failed to send health report to GM:', error);
    });
  }

  _clientShouldReportHealth() {
    if (game.user?.isGM) return false;
    if (this._lastClientIssue) return true;
    if (this.playbackService?.isPlaying || this.playbackService?.isAmbiencePlaying) return true;
    if ((this.playbackService?.activeSoundboardSounds?.size || 0) > 0) return true;
    if ((ambienceLayerManager.layerCount || 0) > 0) return true;
    if (ambienceLayerManager.hasDeferredState?.() || ambienceLayerManager.hasPendingLayers?.()) return true;
    return false;
  }

  _describeChannel(channelName) {
    const channel = this.playbackService?.channels?.[channelName];
    if (!channel) {
      return {
        trackId: null,
        isPlaying: false,
        hasInstance: false,
        currentTime: 0,
        duration: 0
      };
    }

    return {
      trackId: channel.currentTrack?.id || null,
      trackName: channel.currentTrack?.name || null,
      isPlaying: this._isChannelActivelyPlaying(channel),
      hasInstance: this._channelHasPlaybackInstance(channel),
      currentTime: channel.currentTime || 0,
      duration: channel.duration || 0,
      source: channel.currentTrack?.source || null
    };
  }

  _buildClientHealthReport(extra = {}) {
    const activeLayers = ambienceLayerManager.getActiveTrackIds?.() || [];
    const layerIssues = ambienceLayerManager.getAllLayerIssues?.() || [];
    const activeSounds = Array.from(this.playbackService?.activeSoundboardSounds?.entries?.() || [])
      .map(([soundId, sound]) => ({
        soundId,
        isLooping: !!sound?.isLooping,
        isPreview: !!sound?.isPreview
      }));

    const derived = this._deriveLocalHealthStatus({
      extra,
      activeLayers,
      layerIssues,
      activeSounds
    });

    return {
      userId: game.user?.id || null,
      userName: game.user?.name || 'Player',
      timestamp: Date.now(),
      commandId: extra.commandId || null,
      action: extra.action || null,
      status: extra.status || derived.status,
      message: extra.message || derived.message,
      visibilityState: typeof document !== 'undefined' ? document.visibilityState : 'visible',
      focused: typeof document !== 'undefined' ? document.hasFocus?.() ?? true : true,
      music: this._describeChannel('music'),
      ambience: this._describeChannel('ambience'),
      ambienceLayers: {
        activeTrackIds: activeLayers,
        activeCount: activeLayers.length,
        deferredCount: ambienceLayerManager.getDeferredLayerCount?.() || 0,
        pending: ambienceLayerManager.hasPendingLayers?.() || false,
        issues: layerIssues.slice(0, 4)
      },
      soundboard: {
        activeSounds
      },
      issue: this._lastClientIssue
    };
  }

  _deriveLocalHealthStatus({ extra, layerIssues, activeSounds }) {
    if (extra.status) {
      return {
        status: this._normalizeHealthStatus(extra.status),
        message: extra.message || ''
      };
    }

    if (layerIssues?.length) {
      return {
        status: HEALTH_STATUS.ERROR,
        message: layerIssues[0]?.message || 'Ambience layer issue on this client.'
      };
    }

    if (ambienceLayerManager.hasDeferredState?.() || ambienceLayerManager.hasPendingLayers?.()) {
      return {
        status: HEALTH_STATUS.WARNING,
        message: 'Audio is waiting for player interaction.'
      };
    }

    if (this._lastClientIssue && (Date.now() - this._lastClientIssue.timestamp) < HEALTH_ERROR_AFTER) {
      return {
        status: HEALTH_STATUS.WARNING,
        message: this._lastClientIssue.message || 'Recent playback issue.'
      };
    }

    const hasAudio = this.playbackService?.isPlaying ||
      this.playbackService?.isAmbiencePlaying ||
      ambienceLayerManager.layerCount > 0 ||
      activeSounds?.length > 0;

    return {
      status: hasAudio ? HEALTH_STATUS.OK : HEALTH_STATUS.IDLE,
      message: hasAudio ? 'Playback confirmed.' : 'Online.'
    };
  }

  _handleHealthReport(report = {}) {
    if (!game.user?.isGM || !report?.userId) return;

    const user = game.users.get(report.userId);
    const existing = this._health.get(report.userId) || {};
    const now = Date.now();
    const normalizedStatus = this._normalizeHealthStatus(report.status);
    const latency = existing.lastCommandId && existing.lastCommandId === report.commandId && existing.lastCommandAt
      ? Math.max(0, now - existing.lastCommandAt)
      : existing.latency;

    this._health.set(report.userId, {
      ...existing,
      userId: report.userId,
      userName: report.userName || user?.name || existing.userName || 'Player',
      active: user?.active ?? true,
      status: normalizedStatus,
      message: report.message || this._getDefaultHealthMessage(normalizedStatus),
      latency,
      lastReportAt: now,
      updatedAt: now,
      report
    });

    this._maybeAutoResync(report.userId, normalizedStatus);
    this._notifyHealthChanged();
  }

  _getDefaultHealthMessage(status) {
    switch (status) {
      case HEALTH_STATUS.OK: return 'Playback confirmed.';
      case HEALTH_STATUS.PENDING: return 'Waiting for confirmation.';
      case HEALTH_STATUS.WARNING: return 'Playback needs attention.';
      case HEALTH_STATUS.ERROR: return 'Playback failed on this client.';
      case HEALTH_STATUS.OFFLINE: return 'Player offline.';
      default: return 'Online.';
    }
  }

  _runGMHealthTick() {
    if (!game.user?.isGM) return;

    this._ensurePlayerHealthEntries();

    const now = Date.now();
    const hasBroadcast = this._hasActiveBroadcastState();
    if (hasBroadcast && (now - this._lastProbeAt) >= HEALTH_PROBE_INTERVAL) {
      this._lastProbeAt = now;
      this.requestAllPlayerStatus('heartbeat');
    }

    if (hasBroadcast) {
      const summary = this.getHealthSummary();
      for (const player of summary.players) {
        if (!player.active || player.statusClass === HEALTH_STATUS.OK || player.statusClass === HEALTH_STATUS.IDLE) continue;
        if (player.stale || player.statusClass === HEALTH_STATUS.ERROR) {
          this._maybeAutoResync(player.id, player.statusClass);
        }
      }
    }

    this._notifyHealthChanged();
  }

  _maybeAutoResync(userId, status) {
    if (!game.user?.isGM || !this._hasActiveBroadcastState()) return;
    if (status === HEALTH_STATUS.OK || status === HEALTH_STATUS.IDLE || status === HEALTH_STATUS.OFFLINE) return;

    const user = game.users.get(userId);
    if (!user?.active) return;

    const now = Date.now();
    const last = this._autoResyncAt.get(userId) || 0;
    if ((now - last) < HEALTH_AUTO_RESYNC_COOLDOWN) return;

    this._autoResyncAt.set(userId, now);
    debugWarn(`Auto-resyncing ${user.name} after health status: ${status}`);
    this.broadcastState(userId, { reason: 'auto-health' });
  }

  _notifyHealthChanged(force = false) {
    if (!game.user?.isGM) return;
    const summary = this.getHealthSummary();
    const signature = JSON.stringify(summary.players.map(player => [
      player.id,
      player.active,
      player.statusClass,
      player.message,
      player.latencyLabel,
      player.stale
    ]));

    if (!force && signature === this._lastHealthSignature) return;
    this._lastHealthSignature = signature;
    Hooks.call('narratorJukeboxStateChanged', { scope: 'health' });
  }

  getHealthSummary() {
    if (!game.user?.isGM) {
      return {
        visible: false,
        players: [],
        summaryLabel: 'Players',
        overallClass: HEALTH_STATUS.IDLE
      };
    }

    this._ensurePlayerHealthEntries();

    const now = Date.now();
    const hasBroadcast = this._hasActiveBroadcastState();
    const players = this._getUsersArray()
      .filter(user => user && !user.isGM && user.active)
      .map(user => {
        const entry = this._health.get(user.id) || {};
        const active = !!user.active;
        const age = entry.lastReportAt ? now - entry.lastReportAt : null;
        let status = active ? (entry.status || HEALTH_STATUS.IDLE) : HEALTH_STATUS.OFFLINE;
        let stale = false;
        let message = entry.message || (active ? 'Online.' : 'Player offline.');

        if (active && hasBroadcast) {
          if (!entry.lastReportAt) {
            const commandAge = entry.lastCommandAt ? now - entry.lastCommandAt : 0;
            if (commandAge > HEALTH_ERROR_AFTER) {
              status = HEALTH_STATUS.ERROR;
              stale = true;
              message = 'No confirmation after the last broadcast command.';
            } else if (commandAge > HEALTH_WARN_AFTER) {
              status = HEALTH_STATUS.WARNING;
              stale = true;
              message = 'Still waiting for playback confirmation.';
            } else {
              status = HEALTH_STATUS.PENDING;
              message = 'Waiting for first playback confirmation.';
            }
          } else if (age > HEALTH_ERROR_AFTER) {
            status = HEALTH_STATUS.ERROR;
            stale = true;
            message = 'No recent response from this player.';
          } else if (age > HEALTH_WARN_AFTER && status === HEALTH_STATUS.OK) {
            status = HEALTH_STATUS.WARNING;
            stale = true;
            message = 'Playback confirmation is getting stale.';
          }
        } else if (active && !hasBroadcast) {
          status = HEALTH_STATUS.IDLE;
          message = 'Online. No broadcast is active.';
        }

        const latencyLabel = Number.isFinite(entry.latency)
          ? `${Math.round(entry.latency)}ms`
          : '';
        const report = entry.report || {};
        const tooltipParts = [
          user.name || 'Player',
          this._getDefaultHealthMessage(status),
          message,
          latencyLabel ? `Latency: ${latencyLabel}` : '',
          report.music?.trackName ? `Music: ${report.music.trackName}` : '',
          report.ambienceLayers?.activeCount ? `Layers: ${report.ambienceLayers.activeCount}` : '',
          report.issue?.message ? `Issue: ${report.issue.message}` : '',
          'Click: resync this player',
          'Right-click: reset player audio'
        ].filter(Boolean);

        return {
          id: user.id,
          name: user.name || 'Player',
          initials: this._getInitials(user.name),
          active,
          statusClass: status,
          statusLabel: this._getHealthStatusLabel(status),
          message,
          tooltip: tooltipParts.join(' | '),
          latencyLabel,
          stale,
          needsAttention: status === HEALTH_STATUS.WARNING || status === HEALTH_STATUS.ERROR || status === HEALTH_STATUS.PENDING,
          report
        };
      });

    const activePlayers = players.filter(player => player.active);
    const issueCount = players.filter(player => player.needsAttention && player.statusClass !== HEALTH_STATUS.PENDING).length;
    const pendingCount = players.filter(player => player.statusClass === HEALTH_STATUS.PENDING).length;
    const okCount = players.filter(player => player.statusClass === HEALTH_STATUS.OK).length;
    const overallClass = issueCount > 0
      ? HEALTH_STATUS.ERROR
      : pendingCount > 0
        ? HEALTH_STATUS.PENDING
        : hasBroadcast && activePlayers.length && okCount === activePlayers.length
          ? HEALTH_STATUS.OK
          : HEALTH_STATUS.IDLE;

    return {
      visible: players.length > 0,
      hasBroadcast,
      players,
      onlineCount: activePlayers.length,
      issueCount,
      pendingCount,
      okCount,
      overallClass,
      summaryLabel: hasBroadcast
        ? `${okCount}/${activePlayers.length} receiving`
        : `${activePlayers.length} online`
    };
  }

  _getHealthStatusLabel(status) {
    switch (status) {
      case HEALTH_STATUS.OK: return 'Receiving';
      case HEALTH_STATUS.PENDING: return 'Pending';
      case HEALTH_STATUS.WARNING: return 'Needs attention';
      case HEALTH_STATUS.ERROR: return 'Problem';
      case HEALTH_STATUS.OFFLINE: return 'Offline';
      default: return 'Online';
    }
  }

  // ==========================================
  // Player Suggestions
  // ==========================================

  /**
   * Send a track suggestion to the GM
   * @param {object} track - Track data to suggest
   */
  async suggestTrack(track) {
    if (!this.socket) {
      ui.notifications.warn('Socket not available. Cannot send suggestion.');
      return;
    }

    const userName = game.user.name;
    track.user = userName;
    track.suggestedAt = Date.now();

    // Execute for GM only
    await this.socket.executeAsGM('suggestTrack', track, userName);
    ui.notifications.info('Suggestion sent to GM!');
  }

  // ==========================================
  // Handle Incoming Commands
  // ==========================================

  /**
   * Handle suggestion received (GM only)
   */
  async _handleSuggestTrack(track, userName) {
    debugLog(" GM receiving suggestion:", track, "from:", userName);

    try {
      track = this._normalizeTrackData(track, 'music') || track;

      if (!track.user) {
        track.user = userName;
      }
      if (!track.id) {
        track.id = foundry.utils.randomID();
      }
      if (!track.suggestedAt) {
        track.suggestedAt = Date.now();
      }

      await this.dataService.addSuggestion(track);

      debugLog(" Suggestion saved");
      ui.notifications.info(`Narrator Jukebox: New music suggestion from ${userName}`);

      // Trigger UI update
      Hooks.call('narratorJukeboxSuggestionReceived', track);
      Hooks.call('narratorJukeboxStateChanged', { scope: 'suggestions' });
    } catch (err) {
      debugError(" Failed to save suggestion:", err);
    }
  }

  /**
   * Handle remote command
   * @param {object} payload - Command payload
   */
  async _handleRemoteCommand(payload) {
    debugLog(" Received Socket Payload:", payload);

    if (payload?.targetUserId && payload.targetUserId !== game.user?.id) {
      return;
    }

    if (payload.action === 'healthReport') {
      this._handleHealthReport(payload.report || payload);
      return;
    }

    if (payload.action === 'healthProbe') {
      if (!game.user.isGM) {
        this.reportClientHealth({
          status: HEALTH_STATUS.OK,
          action: 'healthProbe',
          commandId: payload.commandId || null,
          message: 'Health probe answered.'
        });
      }
      return;
    }

    // Handle requestState (only GM responds)
    if (payload.action === 'requestState') {
      if (game.user.isGM) {
        this.broadcastState(payload.requestingUserId || null, { reason: 'player-request' });
      }
      return;
    }

    if (payload.action === 'softReset') {
      await this._handleSoftResetCommand(payload);
      return;
    }

    // Skip execution for GM in preview mode
    if (game.user.isGM && this.playbackService?.isPreviewMode) {
      debugLog(" GM in preview mode, ignoring remote command");
      return;
    }

    // Process command
    let result = null;
    try {
      result = await this._processCommand(payload);
    } catch (err) {
      debugError(' Remote command failed:', err);
      result = {
        ok: false,
        status: HEALTH_STATUS.ERROR,
        message: err?.message || 'Remote command failed.'
      };
    }

    // Trigger UI update
    Hooks.call('narratorJukeboxRemoteCommand', payload);

    if (!game.user.isGM && payload.commandId) {
      this.reportClientHealth({
        commandId: payload.commandId,
        action: payload.action,
        status: result?.status || (result?.ok === false ? HEALTH_STATUS.ERROR : HEALTH_STATUS.OK),
        message: result?.message || null
      });
    }
  }

  async _processCommand(payload) {
    if (!this.playbackService) {
      debugWarn(' PlaybackService not available for remote command');
      return {
        ok: false,
        status: HEALTH_STATUS.ERROR,
        message: 'Playback service not available.'
      };
    }

    switch (payload.action) {
      case 'play':
        return await this._handlePlayCommand(payload);

      case 'pause':
        if (!this.playbackService.channels[payload.channel]) {
          return { ok: false, status: HEALTH_STATUS.ERROR, message: `Unknown channel: ${payload.channel}` };
        }
        this.playbackService.channels[payload.channel].pause();
        if (payload.channel === 'music') this.playbackService.isPlaying = false;
        if (payload.channel === 'ambience') this.playbackService.isAmbiencePlaying = false;
        return { ok: true, status: HEALTH_STATUS.OK, message: 'Paused.' };

      case 'resume':
        if (!this.playbackService.channels[payload.channel]) {
          return { ok: false, status: HEALTH_STATUS.ERROR, message: `Unknown channel: ${payload.channel}` };
        }
        this.playbackService.channels[payload.channel].resume();
        if (payload.channel === 'music') this.playbackService.isPlaying = true;
        if (payload.channel === 'ambience') this.playbackService.isAmbiencePlaying = true;
        return { ok: true, status: HEALTH_STATUS.OK, message: 'Resumed.' };

      case 'stop':
        if (!this.playbackService.channels[payload.channel]) {
          return { ok: false, status: HEALTH_STATUS.ERROR, message: `Unknown channel: ${payload.channel}` };
        }
        this.playbackService.channels[payload.channel].stop();
        if (payload.channel === 'music') this.playbackService.isPlaying = false;
        if (payload.channel === 'ambience') this.playbackService.isAmbiencePlaying = false;
        return { ok: true, status: HEALTH_STATUS.OK, message: 'Stopped.' };

      case 'volume':
        if (!this.playbackService.channels[payload.channel]) {
          return { ok: false, status: HEALTH_STATUS.ERROR, message: `Unknown channel: ${payload.channel}` };
        }

        if (game.user.isGM) {
          this.playbackService.channels[payload.channel].setVolume(payload.volume);
        } else {
          this._applySyncedChannelVolume(payload.channel);
        }
        return { ok: true, status: HEALTH_STATUS.OK, message: 'Local volume preserved.' };

      case 'seek':
        if (!this.playbackService.channels[payload.channel]) {
          return { ok: false, status: HEALTH_STATUS.ERROR, message: `Unknown channel: ${payload.channel}` };
        }
        this.playbackService.channels[payload.channel].seek(payload.percent);
        return { ok: true, status: HEALTH_STATUS.OK, message: 'Seek applied.' };

      case 'syncState':
        return await this._handleSyncState(payload);

      case 'soundboard':
        return await this._handleSoundboardCommand(payload);

      case 'ambienceLayers':
        return await this._handleAmbienceLayersCommand(payload);
    }

    return {
      ok: true,
      status: HEALTH_STATUS.OK,
      message: 'Command ignored.'
    };
  }

  async _handleSoftResetCommand(payload) {
    if (game.user.isGM) return;

    try {
      this._resetClientAudioState();
      await this.dataService.loadAllData();

      let syncResult = {
        ok: true,
        status: HEALTH_STATUS.OK,
        message: 'Audio reset completed.'
      };
      if (payload.state) {
        syncResult = await this._handleSyncState({
          ...payload.state,
          commandId: payload.commandId,
          targetUserId: game.user?.id || null
        });
      }

      Hooks.call('narratorJukeboxRemoteCommand', payload);
      this.reportClientHealth({
        commandId: payload.commandId || null,
        action: 'softReset',
        status: syncResult?.status || HEALTH_STATUS.OK,
        message: syncResult?.message || 'Audio reset and resync completed.'
      });
    } catch (err) {
      debugError(' Soft reset failed:', err);
      this._lastClientIssue = {
        message: err?.message || 'Soft reset failed.',
        channel: 'system',
        timestamp: Date.now()
      };
      this.reportClientHealth({
        commandId: payload.commandId || null,
        action: 'softReset',
        status: HEALTH_STATUS.ERROR,
        message: err?.message || 'Soft reset failed.'
      });
    }
  }

  _resetClientAudioState() {
    this.playbackService.channels?.music?.stop();
    this.playbackService.channels?.ambience?.stop();
    this.playbackService.isPlaying = false;
    this.playbackService.isAmbiencePlaying = false;

    for (const [id] of Array.from(this.playbackService.activeSoundboardSounds || [])) {
      this.playbackService.stopSoundboardSound(id, false);
    }

    ambienceLayerManager.stopAll(false);
  }

  async _handlePlayCommand(payload) {
    let track = this._normalizeTrackData(this.dataService.findTrack(payload.trackId, payload.channel), payload.channel);

    // Reload data if track not found (settings may not have synced yet)
    if (!track) {
      debugWarn(` Track ${payload.trackId} not found. Reloading data...`);
      await this.dataService.loadAllData();
      track = this._normalizeTrackData(this.dataService.findTrack(payload.trackId, payload.channel), payload.channel);
    }

    // Retry after delay - Foundry world settings propagation can lag behind socketlib
    if (!track) {
      debugWarn(` Track still not found. Retrying after delay...`);
      await new Promise(resolve => setTimeout(resolve, 1500));
      await this.dataService.loadAllData();
      track = this._normalizeTrackData(this.dataService.findTrack(payload.trackId, payload.channel), payload.channel);
    }

    // Last resort: use embedded track data from the broadcast payload
    if (!track && payload.trackData) {
      debugWarn(` Using embedded track data from broadcast for: ${payload.trackData.name}`);
      track = this._normalizeTrackData(payload.trackData, payload.channel);
      this._cacheTrackData(track, payload.channel);
    }

    if (!track) {
      debugError(`Track ${payload.trackId} not found after all retries.`);
      ui.notifications.error(`Failed to sync: track not found`);
      this._lastClientIssue = {
        message: `Track not found: ${payload.trackId}`,
        channel: payload.channel,
        timestamp: Date.now()
      };
      return {
        ok: false,
        status: HEALTH_STATUS.ERROR,
        message: `Track not found: ${payload.trackId}`
      };
    }

    debugLog(`Playing synced track: ${track.name}`);

    if (payload.channel === 'music') this.playbackService.isPlaying = true;
    if (payload.channel === 'ambience') this.playbackService.isAmbiencePlaying = true;

    // Apply volume before playing
    if (payload.volume !== undefined) {
      if (game.user.isGM) {
        // GM uses broadcast volume directly
        this.playbackService.channels[payload.channel].setVolume(payload.volume);
      } else {
        // Players use their own saved volume preference (persisted from widget/app slider)
        // This prevents GM's volume from overriding the player's choice on every track change
        const settingKey = payload.channel === 'music'
          ? JUKEBOX.SETTINGS.VOLUME
          : JUKEBOX.SETTINGS.AMBIENCE_VOLUME;
        const muteKey = payload.channel === 'music'
          ? JUKEBOX.SETTINGS.MUSIC_MUTED
          : JUKEBOX.SETTINGS.AMBIENCE_MUTED;
        const playerVolume = game.settings.get(JUKEBOX.ID, settingKey);
        const isMuted = game.settings.get(JUKEBOX.ID, muteKey);
        this.playbackService.channels[payload.channel].setVolume(isMuted ? 0 : playerVolume);
      }
    }

    try {
      await this.playbackService.channels[payload.channel].play(track);
      this._lastClientIssue = null;
      const displayName = payload.channel === 'music' && normalizeBooleanFlag(track.hidden) && !game.user.isGM
        ? 'Now Playing'
        : (track.name || 'track');

      return {
        ok: true,
        status: HEALTH_STATUS.OK,
        message: `Playing ${displayName}.`
      };
    } catch (err) {
      debugError(" Remote play failed:", err);
      ui.notifications.error(`Failed to play synced music: ${err.message}`);
      if (payload.channel === 'music') this.playbackService.isPlaying = false;
      if (payload.channel === 'ambience') this.playbackService.isAmbiencePlaying = false;
      this._lastClientIssue = {
        message: err?.message || 'Remote play failed.',
        channel: payload.channel,
        timestamp: Date.now()
      };
      return {
        ok: false,
        status: HEALTH_STATUS.ERROR,
        message: err?.message || 'Remote play failed.'
      };
    }
  }

  _applySyncedChannelVolume(channel, volume) {
    if (volume === undefined) return;

    if (game.user.isGM) {
      this.playbackService.channels[channel].setVolume(volume);
      return;
    }

    const settingKey = channel === 'music'
      ? JUKEBOX.SETTINGS.VOLUME
      : JUKEBOX.SETTINGS.AMBIENCE_VOLUME;
    const muteKey = channel === 'music'
      ? JUKEBOX.SETTINGS.MUSIC_MUTED
      : JUKEBOX.SETTINGS.AMBIENCE_MUTED;
    const playerVolume = game.settings.get(JUKEBOX.ID, settingKey);
    const isMuted = game.settings.get(JUKEBOX.ID, muteKey);
    this.playbackService.channels[channel].setVolume(isMuted ? 0 : playerVolume);
  }

  _channelHasPlaybackInstance(channel) {
    return !!(channel?.audioElement || channel?.youtubePlayer);
  }

  _isChannelActivelyPlaying(channel) {
    if (!channel) return false;

    if (channel.audioElement) {
      return !channel.audioElement.paused && !channel.audioElement.ended;
    }

    if (typeof YT !== 'undefined' && channel.youtubePlayer?.getPlayerState) {
      try {
        const state = channel.youtubePlayer.getPlayerState();
        return state === YT.PlayerState.PLAYING || state === YT.PlayerState.BUFFERING;
      } catch (error) {}
    }

    return false;
  }

  _shouldResyncMusicPosition(channel, targetTime = 0) {
    if (!targetTime) return false;
    const currentTime = channel?.currentTime || 0;
    return Math.abs(currentTime - targetTime) > 2;
  }

  _seekMusicChannelToTime(channel, targetTime = 0) {
    if (!targetTime) return;
    const duration = channel?.duration;
    if (!duration) return;
    channel.seek(targetTime / duration * 100);
  }

  async _syncSoundboardState(soundboardState = null) {
    if (!soundboardState?.activeSounds) return;

    const desired = new Set(soundboardState.activeSounds.map(sound => sound.soundId).filter(Boolean));

    for (const [id, active] of Array.from(this.playbackService.activeSoundboardSounds || [])) {
      if (active?.isLooping && !desired.has(id)) {
        this.playbackService.stopSoundboardSound(id, false);
      }
    }

    for (const activeSound of soundboardState.activeSounds) {
      if (!activeSound?.soundId) continue;
      if (activeSound.soundData) {
        this._cacheSoundboardData(activeSound.soundData);
      }

      let sound = this.dataService.getSoundboardSound(activeSound.soundId);
      if (!sound && activeSound.soundData) {
        sound = this._normalizeSoundboardData(activeSound.soundData);
        this._cacheSoundboardData(sound);
      }

      if (!sound) {
        debugWarn(` Sync state: soundboard sound ${activeSound.soundId} unavailable on this client.`);
        this._lastClientIssue = {
          message: `Soundboard sound not found: ${activeSound.soundId}`,
          channel: 'soundboard',
          timestamp: Date.now()
        };
        continue;
      }

      if (!this.playbackService.activeSoundboardSounds.has(activeSound.soundId)) {
        await this.playbackService.playSoundboardSound(activeSound.soundId, {
          loop: !!activeSound.loop,
          randomIntervalEnabled: false,
          preview: true
        });
      }
    }
  }

  _assessSyncState(payload) {
    const issues = [];
    const warnings = [];

    const musicChannel = this.playbackService.channels.music;
    if (payload.musicTrackId && payload.isPlaying) {
      const sameTrack = musicChannel.currentTrack?.id === payload.musicTrackId;
      const isPlaying = this._isChannelActivelyPlaying(musicChannel);
      if (!sameTrack) issues.push('Music track mismatch.');
      if (!isPlaying) issues.push('Music is not actively playing.');
      if (sameTrack && payload.musicTime && Math.abs((musicChannel.currentTime || 0) - payload.musicTime) > 4) {
        warnings.push('Music position drift detected.');
      }
    }

    const expectedLayers = (payload.ambienceLayersState?.layers || []).map(layer => layer.trackId);
    if (expectedLayers.length) {
      const activeLayers = new Set(ambienceLayerManager.getActiveTrackIds?.() || []);
      const missing = expectedLayers.filter(trackId => !activeLayers.has(trackId));
      if (missing.length && ambienceLayerManager.hasDeferredState?.()) {
        warnings.push(`${missing.length} ambience layer${missing.length === 1 ? '' : 's'} waiting for audio unlock.`);
      } else if (missing.length) {
        issues.push(`${missing.length} ambience layer${missing.length === 1 ? '' : 's'} missing.`);
      }
    }

    const layerIssues = ambienceLayerManager.getAllLayerIssues?.() || [];
    if (layerIssues.length) {
      issues.push(layerIssues[0]?.message || 'Ambience layer issue.');
    }

    const expectedSounds = (payload.soundboardState?.activeSounds || []).map(sound => sound.soundId);
    if (expectedSounds.length) {
      const activeSounds = this.playbackService.activeSoundboardSounds || new Map();
      const missingSounds = expectedSounds.filter(soundId => !activeSounds.has(soundId));
      if (missingSounds.length) issues.push(`${missingSounds.length} looped soundboard cue${missingSounds.length === 1 ? '' : 's'} missing.`);
    }

    if (issues.length) {
      this._lastClientIssue = {
        message: issues[0],
        channel: 'sync',
        timestamp: Date.now()
      };
      return {
        ok: false,
        status: HEALTH_STATUS.ERROR,
        message: issues[0]
      };
    }

    if (warnings.length) {
      return {
        ok: true,
        status: HEALTH_STATUS.WARNING,
        message: warnings[0]
      };
    }

    this._lastClientIssue = null;
    return {
      ok: true,
      status: HEALTH_STATUS.OK,
      message: 'State synchronized.'
    };
  }

  async _handleSyncState(payload) {
    // Ensure data is loaded (use || to ensure both are loaded)
    if (this.dataService.music.length === 0 || this.dataService.ambience.length === 0) {
      await this.dataService.loadAllData();
    }

    // Sync Music
    if (payload.musicTrackId) {
      let track = this._normalizeTrackData(this.dataService.getMusic(payload.musicTrackId), 'music');

      // Reload data if track not found (may have been added recently, e.g. approved suggestion)
      if (!track) {
        debugWarn(` Sync state: music track ${payload.musicTrackId} not found. Reloading...`);
        await this.dataService.loadAllData();
        track = this._normalizeTrackData(this.dataService.getMusic(payload.musicTrackId), 'music');
      }

      // Last resort: use embedded track data from the sync payload
      if (!track && payload.musicTrackData) {
        debugWarn(` Sync state: using embedded track data for: ${payload.musicTrackData.name}`);
        track = this._normalizeTrackData(payload.musicTrackData, 'music');
        this._cacheTrackData(track, 'music');
      }

      const currentId = this.playbackService.channels.music.currentTrack?.id;
      const musicChannel = this.playbackService.channels.music;
      const sameTrack = currentId === payload.musicTrackId;
      const hasInstance = this._channelHasPlaybackInstance(musicChannel);
      const isActuallyPlaying = this._isChannelActivelyPlaying(musicChannel);

      this._applySyncedChannelVolume('music', payload.volume);

      if (track && (!sameTrack || !hasInstance)) {
        if (payload.isPlaying) {
          this.playbackService.isPlaying = true;
        }

        try {
          await musicChannel.play(track, () => {
            this._seekMusicChannelToTime(musicChannel, payload.musicTime);
            if (!payload.isPlaying) {
              musicChannel.pause();
              this.playbackService.isPlaying = false;
            }
          });
        } catch (err) {
          debugError(' Sync state music playback failed:', err);
          this.playbackService.isPlaying = false;
        }
      } else if (track && sameTrack) {
        this._seekMusicChannelToTime(
          musicChannel,
          this._shouldResyncMusicPosition(musicChannel, payload.musicTime) ? payload.musicTime : 0
        );

        if (payload.isPlaying) {
          if (!isActuallyPlaying) {
            musicChannel.resume();
          }
          this.playbackService.isPlaying = true;
        } else {
          if (isActuallyPlaying) {
            musicChannel.pause();
          }
          this.playbackService.isPlaying = false;
        }
      }
    } else {
      const musicChannel = this.playbackService.channels.music;
      if (musicChannel.currentTrack || this.playbackService.isPlaying || this._channelHasPlaybackInstance(musicChannel)) {
        musicChannel.stop();
      }
      this.playbackService.isPlaying = false;
    }

    // Sync Ambience (legacy single-track mode)
    if (payload.ambienceTrackId) {
      let track = this._normalizeTrackData(this.dataService.getAmbience(payload.ambienceTrackId), 'ambience');
      if (!track) track = this._normalizeTrackData(this.dataService.getMusic(payload.ambienceTrackId), 'ambience');

      // Last resort: use embedded track data from the sync payload
      if (!track && payload.ambienceTrackData) {
        debugWarn(` Sync state: using embedded ambience track data for: ${payload.ambienceTrackData.name}`);
        track = this._normalizeTrackData(payload.ambienceTrackData, 'ambience');
        this._cacheTrackData(track, 'ambience');
      }

      const currentId = this.playbackService.channels.ambience.currentTrack?.id;
      const ambienceChannel = this.playbackService.channels.ambience;
      const sameTrack = currentId === payload.ambienceTrackId;
      const hasInstance = this._channelHasPlaybackInstance(ambienceChannel);
      const isActuallyPlaying = this._isChannelActivelyPlaying(ambienceChannel);

      this._applySyncedChannelVolume('ambience', payload.ambienceVolume);

      if (track && (!sameTrack || !hasInstance)) {
        if (payload.isAmbiencePlaying) {
          this.playbackService.isAmbiencePlaying = true;
        }

        try {
          await ambienceChannel.play(track, () => {
            if (!payload.isAmbiencePlaying) {
              ambienceChannel.pause();
              this.playbackService.isAmbiencePlaying = false;
            }
          });
        } catch (err) {
          debugError(' Sync state ambience playback failed:', err);
          this.playbackService.isAmbiencePlaying = false;
        }
      } else if (track && sameTrack) {
        if (payload.isAmbiencePlaying) {
          if (!isActuallyPlaying) {
            ambienceChannel.resume();
          }
          this.playbackService.isAmbiencePlaying = true;
        } else {
          if (isActuallyPlaying) {
            ambienceChannel.pause();
          }
          this.playbackService.isAmbiencePlaying = false;
        }
      }
    } else {
      const ambienceChannel = this.playbackService.channels.ambience;
      if (ambienceChannel.currentTrack || this.playbackService.isAmbiencePlaying || this._channelHasPlaybackInstance(ambienceChannel)) {
        ambienceChannel.stop();
      }
      this.playbackService.isAmbiencePlaying = false;
    }

    // Sync Ambience Layers (new multi-layer mode)
    // Handle both cases: layers present OR explicit empty state (GM cleared layers)
    if (payload.ambienceLayersState) {
      const hasLayers = payload.ambienceLayersState.layers?.length > 0;
      const playerHasLayers = ambienceLayerManager.layerCount > 0;

      // Restore state if GM has layers, OR if player has layers but GM doesn't (clear them)
      if (hasLayers || playerHasLayers) {
        try {
          this._cacheTrackDataMap(payload.ambienceLayersTrackData, 'ambience');
          await ambienceLayerManager.restoreState(payload.ambienceLayersState, false);
          debugLog(' Synced ambience layers:', ambienceLayerManager.layerCount);
        } catch (err) {
          debugError(' Failed to sync ambience layers:', err);
        }
      }
    }

    await this._syncSoundboardState(payload.soundboardState);

    return this._assessSyncState(payload);
  }

  async _handleSoundboardCommand(payload) {
    if (payload.subAction === 'play') {
      if (payload.soundData) {
        this._cacheSoundboardData(payload.soundData);
      }

      let sound = this.dataService.getSoundboardSound(payload.soundId);

      if (!sound) {
        debugWarn(` Soundboard sound not found. Reloading...`);
        await this.dataService.loadAllData();
        sound = this.dataService.getSoundboardSound(payload.soundId);

        if (!sound && payload.soundData) {
          sound = this._normalizeSoundboardData(payload.soundData);
          this._cacheSoundboardData(sound);
        }

        if (!sound) {
          debugError(" Soundboard sound not found after reload");
          ui.notifications.error('Failed to play soundboard: sound not found');
          this._lastClientIssue = {
            message: `Soundboard sound not found: ${payload.soundId}`,
            channel: 'soundboard',
            timestamp: Date.now()
          };
          return {
            ok: false,
            status: HEALTH_STATUS.ERROR,
            message: `Soundboard sound not found: ${payload.soundId}`
          };
        }
      }

      try {
        const result = await this.playbackService.playSoundboardSound(payload.soundId, {
          loop: payload.loop,
          randomIntervalEnabled: false,
          preview: true  // Don't re-broadcast
        });

        if (result?.ok === false) {
          return {
            ok: false,
            status: HEALTH_STATUS.ERROR,
            message: result.message || 'Soundboard playback failed.'
          };
        }

        return {
          ok: true,
          status: HEALTH_STATUS.OK,
          message: `Soundboard cue playing: ${sound.name || payload.soundId}.`
        };
      } catch (err) {
        debugError(" Remote soundboard play failed:", err);
        ui.notifications.error(`Failed to play soundboard: ${err.message}`);
        this._lastClientIssue = {
          message: err?.message || 'Remote soundboard play failed.',
          channel: 'soundboard',
          timestamp: Date.now()
        };
        return {
          ok: false,
          status: HEALTH_STATUS.ERROR,
          message: err?.message || 'Remote soundboard play failed.'
        };
      }
    } else if (payload.subAction === 'stop') {
      this.playbackService.stopSoundboardSound(payload.soundId, false);
      return { ok: true, status: HEALTH_STATUS.OK, message: 'Soundboard cue stopped.' };
    } else if (payload.subAction === 'stopAll') {
      for (const [id] of this.playbackService.activeSoundboardSounds) {
        this.playbackService.stopSoundboardSound(id, false);
      }
      return { ok: true, status: HEALTH_STATUS.OK, message: 'Soundboard stopped.' };
    }

    return { ok: true, status: HEALTH_STATUS.OK, message: 'Soundboard command ignored.' };
  }

  /**
   * Handle ambience layers command (incremental sync)
   * @param {object} payload - Command payload
   */
  async _handleAmbienceLayersCommand(payload) {
    debugLog(' Handling ambience layers command:', payload.subAction || 'unknown');

    // Ensure data is loaded for any operation that needs track data
    const ensureData = async () => {
      if (this.dataService.ambience.length === 0) {
        await this.dataService.loadAllData();
      }
    };

    switch (payload.subAction) {
      case 'addLayer':
        await ensureData();
        try {
          if (payload.trackData) {
            this._cacheTrackData(payload.trackData, 'ambience');
          }

          // Only add if not already present
          if (!ambienceLayerManager.isLayerActive(payload.trackId)) {
            let layer = await ambienceLayerManager.addLayerWithoutBroadcast(payload.trackId, payload.volume);

            if (!layer && !payload.trackData && !ambienceLayerManager.hasDeferredState?.()) {
              await this.dataService.loadAllData();
              layer = await ambienceLayerManager.addLayerWithoutBroadcast(payload.trackId, payload.volume);
            }

            if (layer || ambienceLayerManager.hasDeferredState?.() || ambienceLayerManager.hasPendingLayers?.()) {
              debugLog(' Added synced layer:', payload.trackId);
              if (ambienceLayerManager.hasDeferredState?.() || ambienceLayerManager.hasPendingLayers?.()) {
                return {
                  ok: true,
                  status: HEALTH_STATUS.WARNING,
                  message: 'Ambience layer waiting for player audio unlock.'
                };
              }
              return {
                ok: true,
                status: HEALTH_STATUS.OK,
                message: 'Ambience layer added.'
              };
            } else {
              debugWarn(' Synced layer could not be created on this client:', payload.trackId);
              return {
                ok: false,
                status: HEALTH_STATUS.ERROR,
                message: `Ambience layer could not be created: ${payload.trackId}`
              };
            }
          }
          return {
            ok: true,
            status: HEALTH_STATUS.OK,
            message: 'Ambience layer already active.'
          };
        } catch (err) {
          debugError(' Failed to add synced layer:', err);
          return {
            ok: false,
            status: HEALTH_STATUS.ERROR,
            message: err?.message || 'Failed to add ambience layer.'
          };
        }

      case 'removeLayer':
        ambienceLayerManager.removeLayerWithoutBroadcast(payload.trackId);
        debugLog(' Removed synced layer:', payload.trackId);
        return { ok: true, status: HEALTH_STATUS.OK, message: 'Ambience layer removed.' };

      case 'layerVolume':
        ambienceLayerManager.setLayerVolumeWithoutBroadcast(payload.trackId, payload.volume);
        return { ok: true, status: HEALTH_STATUS.OK, message: 'Ambience layer volume applied.' };

      case 'masterVolume':
        if (!game.user.isGM) {
          return { ok: true, status: HEALTH_STATUS.OK, message: 'Local ambience volume preserved.' };
        }
        ambienceLayerManager.setMasterVolumeWithoutBroadcast(payload.volume);
        return { ok: true, status: HEALTH_STATUS.OK, message: 'Ambience master volume applied.' };

      case 'masterMute':
        if (!game.user.isGM) {
          return { ok: true, status: HEALTH_STATUS.OK, message: 'Local ambience mute preserved.' };
        }
        ambienceLayerManager.setMasterMuteWithoutBroadcast(payload.muted);
        return { ok: true, status: HEALTH_STATUS.OK, message: 'Ambience master mute applied.' };

      case 'stopAll':
        ambienceLayerManager.stopAll(false);
        debugLog(' Stopped all synced layers');
        return { ok: true, status: HEALTH_STATUS.OK, message: 'Ambience layers stopped.' };

      case 'fullSync':
        // Full state sync (for player joining mid-session)
        await ensureData();
        try {
          this._cacheTrackDataMap(payload.trackDataMap, 'ambience');
          await ambienceLayerManager.restoreState(payload.layersState, false);
          debugLog(' Full sync completed:', ambienceLayerManager.layerCount, 'layers');
          return this._assessSyncState({
            ambienceLayersState: payload.layersState,
            soundboardState: null
          });
        } catch (err) {
          debugError(' Failed full sync:', err);
          return {
            ok: false,
            status: HEALTH_STATUS.ERROR,
            message: err?.message || 'Full ambience sync failed.'
          };
        }

      default:
        // Legacy: handle old format with layersState directly
        if (payload.layersState) {
          await ensureData();
          try {
            this._cacheTrackDataMap(payload.trackDataMap, 'ambience');
            await ambienceLayerManager.restoreState(payload.layersState, false);
            debugLog(' Legacy sync completed');
            return this._assessSyncState({
              ambienceLayersState: payload.layersState,
              soundboardState: null
            });
          } catch (err) {
            debugError(' Failed legacy sync:', err);
            return {
              ok: false,
              status: HEALTH_STATUS.ERROR,
              message: err?.message || 'Legacy ambience sync failed.'
            };
          }
        }
    }

    return {
      ok: true,
      status: HEALTH_STATUS.OK,
      message: 'Ambience command ignored.'
    };
  }
}

// Export singleton instance
export const syncService = new SyncService();

// Also export the class for testing
export { SyncService };
