/**
 * Narrator's Jukebox - Playback Service
 * Handles all playback control operations for music, ambience, and soundboard
 */

import {
  DEFAULT_PREVIEW_MODE,
  JUKEBOX,
  MUSIC_REPEAT_MODES,
  SOUNDBOARD_END_CHECK,
  SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MAX,
  SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MIN
} from '../core/constants.js';
import { JukeboxBrowser } from '../utils/browser-detection.js';
import { extractYouTubeVideoId, styleHiddenYouTubeContainer } from '../utils/youtube-utils.js';
import { ambienceLayerManager } from '../core/ambience-layer-manager.js';
import { debugLog, debugWarn, debugError } from '../utils/debug.js';
import { normalizeTrackUrl } from './track-data-service.js';

/**
 * PlaybackService - Manages audio playback across all channels
 * Requires channels and dataService to be injected
 */
class PlaybackService {
  constructor() {
    this.channels = null;      // Injected: { music, ambience, soundboard }
    this.dataService = null;   // Injected: DataService instance
    this.syncService = null;   // Injected: SyncService instance

    // Playback state
    this.isPlaying = false;
    this.isAmbiencePlaying = false;
    this.shuffle = false;
    this._musicRepeatMode = MUSIC_REPEAT_MODES.OFF;
    this.ambienceLoop = true;
    this.isPreviewMode = DEFAULT_PREVIEW_MODE;
    this.isMuted = false;
    this.isAmbienceMuted = false;
    this.volumeBeforeMute = 0.8;
    this.ambienceVolumeBeforeMute = 0.5;

    // Current playlist/source context
    this.currentPlaylist = null;
    this.currentMusicSourceContext = null;
    this.manualQueue = [];
    this._manualQueueReturnContext = null;
    this._manualQueueCounter = 0;

    // Soundboard active sounds
    this.activeSoundboardSounds = new Map();
    this.soundboardBroadcastMode = !DEFAULT_PREVIEW_MODE;
    this.soundboardLoopState = new Map();
  }

  /**
   * Initialize the service with dependencies
   * @param {object} channels - Audio channels { music, ambience, soundboard }
   * @param {object} dataService - DataService instance
   * @param {object} syncService - SyncService instance (optional)
   */
  initialize(channels, dataService, syncService = null) {
    this.channels = channels;
    this.dataService = dataService;
    this.syncService = syncService;

    // Initialize the Ambience Layer Manager
    ambienceLayerManager.initialize(dataService, syncService);
    ambienceLayerManager.setPreviewMode(this.isPreviewMode);
  }

  // ==========================================
  // Music Playback
  // ==========================================

  _getPlayablePlaylistMusicIds(playlist) {
    return (playlist?.musicIds || []).filter(id => this.dataService.getMusic(id));
  }

  _createManualQueueEntryId() {
    return globalThis.foundry?.utils?.randomID?.() || `queue-${Date.now()}-${++this._manualQueueCounter}`;
  }

  _getManualQueueSourceContext(musicId = null) {
    const playlist = this.currentPlaylist;
    const playlistIds = this._getPlayablePlaylistMusicIds(playlist);

    if (playlist && playlistIds.length && (!musicId || playlistIds.includes(musicId))) {
      return {
        sourceType: 'playlist',
        sourceName: playlist.name || 'Playlist',
        sourceId: playlist.id || null
      };
    }

    const sourceContext = this._getPlayableMusicSourceContext();
    if (sourceContext && (!musicId || sourceContext.musicIds.includes(musicId))) {
      return {
        sourceType: 'library',
        sourceSubType: sourceContext.sourceSubType || 'library',
        sourceName: sourceContext.sourceName || 'Music Library',
        sourceId: sourceContext.sourceId || null,
        musicIds: [...sourceContext.musicIds]
      };
    }

    return {
      sourceType: 'library',
      sourceName: 'Music Library',
      sourceId: null
    };
  }

  _sanitizeManualQueue() {
    const before = this.manualQueue.length;
    this.manualQueue = this.manualQueue.filter(entry => this.dataService.getMusic(entry.musicId));
    if (before > 0 && this.manualQueue.length === 0 && !this.channels.music.currentTrack) {
      this._manualQueueReturnContext = null;
    }
    return this.manualQueue;
  }

  getManualQueue() {
    return this._sanitizeManualQueue().map(entry => ({
      ...entry,
      musicIds: Array.isArray(entry.musicIds) ? [...entry.musicIds] : entry.musicIds
    }));
  }

  getManualQueueCount() {
    return this._sanitizeManualQueue().length;
  }

  getManualQueueReturnContext() {
    return this._manualQueueReturnContext
      ? {
          ...this._manualQueueReturnContext,
          musicIds: Array.isArray(this._manualQueueReturnContext.musicIds)
            ? [...this._manualQueueReturnContext.musicIds]
            : this._manualQueueReturnContext.musicIds
        }
      : null;
  }

  clearManualQueueReturnContext() {
    this._manualQueueReturnContext = null;
  }

  addToManualQueue(musicId, options = {}) {
    const track = this.dataService.getMusic(musicId);
    if (!track) return null;

    const inferredSource = this._getManualQueueSourceContext(musicId);
    const entry = {
      entryId: this._createManualQueueEntryId(),
      musicId,
      addedAt: Date.now(),
      addedBy: globalThis.game?.user?.name || 'GM',
      sourceType: options.sourceType || inferredSource.sourceType,
      sourceSubType: options.sourceSubType || inferredSource.sourceSubType,
      sourceName: options.sourceName || inferredSource.sourceName,
      sourceId: options.sourceId || inferredSource.sourceId,
      musicIds: Array.isArray(options.musicIds)
        ? [...options.musicIds]
        : Array.isArray(inferredSource.musicIds)
          ? [...inferredSource.musicIds]
          : undefined
    };

    if (options.position === 'next') {
      this.manualQueue.unshift(entry);
    } else {
      this.manualQueue.push(entry);
    }

    return {
      ...entry,
      musicIds: Array.isArray(entry.musicIds) ? [...entry.musicIds] : entry.musicIds
    };
  }

  addNextToManualQueue(musicId, options = {}) {
    return this.addToManualQueue(musicId, { ...options, position: 'next' });
  }

  removeManualQueueEntry(entryId) {
    const index = this.manualQueue.findIndex(entry => entry.entryId === entryId);
    if (index === -1) return null;
    const [removed] = this.manualQueue.splice(index, 1);
    if (this.manualQueue.length === 0 && !this.channels.music.currentTrack) {
      this._manualQueueReturnContext = null;
    }
    return { ...removed };
  }

  clearManualQueue() {
    const hadEntries = this.manualQueue.length > 0;
    const preserveReturnContext = !!(this._manualQueueReturnContext && this.channels.music.currentTrack);
    this.manualQueue = [];
    if (!preserveReturnContext) {
      this._manualQueueReturnContext = null;
    }
    return hadEntries;
  }

  reorderManualQueueEntry(entryId, targetIndex) {
    this._sanitizeManualQueue();
    const currentIndex = this.manualQueue.findIndex(entry => entry.entryId === entryId);
    if (currentIndex === -1) return null;

    const boundedIndex = Math.max(0, Math.min(Number(targetIndex) || 0, this.manualQueue.length - 1));
    if (boundedIndex === currentIndex) return { ...this.manualQueue[currentIndex] };

    const [entry] = this.manualQueue.splice(currentIndex, 1);
    this.manualQueue.splice(boundedIndex, 0, entry);
    return { ...entry };
  }

  _captureManualQueueReturnContext() {
    if (this._manualQueueReturnContext) return;

    const currentId = this.channels.music.currentTrack?.id || null;
    const playlist = this.currentPlaylist;
    const playlistIds = this._getPlayablePlaylistMusicIds(playlist);

    if (playlist && playlistIds.length && (!currentId || playlistIds.includes(currentId))) {
      this._manualQueueReturnContext = {
        sourceType: 'playlist',
        sourceId: playlist.id || null,
        sourceName: playlist.name || 'Playlist',
        anchorTrackId: currentId
      };
      return;
    }

    const sourceContext = this._getPlayableMusicSourceContext();
    if (sourceContext && (!currentId || sourceContext.musicIds.includes(currentId))) {
      this._manualQueueReturnContext = {
        ...sourceContext,
        anchorTrackId: currentId
      };
      return;
    }

    this._manualQueueReturnContext = {
      sourceType: 'library',
      sourceId: null,
      sourceName: 'Music Library',
      anchorTrackId: currentId
    };
  }

  _getManualQueueReturnTrackId(wrap = false) {
    const context = this._manualQueueReturnContext;
    if (!context) return null;

    if (context.sourceType === 'playlist' && context.sourceId) {
      const playlist = this.dataService.getPlaylist(context.sourceId);
      const playlistIds = this._getPlayablePlaylistMusicIds(playlist);
      if (!playlist || !playlistIds.length) return null;

      const anchorIndex = context.anchorTrackId ? playlistIds.indexOf(context.anchorTrackId) : -1;
      let nextIndex = anchorIndex + 1;
      if (nextIndex < 0) nextIndex = 0;

      if (nextIndex >= playlistIds.length) {
        if (playlist.loop || this.isMusicRepeatQueueEnabled() || wrap) {
          nextIndex = 0;
        } else {
          return null;
        }
      }

      this.currentPlaylist = playlist;
      return playlistIds[nextIndex] || null;
    }

    const sourceContext = this._normalizeMusicSourceContext(context);
    const musicIds = sourceContext?.musicIds || this.dataService.getAllMusic().map(track => track.id);
    if (!musicIds.length) return null;

    const anchorIndex = context.anchorTrackId ? musicIds.indexOf(context.anchorTrackId) : -1;
    let nextIndex = anchorIndex + 1;
    if (nextIndex < 0) nextIndex = 0;

    if (nextIndex >= musicIds.length) {
      if (this.isMusicRepeatQueueEnabled() || wrap) {
        nextIndex = 0;
      } else {
        return null;
      }
    }

    this.currentPlaylist = null;
    this.currentMusicSourceContext = sourceContext;
    return musicIds[nextIndex] || null;
  }

  _shiftNextManualQueueEntry() {
    this._sanitizeManualQueue();
    while (this.manualQueue.length) {
      const entry = this.manualQueue.shift();
      if (this.dataService.getMusic(entry.musicId)) return entry;
    }
    return null;
  }

  _consumeNextManualQueueEntry() {
    const entry = this._shiftNextManualQueueEntry();
    if (!entry) return null;

    this._captureManualQueueReturnContext();
    return this.playMusic(entry.musicId, 'music', { fromManualQueue: true });
  }

  playManualQueueEntry(entryId) {
    const index = this.manualQueue.findIndex(entry => entry.entryId === entryId);
    if (index === -1) return null;

    const [entry] = this.manualQueue.splice(index, 1);
    if (!this.dataService.getMusic(entry.musicId)) return null;

    this._captureManualQueueReturnContext();
    return this.playMusic(entry.musicId, 'music', { fromManualQueue: true });
  }

  _normalizeMusicSourceContext(context) {
    if (!context || context.sourceType === 'playlist') return null;

    const sourceIds = Array.isArray(context.musicIds)
      ? [...new Set(context.musicIds.filter(Boolean))]
      : [];
    const musicIds = sourceIds.filter(id => this.dataService.getMusic(id));
    if (!musicIds.length) return null;

    return {
      sourceType: 'library',
      sourceSubType: context.sourceSubType || 'library',
      sourceName: String(context.sourceName || 'Music Library'),
      sourceId: context.sourceId || null,
      musicIds
    };
  }

  _getPlayableMusicSourceContext(context = this.currentMusicSourceContext) {
    const normalized = this._normalizeMusicSourceContext(context);
    if (!normalized) return null;

    if (context === this.currentMusicSourceContext) {
      this.currentMusicSourceContext = normalized;
    }

    return normalized;
  }

  getMusicSourceContext() {
    const context = this._getPlayableMusicSourceContext();
    return context ? { ...context, musicIds: [...context.musicIds] } : null;
  }

  _getMusicSourceLabel(context) {
    switch (context?.sourceSubType) {
      case 'folder': return 'Folder';
      case 'unfiled': return 'Unfiled';
      case 'filtered': return 'Filtered Library';
      default: return 'Library';
    }
  }

  _getActiveMusicSourceIds(currentId = null) {
    const context = this._getPlayableMusicSourceContext();
    if (!context || (currentId && !context.musicIds.includes(currentId))) return null;
    return [...context.musicIds];
  }

  get musicRepeatMode() {
    return this._musicRepeatMode;
  }

  set musicRepeatMode(mode) {
    this.setMusicRepeatMode(mode);
  }

  get musicLoop() {
    return this._musicRepeatMode !== MUSIC_REPEAT_MODES.OFF;
  }

  set musicLoop(enabled) {
    this.setMusicRepeatMode(enabled ? MUSIC_REPEAT_MODES.TRACK : MUSIC_REPEAT_MODES.OFF);
  }

  _normalizeMusicRepeatMode(mode) {
    return Object.values(MUSIC_REPEAT_MODES).includes(mode) ? mode : MUSIC_REPEAT_MODES.OFF;
  }

  isMusicRepeatTrackEnabled() {
    return this._musicRepeatMode === MUSIC_REPEAT_MODES.TRACK;
  }

  isMusicRepeatQueueEnabled() {
    return this._musicRepeatMode === MUSIC_REPEAT_MODES.QUEUE;
  }

  setMusicRepeatMode(mode, { persist = true } = {}) {
    this._musicRepeatMode = this._normalizeMusicRepeatMode(mode);

    if (persist && globalThis.game?.settings) {
      void game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.MUSIC_REPEAT_MODE, this._musicRepeatMode);
    }

    return this._musicRepeatMode;
  }

  cycleMusicRepeatMode() {
    const nextMode = this._musicRepeatMode === MUSIC_REPEAT_MODES.OFF
      ? MUSIC_REPEAT_MODES.TRACK
      : this._musicRepeatMode === MUSIC_REPEAT_MODES.TRACK
        ? MUSIC_REPEAT_MODES.QUEUE
        : MUSIC_REPEAT_MODES.OFF;

    return this.setMusicRepeatMode(nextMode);
  }

  /**
   * Play a music track
   * @param {string} id - Track ID
   * @param {string} channel - 'music' or 'ambience'
   */
  async playMusic(id, channel = 'music', options = {}) {
    debugLog(` PlaybackService.playMusic: ${id} on ${channel}`);

    const track = this.dataService.findTrack(id, channel);

    if (!track) {
      debugError(` Track not found: ${id}`);
      throw new Error('Track not found');
    }

    if (channel === 'music') {
      this.isPlaying = true;
      if (!options.fromManualQueue) {
        this._manualQueueReturnContext = null;

        const explicitContext = this._normalizeMusicSourceContext(options.sourceContext);
        if (explicitContext) {
          this.currentPlaylist = null;
          this.currentMusicSourceContext = explicitContext;
        } else if (options.preserveMusicSourceContext) {
          this.currentMusicSourceContext = this._getPlayableMusicSourceContext();
        } else {
          this.currentMusicSourceContext = null;
        }
      }
    }
    if (channel === 'ambience') this.isAmbiencePlaying = true;

    try {
      await this.channels[channel].play(track);
      debugLog(` Playback started for ${track.name}`);

      // Broadcast if not in preview mode
      if (game.user.isGM && !this.isPreviewMode && this.syncService) {
        const volume = this.channels[channel].volume;
        this.syncService.broadcastPlay(id, channel, volume, track);
        ui.notifications.info(`Broadcasting: ${track.name}`);

        // Safety net: also broadcast full state after a delay
        // Ensures players get the track even if broadcastPlay was missed
        setTimeout(() => {
          if (this.syncService) this.syncService.broadcastState();
        }, 2000);
      }

      return track;
    } catch (err) {
      debugError(" Playback failed:", err);

      if (channel === 'music') this.isPlaying = false;
      if (channel === 'ambience') this.isAmbiencePlaying = false;

      throw err;
    }
  }

  /**
   * Play a playlist
   * @param {string} id - Playlist ID
   * @param {boolean} shuffleStart - Start with shuffle
   */
  playPlaylist(id, shuffleStart = false) {
    const playlist = this.dataService.getPlaylist(id);
    const musicIds = this._getPlayablePlaylistMusicIds(playlist);
    if (!playlist || !musicIds.length) {
      ui.notifications.warn('This playlist has no playable tracks.');
      return null;
    }

    this.currentPlaylist = playlist;
    this.currentMusicSourceContext = null;

    let trackIndex = 0;
    if (shuffleStart || this.shuffle) {
      trackIndex = Math.floor(Math.random() * musicIds.length);
    }

    this.playMusic(musicIds[trackIndex]).catch(err => {
      debugError(" Playlist playback failed:", err);
      ui.notifications.error(`Playback failed: ${err.message}`);
    });
    return playlist;
  }

  /**
   * Play a random track by tag
   * @param {string} tag - Tag to filter by
   */
  playRandomByTag(tag) {
    const candidates = this.dataService.getTracksByTag(tag, 'music');
    if (candidates.length) {
      const random = candidates[Math.floor(Math.random() * candidates.length)];
      this.playMusic(random.id);
      return random;
    } else {
      ui.notifications.warn(`No music found with tag: ${tag}`);
      return null;
    }
  }

  /**
   * Toggle play/pause
   * @param {string} channel - 'music' or 'ambience'
   */
  togglePlayPause(channel = 'music') {
    const isPlaying = (channel === 'music') ? this.isPlaying : this.isAmbiencePlaying;

    if (isPlaying) {
      this.channels[channel].pause();
      if (channel === 'music') this.isPlaying = false;
      else this.isAmbiencePlaying = false;

      if (game.user.isGM && !this.isPreviewMode && this.syncService) {
        this.syncService.broadcastPause(channel);
      }
    } else {
      this.channels[channel].resume();
      if (channel === 'music') this.isPlaying = true;
      else this.isAmbiencePlaying = true;

      if (game.user.isGM && !this.isPreviewMode && this.syncService) {
        this.syncService.broadcastResume(channel);
      }
    }
  }

  /**
   * Stop playback
   * @param {string} channel - 'music' or 'ambience'
   */
  stop(channel = 'music') {
    debugLog(` PlaybackService.stop: ${channel}`);
    this.channels[channel].stop();

    if (channel === 'music') {
      this.isPlaying = false;
    } else if (channel === 'ambience') {
      this.isAmbiencePlaying = false;
    }

    if (game.user.isGM && !this.isPreviewMode && this.syncService) {
      this.syncService.broadcastStop(channel);
    }
  }

  /**
   * Skip to next track
   * @param {boolean} wrap - If true, always wrap around at end (for manual next button).
   *                         If false, stop at end unless repeat-queue or playlist loop is enabled.
   */
  next(wrap = false) {
    const queuedPlayback = this._consumeNextManualQueueEntry();
    if (queuedPlayback) return queuedPlayback;

    if (this._manualQueueReturnContext) {
      const returnContext = this._manualQueueReturnContext;
      const returnTrackId = this._getManualQueueReturnTrackId(wrap);
      this._manualQueueReturnContext = null;

      if (returnTrackId) {
        return this.playMusic(returnTrackId, 'music', { sourceContext: returnContext });
      }

      debugLog(" Manual queue ended, no source continuation");
      this.isPlaying = false;
      return null;
    }

    const currentId = this.channels.music.currentTrack?.id;
    const playlistIds = this._getPlayablePlaylistMusicIds(this.currentPlaylist);

    // 1. Handle Playlist Logic
    if (this.currentPlaylist && playlistIds.length && (!currentId || playlistIds.includes(currentId))) {
      let nextIndex = 0;

      if (this.shuffle) {
        // Smart shuffle: avoid repeating the same track consecutively
        nextIndex = this._getShuffleIndex(playlistIds, currentId);
      } else {
        const currentIndex = playlistIds.indexOf(currentId);
        nextIndex = currentIndex + 1;
        if (nextIndex >= playlistIds.length) {
          // Use playlist-level loop or repeat-queue mode at the end of a source.
          const playlistLoop = this.currentPlaylist.loop ?? false;
          if (playlistLoop || this.isMusicRepeatQueueEnabled() || wrap) {
            nextIndex = 0;
          } else {
            debugLog(" Playlist ended, no loop");
            this.isPlaying = false;
            return null;
          }
        }
      }

      return this.playMusic(playlistIds[nextIndex]);
    }

    // 2. Library source context: folder/filter/visible source selected in Music Library
    const sourceIds = this._getActiveMusicSourceIds(currentId);
    if (sourceIds && sourceIds.length > 0) {
      let nextIndex = 0;

      if (this.shuffle) {
        nextIndex = this._getShuffleIndex(sourceIds, currentId);
      } else {
        const currentIndex = sourceIds.indexOf(currentId);
        nextIndex = currentIndex + 1;
        if (nextIndex >= sourceIds.length) {
          if (this.isMusicRepeatQueueEnabled() || wrap) {
            nextIndex = 0;
          } else {
            debugLog(` ${this._getMusicSourceLabel(this.currentMusicSourceContext)} ended, no loop`);
            this.isPlaying = false;
            return null;
          }
        }
      }

      return this.playMusic(sourceIds[nextIndex], 'music', { preserveMusicSourceContext: true });
    }

    // 3. No source context: Navigate through full music library
    const music = this.dataService.getAllMusic();
    if (music && music.length > 0) {
      const currentIndex = music.findIndex(m => m.id === currentId);

      if (this.shuffle) {
        // Smart shuffle: avoid repeating the same track consecutively
        const musicIds = music.map(m => m.id);
        const nextIndex = this._getShuffleIndex(musicIds, currentId);
        return this.playMusic(musicIds[nextIndex]);
      }

      let nextIndex = currentIndex + 1;
      if (nextIndex >= music.length) {
        if (this.isMusicRepeatQueueEnabled() || wrap) {
          nextIndex = 0;
        } else {
          debugLog(" End of library, no loop");
          this.isPlaying = false;
          return null;
        }
      }

      return this.playMusic(music[nextIndex].id);
    }

    // 4. Single Track Loop (Fallback)
    if (this.isMusicRepeatTrackEnabled() && currentId) {
      debugLog(" Looping single track:", currentId);
      return this.playMusic(currentId);
    }

    // 5. Nothing to play
    debugLog(" No next track available");
    this.isPlaying = false;
    return null;
  }

  /**
   * Skip to previous track or restart current
   */
  prev() {
    // Restart track if playing for more than 3 seconds
    if (this.channels.music.currentTime > 3) {
      this.channels.music.seek(0);
      return;
    }

    const currentId = this.channels.music.currentTrack?.id;
    const playlistIds = this._getPlayablePlaylistMusicIds(this.currentPlaylist);

    // 1. Handle Playlist Logic
    if (this.currentPlaylist && playlistIds.length && (!currentId || playlistIds.includes(currentId))) {
      const currentIndex = playlistIds.indexOf(currentId);
      let prevIndex = currentIndex - 1;

      if (prevIndex < 0) {
        const playlistLoop = this.currentPlaylist.loop ?? false;
        if (playlistLoop || this.isMusicRepeatQueueEnabled()) prevIndex = playlistIds.length - 1;
        else prevIndex = 0;
      }

      return this.playMusic(playlistIds[prevIndex]);
    }

    // 2. Library source context: folder/filter/visible source selected in Music Library
    const sourceIds = this._getActiveMusicSourceIds(currentId);
    if (sourceIds && sourceIds.length > 0) {
      const currentIndex = sourceIds.indexOf(currentId);
      let prevIndex = currentIndex - 1;

      if (prevIndex < 0) {
        if (this.isMusicRepeatQueueEnabled()) prevIndex = sourceIds.length - 1;
        else prevIndex = 0;
      }

      return this.playMusic(sourceIds[prevIndex], 'music', { preserveMusicSourceContext: true });
    }

    // 3. No source context: Navigate through full music library
    const music = this.dataService.getAllMusic();
    if (music && music.length > 0) {
      const currentIndex = music.findIndex(m => m.id === currentId);
      let prevIndex = currentIndex - 1;

      if (prevIndex < 0) {
        if (this.isMusicRepeatQueueEnabled()) {
          prevIndex = music.length - 1;
        } else {
          prevIndex = 0;
        }
      }

      return this.playMusic(music[prevIndex].id);
    }

    debugLog(" No previous track available");
    return null;
  }

  // ==========================================
  // Volume Control
  // ==========================================

  /**
   * Set volume for a channel
   * @param {string} channel - 'music' or 'ambience'
   * @param {number} value - Volume value (0-1)
   */
  setVolume(channel, value) {
    this.channels[channel].setVolume(value);

    if (channel === 'music' && this.isMuted && value > 0) {
      this.isMuted = false;
      game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.MUSIC_MUTED, false);
    }
    if (channel === 'ambience' && this.isAmbienceMuted && value > 0) {
      this.isAmbienceMuted = false;
      game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.AMBIENCE_MUTED, false);
    }

    // Persist volume to settings (only if not muting - mute sets volume to 0)
    if (value > 0) {
      if (channel === 'music') {
        game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.VOLUME, value);
      } else if (channel === 'ambience') {
        game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.AMBIENCE_VOLUME, value);
      }
    }

    // Channel volume is a local listening preference for each client. Playback
    // state still syncs, but GM volume/mute changes must not overwrite players.
  }

  /**
   * Toggle mute for a channel
   * @param {string} channel - 'music' or 'ambience'
   */
  toggleMute(channel = 'music') {
    if (channel === 'music') {
      if (this.isMuted) {
        this.setVolume(channel, this.volumeBeforeMute);
        this.isMuted = false;
        game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.MUSIC_MUTED, false);
      } else {
        this.volumeBeforeMute = this.channels[channel].volume;
        this.setVolume(channel, 0);
        this.isMuted = true;
        game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.MUSIC_MUTED, true);
      }
    } else if (channel === 'ambience') {
      if (this.isAmbienceMuted) {
        this.setVolume(channel, this.ambienceVolumeBeforeMute);
        this.isAmbienceMuted = false;
        game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.AMBIENCE_MUTED, false);
      } else {
        this.ambienceVolumeBeforeMute = this.channels[channel].volume;
        this.setVolume(channel, 0);
        this.isAmbienceMuted = true;
        game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.AMBIENCE_MUTED, true);
      }
    }
  }

  /**
   * Seek to a position in the current track
   * @param {string} channel - 'music' or 'ambience'
   * @param {number} percent - Position as percentage (0-100)
   */
  seek(channel, percent) {
    this.channels[channel].seek(percent);
  }

  /**
   * Get a random index that avoids the current track
   * Smart shuffle: prevents the same track from playing consecutively
   * @param {string[]} trackIds - Array of track IDs
   * @param {string} currentId - Current track ID to avoid
   * @returns {number} Random index different from current (if possible)
   */
  _getShuffleIndex(trackIds, currentId) {
    const length = trackIds.length;

    // If only one track, no choice but to repeat
    if (length <= 1) {
      return 0;
    }

    // Find current index
    const currentIndex = trackIds.indexOf(currentId);

    // If current track not found, just pick random
    if (currentIndex === -1) {
      return Math.floor(Math.random() * length);
    }

    // Pick a random index that's different from current
    // Generate random offset (1 to length-1), then add to current index
    const offset = 1 + Math.floor(Math.random() * (length - 1));
    return (currentIndex + offset) % length;
  }

  // ==========================================
  // Playback State Toggles
  // ==========================================

  toggleShuffle() {
    this.shuffle = !this.shuffle;
    return this.shuffle;
  }

  toggleMusicLoop() {
    const nextMode = this.musicLoop ? MUSIC_REPEAT_MODES.OFF : MUSIC_REPEAT_MODES.TRACK;
    this.setMusicRepeatMode(nextMode);
    return this.musicLoop;
  }

  toggleMusicRepeatMode() {
    this.cycleMusicRepeatMode();
    return this.musicRepeatMode;
  }

  toggleAmbienceLoop() {
    this.ambienceLoop = !this.ambienceLoop;
    return this.ambienceLoop;
  }

  togglePreviewMode() {
    return this.setPreviewMode(!this.isPreviewMode);
  }

  setPreviewMode(enabled) {
    this.isPreviewMode = !!enabled;
    this.soundboardBroadcastMode = !this.isPreviewMode;
    ambienceLayerManager.setPreviewMode(this.isPreviewMode);
    return this.isPreviewMode;
  }

  // ==========================================
  // Soundboard Playback
  // ==========================================

  _getPositiveDelaySeconds(value, fallback) {
    const seconds = Number(value);
    return Number.isFinite(seconds) && seconds > 0 ? seconds : fallback;
  }

  _getSoundboardRandomInterval(sound = {}, options = {}) {
    const enabled = Object.hasOwn(options, 'randomIntervalEnabled')
      ? !!options.randomIntervalEnabled
      : !!sound.randomIntervalEnabled;
    const min = this._getPositiveDelaySeconds(
      Object.hasOwn(options, 'randomIntervalMin') ? options.randomIntervalMin : sound.randomIntervalMin,
      SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MIN
    );
    const max = Math.max(min, this._getPositiveDelaySeconds(
      Object.hasOwn(options, 'randomIntervalMax') ? options.randomIntervalMax : sound.randomIntervalMax,
      SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MAX
    ));

    return { enabled, min, max };
  }

  _prepareSoundboardPlaybackSound(sound) {
    let playableSound = sound;
    if (sound.source !== 'youtube' && sound.url) {
      try {
        const playableUrl = normalizeTrackUrl(sound.url, 'local');
        if (playableUrl !== sound.url) playableSound = { ...sound, url: playableUrl };
      } catch (error) {}
    }

    // Check format compatibility
    if (playableSound.source !== 'youtube' && !JukeboxBrowser.isFormatSupported(playableSound.url)) {
      const ext = String(playableSound.url || '').split(/[?#]/)[0].split('.').pop().toLowerCase();
      const browser = JukeboxBrowser.getBrowserInfo();
      ui.notifications.warn(`Your browser (${browser.name}) may not support .${ext} files.`);
    }

    return {
      playableSound,
      startTime: playableSound.startTime || 0,
      endTime: playableSound.endTime || null
    };
  }

  _broadcastSoundboardPlay(id, loop, playableSound, preview) {
    if (game.user.isGM && !preview && this.syncService) {
      this.syncService.broadcastSoundboardPlay(id, loop, playableSound);
      ui.notifications.info(`Broadcasting sound: ${playableSound.name}`);
    }
  }

  _applySoundboardYouTubeVolume(player, volume) {
    if (!player) return;

    const target = Math.max(0, Math.min(Math.round(Number(volume) || 0), 100));
    if (target > 0) {
      try {
        player.unMute?.();
      } catch (error) {}
    }

    try {
      player.setVolume?.(target);
    } catch (error) {}
  }

  _handleSoundboardYouTubeBlocked(id, sound) {
    debugWarn(' YouTube soundboard autoplay blocked:', {
      soundId: id,
      name: sound?.name,
      url: sound?.url
    });
    this.stopSoundboardSound(id, true, true);
    ui.notifications.warn('Narrator Jukebox: YouTube playback was blocked by the browser or host permissions. Click play again or allow autoplay for this site.');
  }

  _clearSoundboardIntervalTimer(activeSound) {
    if (activeSound?.intervalTimeout) {
      clearTimeout(activeSound.intervalTimeout);
      activeSound.intervalTimeout = null;
    }
  }

  _getRandomIntervalDelayMs(activeSound) {
    const min = this._getPositiveDelaySeconds(activeSound?.randomIntervalMin, SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MIN);
    const max = Math.max(min, this._getPositiveDelaySeconds(activeSound?.randomIntervalMax, SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MAX));
    return Math.round((min + Math.random() * (max - min)) * 1000);
  }

  _scheduleNextSoundboardInterval(id) {
    const activeSound = this.activeSoundboardSounds.get(id);
    if (!activeSound?.isRandomInterval) return;

    this._clearSoundboardIntervalTimer(activeSound);
    const delay = this._getRandomIntervalDelayMs(activeSound);
    activeSound.isIntervalWaiting = true;
    activeSound.nextFireAt = Date.now() + delay;
    activeSound.intervalTimeout = setTimeout(() => {
      this._fireSoundboardInterval(id).catch(err => {
        debugError(" Random interval soundboard playback failed:", err);
        this.stopSoundboardSound(id, true, true);
      });
    }, delay);
  }

  _cleanupActiveSoundboardPlayback(activeSound) {
    if (!activeSound) return;

    if (activeSound.endTimeInterval) {
      clearInterval(activeSound.endTimeInterval);
      activeSound.endTimeInterval = null;
    }

    if (activeSound.type === 'local' && activeSound.audio) {
      if (activeSound.endedHandler) {
        activeSound.audio.removeEventListener('ended', activeSound.endedHandler);
      }
      if (activeSound.endTimeHandler) {
        activeSound.audio.removeEventListener('timeupdate', activeSound.endTimeHandler);
      }
      if (activeSound.errorHandler) {
        activeSound.audio.removeEventListener('error', activeSound.errorHandler);
      }
      activeSound.audio.pause();
      activeSound.audio.currentTime = 0;
      activeSound.audio.removeAttribute?.('src');
      activeSound.audio.src = '';
      activeSound.audio.load?.();
    } else if (activeSound.type === 'youtube' && activeSound.player) {
      if (activeSound.player.stopVideo) activeSound.player.stopVideo();
      if (activeSound.player.destroy) activeSound.player.destroy();
      const container = document.getElementById(activeSound.containerId);
      if (container) container.remove();
    }

    delete activeSound.audio;
    delete activeSound.player;
    delete activeSound.containerId;
    delete activeSound.endedHandler;
    delete activeSound.endTimeHandler;
    delete activeSound.endTimeInterval;
    delete activeSound.errorHandler;
  }

  _completeSoundboardIntervalFire(id, emitStateChange = true) {
    const activeSound = this.activeSoundboardSounds.get(id);
    if (!activeSound?.isRandomInterval) return;

    const wasPreview = activeSound.isPreview;
    this._cleanupActiveSoundboardPlayback(activeSound);
    activeSound.type = 'interval';
    activeSound.isLooping = false;
    activeSound.isIntervalWaiting = true;

    if (game.user.isGM && !wasPreview && this.syncService) {
      this.syncService.broadcastSoundboardStop(id);
    }

    this._scheduleNextSoundboardInterval(id);

    if (emitStateChange) {
      Hooks.call('narratorJukeboxStateChanged', { scope: 'soundboard', soundId: id });
    }
  }

  async _fireSoundboardInterval(id) {
    const activeSound = this.activeSoundboardSounds.get(id);
    if (!activeSound?.isRandomInterval) return {
      ok: false,
      message: 'Random interval is no longer active.'
    };

    const sound = this.dataService.getSoundboardSound(id);
    if (!sound) {
      debugError(` Soundboard sound not found: ${id}`);
      this.stopSoundboardSound(id, true, true);
      return {
        ok: false,
        message: 'Sound not found'
      };
    }

    this._clearSoundboardIntervalTimer(activeSound);
    activeSound.isIntervalWaiting = false;
    activeSound.nextFireAt = null;

    const { playableSound, startTime, endTime } = this._prepareSoundboardPlaybackSound(sound);
    const playbackMeta = {
      randomInterval: true,
      randomIntervalMin: activeSound.randomIntervalMin,
      randomIntervalMax: activeSound.randomIntervalMax
    };

    if (playableSound.source === 'youtube') {
      await this._playSoundboardYouTube(id, playableSound, false, activeSound.isPreview, startTime, endTime, playbackMeta);
    } else {
      await this._playSoundboardLocal(id, playableSound, false, activeSound.isPreview, startTime, endTime, playbackMeta);
    }

    this._broadcastSoundboardPlay(id, false, playableSound, activeSound.isPreview);

    Hooks.call('narratorJukeboxStateChanged', { scope: 'soundboard', soundId: id });

    return {
      ok: true,
      soundId: id,
      isLooping: false,
      isRandomInterval: true
    };
  }

  async _startSoundboardRandomInterval(id, sound, preview, interval) {
    this.activeSoundboardSounds.set(id, {
      type: 'interval',
      isLooping: false,
      isPreview: preview,
      isRandomInterval: true,
      isIntervalWaiting: false,
      randomIntervalMin: interval.min,
      randomIntervalMax: interval.max,
      nextFireAt: null,
      intervalTimeout: null,
      startTime: sound.startTime || 0,
      endTime: sound.endTime ?? null
    });

    return this._fireSoundboardInterval(id);
  }

  /**
   * Play a soundboard sound
   * @param {string} id - Sound ID
   * @param {object} options - { loop, preview }
   */
  async playSoundboardSound(id, options = {}) {
    const { preview = this.isPreviewMode } = options;
    const sound = this.dataService.getSoundboardSound(id);

    if (!sound) {
      debugError(` Soundboard sound not found: ${id}`);
      ui.notifications.error('Sound not found');
      return {
        ok: false,
        message: 'Sound not found'
      };
    }

    const interval = this._getSoundboardRandomInterval(sound, options);
    const loop = interval.enabled ? false : (Object.hasOwn(options, 'loop') ? !!options.loop : !!sound.loop);
    const { playableSound, startTime, endTime } = this._prepareSoundboardPlaybackSound(sound);

    debugLog(` Playing soundboard: ${playableSound.name}, loop: ${loop}, random interval: ${interval.enabled}`);

    // Stop if already playing
    if (this.activeSoundboardSounds.has(id)) {
      this.stopSoundboardSound(id);
    }

    try {
      if (interval.enabled) {
        return await this._startSoundboardRandomInterval(id, playableSound, preview, interval);
      }

      if (playableSound.source === 'youtube') {
        await this._playSoundboardYouTube(id, playableSound, loop, preview, startTime, endTime);
      } else {
        await this._playSoundboardLocal(id, playableSound, loop, preview, startTime, endTime);
      }

      this._broadcastSoundboardPlay(id, loop, playableSound, preview);

      return {
        ok: true,
        soundId: id,
        isLooping: loop
      };
    } catch (err) {
      debugError(" Soundboard playback failed:", err);
      if (interval.enabled && this.activeSoundboardSounds.get(id)?.isRandomInterval) {
        this.stopSoundboardSound(id, false, true);
      }
      ui.notifications.error(`Failed to play: ${playableSound.name}`);
      return {
        ok: false,
        message: err?.message || `Failed to play: ${playableSound.name}`
      };
    }
  }

  async _playSoundboardLocal(id, sound, loop, preview, startTime, endTime, meta = {}) {
    const audioElement = new Audio(sound.url);
    audioElement.volume = sound.volume || 0.8;
    const isRandomInterval = !!meta.randomInterval;
    let isCompleting = false;

    const completePlayback = () => {
      if (isCompleting) return;
      isCompleting = true;

      if (isRandomInterval) {
        this._completeSoundboardIntervalFire(id, true);
      } else {
        this.stopSoundboardSound(id, true, true);
      }
    };

    if (startTime > 0) {
      audioElement.currentTime = startTime;
    }

    const shouldManualLoop = loop && (startTime > 0 || endTime !== null);
    if (!shouldManualLoop) {
      audioElement.loop = loop;
    }

    let endTimeHandler = null;
    if (endTime !== null) {
      endTimeHandler = () => {
        if (audioElement.currentTime >= endTime) {
          if (shouldManualLoop) {
            audioElement.currentTime = startTime;
          } else {
            completePlayback();
          }
        }
      };
      audioElement.addEventListener('timeupdate', endTimeHandler);
    }

    const endedHandler = () => {
      if (shouldManualLoop) {
        audioElement.currentTime = startTime;
        audioElement.play();
      } else if (!loop) {
        completePlayback();
      }
    };
    audioElement.addEventListener('ended', endedHandler);

    const errorHandler = (e) => {
      debugError(" Soundboard audio error:", e);
      this.stopSoundboardSound(id, true, true);
      ui.notifications.error(`Failed to play: ${sound.name}`);
    };
    audioElement.addEventListener('error', errorHandler);

    await audioElement.play();

    this.activeSoundboardSounds.set(id, {
      type: 'local',
      audio: audioElement,
      isLooping: loop,
      isPreview: preview,
      isRandomInterval,
      isIntervalWaiting: false,
      randomIntervalMin: meta.randomIntervalMin,
      randomIntervalMax: meta.randomIntervalMax,
      nextFireAt: null,
      intervalTimeout: null,
      startTime,
      endTime,
      endedHandler,
      endTimeHandler,
      errorHandler
    });
  }

  async _playSoundboardYouTube(id, sound, loop, preview, startTime, endTime, meta = {}) {
    const containerId = `jukebox-sb-yt-${id}`;
    let container = document.getElementById(containerId);
    if (container) {
      styleHiddenYouTubeContainer(container);
    }
    if (!container) {
      container = document.createElement('div');
      container.id = containerId;
      styleHiddenYouTubeContainer(container);
      document.body.appendChild(container);
    }

    await window.NarratorJukeboxYTReady;

    const videoId = extractYouTubeVideoId(sound.url);
    if (!videoId) throw new Error("Invalid YouTube URL");

    const volume = (sound.volume || 0.8) * 100;
    const shouldManualLoop = loop && (startTime > 0 || endTime !== null);
    const isRandomInterval = !!meta.randomInterval;
    let isCompleting = false;

    const completePlayback = () => {
      if (isCompleting) return;
      isCompleting = true;

      if (isRandomInterval) {
        this._completeSoundboardIntervalFire(id, true);
      } else {
        this.stopSoundboardSound(id, true, true);
      }
    };

    // Note: Do NOT use host: 'youtube-nocookie.com' — causes error 150 on HTTP pages
    // `origin` is intentionally omitted here for the same reason as the
    // main music player: remote player clients can fail with YouTube error 150.
    const sbPlayerVars = {
      autoplay: 1,
      controls: 0,
      start: Math.floor(startTime),
      end: endTime ? Math.floor(endTime) : undefined,
      loop: (loop && !shouldManualLoop) ? 1 : 0,
      playlist: (loop && !shouldManualLoop) ? videoId : undefined
    };
    const player = new YT.Player(containerId, {
      height: '200', width: '200',
      videoId: videoId,
      playerVars: sbPlayerVars,
      events: {
        'onReady': (e) => {
          this._applySoundboardYouTubeVolume(e.target, volume);
          e.target.playVideo?.();
          if (startTime > 0 && startTime % 1 !== 0) {
            e.target.seekTo(startTime, true);
          }
        },
        'onStateChange': (e) => {
          if (e.data === YT.PlayerState.PLAYING) {
            this._applySoundboardYouTubeVolume(e.target, volume);
          }

          if (e.data === YT.PlayerState.ENDED) {
            if (shouldManualLoop) {
              e.target.seekTo(startTime, true);
              e.target.playVideo();
            } else if (!loop) {
              completePlayback();
            }
          } else if (e.data === YT.PlayerState.PLAYING && endTime !== null) {
            const activeSound = this.activeSoundboardSounds.get(id);
            if (activeSound && !activeSound.endTimeInterval) {
              activeSound.endTimeInterval = setInterval(() => {
                const currentTime = e.target.getCurrentTime();
                if (currentTime >= endTime) {
                  if (shouldManualLoop) {
                    e.target.seekTo(startTime, true);
                  } else {
                    completePlayback();
                  }
                }
              }, SOUNDBOARD_END_CHECK);
            }
          }
        },
        'onError': (e) => {
          debugError(" YouTube soundboard error:", e);
          this.stopSoundboardSound(id, true, true);
        },
        'onAutoplayBlocked': () => {
          this._handleSoundboardYouTubeBlocked(id, sound);
        }
      }
    });

    this.activeSoundboardSounds.set(id, {
      type: 'youtube',
      player,
      containerId,
      isLooping: loop,
      isPreview: preview,
      isRandomInterval,
      isIntervalWaiting: false,
      randomIntervalMin: meta.randomIntervalMin,
      randomIntervalMax: meta.randomIntervalMax,
      nextFireAt: null,
      intervalTimeout: null,
      startTime,
      endTime
    });
  }

  /**
   * Stop a soundboard sound
   * @param {string} id - Sound ID
   * @param {boolean} broadcast - Whether to broadcast the stop
   * @param {boolean} emitStateChange - Whether to notify UI after internal auto-stop
   */
  stopSoundboardSound(id, broadcast = true, emitStateChange = false) {
    const activeSound = this.activeSoundboardSounds.get(id);
    if (!activeSound) return;

    debugLog(` Stopping soundboard sound: ${id}`);

    const wasPreview = activeSound.isPreview;
    this._clearSoundboardIntervalTimer(activeSound);
    this._cleanupActiveSoundboardPlayback(activeSound);
    this.activeSoundboardSounds.delete(id);

    if (game.user.isGM && broadcast && !wasPreview && this.syncService) {
      this.syncService.broadcastSoundboardStop(id);
    }

    if (emitStateChange) {
      Hooks.call('narratorJukeboxStateChanged', { scope: 'soundboard', soundId: id });
    }
  }

  /**
   * Stop all soundboard sounds
   */
  stopAllSoundboardSounds() {
    debugLog(" Stopping all soundboard sounds");
    for (const [id] of this.activeSoundboardSounds) {
      this.stopSoundboardSound(id, false);
    }

    if (game.user.isGM && this.syncService) {
      this.syncService.broadcastSoundboardStopAll();
    }
  }

  /**
   * Check if a soundboard sound is playing
   * @param {string} id - Sound ID
   */
  isSoundboardSoundPlaying(id) {
    return this.activeSoundboardSounds.has(id);
  }

  // ==========================================
  // Ambience Layer Playback
  // ==========================================

  /**
   * Play an ambience track as a layer (multi-layer system)
   * @param {string} trackId - Track ID to add as layer
   * @returns {Promise<object|null>} The created layer or null if failed
   */
  async playAmbienceLayer(trackId) {
    // Update preview mode in layer manager
    ambienceLayerManager.setPreviewMode(this.isPreviewMode);
    return await ambienceLayerManager.addLayer(trackId);
  }

  /**
   * Stop an ambience layer
   * @param {string} trackId - Track ID to stop
   * @param {boolean} broadcast - Whether to broadcast the change
   */
  stopAmbienceLayer(trackId, broadcast = true) {
    ambienceLayerManager.setPreviewMode(this.isPreviewMode);
    ambienceLayerManager.removeLayer(trackId, broadcast);
  }

  /**
   * Toggle an ambience layer on/off
   * @param {string} trackId - Track ID to toggle
   * @returns {Promise<boolean>} New state (true = playing)
   */
  async toggleAmbienceLayer(trackId) {
    ambienceLayerManager.setPreviewMode(this.isPreviewMode);
    return await ambienceLayerManager.toggleLayer(trackId);
  }

  /**
   * Set volume for a specific ambience layer
   * @param {string} trackId - Track ID
   * @param {number} volume - Volume value (0-1)
   */
  setAmbienceLayerVolume(trackId, volume) {
    ambienceLayerManager.setPreviewMode(this.isPreviewMode);
    ambienceLayerManager.setLayerVolume(trackId, volume);
  }

  /**
   * Get volume for a specific ambience layer
   * @param {string} trackId - Track ID
   * @returns {number} Volume value (0-1)
   */
  getAmbienceLayerVolume(trackId) {
    return ambienceLayerManager.getLayerVolume(trackId);
  }

  /**
   * Set master volume for all ambience layers
   * @param {number} volume - Volume value (0-1)
   */
  setAmbienceMasterVolume(volume) {
    ambienceLayerManager.setPreviewMode(this.isPreviewMode);
    ambienceLayerManager.setMasterVolume(volume);
  }

  /**
   * Get master volume for ambience layers
   * @returns {number} Volume value (0-1)
   */
  getAmbienceMasterVolume() {
    return ambienceLayerManager.masterVolume;
  }

  /**
   * Set the player-local global volume for ambience layers.
   * This does not change the GM's shared ambience mix.
   * @param {number} volume - Volume value (0-1)
   */
  setAmbienceClientVolume(volume) {
    const result = ambienceLayerManager.setClientMasterVolume(volume);
    if (!game.user.isGM && volume > 0) {
      this.isAmbienceMuted = false;
    }
    return result;
  }

  /**
   * Get the player-local global volume for ambience layers.
   * @returns {number}
   */
  getAmbienceClientVolume() {
    return ambienceLayerManager.getClientMasterVolume();
  }

  /**
   * Toggle the player-local mute for ambience layers.
   * @returns {boolean}
   */
  toggleAmbienceClientMute() {
    const muted = ambienceLayerManager.toggleClientMute();
    if (!game.user.isGM) {
      this.isAmbienceMuted = muted;
    }
    return muted;
  }

  /**
   * Check if ambience layers are muted locally on this client.
   * @returns {boolean}
   */
  isAmbienceClientMuted() {
    return ambienceLayerManager.isClientMuted();
  }

  /**
   * Toggle master mute for all ambience layers
   * @returns {boolean} New mute state
   */
  toggleAmbienceMasterMute() {
    return ambienceLayerManager.toggleMasterMute();
  }

  /**
   * Check if ambience master is muted
   * @returns {boolean}
   */
  isAmbienceMasterMuted() {
    return ambienceLayerManager.isMasterMuted;
  }

  /**
   * Get all active ambience layers
   * @returns {Array<{trackId: string, track: object, volume: number}>}
   */
  getActiveAmbienceLayers() {
    return ambienceLayerManager.getActiveLayers();
  }

  /**
   * Get the number of active ambience layers
   * @returns {number}
   */
  getAmbienceLayerCount() {
    return ambienceLayerManager.layerCount;
  }

  /**
   * Get the last recorded issue for a specific ambience track, if any.
   * @param {string} trackId - Track ID
   * @returns {object|null}
   */
  getAmbienceLayerIssue(trackId) {
    return ambienceLayerManager.getLayerIssue(trackId);
  }

  /**
   * Get all recorded ambience layer issues.
   * @returns {Array<object>}
   */
  getAmbienceLayerIssues() {
    return ambienceLayerManager.getAllLayerIssues();
  }

  /**
   * Check if an ambience track is currently playing as a layer
   * @param {string} trackId - Track ID to check
   * @returns {boolean}
   */
  isAmbienceLayerActive(trackId) {
    return ambienceLayerManager.isLayerActive(trackId);
  }

  /**
   * Stop all ambience layers
   * @param {boolean} broadcast - Whether to broadcast the change
   */
  stopAllAmbienceLayers(broadcast = true) {
    ambienceLayerManager.setPreviewMode(this.isPreviewMode);
    ambienceLayerManager.stopAll(broadcast);
  }

  /**
   * Get the serializable state of all ambience layers (for sync/presets)
   * @returns {object}
   */
  getAmbienceLayersState() {
    return ambienceLayerManager.getLayersState();
  }

  /**
   * Restore ambience layers state (for sync/presets)
   * @param {object} state - State object from getAmbienceLayersState()
   * @param {boolean} broadcast - Whether to broadcast after restore
   */
  async restoreAmbienceLayersState(state, broadcast = false) {
    ambienceLayerManager.setPreviewMode(this.isPreviewMode);
    await ambienceLayerManager.restoreState(state, broadcast);
  }

  /**
   * Check if we can add more ambience layers
   * @returns {boolean}
   */
  canAddAmbienceLayer() {
    return ambienceLayerManager.canAddLayer();
  }

  /**
   * Get the Ambience Layer Manager instance (for advanced use)
   * @returns {AmbienceLayerManager}
   */
  getAmbienceLayerManager() {
    return ambienceLayerManager;
  }

  /**
   * Check if there are pending ambience layers waiting for user interaction
   * (blocked by autoplay policy)
   * @returns {boolean}
   */
  hasAmbiencePendingLayers() {
    return ambienceLayerManager.hasPendingLayers();
  }

  /**
   * Retry playing ambience layers that were blocked by autoplay policy
   * Call this after user interaction (e.g., click)
   */
  async retryAmbiencePendingLayers() {
    await ambienceLayerManager.retryPendingLayers();
  }

  // ==========================================
  // Getters for current state
  // ==========================================

  getCurrentMusicTrack() {
    return this.channels?.music?.currentTrack || null;
  }

  getCurrentAmbienceTrack() {
    return this.channels?.ambience?.currentTrack || null;
  }

  getMusicProgress() {
    if (!this.channels?.music) return { current: 0, duration: 0, percent: 0 };
    const current = this.channels.music.currentTime || 0;
    const duration = this.channels.music.duration || 0;
    const percent = duration > 0 ? (current / duration) * 100 : 0;
    return { current, duration, percent };
  }

  getAmbienceProgress() {
    if (!this.channels?.ambience) return { current: 0, duration: 0, percent: 0 };
    const current = this.channels.ambience.currentTime || 0;
    const duration = this.channels.ambience.duration || 0;
    const percent = duration > 0 ? (current / duration) * 100 : 0;
    return { current, duration, percent };
  }
}

// Export singleton instance
export const playbackService = new PlaybackService();

// Also export the class for testing
export { PlaybackService };

// Re-export ambienceLayerManager for direct access
export { ambienceLayerManager };
