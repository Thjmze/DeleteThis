/**
 * Narrator's Jukebox - Ambience Layer Manager
 * Manages multiple simultaneous ambience layers for creating complex soundscapes
 */

import { DEFAULT_PREVIEW_MODE, JUKEBOX, MAX_AMBIENCE_LAYERS } from './constants.js';
import { AudioChannel } from './audio-channel.js';
import { debugLog, debugWarn, debugError } from '../utils/debug.js';

/**
 * Represents a single ambience layer with its own audio channel
 */
class AmbienceLayer {
  constructor(trackId, track, channel) {
    this.trackId = trackId;
    this.track = track;
    this.channel = channel;
    this.volume = 0.8;
    this.isPlaying = true;
    this.addedAt = Date.now();
  }
}

/**
 * AmbienceLayerManager - Manages multiple simultaneous ambience layers
 * Allows GMs to create complex soundscapes by combining multiple ambient sounds
 */
class AmbienceLayerManager {
  constructor() {
    /** @type {Map<string, AmbienceLayer>} */
    this.layers = new Map();
    this.layerIssues = new Map();

    /** @type {number} Master volume multiplier for all layers (0-1) */
    this.masterVolume = 0.8;

    /** @type {boolean} Master mute state */
    this.isMasterMuted = false;

    /** @type {number} Volume before mute for restore */
    this.volumeBeforeMute = 0.8;

    /** @type {number} Player-local ambience layer volume multiplier */
    this.clientVolume = 1;

    /** @type {boolean} Player-local ambience layer mute state */
    this.clientMuted = false;

    // Dependencies (injected)
    this.dataService = null;
    this.syncService = null;
    this.isPreviewMode = DEFAULT_PREVIEW_MODE;

    // Pending layers (blocked by autoplay policy)
    this._pendingLayers = [];

    // Deferred state (when user hasn't interacted yet)
    this._deferredState = null;
    this._userHasInteracted = game.user?.isGM ?? false; // GM always "interacted"
  }

  /**
   * Initialize the manager with dependencies
   * @param {object} dataService - DataService instance
   * @param {object} syncService - SyncService instance (optional)
   */
  initialize(dataService, syncService = null) {
    this.dataService = dataService;
    this.syncService = syncService;
    // Reset interaction state - GM is always considered "interacted"
    this._userHasInteracted = game.user?.isGM ?? false;
    this._loadClientPreferences();
  }

  _loadClientPreferences() {
    if (game.user?.isGM) {
      try {
        this.masterVolume = game.settings.get(JUKEBOX.ID, JUKEBOX.SETTINGS.AMBIENCE_MASTER_VOLUME) ?? this.masterVolume;
      } catch {}

      try {
        this.isMasterMuted = game.settings.get(JUKEBOX.ID, JUKEBOX.SETTINGS.AMBIENCE_MUTED) ?? this.isMasterMuted;
      } catch {}

      this.clientVolume = 1;
      this.clientMuted = false;
      return;
    }

    try {
      this.clientVolume = game.settings.get(JUKEBOX.ID, JUKEBOX.SETTINGS.AMBIENCE_MASTER_VOLUME) ?? 1;
    } catch {
      this.clientVolume = 1;
    }

    try {
      this.clientMuted = game.settings.get(JUKEBOX.ID, JUKEBOX.SETTINGS.AMBIENCE_MUTED) ?? false;
    } catch {
      this.clientMuted = false;
    }
  }

  _getEffectiveLayerVolume(layerVolume = 0.8) {
    const masterVolume = game.user?.isGM ? this.masterVolume : 1;
    const clientVolume = game.user?.isGM ? 1 : this.clientVolume;
    const muted = game.user?.isGM ? this.isMasterMuted : this.clientMuted;

    if (muted) {
      return 0;
    }

    return layerVolume * masterVolume * clientVolume;
  }

  _applyEffectiveVolumes() {
    for (const layer of this.layers.values()) {
      layer.channel.setVolume(this._getEffectiveLayerVolume(layer.volume));
    }
  }

  setClientMasterVolume(volume) {
    if (game.user?.isGM) return this.masterVolume;

    this.clientVolume = Math.max(0, Math.min(volume, 1));
    if (this.clientVolume > 0) {
      this.clientMuted = false;
    }

    void game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.AMBIENCE_MASTER_VOLUME, this.clientVolume);
    if (this.clientVolume > 0) {
      void game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.AMBIENCE_MUTED, false);
    }

    this._applyEffectiveVolumes();
    Hooks.call('narratorJukeboxStateChanged', { scope: 'ambienceLayers' });
    return this.clientVolume;
  }

  getClientMasterVolume() {
    return game.user?.isGM ? this.masterVolume : this.clientVolume;
  }

  setClientMute(muted) {
    if (game.user?.isGM) return this.isMasterMuted;

    this.clientMuted = !!muted;
    void game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.AMBIENCE_MUTED, this.clientMuted);

    this._applyEffectiveVolumes();
    Hooks.call('narratorJukeboxStateChanged', { scope: 'ambienceLayers' });
    return this.clientMuted;
  }

  toggleClientMute() {
    return this.setClientMute(!this.clientMuted);
  }

  isClientMuted() {
    return game.user?.isGM ? this.isMasterMuted : this.clientMuted;
  }

  /**
   * Mark that the user has interacted with the page (unlocks audio)
   * Call this after user clicks/keydown
   */
  markUserInteracted() {
    if (this._userHasInteracted) return;

    debugLog(' User interaction detected, audio unlocked');
    this._userHasInteracted = true;

    // If we have deferred state, apply it now
    if (this._deferredState) {
      debugLog(' Applying deferred ambience state after interaction');
      this._applyDeferredState();
    }
  }

  /**
   * Check if user has interacted
   * @returns {boolean}
   */
  hasUserInteracted() {
    return this._userHasInteracted;
  }

  /**
   * Check if there's deferred state waiting for interaction
   * @returns {boolean}
   */
  hasDeferredState() {
    return this._deferredState !== null;
  }

  /**
   * Get the expected layer count from deferred state
   * @returns {number}
   */
  getDeferredLayerCount() {
    return this._deferredState?.layers?.length ?? 0;
  }

  /**
   * Apply the deferred state (internal)
   * @private
   */
  async _applyDeferredState() {
    if (!this._deferredState) return;

    const state = this._deferredState;
    this._deferredState = null;

    debugLog(`Creating ${state.layers?.length ?? 0} deferred layers`);

    // Restore master volume
    this.masterVolume = state.masterVolume ?? 0.8;
    this.isMasterMuted = state.isMasterMuted ?? false;

    // Create each layer
    for (const layerState of (state.layers || [])) {
      try {
        const layer = await this._createLayer(layerState.trackId, layerState.volume ?? 0.8);
        if (!layer) {
          const track = this.dataService.findTrack(layerState.trackId, 'ambience');
          this._recordLayerIssue(layerState.trackId, track, new Error('Ambience track unavailable on this client.'));
          debugWarn(` Failed to create deferred layer ${layerState.trackId}: track unavailable on this client`);
        }
      } catch (err) {
        const track = this.dataService.findTrack(layerState.trackId, 'ambience');
        this._recordLayerIssue(layerState.trackId, track, err);
        if (this._isAutoplayError(err)) {
          this._pendingLayers.push({
            trackId: layerState.trackId,
            volume: layerState.volume ?? 0.8
          });
        }
        debugWarn(` Failed to create deferred layer ${layerState.trackId}:`, err);
      }
    }

    Hooks.call('narratorJukeboxStateChanged', { scope: 'ambienceLayers' });
    Hooks.call('narratorJukeboxDeferredStateApplied', { layerCount: this.layerCount });
  }

  /**
   * Set preview mode (affects broadcasting)
   * @param {boolean} mode - Preview mode state
   */
  setPreviewMode(mode) {
    this.isPreviewMode = mode;
  }

  /**
   * Get the current number of active layers
   * @returns {number}
   */
  get layerCount() {
    return this.layers.size;
  }

  /**
   * Check if we can add more layers
   * @returns {boolean}
   */
  canAddLayer() {
    return this.layers.size < MAX_AMBIENCE_LAYERS;
  }

  /**
   * Internal method to create and start a layer
   * @private
   */
  async _createLayer(trackId, initialVolume = 0.8) {
    // Check if already at max layers
    if (!this.canAddLayer()) {
      debugWarn(` Cannot add layer: maximum ${MAX_AMBIENCE_LAYERS} layers reached`);
      return null;
    }

    // Check if this track is already playing
    if (this.layers.has(trackId)) {
      debugLog(`Layer already exists for track: ${trackId}`);
      return this.layers.get(trackId);
    }

    // Get track data
    const track = this.dataService.findTrack(trackId, 'ambience');
    if (!track) {
      debugError(` Ambience track not found: ${trackId}`);
      return null;
    }

    // Create a new audio channel for this layer
    const channel = new AudioChannel(`ambience-layer-${trackId}`);
    await channel.initialize();

    // Create the layer with the specified initial volume
    const layer = new AmbienceLayer(trackId, track, channel);
    layer.volume = initialVolume;

    // Apply effective volume to channel (layer * GM master * player-local control)
    channel.volume = this._getEffectiveLayerVolume(layer.volume);

    // Start playback
    await channel.play(track);

    // Store the layer
    this.layers.set(trackId, layer);
    this.clearLayerIssue(trackId);

    debugLog(`Added ambience layer: ${track.name} (${this.layerCount}/${MAX_AMBIENCE_LAYERS})`);

    return layer;
  }

  /**
   * Add a new ambience layer (with broadcast)
   * @param {string} trackId - Track ID to add
   * @param {number} initialVolume - Optional initial volume (0-1), defaults to 0.8
   * @returns {Promise<AmbienceLayer|null>} The created layer or null if failed
   */
  async addLayer(trackId, initialVolume = 0.8) {
    try {
      const layer = await this._createLayer(trackId, initialVolume);
      if (!layer) {
        if (!this.canAddLayer()) {
          ui.notifications.warn(`Maximum ${MAX_AMBIENCE_LAYERS} ambience layers reached`);
        } else if (!this.layers.has(trackId)) {
          ui.notifications.error('Ambience track not found');
        }
        return null;
      }

      // Broadcast incrementally if not in preview mode
      if (game.user.isGM && !this.isPreviewMode && this.syncService) {
        this.syncService.broadcastAmbienceLayerAdd(trackId, initialVolume, layer.track);
        ui.notifications.info(`Broadcasting ambience: ${layer.track.name}`);
      }

      // Notify UI
      Hooks.call('narratorJukeboxStateChanged', { scope: 'ambienceLayers' });
      Hooks.call('narratorJukeboxAmbienceLayerAdded', { trackId, track: layer.track });

      return layer;
    } catch (err) {
      const track = this.dataService.findTrack(trackId, 'ambience');
      this._recordLayerIssue(trackId, track, err);
      debugError(` Failed to add ambience layer:`, err);
      throw err;
    }
  }

  /**
   * Add a layer without broadcasting (for sync handler)
   * @param {string} trackId - Track ID to add
   * @param {number} initialVolume - Initial volume (0-1)
   */
  async addLayerWithoutBroadcast(trackId, initialVolume = 0.8) {
    // If user hasn't interacted, defer this layer
    if (!this._userHasInteracted) {
      debugLog(`Deferring layer ${trackId} until user interaction`);

      // Add to deferred state
      if (!this._deferredState) {
        this._deferredState = {
          masterVolume: this.masterVolume,
          isMasterMuted: this.isMasterMuted,
          layers: []
        };
      }

      // Check if already in deferred
      const existing = this._deferredState.layers.find(l => l.trackId === trackId);
      if (!existing) {
        this._deferredState.layers.push({ trackId, volume: initialVolume });
      }

      // Notify UI
      Hooks.call('narratorJukeboxAutoplayBlocked', {
        count: this._deferredState.layers.length,
        expected: this._deferredState.layers.length,
        actual: this.layers.size,
        deferred: true
      });

      return null;
    }

    try {
      const layer = await this._createLayer(trackId, initialVolume);
      if (layer) {
        Hooks.call('narratorJukeboxAmbienceLayerAdded', { trackId, track: layer.track });
      } else if (this._userHasInteracted) {
        const track = this.dataService.findTrack(trackId, 'ambience');
        this._recordLayerIssue(trackId, track, new Error('Ambience track unavailable on this client.'));
      }
      return layer;
    } catch (err) {
      const track = this.dataService.findTrack(trackId, 'ambience');
      this._recordLayerIssue(trackId, track, err);
      debugError(` Failed to add synced layer:`, err);
      return null;
    }
  }

  /**
   * Internal method to stop and remove a layer
   * @private
   */
  _removeLayer(trackId) {
    const layer = this.layers.get(trackId);
    if (!layer) {
      debugWarn(` Layer not found for track: ${trackId}`);
      return false;
    }

    // Stop and cleanup the channel
    layer.channel.stop();
    this.layers.delete(trackId);

    debugLog(`Removed ambience layer: ${layer.track.name} (${this.layerCount}/${MAX_AMBIENCE_LAYERS})`);
    return true;
  }

  /**
   * Remove an ambience layer (with broadcast)
   * @param {string} trackId - Track ID to remove
   * @param {boolean} broadcast - Whether to broadcast the change
   */
  removeLayer(trackId, broadcast = true) {
    if (!this._removeLayer(trackId)) return false;

    // Broadcast incrementally if not in preview mode
    if (game.user.isGM && broadcast && !this.isPreviewMode && this.syncService) {
      this.syncService.broadcastAmbienceLayerRemove(trackId);
    }

    // Notify UI
    Hooks.call('narratorJukeboxStateChanged', { scope: 'ambienceLayers' });
    Hooks.call('narratorJukeboxAmbienceLayerRemoved', { trackId });

    return true;
  }

  /**
   * Remove a layer without broadcasting (for sync handler)
   * @param {string} trackId - Track ID to remove
   */
  removeLayerWithoutBroadcast(trackId) {
    if (this._removeLayer(trackId)) {
      Hooks.call('narratorJukeboxAmbienceLayerRemoved', { trackId });
    }
  }

  /**
   * Toggle a layer on/off
   * @param {string} trackId - Track ID to toggle
   * @returns {Promise<boolean>} New state (true = playing)
   */
  async toggleLayer(trackId) {
    if (this.layers.has(trackId)) {
      this.removeLayer(trackId);
      return false;
    } else {
      const layer = await this.addLayer(trackId);
      return layer !== null;
    }
  }

  /**
   * Internal method to set layer volume
   * @private
   */
  _setLayerVolume(trackId, volume) {
    const layer = this.layers.get(trackId);
    if (!layer) return false;

    layer.volume = volume;

    layer.channel.setVolume(this._getEffectiveLayerVolume(volume));
    return true;
  }

  /**
   * Set volume for a specific layer (with broadcast)
   * @param {string} trackId - Track ID
   * @param {number} volume - Volume value (0-1)
   */
  setLayerVolume(trackId, volume) {
    if (!this._setLayerVolume(trackId, volume)) return;

    // Broadcast incrementally if not in preview mode
    if (game.user.isGM && !this.isPreviewMode && this.syncService) {
      this.syncService.broadcastAmbienceLayerVolume(trackId, volume);
    }
  }

  /**
   * Set layer volume without broadcasting (for sync handler)
   * @param {string} trackId - Track ID
   * @param {number} volume - Volume value (0-1)
   */
  setLayerVolumeWithoutBroadcast(trackId, volume) {
    this._setLayerVolume(trackId, volume);
  }

  /**
   * Get volume for a specific layer
   * @param {string} trackId - Track ID
   * @returns {number} Volume value (0-1)
   */
  getLayerVolume(trackId) {
    const layer = this.layers.get(trackId);
    return layer ? layer.volume : 0;
  }

  /**
   * Internal method to set master volume
   * @private
   */
  _setMasterVolume(volume) {
    this.masterVolume = volume;

    if (this.isMasterMuted && volume > 0) {
      this.isMasterMuted = false;
    }

    this._applyEffectiveVolumes();
  }

  /**
   * Set master volume for all layers (with broadcast)
   * @param {number} volume - Volume value (0-1)
   */
  setMasterVolume(volume) {
    this._setMasterVolume(volume);
    if (game.user?.isGM) {
      void game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.AMBIENCE_MASTER_VOLUME, this.masterVolume);
      if (this.masterVolume > 0) {
        void game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.AMBIENCE_MUTED, false);
      }
    }

    // Note: Don't call narratorJukeboxStateChanged here to avoid re-render during slider drag
    // The UI updates the display value directly in the listener
  }

  /**
   * Set master volume without broadcasting (for sync handler)
   * @param {number} volume - Volume value (0-1)
   */
  setMasterVolumeWithoutBroadcast(volume) {
    this._setMasterVolume(volume);
  }

  /**
   * Internal method to set mute state
   * @private
   */
  _setMasterMute(muted) {
    if (muted) {
      // Mute
      this.volumeBeforeMute = this.masterVolume;
      this.isMasterMuted = true;
      this._applyEffectiveVolumes();
    } else {
      // Unmute
      this.isMasterMuted = false;
      this._setMasterVolume(this.volumeBeforeMute);
    }
  }

  /**
   * Toggle master mute (with broadcast)
   * @returns {boolean} New mute state
   */
  toggleMasterMute() {
    const newMuted = !this.isMasterMuted;
    this._setMasterMute(newMuted);
    if (game.user?.isGM) {
      void game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.AMBIENCE_MUTED, this.isMasterMuted);
      if (!this.isMasterMuted) {
        void game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.AMBIENCE_MASTER_VOLUME, this.masterVolume);
      }
    }

    Hooks.call('narratorJukeboxStateChanged', { scope: 'ambienceLayers' });
    return this.isMasterMuted;
  }

  /**
   * Set master mute without broadcasting (for sync handler)
   * @param {boolean} muted - Mute state
   */
  setMasterMuteWithoutBroadcast(muted) {
    this._setMasterMute(muted);
  }

  /**
   * Stop all ambience layers
   * @param {boolean} broadcast - Whether to broadcast the change
   */
  stopAll(broadcast = true) {
    debugLog(`Stopping all ${this.layerCount} ambience layers`);

    for (const [trackId, layer] of this.layers) {
      layer.channel.stop();
    }
    this.layers.clear();

    // Broadcast if not in preview mode
    if (game.user.isGM && broadcast && !this.isPreviewMode && this.syncService) {
      this.syncService.broadcastAmbienceLayersStopAll();
    }

    Hooks.call('narratorJukeboxStateChanged', { scope: 'ambienceLayers' });
    Hooks.call('narratorJukeboxAmbienceStoppedAll');
  }

  /**
   * Check if a track is currently playing as a layer
   * @param {string} trackId - Track ID to check
   * @returns {boolean}
   */
  isLayerActive(trackId) {
    return this.layers.has(trackId);
  }

  /**
   * Get all active layers as an array
   * @returns {Array<{trackId: string, track: object, volume: number}>}
   */
  getActiveLayers() {
    return Array.from(this.layers.values()).map(layer => ({
      trackId: layer.trackId,
      track: layer.track,
      volume: layer.volume,
      addedAt: layer.addedAt
    }));
  }

  /**
   * Get a serializable state object for sync/presets
   * @returns {object}
   */
  getLayersState() {
    return {
      masterVolume: this.masterVolume,
      isMasterMuted: this.isMasterMuted,
      layers: Array.from(this.layers.values()).map(layer => ({
        trackId: layer.trackId,
        volume: layer.volume
      }))
    };
  }

  /**
   * Restore state from a state object (for sync/presets)
   * @param {object} state - State object from getLayersState()
   * @param {boolean} broadcast - Whether to broadcast after restore (sends full state)
   */
  async restoreState(state, broadcast = false) {
    const expectedLayers = (state.layers || []).length;

    // CRITICAL: If user hasn't interacted yet, defer the entire state
    // This prevents silent autoplay failures
    if (!this._userHasInteracted && expectedLayers > 0) {
      debugLog(`Deferring ${expectedLayers} layers until user interaction`);

      // Stop any existing layers
      for (const [, layer] of this.layers) {
        layer.channel.stop();
      }
      this.layers.clear();
      this._pendingLayers = [];

      // Store state for later
      this._deferredState = {
        masterVolume: state.masterVolume ?? 0.8,
        isMasterMuted: state.isMasterMuted ?? false,
        layers: state.layers || []
      };

      // Notify UI that audio is blocked and waiting for interaction
      Hooks.call('narratorJukeboxAutoplayBlocked', {
        count: expectedLayers,
        expected: expectedLayers,
        actual: 0,
        deferred: true
      });

      Hooks.call('narratorJukeboxStateChanged', { scope: 'ambienceLayers' });
      return;
    }

    // User has interacted - reconcile the state without restarting layers
    // that are already playing. This keeps player-side resyncs from making
    // ambience visibly restart when the broadcast state has not changed.
    this._pendingLayers = [];
    this._deferredState = null;

    this.masterVolume = state.masterVolume ?? 0.8;
    this.isMasterMuted = state.isMasterMuted ?? false;

    const desiredLayers = new Map();
    for (const layerState of (state.layers || [])) {
      if (!layerState?.trackId) continue;
      desiredLayers.set(layerState.trackId, {
        trackId: layerState.trackId,
        volume: layerState.volume ?? 0.8
      });
    }

    for (const trackId of Array.from(this.layers.keys())) {
      if (!desiredLayers.has(trackId)) {
        this._removeLayer(trackId);
      }
    }

    for (const layerState of desiredLayers.values()) {
      const { trackId, volume } = layerState;
      const existingLayer = this.layers.get(trackId);

      if (existingLayer) {
        existingLayer.volume = volume;
        existingLayer.channel.setVolume(this._getEffectiveLayerVolume(volume));
        this.clearLayerIssue(trackId);
        continue;
      }

      try {
        const layer = await this._createLayer(trackId, volume);
        if (!layer) {
          const track = this.dataService.findTrack(trackId, 'ambience');
          this._recordLayerIssue(trackId, track, new Error('Ambience track unavailable on this client.'));
          debugWarn(` Failed to restore layer ${trackId}: track unavailable on this client`);
        }
      } catch (err) {
        const track = this.dataService.findTrack(trackId, 'ambience');
        this._recordLayerIssue(trackId, track, err);
        if (this._isAutoplayError(err)) {
          debugWarn(` Autoplay blocked for layer ${trackId}:`, err.message);
          this._pendingLayers.push({ trackId, volume });
        } else {
          debugWarn(` Failed to restore layer ${trackId}:`, err);
        }
      }
    }

    // Notify only when we actually detected autoplay-blocked layers.
    const actualLayers = this.layers.size;
    if (this._pendingLayers.length > 0) {
      debugLog(`Autoplay detection: expected ${expectedLayers}, got ${actualLayers}, pending ${this._pendingLayers.length}`);
      Hooks.call('narratorJukeboxAutoplayBlocked', {
        count: this._pendingLayers.length,
        expected: expectedLayers,
        actual: actualLayers
      });
    }

    // Broadcast full state if requested (for presets loaded by GM)
    if (game.user.isGM && broadcast && !this.isPreviewMode && this.syncService) {
      this.syncService.broadcastAmbienceLayers(this.getLayersState());
    }

    Hooks.call('narratorJukeboxStateChanged', { scope: 'ambienceLayers' });
  }

  /**
   * Retry playing layers that were blocked by autoplay policy
   * Call this after user interaction
   */
  async retryPendingLayers() {
    if (!this._pendingLayers || this._pendingLayers.length === 0) return;

    debugLog(`Retrying ${this._pendingLayers.length} pending layers after user interaction`);

    const pending = [...this._pendingLayers];
    this._pendingLayers = [];

    for (const { trackId, volume } of pending) {
      try {
        await this._createLayer(trackId, volume);
      } catch (err) {
        debugWarn(` Still failed to play layer ${trackId}:`, err);
      }
    }

    Hooks.call('narratorJukeboxStateChanged', { scope: 'ambienceLayers' });
  }

  /**
   * Check if there are pending layers waiting for user interaction
   * @returns {boolean}
   */
  hasPendingLayers() {
    return this._pendingLayers && this._pendingLayers.length > 0;
  }

  /**
   * Get track IDs of all active layers
   * @returns {string[]}
   */
  getActiveTrackIds() {
    return Array.from(this.layers.keys());
  }

  getLayerIssue(trackId) {
    return this.layerIssues.get(trackId) || null;
  }

  getAllLayerIssues() {
    return Array.from(this.layerIssues.values());
  }

  clearLayerIssue(trackId) {
    if (!this.layerIssues.has(trackId)) return false;
    this.layerIssues.delete(trackId);
    Hooks.call('narratorJukeboxAmbienceLayerIssueCleared', { trackId });
    return true;
  }

  _isAutoplayError(err) {
    return err?.name === 'NotAllowedError' ||
      err?.message?.includes('play()') ||
      err?.message?.includes('user gesture') ||
      err?.message?.includes('autoplay');
  }

  _recordLayerIssue(trackId, track, err) {
    if (!trackId) return null;

    const issue = {
      trackId,
      trackName: track?.name || null,
      code: err?.code ?? null,
      reason: err?.reason || (this._isAutoplayError(err) ? 'autoplay_blocked' : 'unknown'),
      message: err?.message || 'Ambience layer failed to start.',
      permanent: !!err?.isPermanent,
      timestamp: Date.now()
    };

    this.layerIssues.set(trackId, issue);
    Hooks.call('narratorJukeboxAmbienceLayerIssue', issue);
    Hooks.call('narratorJukeboxStateChanged', { scope: 'ambienceLayers' });
    return issue;
  }
}

// Export singleton instance
export const ambienceLayerManager = new AmbienceLayerManager();

// Also export the class for testing
export { AmbienceLayerManager, AmbienceLayer };
