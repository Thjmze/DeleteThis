/**
 * Progress Manager Module
 * Handles RAF-based progress bar updates for music and ambience channels
 *
 * @module ui/progress-manager
 */

import { formatTime } from '../utils/time-format.js';

// Update interval in milliseconds (throttle updates)
const UPDATE_INTERVAL = 500;
const VISUALIZER_INTERVAL = 80;

function getFallbackLevels(app, bandCount, timestamp) {
    const channel = app.jukebox.channels.music;
    const volume = Math.max(0.12, channel.volume || 0);
    const time = channel.currentTime || (timestamp / 1000);
    const id = channel.currentTrack?.id || channel.currentTrack?.name || 'music';
    const seed = Array.from(String(id)).reduce((sum, char) => sum + char.charCodeAt(0), 0) % 89;

    return Array.from({ length: bandCount }, (_, index) => {
        const speed = 2.2 + index * 0.42 + (seed % 5) * 0.04;
        const phase = seed * 0.09 + index * 1.45;
        return Math.max(0.08, Math.min(1, (0.2 + Math.abs(Math.sin(time * speed + phase)) * 0.72) * volume));
    });
}

function updateTransportVisualizer(app, timestamp) {
    const html = app.element;
    if (!html || !html.length) return;

    const visualizer = html.find('.transport-eq, .micro-rail-eq');
    if (!visualizer.length) return;

    const bars = visualizer.find('span');
    const isLive = app.jukebox.isPlaying && !app.jukebox.isMuted && !!app.jukebox.channels.music.currentTrack;

    if (!isLive) {
        visualizer.removeClass('active reactive');
        bars.each((index, bar) => {
            bar.style.height = `${5 + (index % 2) * 2}px`;
            bar.style.opacity = '0.45';
        });
        return;
    }

    const channel = app.jukebox.channels.music;
    const levels = channel.getVisualizerLevels?.(bars.length) || getFallbackLevels(app, bars.length, timestamp);

    visualizer.addClass('active reactive');
    bars.each((index, bar) => {
        const level = levels[index] ?? 0.1;
        const height = Math.round(5 + level * 20);
        bar.style.height = `${height}px`;
        bar.style.opacity = `${0.52 + level * 0.48}`;
    });
}

/**
 * Start the music progress timer using requestAnimationFrame
 * @param {NarratorsJukeboxApp} app - The application instance
 */
export function startMusicProgress(app) {
    if (app._progressRAF) return;

    if (!app.element || !app.element.length) return;

    let lastUpdate = 0;
    let lastVisualizerUpdate = 0;

    const updateProgress = (timestamp) => {
        // Check if app is still open
        if (!app.element || !app.element.length) {
            stopMusicProgress(app);
            return;
        }

        if (timestamp - lastVisualizerUpdate >= VISUALIZER_INTERVAL) {
            lastVisualizerUpdate = timestamp;
            updateTransportVisualizer(app, timestamp);
        }

        // Throttle text and progress updates
        if (timestamp - lastUpdate >= UPDATE_INTERVAL) {
            lastUpdate = timestamp;

            // Query DOM elements fresh each time (they may be recreated by render)
            const html = app.element;
            const progressFill = html.find('#progress-fill')[0];
            const progressBar = html.find('#progress-bar')[0];
            const currentTimeEl = html.find('#current-time')[0];
            const totalTimeEl = html.find('#total-time')[0];
            const microRoot = html.find('.narrator-jukebox-micro')[0];
            const microProgressFill = html.find('#micro-progress-fill')[0];
            const microProgressBar = html.find('#micro-progress-bar')[0];
            const microCurrentTimeEl = html.find('#micro-current-time')[0];
            const microTotalTimeEl = html.find('#micro-total-time')[0];

            const channel = app.jukebox.channels.music;
            const current = channel.currentTime;
            const total = channel.duration;

            // Update progress bar
            if (total && total > 0) {
                const percent = (current / total) * 100;

                // Only update slider position if user is NOT dragging
                if (!app.isDragging) {
                    if (progressFill) progressFill.style.width = `${percent}%`;
                    if (progressBar) progressBar.value = percent;
                    if (currentTimeEl) currentTimeEl.textContent = formatTime(current);
                    if (microRoot) microRoot.style.setProperty('--micro-progress', `${percent * 3.6}deg`);
                    if (microProgressFill) microProgressFill.style.width = `${percent}%`;
                    if (microProgressBar) microProgressBar.value = percent;
                    if (microCurrentTimeEl) microCurrentTimeEl.textContent = formatTime(current);
                }

                if (totalTimeEl) totalTimeEl.textContent = formatTime(total);
                if (microTotalTimeEl) microTotalTimeEl.textContent = formatTime(total);
            } else if (!app.isDragging) {
                if (microRoot) microRoot.style.setProperty('--micro-progress', '0deg');
                if (microProgressFill) microProgressFill.style.width = '0%';
                if (microProgressBar) microProgressBar.value = 0;
                if (microCurrentTimeEl) microCurrentTimeEl.textContent = '0:00';
                if (microTotalTimeEl) microTotalTimeEl.textContent = '0:00';
            }
        }

        // Continue the animation loop
        app._progressRAFId = requestAnimationFrame(updateProgress);
    };

    // Start the animation loop
    app._progressRAF = true;
    app._progressRAFId = requestAnimationFrame(updateProgress);
}

/**
 * Stop the music progress timer
 * @param {NarratorsJukeboxApp} app - The application instance
 */
export function stopMusicProgress(app) {
    if (app._progressRAFId) {
        cancelAnimationFrame(app._progressRAFId);
        app._progressRAFId = null;
    }
    app._progressRAF = false;
}

/**
 * Start the ambience progress timer using requestAnimationFrame
 * @param {NarratorsJukeboxApp} app - The application instance
 */
export function startAmbienceProgress(app) {
    if (app._ambienceProgressRAF) return;

    if (!app.element || !app.element.length) return;

    let lastUpdate = 0;

    const updateAmbienceProgress = (timestamp) => {
        // Check if app is still open
        if (!app.element || !app.element.length) {
            stopAmbienceProgress(app);
            return;
        }

        // Throttle updates
        if (timestamp - lastUpdate >= UPDATE_INTERVAL) {
            lastUpdate = timestamp;

            // Query DOM elements fresh each time (they may be recreated by render)
            const html = app.element;
            const progressFill = html.find('#ambience-progress-fill')[0];
            const progressBar = html.find('#ambience-progress-bar')[0];
            const currentTimeEl = html.find('#ambience-current-time')[0];
            const totalTimeEl = html.find('#ambience-total-time')[0];

            const channel = app.jukebox.channels.ambience;
            const current = channel.currentTime;
            const total = channel.duration;

            if (total && total > 0 && isFinite(total)) {
                const percent = (current / total) * 100;

                // Only update slider position if user is NOT dragging
                if (!app.isAmbienceDragging) {
                    if (progressFill) progressFill.style.width = `${percent}%`;
                    if (progressBar) progressBar.value = percent;
                    if (currentTimeEl) currentTimeEl.textContent = formatTime(current);
                }

                if (totalTimeEl) totalTimeEl.textContent = formatTime(total);
            } else {
                // For looping/infinite ambience
                if (currentTimeEl) currentTimeEl.textContent = formatTime(current || 0);
                if (totalTimeEl) totalTimeEl.textContent = '∞';
            }
        }

        // Continue the animation loop
        app._ambienceProgressRAFId = requestAnimationFrame(updateAmbienceProgress);
    };

    // Start the animation loop
    app._ambienceProgressRAF = true;
    app._ambienceProgressRAFId = requestAnimationFrame(updateAmbienceProgress);
}

/**
 * Stop the ambience progress timer
 * @param {NarratorsJukeboxApp} app - The application instance
 */
export function stopAmbienceProgress(app) {
    if (app._ambienceProgressRAFId) {
        cancelAnimationFrame(app._ambienceProgressRAFId);
        app._ambienceProgressRAFId = null;
    }
    app._ambienceProgressRAF = false;
}

/**
 * Stop all progress timers (cleanup)
 * @param {NarratorsJukeboxApp} app - The application instance
 */
export function stopAllProgress(app) {
    stopMusicProgress(app);
    stopAmbienceProgress(app);
}

/**
 * Update progress bar element directly
 * @param {HTMLElement} element - Progress bar element
 * @param {number} percent - Progress percentage (0-100)
 */
export function updateProgressBar(element, percent) {
    if (!element) return;
    element.style.width = `${percent}%`;
}

/**
 * Update time display element
 * @param {HTMLElement} element - Time display element
 * @param {number} seconds - Time in seconds
 */
export function updateTimeDisplay(element, seconds) {
    if (!element) return;
    element.textContent = formatTime(seconds);
}
