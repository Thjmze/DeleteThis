/**
 * Session Health Listeners
 * Handles GM player health dots and targeted recovery actions.
 *
 * @module ui/listeners/health-listeners
 */

import { syncService } from '../../services/sync-service.js';

/**
 * Activate session health listeners for normal, mini, and micro modes.
 * @param {NarratorsJukeboxApp} app
 * @param {jQuery} html
 */
export function activateSessionHealthListeners(app, html) {
    if (!game.user?.isGM) return;

    html.on('click', '.session-health-summary', e => {
        e.preventDefault();
        e.stopPropagation();
        syncService.requestAllPlayerStatus('manual');
        ui.notifications.info('Narrator Jukebox: checking player audio status.');
    });

    html.on('click', '.session-health-dot[data-user-id]', e => {
        e.preventDefault();
        e.stopPropagation();

        const userId = e.currentTarget.dataset.userId;
        if (!userId) return;

        syncService.resyncUser(userId, 'manual');
        app.render(false);
    });

    html.on('contextmenu', '.session-health-dot[data-user-id]', e => {
        e.preventDefault();
        e.stopPropagation();

        const userId = e.currentTarget.dataset.userId;
        if (!userId) return;

        syncService.softResetUser(userId, 'manual');
        app.render(false);
    });
}
