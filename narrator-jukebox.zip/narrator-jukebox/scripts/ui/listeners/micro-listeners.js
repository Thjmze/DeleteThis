/**
 * Micro Mode Listeners Module
 * Handles the floating micro player controls, rail pinning, seeking, and drag.
 *
 * @module ui/listeners/micro-listeners
 */

import { syncService } from '../../core/jukebox-state.js';
import { debugLog } from '../../utils/debug.js';
import { formatTime } from '../../utils/time-format.js';

/**
 * Activate micro mode listeners
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {jQuery} html - The HTML element
 */
export function activateMicroListeners(app, html) {
    const jukebox = app.jukebox;

    initMicroDrag(app);
    activateMicroRail(app, html);
    activateMicroPlayback(app, html, jukebox);
    activateMicroProgress(app, html, jukebox);

    app._startProgressTimer();
}

function getQueueBoundaryTrack(jukebox, edge = 'first') {
    const playlistIds = jukebox.currentPlaylist?.musicIds || [];
    const sourceIds = playlistIds.length ? playlistIds : (jukebox.music || []).map(track => track.id);
    const orderedIds = edge === 'last' ? [...sourceIds].reverse() : sourceIds;
    return orderedIds.map(id => jukebox.music.find(track => track.id === id)).find(Boolean) || null;
}

function activateMicroRail(app, html) {
    const root = html.find('.narrator-jukebox-micro');
    let keyboardFocusIntent = false;

    html.on('keydown.microRailFocus', e => {
        if (e.key === 'Tab') {
            keyboardFocusIntent = true;
            root.addClass('rail-keyboard-focus');
        }
    });

    html.on('mousedown.microRailFocus pointerdown.microRailFocus touchstart.microRailFocus', () => {
        keyboardFocusIntent = false;
        root.removeClass('rail-keyboard-focus');
    });

    html.on('focusin.microRailFocus', () => {
        if (keyboardFocusIntent) {
            root.addClass('rail-keyboard-focus');
        }
    });

    html.on('focusout.microRailFocus', () => {
        setTimeout(() => {
            if (!root[0]?.contains(document.activeElement)) {
                keyboardFocusIntent = false;
                root.removeClass('rail-keyboard-focus');
            }
        }, 0);
    });

    html.find('.micro-rest').on('click', e => {
        if ($(e.target).closest('button, input').length) return;
        if (app._microIsDragging) return;
        e.preventDefault();
        e.stopPropagation();
        root.toggleClass('rail-pinned');
    });

    html.find('.micro-rail').on('click', e => {
        if ($(e.target).closest('.session-health-bar').length) return;
        e.stopPropagation();
    });

    $(document).off('click.microRail').on('click.microRail', e => {
        if (!html[0]?.contains(e.target)) {
            keyboardFocusIntent = false;
            root.removeClass('rail-pinned rail-keyboard-focus');
        }
    });

    html.find('#micro-expand-mini').click(e => {
        e.stopPropagation();
        app._exitMicroMode();
    });

    html.find('.micro-status-pill[data-micro-open-tab]').click(e => {
        e.stopPropagation();
        const tab = e.currentTarget.dataset.microOpenTab;
        if (tab) app._miniActiveTab = tab;
        app._exitMicroMode();
    });

    html.find('.micro-rail-art').dblclick(e => {
        if (app._microIsDragging) return;
        e.preventDefault();
        e.stopPropagation();
        app._exitMicroToNormal();
    });
}

function activateMicroPlayback(app, html, jukebox) {
    const playOrPause = async () => {
        try {
            if (!jukebox.channels.music.currentTrack && !jukebox.isPlaying) {
                if ((jukebox.getManualQueueCount?.() || 0) > 0) {
                    jukebox.next(true);
                    app.render(false);
                    return;
                }

                const firstTrack = getQueueBoundaryTrack(jukebox, 'first');
                if (!firstTrack) {
                    ui.notifications.warn('Add music to the library before pressing play.');
                    return;
                }

                await jukebox.playMusic(firstTrack.id, 'music');
            } else {
                jukebox.togglePlay('music');
            }
        } catch (error) {
            debugLog('Micro play/pause failed:', error);
            return;
        }

        app.render(false);
    };

    html.find('#micro-rest-play-pause, #micro-play-pause').click(e => {
        e.stopPropagation();
        playOrPause();
    });

    html.find('#micro-prev').click(async e => {
        e.stopPropagation();
        try {
            if (!jukebox.channels.music.currentTrack && !jukebox.isPlaying) {
                const lastTrack = getQueueBoundaryTrack(jukebox, 'last');
                if (!lastTrack) {
                    ui.notifications.warn('Add music to the library before skipping.');
                    return;
                }
                await jukebox.playMusic(lastTrack.id, 'music');
                return;
            }

            jukebox.prev();
        } catch (error) {
            debugLog('Micro previous failed:', error);
        }
    });

    html.find('#micro-next').click(async e => {
        e.stopPropagation();
        try {
            if (!jukebox.channels.music.currentTrack && !jukebox.isPlaying) {
                if ((jukebox.getManualQueueCount?.() || 0) > 0) {
                    jukebox.next(true);
                    app.render(false);
                    return;
                }

                const firstTrack = getQueueBoundaryTrack(jukebox, 'first');
                if (!firstTrack) {
                    ui.notifications.warn('Add music to the library before skipping.');
                    return;
                }
                await jukebox.playMusic(firstTrack.id, 'music');
                return;
            }

            jukebox.next(true);
        } catch (error) {
            debugLog('Micro next failed:', error);
        }
    });

    html.find('#micro-mute').click(e => {
        e.stopPropagation();
        jukebox.toggleMute('music');
        app.render(false);
    });

    html.find('#micro-volume-slider').on('input', e => {
        const value = parseFloat(e.target.value) || 0;
        const vol = value / 100;
        e.currentTarget.style.setProperty('--volume-level', `${value}%`);
        jukebox.setVolume(vol, 'music');
    });

    html.find('#micro-broadcast-toggle').click(e => {
        e.stopPropagation();
        e.preventDefault();

        jukebox.isPreviewMode = !jukebox.isPreviewMode;

        debugLog('Micro broadcast mode toggled:', {
            isPreviewMode: jukebox.isPreviewMode,
            soundboardBroadcastMode: jukebox.soundboardBroadcastMode
        });

        app.render(false);
    });
}

function activateMicroProgress(app, html, jukebox) {
    const progressFillEl = html.find('#micro-progress-fill');
    const currentTimeEl = html.find('#micro-current-time');
    const progressBar = html.find('#micro-progress-bar');

    if (!progressBar.length) return;
    if (app.isDragging === undefined) app.isDragging = false;

    progressBar.on('mousedown', () => {
        app.isDragging = true;
    });

    progressBar.on('input', e => {
        app.isDragging = true;
        const percent = parseFloat(e.target.value) || 0;
        progressFillEl.css('width', `${percent}%`);
        html.find('.narrator-jukebox-micro')[0]?.style.setProperty('--micro-progress', `${percent * 3.6}deg`);

        const duration = jukebox.channels.music.duration;
        if (duration) {
            currentTimeEl.text(formatTime((percent / 100) * duration));
        }
    });

    progressBar.on('change', e => {
        const percent = parseFloat(e.target.value) || 0;
        jukebox.channels.music.seek(percent);

        if (game.user.isGM && !jukebox.isPreviewMode) {
            syncService.broadcastSeek('music', percent);
        }

        setTimeout(() => {
            app.isDragging = false;
        }, 200);
    });

    progressBar.on('mouseup', () => {
        setTimeout(() => {
            app.isDragging = false;
        }, 200);
    });
}

/**
 * Initialize micro mode drag functionality
 * @param {NarratorsJukeboxApp} app - The application instance
 */
function initMicroDrag(app) {
    if (app._initMicroDrag) {
        app._initMicroDrag();
    }
}

export { initMicroDrag };
