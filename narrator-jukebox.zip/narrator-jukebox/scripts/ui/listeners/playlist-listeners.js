/**
 * Playlist Listeners Module
 * Handles playlist browser interactions: selection, play, shuffle, delete, context menu
 *
 * @module ui/listeners/playlist-listeners
 */

import { localize, format, has } from '../../utils/i18n.js';
import { debounce } from '../../utils/debounce.js';

const CONTEXT_MENU_SELECTOR = '.nj-playlist-context-menu';
const CONTEXT_MENU_NAMESPACE = '.njPlaylistContextMenu';

/**
 * Activate playlist-related listeners
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {jQuery} html - The HTML element
 */
export function activatePlaylistListeners(app, html) {
    const jukebox = app.jukebox;
    const renderPlaylistSearch = debounce(() => app.render(false), 180);
    const renderQueueSearch = debounce(() => app.render(false), 160);
    let draggedQueueEntryId = null;

    // ========== PLAYLIST SEARCH ==========
    html.on('input', '.playlist-search-input', e => {
        app.playlistSearchQuery = e.currentTarget.value || '';
        app._focusPlaylistSearchAfterRender = true;
        renderPlaylistSearch();
    });

    html.on('keydown', '.playlist-search-input', e => {
        if (e.key !== 'Escape') return;
        e.preventDefault();
        app.playlistSearchQuery = '';
        app._focusPlaylistSearchAfterRender = true;
        app.render(false);
    });

    html.on('click', '.playlist-search-clear', e => {
        e.preventDefault();
        e.stopPropagation();
        app.playlistSearchQuery = '';
        app._focusPlaylistSearchAfterRender = true;
        app.render(false);
    });

    if (app._focusPlaylistSearchAfterRender && app.view === 'playlists') {
        const searchInput = html.find('.playlist-search-input')[0];
        if (searchInput) {
            searchInput.focus();
            const length = searchInput.value.length;
            searchInput.setSelectionRange(length, length);
        }
        app._focusPlaylistSearchAfterRender = false;
    }

    // ========== PLAYLIST BROWSER ITEM CLICK ==========
    html.on('click', '.playlist-browser-item', e => {
        e.stopPropagation();

        if ($(e.target).closest('.playlist-browser-play').length) return;

        const id = e.currentTarget.dataset.playlistId;
        if (id) {
            app.showPlayerQueue = false;
            app.selectedPlaylistId = id;
            app.render();
        }
    });

    html.on('click', '.queue-browser-item', e => {
        e.stopPropagation();
        app.showPlayerQueue = true;
        app.render();
    });

    // ========== SESSION QUEUE ==========
    html.on('input', '.queue-source-search-input', e => {
        app.queueSearchQuery = e.currentTarget.value || '';
        renderQueueSearch();
    });

    html.on('keydown', '.queue-source-search-input', e => {
        if (e.key !== 'Escape') return;
        e.preventDefault();
        app.queueSearchQuery = '';
        app.render(false);
    });

    html.on('click', '.queue-source-search-clear', e => {
        e.preventDefault();
        e.stopPropagation();
        app.queueSearchQuery = '';
        app.render(false);
    });

    html.on('click', '.queue-clear-btn', e => {
        e.preventDefault();
        e.stopPropagation();
        jukebox.clearManualQueue?.();
        app.showPlayerQueue = true;
        app.render(false);
    });

    html.on('click', '.queue-remove-entry-btn', e => {
        e.preventDefault();
        e.stopPropagation();
        const entryId = e.currentTarget.dataset.queueEntryId;
        if (!entryId) return;
        jukebox.removeManualQueueEntry?.(entryId);
        app.showPlayerQueue = true;
        app.render(false);
    });

    html.on('click', '.queue-play-entry-btn', e => {
        e.preventDefault();
        e.stopPropagation();
        const entryId = e.currentTarget.dataset.queueEntryId;
        if (!entryId) return;
        jukebox.playManualQueueEntry?.(entryId);
        app.showPlayerQueue = true;
        app.render(false);
    });

    html.on('dragstart', '.manual-queue-row[data-queue-entry-id]', e => {
        draggedQueueEntryId = e.currentTarget.dataset.queueEntryId || null;
        if (!draggedQueueEntryId) return;
        e.currentTarget.classList.add('dragging');
        e.originalEvent.dataTransfer.effectAllowed = 'move';
        e.originalEvent.dataTransfer.setData('text/plain', draggedQueueEntryId);
    });

    html.on('dragover', '.manual-queue-row[data-queue-index]', e => {
        if (!draggedQueueEntryId) return;
        e.preventDefault();
        e.currentTarget.classList.add('drag-over');
        e.originalEvent.dataTransfer.dropEffect = 'move';
    });

    html.on('dragleave', '.manual-queue-row', e => {
        e.currentTarget.classList.remove('drag-over');
    });

    html.on('drop', '.manual-queue-row[data-queue-index]', e => {
        if (!draggedQueueEntryId) return;
        e.preventDefault();
        e.currentTarget.classList.remove('drag-over');

        const targetIndex = Number(e.currentTarget.dataset.queueIndex || 0);
        jukebox.reorderManualQueueEntry?.(draggedQueueEntryId, targetIndex);
        draggedQueueEntryId = null;
        app.showPlayerQueue = true;
        app.render(false);
    });

    html.on('dragend', '.manual-queue-row', e => {
        e.currentTarget.classList.remove('dragging', 'drag-over');
        html.find('.manual-queue-row.drag-over').removeClass('drag-over');
        draggedQueueEntryId = null;
    });

    // ========== INLINE PLAY BUTTON IN BROWSER ==========
    html.on('click', '.playlist-browser-play', e => {
        e.stopPropagation();
        const id = e.currentTarget.dataset.playlistId;
        if (!id) return;

        const playlist = jukebox.playlists.find(p => p.id === id);
        if (!playlistHasPlayableTracks(jukebox, playlist)) {
            notifyEmptyPlaylist();
            return;
        }

        const isThisPlaylist = jukebox.currentPlaylist?.id === id;

        if (isThisPlaylist) {
            jukebox.togglePlay('music');
            app.render();
        } else {
            jukebox.playPlaylist(id);
        }
    });

    // ========== DEDICATED PLAY BUTTON ==========
    html.on('click', '.play-playlist-btn', e => {
        e.stopPropagation();
        const id = e.currentTarget.dataset.playlistId;
        if (!id) return;

        const playlist = jukebox.playlists.find(p => p.id === id);
        if (!playlistHasPlayableTracks(jukebox, playlist)) {
            notifyEmptyPlaylist();
            return;
        }

        const isThisPlaylist = jukebox.currentPlaylist?.id === id;

        if (isThisPlaylist) {
            jukebox.togglePlay('music');
            app.render();
        } else {
            jukebox.playPlaylist(id);
        }
    });

    // ========== SHUFFLE PLAY BUTTON ==========
    html.on('click', '.playlist-shuffle-btn', e => {
        e.stopPropagation();
        const id = e.currentTarget.dataset.playlistId;
        if (id) {
            const playlist = jukebox.playlists.find(p => p.id === id);
            if (!playlistHasPlayableTracks(jukebox, playlist)) {
                notifyEmptyPlaylist();
                return;
            }

            jukebox.shuffle = true;
            jukebox.playPlaylist(id);
            ui.notifications.info(localize('Notifications.ShuffleModeEnabled'));
        }
    });

    // ========== PLAYLIST LOOP TOGGLE ==========
    html.on('click', '.playlist-loop-btn', async e => {
        e.stopPropagation();
        const id = e.currentTarget.dataset.playlistId;
        if (!id) return;

        const playlist = jukebox.playlists.find(p => p.id === id);
        if (isSystemPlaylist(playlist)) {
            ui.notifications.info('Favorites is managed automatically.');
            return;
        }

        const newState = await jukebox.togglePlaylistLoop(id);
        const label = newState ? 'Loop Playlist (On)' : 'Loop Playlist (Off)';
        ui.notifications.info(label);
        app.render();
    });

    // ========== PER-TRACK LOOP TOGGLE ==========
    html.on('click', '.track-loop-btn', async e => {
        e.stopPropagation();
        const musicId = e.currentTarget.dataset.musicId;
        const playlistId = e.currentTarget.dataset.playlistId;
        if (!musicId || !playlistId) return;

        await jukebox.togglePlaylistTrackLoop(playlistId, musicId);
        app.render();
    });

    // ========== DELETE PLAYLIST BUTTON ==========
    html.on('click', '.playlist-delete-btn', e => {
        e.stopPropagation();
        const id = e.currentTarget.dataset.playlistId;
        if (!id) return;

        const playlist = jukebox.playlists.find(p => p.id === id);
        if (!playlist) return;
        if (isSystemPlaylist(playlist)) {
            ui.notifications.info('Favorites cannot be deleted.');
            return;
        }

        confirmPlaylistDeletion(app, jukebox, playlist);
    });

    // ========== CONTEXT MENU ==========
    html.on('contextmenu', '.playlist-browser-item', e => {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        const id = e.currentTarget.dataset.playlistId;
        if (!id) return false;

        const playlist = jukebox.playlists.find(p => p.id === id);
        if (!playlist) return false;

        app.selectedPlaylistId = id;
        showPlaylistContextMenu(app, jukebox, playlist, e.clientX, e.clientY);
        return false;
    });
}

/**
 * Show context menu for playlist item
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {NarratorJukebox} jukebox - The jukebox instance
 * @param {Object} playlist - The playlist object
 * @param {number} x - Mouse X position
 * @param {number} y - Mouse Y position
 */
function showPlaylistContextMenu(app, jukebox, playlist, x, y) {
    closePlaylistContextMenu();

    const editablePlaylists = getEditablePlaylists(jukebox);
    const playlistIndex = editablePlaylists.findIndex(p => p.id === playlist.id);
    const isCurrentPlaylist = jukebox.currentPlaylist?.id === playlist.id;
    const isPlaying = isCurrentPlaylist && jukebox.isPlaying;
    const isGM = game.user?.isGM;
    const canEditPlaylist = isGM && !isSystemPlaylist(playlist);
    const playableCount = getPlayableTrackCount(jukebox, playlist);
    const tracksCountLabel = format('Dialog.Playlist.TracksCount', { count: playableCount });

    const menu = $(`
        <div class="nj-context-menu nj-playlist-context-menu" role="menu" aria-label="${escapeHtml(playlist.name)}">
            <div class="nj-context-header">
                <div class="nj-context-title">${escapeHtml(playlist.name)}</div>
                <div class="nj-context-subtitle">${escapeHtml(tracksCountLabel)}</div>
            </div>
            ${buildMenuItem({
                action: 'play',
                icon: isPlaying ? 'fas fa-pause' : 'fas fa-play',
                label: isPlaying ? contextText('ContextMenu.Pause', 'Pause') : localize('ContextMenu.Play'),
                description: playableCount <= 0
                    ? contextText('ContextMenu.EmptyPlaylistHint', 'This playlist has no playable tracks')
                    : isPlaying
                    ? contextText('ContextMenu.PauseHint', 'Pause this playlist')
                    : contextText('ContextMenu.PlayHint', 'Start this playlist'),
                disabled: playableCount <= 0
            })}
            ${buildMenuItem({
                action: 'shuffle',
                icon: 'fas fa-random',
                label: localize('ContextMenu.ShufflePlay'),
                description: playableCount <= 0
                    ? contextText('ContextMenu.EmptyPlaylistHint', 'This playlist has no playable tracks')
                    : contextText('ContextMenu.ShuffleHint', 'Start with shuffle enabled'),
                disabled: playableCount <= 0
            })}
            ${canEditPlaylist ? '<div class="nj-context-divider"></div>' : ''}
            ${canEditPlaylist ? buildMenuItem({
                action: 'edit',
                icon: 'fas fa-edit',
                label: contextText('ContextMenu.EditPlaylist', 'Edit Details'),
                description: contextText('ContextMenu.EditPlaylistHint', 'Rename or change the cover')
            }) : ''}
            ${canEditPlaylist ? buildMenuItem({
                action: 'duplicate',
                icon: 'fas fa-copy',
                label: contextText('ContextMenu.DuplicatePlaylist', 'Duplicate Playlist'),
                description: contextText('ContextMenu.DuplicatePlaylistHint', 'Create a copy with the same tracks')
            }) : ''}
            ${canEditPlaylist ? buildMenuItem({
                action: 'move-up',
                icon: 'fas fa-arrow-up',
                label: contextText('ContextMenu.MoveUp', 'Move Up'),
                description: contextText('ContextMenu.MoveUpHint', 'Move this playlist higher in the list'),
                disabled: playlistIndex <= 0
            }) : ''}
            ${canEditPlaylist ? buildMenuItem({
                action: 'move-down',
                icon: 'fas fa-arrow-down',
                label: contextText('ContextMenu.MoveDown', 'Move Down'),
                description: contextText('ContextMenu.MoveDownHint', 'Move this playlist lower in the list'),
                disabled: playlistIndex === -1 || playlistIndex >= editablePlaylists.length - 1
            }) : ''}
            ${canEditPlaylist ? '<div class="nj-context-divider"></div>' : ''}
            ${canEditPlaylist ? buildMenuItem({
                action: 'delete',
                icon: 'fas fa-trash',
                label: localize('ContextMenu.DeletePlaylist'),
                description: contextText('ContextMenu.DeletePlaylistHint', 'Remove this playlist'),
                danger: true
            }) : ''}
        </div>
    `);

    menu.css({ left: 0, top: 0, visibility: 'hidden' });
    $('body').append(menu);
    positionContextMenu(menu, x, y);

    menu.on('click', '.nj-context-item', async evt => {
        const button = evt.currentTarget;
        if (button.disabled) return;

        const action = button.dataset.action;
        closePlaylistContextMenu();
        await handlePlaylistContextAction(app, jukebox, playlist, action);
    });

    window.setTimeout(() => {
        $(document).on(`mousedown${CONTEXT_MENU_NAMESPACE} contextmenu${CONTEXT_MENU_NAMESPACE}`, event => {
            if (!menu[0]?.contains(event.target)) {
                closePlaylistContextMenu();
            }
        });

        $(window).on(`resize${CONTEXT_MENU_NAMESPACE} scroll${CONTEXT_MENU_NAMESPACE}`, () => {
            closePlaylistContextMenu();
        });
    }, 0);
}

/**
 * Handle playlist context menu actions
 * @param {NarratorsJukeboxApp} app - App instance
 * @param {NarratorJukebox} jukebox - Jukebox instance
 * @param {Object} playlist - Playlist data
 * @param {string} action - Menu action identifier
 */
async function handlePlaylistContextAction(app, jukebox, playlist, action) {
    const editablePlaylists = getEditablePlaylists(jukebox);
    const playlistIndex = editablePlaylists.findIndex(p => p.id === playlist.id);
    const canEditPlaylist = !isSystemPlaylist(playlist);

    switch (action) {
        case 'play':
            if (!playlistHasPlayableTracks(jukebox, playlist)) {
                notifyEmptyPlaylist();
                break;
            }

            if (jukebox.currentPlaylist?.id === playlist.id && jukebox.isPlaying) {
                jukebox.togglePlay('music');
                app.render();
            } else {
                jukebox.playPlaylist(playlist.id);
            }
            break;

        case 'shuffle':
            if (!playlistHasPlayableTracks(jukebox, playlist)) {
                notifyEmptyPlaylist();
                break;
            }

            jukebox.shuffle = true;
            jukebox.playPlaylist(playlist.id);
            ui.notifications.info(localize('Notifications.ShuffleModeEnabled'));
            break;

        case 'edit':
            if (!canEditPlaylist) break;
            app.showEditPlaylistDialog(playlist.id);
            break;

        case 'duplicate': {
            if (!canEditPlaylist) break;
            const duplicate = await jukebox.duplicatePlaylist(playlist.id);
            if (duplicate) {
                app.selectedPlaylistId = duplicate.id;
                ui.notifications.info(format('Notifications.CreatedPlaylist', { name: duplicate.name }));
                app.render();
            }
            break;
        }

        case 'move-up':
            if (canEditPlaylist && playlistIndex > 0) {
                await jukebox.reorderPlaylist(playlist.id, playlistIndex - 1);
                app.selectedPlaylistId = playlist.id;
                app.render();
            }
            break;

        case 'move-down':
            if (canEditPlaylist && playlistIndex !== -1 && playlistIndex < editablePlaylists.length - 1) {
                await jukebox.reorderPlaylist(playlist.id, playlistIndex + 1);
                app.selectedPlaylistId = playlist.id;
                app.render();
            }
            break;

        case 'delete':
            if (!canEditPlaylist) break;
            confirmPlaylistDeletion(app, jukebox, playlist);
            break;
    }
}

function isSystemPlaylist(playlist) {
    return !!playlist?.system;
}

function getEditablePlaylists(jukebox) {
    return (jukebox.playlists || []).filter(playlist => !isSystemPlaylist(playlist));
}

function getPlayableTrackCount(jukebox, playlist) {
    if (!playlist) return 0;
    return (playlist.musicIds || []).filter(id => jukebox.music?.some(track => track.id === id)).length;
}

function playlistHasPlayableTracks(jukebox, playlist) {
    return getPlayableTrackCount(jukebox, playlist) > 0;
}

function notifyEmptyPlaylist() {
    ui.notifications.warn('This playlist has no playable tracks.');
}

/**
 * Confirm playlist deletion
 * @param {NarratorsJukeboxApp} app - App instance
 * @param {NarratorJukebox} jukebox - Jukebox instance
 * @param {Object} playlist - Playlist to delete
 */
function confirmPlaylistDeletion(app, jukebox, playlist) {
    if (isSystemPlaylist(playlist)) {
        ui.notifications.info('Favorites cannot be deleted.');
        return;
    }

    Dialog.confirm({
        title: localize('Dialog.Confirm.DeletePlaylist'),
        content: `<p>${format('Dialog.Confirm.DeletePlaylistContent', { name: playlist.name })}</p>`,
        classes: ['narrator-jukebox-dialog'],
        yes: async () => {
            await jukebox.deletePlaylist(playlist.id);

            if (jukebox.currentPlaylist?.id === playlist.id) {
                jukebox.currentPlaylist = null;
            }

            if (app.selectedPlaylistId === playlist.id) {
                const remainingPlaylists = getEditablePlaylists(jukebox);
                app.selectedPlaylistId = remainingPlaylists.length > 0 ? remainingPlaylists[0].id : null;
            }

            app.render();
        }
    });
}

/**
 * Remove any open playlist context menu and associated handlers
 */
function closePlaylistContextMenu() {
    $(CONTEXT_MENU_SELECTOR).remove();
    $(document).off(CONTEXT_MENU_NAMESPACE);
    $(window).off(CONTEXT_MENU_NAMESPACE);
}

/**
 * Keep the context menu within the viewport
 * @param {jQuery} menu - Context menu element
 * @param {number} x - Requested X position
 * @param {number} y - Requested Y position
 */
function positionContextMenu(menu, x, y) {
    const margin = 12;
    const width = menu.outerWidth();
    const height = menu.outerHeight();
    const left = Math.min(Math.max(margin, x), window.innerWidth - width - margin);
    const top = Math.min(Math.max(margin, y), window.innerHeight - height - margin);

    menu.css({
        left: `${left}px`,
        top: `${top}px`,
        visibility: 'visible'
    });
}

/**
 * Build one menu item row
 * @param {Object} options - Menu item options
 * @returns {string}
 */
function buildMenuItem({ action, icon, label, description = '', shortcut = '', danger = false, disabled = false }) {
    return `
        <button type="button" class="nj-context-item ${danger ? 'danger' : ''}" data-action="${action}" ${disabled ? 'disabled' : ''}>
            <span class="nj-context-item-main">
                <i class="${icon}"></i>
                <span class="nj-context-item-copy">
                    <span class="nj-context-label">${escapeHtml(label)}</span>
                    ${description ? `<span class="nj-context-description">${escapeHtml(description)}</span>` : ''}
                </span>
            </span>
            ${shortcut ? `<span class="nj-context-shortcut">${escapeHtml(shortcut)}</span>` : ''}
        </button>
    `;
}

/**
 * Resolve localized text for new context menu strings with safe fallback text
 * @param {string} key - Localization key
 * @param {string} fallback - Fallback string
 * @returns {string}
 */
function contextText(key, fallback) {
    return has(key) ? localize(key) : fallback;
}

/**
 * Escape HTML to safely render text inside the custom menu
 * @param {string} value - Raw string
 * @returns {string}
 */
function escapeHtml(value) {
    if (!value) return '';
    const div = document.createElement('div');
    div.textContent = String(value);
    return div.innerHTML;
}

export { showPlaylistContextMenu };
