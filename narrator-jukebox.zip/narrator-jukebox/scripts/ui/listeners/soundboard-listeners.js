/**
 * Soundboard Listeners Module
 * Handles soundboard interactions: play/stop, loop toggle, edit, delete, stop all, broadcast mode
 *
 * @module ui/listeners/soundboard-listeners
 */

import {
    JUKEBOX,
    SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MAX,
    SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MIN
} from '../../core/constants.js';
import { localize, format } from '../../utils/i18n.js';
import * as Dialogs from '../app-dialogs.js';

const CONTEXT_MENU_SELECTOR = '.nj-soundboard-context-menu';
const CONTEXT_MENU_NAMESPACE = '.njSoundboardContextMenu';
const SOUNDBOARD_DIALOG_CLASSES = ['narrator-jukebox-dialog', 'add-track-dialog-window', 'soundboard-theme', 'soundboard-context-dialog'];
const SOUNDBOARD_RENAME_DIALOG_CLASSES = [...SOUNDBOARD_DIALOG_CLASSES, 'soundboard-rename-dialog'];
const SOUNDBOARD_DELETE_DIALOG_CLASSES = [...SOUNDBOARD_DIALOG_CLASSES, 'soundboard-delete-confirm'];

function getCueLoopState(jukebox, sound) {
    const activeState = jukebox.activeSoundboardSounds.get(sound?.id);
    if (activeState?.isRandomInterval || sound?.randomIntervalEnabled) return false;
    return activeState ? !!activeState.isLooping : !!sound?.loop;
}

function getCueRandomIntervalState(jukebox, sound) {
    const activeState = jukebox.activeSoundboardSounds.get(sound?.id);
    return !!activeState?.isRandomInterval || !!sound?.randomIntervalEnabled;
}

function getCueRandomIntervalLabel(sound) {
    const min = getPositiveDelay(sound?.randomIntervalMin, SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MIN);
    const max = Math.max(min, getPositiveDelay(sound?.randomIntervalMax, SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MAX));
    return `${formatDelayLabel(min)}-${formatDelayLabel(max)}`;
}

function getPositiveDelay(value, fallback) {
    const seconds = Number(value);
    return Number.isFinite(seconds) && seconds > 0 ? seconds : fallback;
}

function formatDelayLabel(seconds) {
    const value = Math.max(0, Math.round(Number(seconds) || 0));
    if (value < 60) return `${value}s`;
    const mins = Math.floor(value / 60);
    const secs = value % 60;
    return secs ? `${mins}:${secs.toString().padStart(2, '0')}` : `${mins}m`;
}

async function setCueLoopPreference(app, jukebox, sound, loop) {
    if (!sound?.id) return null;

    jukebox.soundboardLoopState.set(sound.id, !!loop);
    const updated = await jukebox.updateSoundboardSound(sound.id, {
        loop: !!loop,
        ...(loop ? { randomIntervalEnabled: false } : {})
    });

    if (!updated) {
        ui.notifications.warn('This cue is no longer available.');
        return null;
    }

    if (jukebox.isSoundboardSoundPlaying(sound.id)) {
        const isBroadcast = jukebox.soundboardBroadcastMode;
        jukebox.stopSoundboardSound(sound.id, false);
        await jukebox.playSoundboardSound(sound.id, {
            loop: !!loop,
            randomIntervalEnabled: false,
            preview: !isBroadcast
        });
    }

    app.render(false);
    return updated;
}

async function setCueRandomIntervalPreference(app, jukebox, sound, enabled) {
    if (!sound?.id) return null;

    const min = getPositiveDelay(sound.randomIntervalMin, SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MIN);
    const max = Math.max(min, getPositiveDelay(sound.randomIntervalMax, SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MAX));
    const updated = await jukebox.updateSoundboardSound(sound.id, {
        randomIntervalEnabled: !!enabled,
        randomIntervalMin: min,
        randomIntervalMax: max,
        loop: enabled ? false : !!sound.loop
    });

    if (!updated) {
        ui.notifications.warn('This cue is no longer available.');
        return null;
    }

    if (enabled) {
        jukebox.soundboardLoopState.set(sound.id, false);
    }

    if (jukebox.isSoundboardSoundPlaying(sound.id)) {
        const isBroadcast = jukebox.soundboardBroadcastMode;
        jukebox.stopSoundboardSound(sound.id, false);
        if (enabled) {
            await jukebox.playSoundboardSound(sound.id, {
                loop: false,
                randomIntervalEnabled: true,
                preview: !isBroadcast
            });
        }
    }

    app.render(false);
    return updated;
}

/**
 * Activate soundboard-related listeners
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {jQuery} html - The HTML element
 */
export function activateSoundboardListeners(app, html) {
    const jukebox = app.jukebox;

    // ========== SOUNDBOARD CARD SIZE TOGGLE ==========
    html.on('click', '.sb-size-btn', e => {
        e.stopPropagation();
        const size = $(e.currentTarget).data('size');
        if (!size) return;
        game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.SOUNDBOARD_SIZE, size);
        app.render(false);
    });

    // ========== STOP ALL SOUNDS BUTTON ==========
    html.find('.stop-all-sounds-btn').click(() => {
        jukebox.stopAllSoundboardSounds();
        ui.notifications.info(localize('Notifications.AllSoundsStopped'));
    });

    html.on('click', '.soundboard-live-stop-btn', e => {
        e.preventDefault();
        e.stopPropagation();
        const id = $(e.currentTarget).data('soundId');
        if (!id) return;
        jukebox.stopSoundboardSound(id);
        app.render(false);
    });

    // ========== CONTEXT MENU ==========
    html.on('contextmenu', '.soundboard-card[data-sound-id]', e => {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        const id = $(e.currentTarget).data('soundId');
        if (!id) return false;

        const sound = jukebox.soundboard.find(s => s.id === id);
        if (!sound) return false;

        showSoundboardContextMenu(app, jukebox, sound, e.clientX, e.clientY);
        return false;
    });

    // ========== GLOBAL BROADCAST MODE TOGGLE ==========
    html.on('click', '.broadcast-toggle-btn', e => {
        e.stopPropagation();
        jukebox.soundboardBroadcastMode = !jukebox.soundboardBroadcastMode;
        app.render(false);
    });

    // ========== PLAY SOUNDBOARD SOUND ==========
    html.on('click', '.soundboard-card .sb-play-btn', e => {
        e.stopPropagation();
        const card = $(e.currentTarget).closest('.soundboard-card');
        const id = card.data('soundId');
        const sound = jukebox.soundboard.find(s => s.id === id);
        if (!sound) return;

        const isLooping = getCueLoopState(jukebox, sound);
        // Use global broadcast mode
        const isBroadcast = jukebox.soundboardBroadcastMode;

        if (jukebox.isSoundboardSoundPlaying(id)) {
            jukebox.stopSoundboardSound(id);
        } else {
            jukebox.soundboardLoopState.set(id, isLooping);
            jukebox.playSoundboardSound(id, { loop: isLooping, preview: !isBroadcast });
        }
    });

    // ========== TOGGLE LOOP MODE ==========
    html.on('click', '.soundboard-card .sb-loop-btn', async e => {
        e.stopPropagation();
        const btn = $(e.currentTarget);
        const card = btn.closest('.soundboard-card');
        const id = card.data('soundId');
        const sound = jukebox.soundboard.find(s => s.id === id);
        if (!sound || btn.data('busy') === true) return;

        btn.data('busy', true);
        btn.toggleClass('active', !getCueLoopState(jukebox, sound));

        try {
            await setCueLoopPreference(app, jukebox, sound, !getCueLoopState(jukebox, sound));
        } catch (err) {
            ui.notifications.error(format('Notifications.FailedToUpdate', { error: err.message }));
            app.render(false);
        } finally {
            btn.removeData('busy');
        }
    });

    // ========== TOGGLE RANDOM INTERVAL MODE ==========
    html.on('click', '.soundboard-card .sb-interval-btn', async e => {
        e.stopPropagation();
        const btn = $(e.currentTarget);
        const card = btn.closest('.soundboard-card');
        const id = card.data('soundId');
        const sound = jukebox.soundboard.find(s => s.id === id);
        if (!sound || btn.data('busy') === true) return;

        const nextState = !getCueRandomIntervalState(jukebox, sound);
        btn.data('busy', true);
        btn.toggleClass('active', nextState);

        try {
            await setCueRandomIntervalPreference(app, jukebox, sound, nextState);
        } catch (err) {
            ui.notifications.error(format('Notifications.FailedToUpdate', { error: err.message }));
            app.render(false);
        } finally {
            btn.removeData('busy');
        }
    });

    // ========== EDIT SOUNDBOARD SOUND ==========
    html.on('click', '.soundboard-card .sb-edit-btn', e => {
        e.stopPropagation();
        const id = $(e.currentTarget).closest('.soundboard-card').data('soundId');
        if (id) app.showEditSoundboardDialog(id);
    });

    // ========== DELETE SOUNDBOARD SOUND ==========
    html.on('click', '.soundboard-card .sb-delete-btn', e => {
        e.stopPropagation();
        const id = $(e.currentTarget).closest('.soundboard-card').data('soundId');
        if (!id) return;

        const sound = jukebox.soundboard.find(s => s.id === id);
        confirmSoundboardDeletion(app, jukebox, sound);
    });
}

function showSoundboardContextMenu(app, jukebox, sound, x, y) {
    closeSoundboardContextMenu();

    app.element?.find('.soundboard-card.context-open').removeClass('context-open');
    app.element?.find(`.soundboard-card[data-sound-id="${cssEscape(sound.id)}"]`).addClass('context-open');

    const isGM = game.user?.isGM;
    const isPlaying = jukebox.isSoundboardSoundPlaying(sound.id);
    const isLooping = getCueLoopState(jukebox, sound);
    const isRandomInterval = getCueRandomIntervalState(jukebox, sound);
    const isBroadcast = jukebox.soundboardBroadcastMode;
    const volume = Math.round(Math.max(0, Math.min(1, typeof sound.volume === 'number' ? sound.volume : 0.8)) * 100);
    const sourceLabel = sound.source === 'youtube' ? 'YouTube cue' : 'Local cue';
    const modeLabel = isBroadcast ? 'Broadcast' : 'Preview';
    const cardColor = sound.color || '#ff6b35';

    const menu = $(`
        <div class="nj-context-menu nj-soundboard-context-menu" role="menu" aria-label="${escapeHtml(sound.name)}" style="--context-accent: ${escapeAttribute(cardColor)};">
            <div class="nj-context-header soundboard-context-header">
                <div class="soundboard-context-art">
                    ${sound.thumbnail ? `<img src="${escapeAttribute(sound.thumbnail)}" alt="">` : `<i class="${escapeAttribute(sound.icon || 'fas fa-volume-up')}"></i>`}
                </div>
                <div class="soundboard-context-copy">
                    <div class="nj-context-title">${escapeHtml(sound.name)}</div>
                    <div class="nj-context-subtitle">${escapeHtml(sourceLabel)} / ${volume}% volume</div>
                </div>
                <span class="soundboard-context-mode ${isBroadcast ? 'broadcast' : 'preview'}">${escapeHtml(modeLabel)}</span>
            </div>
            ${buildMenuItem({
                action: 'play',
                icon: isPlaying ? 'fas fa-stop' : 'fas fa-play',
                label: isPlaying ? 'Stop Cue' : 'Play Cue',
                description: isPlaying ? 'Stop this sound now' : 'Fire this sound now',
                shortcut: isPlaying ? 'Live' : ''
            })}
            ${buildMenuItem({
                action: 'toggle-loop',
                icon: 'fas fa-redo',
                label: isLooping ? 'Disable Loop Default' : 'Loop by Default',
                description: isLooping ? 'Future plays start as one-shots' : 'Future plays repeat until stopped',
                shortcut: isLooping ? 'On' : 'Off'
            })}
            ${buildMenuItem({
                action: 'toggle-interval',
                icon: 'fas fa-clock',
                label: isRandomInterval ? 'Disable Random Interval' : 'Random Interval',
                description: isRandomInterval ? `Currently ${getCueRandomIntervalLabel(sound)}` : 'Fire this cue at uneven delays',
                shortcut: isRandomInterval ? 'On' : 'Off'
            })}
            ${isGM ? '<div class="nj-context-divider"></div>' : ''}
            ${isGM ? buildMenuItem({
                action: 'edit',
                icon: 'fas fa-edit',
                label: 'Edit Details',
                description: 'Change source, color, icon, volume'
            }) : ''}
            ${isGM ? buildMenuItem({
                action: 'rename',
                icon: 'fas fa-i-cursor',
                label: 'Rename',
                description: 'Update the cue label only'
            }) : ''}
            ${isGM ? buildMenuItem({
                action: 'duplicate',
                icon: 'fas fa-copy',
                label: 'Duplicate Cue',
                description: 'Create a copy with the same settings'
            }) : ''}
            ${isGM ? buildMenuItem({
                action: 'move-folder',
                icon: 'fas fa-folder-open',
                label: 'Move to Folder',
                description: 'Organize this cue with your sets'
            }) : ''}
            ${buildMenuItem({
                action: 'copy-url',
                icon: 'fas fa-link',
                label: 'Copy URL',
                description: 'Copy the source path to clipboard',
                disabled: !sound.url
            })}
            ${isGM ? '<div class="nj-context-divider"></div>' : ''}
            ${isGM ? buildMenuItem({
                action: 'delete',
                icon: 'fas fa-trash',
                label: 'Delete Cue',
                description: 'Remove this sound from the soundboard',
                danger: true
            }) : ''}
        </div>
    `);

    menu.css({ left: 0, top: 0, visibility: 'hidden' });
    $('body').append(menu);
    positionContextMenu(menu, x, y);

    menu.on('click', '.nj-context-item', async evt => {
        const button = evt.currentTarget;
        if (button.disabled) return;

        const action = button.dataset.action;
        closeSoundboardContextMenu();
        await handleSoundboardContextAction(app, jukebox, sound, action);
    });

    window.setTimeout(() => {
        $(document).on(`mousedown${CONTEXT_MENU_NAMESPACE} contextmenu${CONTEXT_MENU_NAMESPACE}`, event => {
            if (!menu[0]?.contains(event.target)) {
                closeSoundboardContextMenu();
            }
        });

        $(window).on(`resize${CONTEXT_MENU_NAMESPACE} scroll${CONTEXT_MENU_NAMESPACE}`, () => {
            closeSoundboardContextMenu();
        });
    }, 0);
}

async function handleSoundboardContextAction(app, jukebox, sound, action) {
    const currentSound = jukebox.soundboard.find(s => s.id === sound.id);
    if (!currentSound) {
        ui.notifications.warn('This cue is no longer available.');
        return;
    }

    switch (action) {
        case 'play':
            if (jukebox.isSoundboardSoundPlaying(currentSound.id)) {
                jukebox.stopSoundboardSound(currentSound.id);
                app.render(false);
            } else {
                const isLooping = getCueLoopState(jukebox, currentSound);
                await jukebox.playSoundboardSound(currentSound.id, {
                    loop: isLooping,
                    preview: !jukebox.soundboardBroadcastMode
                });
            }
            break;

        case 'toggle-loop': {
            await setCueLoopPreference(app, jukebox, currentSound, !getCueLoopState(jukebox, currentSound));
            break;
        }

        case 'toggle-interval': {
            await setCueRandomIntervalPreference(app, jukebox, currentSound, !getCueRandomIntervalState(jukebox, currentSound));
            break;
        }

        case 'edit':
            app.showEditSoundboardDialog(currentSound.id);
            break;

        case 'rename':
            showRenameSoundboardDialog(app, jukebox, currentSound);
            break;

        case 'duplicate':
            await duplicateSoundboardCue(app, jukebox, currentSound);
            break;

        case 'move-folder':
            Dialogs.showMoveToFolderDialog({
                trackIds: [currentSound.id],
                library: 'soundboard',
                jukebox,
                onSuccess: () => app.render()
            });
            break;

        case 'copy-url':
            await copySoundboardUrl(currentSound);
            break;

        case 'delete':
            confirmSoundboardDeletion(app, jukebox, currentSound);
            break;
    }
}

function showRenameSoundboardDialog(app, jukebox, sound) {
    const currentName = sound.name || '';
    const accent = sound.color || '#ff6b35';
    const volume = Math.round(Math.max(0, Math.min(1, typeof sound.volume === 'number' ? sound.volume : 0.8)) * 100);
    const sourceLabel = sound.source === 'youtube' ? 'YouTube cue' : 'Local cue';
    const modeLabel = jukebox.soundboardBroadcastMode ? 'Broadcast' : 'Preview';
    const artHtml = sound.thumbnail
        ? `<img src="${escapeAttribute(sound.thumbnail)}" alt="">`
        : `<i class="${escapeAttribute(sound.icon || 'fas fa-volume-up')}"></i>`;

    let isSaving = false;
    const modal = Dialogs.createModuleModal({
        title: 'Rename Cue',
        content: `
            <form class="soundboard-rename-form soundboard-context-form" style="--soundboard-dialog-accent: ${escapeAttribute(accent)};">
                <div class="soundboard-context-dialog-hero">
                    <div class="soundboard-context-dialog-art">
                        ${artHtml}
                    </div>
                    <div class="soundboard-context-dialog-copy">
                        <span class="soundboard-context-dialog-kicker"><i class="fas fa-i-cursor"></i> Rename Cue</span>
                        <h2>${escapeHtml(currentName || 'Soundboard Cue')}</h2>
                        <div class="soundboard-context-dialog-meta">
                            <span>${escapeHtml(sourceLabel)}</span>
                            <span>${volume}%</span>
                            <span>${escapeHtml(modeLabel)}</span>
                        </div>
                    </div>
                </div>
                <div class="soundboard-context-field">
                    <label for="soundboard-rename-input"><i class="fas fa-heading"></i> Cue label</label>
                    <input id="soundboard-rename-input" type="text" name="name" value="${escapeAttribute(currentName)}" spellcheck="false" autofocus>
                </div>
                <div class="soundboard-context-preview">
                    <span class="soundboard-context-preview-chip" style="--preview-color: ${escapeAttribute(accent)};">
                        <i class="${escapeAttribute(sound.icon || 'fas fa-volume-up')}"></i>
                        <span>${escapeHtml(currentName || 'Soundboard Cue')}</span>
                    </span>
                </div>
                <div class="soundboard-premium-actions">
                    <button type="button" class="soundboard-premium-btn secondary soundboard-dialog-cancel">
                        ${localize('Common.Cancel')}
                    </button>
                    <button type="submit" class="soundboard-premium-btn primary">
                        <i class="fas fa-save"></i>
                        ${localize('Common.Save')}
                    </button>
                </div>
            </form>
        `,
        classes: SOUNDBOARD_RENAME_DIALOG_CLASSES,
        closeLabel: localize('Header.Close'),
        initialFocus: 'input[name="name"]',
        onRender: ({ body, close }) => {
            const input = body.find('input[name="name"]');
            const previewLabel = body.find('.soundboard-context-preview-chip span');
            input.on('input', () => {
                previewLabel.text(input.val()?.trim() || 'Soundboard Cue');
            });
            body.find('.soundboard-dialog-cancel').on('click', () => close());
            body.find('.soundboard-rename-form').on('submit', async evt => {
                evt.preventDefault();
                if (isSaving) return;

                const name = input.val()?.trim();
                if (!name) {
                    ui.notifications.warn('Cue name cannot be empty.');
                    return;
                }

                const currentSound = jukebox.soundboard.find(s => s.id === sound.id);
                if (!currentSound) {
                    ui.notifications.warn('This cue is no longer available.');
                    close();
                    return;
                }

                isSaving = true;
                const submitButton = body.find('button[type="submit"]');
                submitButton.prop('disabled', true);

                try {
                    const updated = await jukebox.updateSoundboardSound(sound.id, { name });
                    if (!updated) {
                        ui.notifications.warn('This cue is no longer available.');
                        return;
                    }
                    ui.notifications.info(format('Notifications.Updated', { name }));
                    app.render();
                    close();
                } catch (err) {
                    ui.notifications.error(format('Notifications.FailedToUpdate', { error: err.message }));
                } finally {
                    if (!modal?.isClosed) {
                        isSaving = false;
                        submitButton.prop('disabled', false);
                    }
                }
            });

            window.setTimeout(() => {
                input.trigger('focus');
                input[0]?.select?.();
            }, 0);
        }
    });
}

async function duplicateSoundboardCue(app, jukebox, sound) {
    const copy = clonePlain(sound);
    delete copy.isPlaying;
    delete copy.isLooping;
    delete copy.sourceLabel;
    delete copy.sourceIcon;
    delete copy.sourceClass;
    delete copy.volumePercent;
    delete copy.fallbackClass;
    delete copy.isAudible;
    delete copy.loopDefault;
    delete copy.randomIntervalLabel;
    delete copy.isRandomIntervalActive;
    delete copy.isIntervalWaiting;
    delete copy.nextIntervalLabel;
    copy.id = generateId();
    copy.name = getCopyName(sound.name || 'Soundboard Cue', jukebox.soundboard);

    const duplicate = await jukebox.addSoundboardSound(copy);
    ui.notifications.info(`Duplicated cue "${duplicate.name}".`);
    app.render();
}

async function copySoundboardUrl(sound) {
    if (!sound.url) {
        ui.notifications.warn('This cue has no source URL to copy.');
        return;
    }

    try {
        if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
            await navigator.clipboard.writeText(sound.url);
        } else {
            fallbackCopyToClipboard(sound.url);
        }
        ui.notifications.info('Cue URL copied to clipboard.');
    } catch (err) {
        fallbackCopyToClipboard(sound.url);
        ui.notifications.info('Cue URL copied to clipboard.');
    }
}

function fallbackCopyToClipboard(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.left = '-9999px';
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    textarea.remove();
}

function confirmSoundboardDeletion(app, jukebox, sound) {
    if (!sound) return;

    const accent = sound.color || '#ff6b35';
    const deleteMessage = escapeHtml(format('Dialog.Confirm.DeleteSoundContent', {
        name: sound?.name || localize('Common.ThisSound')
    }));
    const artHtml = sound.thumbnail
        ? `<img src="${escapeAttribute(sound.thumbnail)}" alt="">`
        : `<i class="${escapeAttribute(sound.icon || 'fas fa-volume-up')}"></i>`;

    let isDeleting = false;
    const modal = Dialogs.createModuleModal({
        title: localize('Dialog.Confirm.DeleteSound'),
        content: `
            <div class="soundboard-delete-panel" style="--soundboard-dialog-accent: ${escapeAttribute(accent)};">
                <div class="soundboard-delete-art">
                    ${artHtml}
                </div>
                <div class="soundboard-delete-copy">
                    <span class="soundboard-context-dialog-kicker"><i class="fas fa-trash"></i> Delete Cue</span>
                    <h2>${escapeHtml(sound.name || localize('Common.ThisSound'))}</h2>
                    <p>${deleteMessage}</p>
                </div>
                <div class="soundboard-premium-actions">
                    <button type="button" class="soundboard-premium-btn secondary soundboard-dialog-cancel">
                        ${localize('Common.Cancel')}
                    </button>
                    <button type="button" class="soundboard-premium-btn danger soundboard-dialog-delete">
                        <i class="fas fa-trash"></i>
                        ${localize('Common.Delete')}
                    </button>
                </div>
            </div>
        `,
        classes: SOUNDBOARD_DELETE_DIALOG_CLASSES,
        closeLabel: localize('Header.Close'),
        initialFocus: '.soundboard-dialog-cancel',
        onRender: ({ body, close }) => {
            body.find('.soundboard-dialog-cancel').on('click', () => close());
            body.find('.soundboard-dialog-delete').on('click', async () => {
                if (isDeleting) return;

                const currentSound = jukebox.soundboard.find(s => s.id === sound.id);
                if (!currentSound) {
                    ui.notifications.warn('This cue is no longer available.');
                    close();
                    return;
                }

                isDeleting = true;
                const deleteButton = body.find('.soundboard-dialog-delete');
                deleteButton.prop('disabled', true);

                try {
                    await jukebox.deleteSoundboardSound(sound.id);
                    app.render();
                    close();
                } catch (err) {
                    ui.notifications.error(format('Notifications.FailedToUpdate', { error: err.message }));
                } finally {
                    if (!modal?.isClosed) {
                        isDeleting = false;
                        deleteButton.prop('disabled', false);
                    }
                }
            });
        }
    });
}

function closeSoundboardContextMenu() {
    $(CONTEXT_MENU_SELECTOR).remove();
    $(document).off(CONTEXT_MENU_NAMESPACE);
    $(window).off(CONTEXT_MENU_NAMESPACE);
    $('.soundboard-card.context-open').removeClass('context-open');
}

function positionContextMenu(menu, x, y) {
    const margin = 12;
    const width = menu.outerWidth();
    const height = menu.outerHeight();
    const left = Math.min(Math.max(margin, x), window.innerWidth - width - margin);
    const top = Math.min(Math.max(margin, y), window.innerHeight - height - margin);

    menu.css({
        left: `${left}px`,
        top: `${top}px`,
        visibility: 'visible'
    });
}

function buildMenuItem({ action, icon, label, description = '', shortcut = '', danger = false, disabled = false }) {
    return `
        <button type="button" class="nj-context-item ${danger ? 'danger' : ''}" data-action="${action}" ${disabled ? 'disabled' : ''}>
            <span class="nj-context-item-main">
                <i class="${icon}"></i>
                <span class="nj-context-item-copy">
                    <span class="nj-context-label">${escapeHtml(label)}</span>
                    ${description ? `<span class="nj-context-description">${escapeHtml(description)}</span>` : ''}
                </span>
            </span>
            ${shortcut ? `<span class="nj-context-shortcut">${escapeHtml(shortcut)}</span>` : ''}
        </button>
    `;
}

function getCopyName(name, sounds) {
    const baseName = `${name} Copy`;
    const existingNames = new Set((sounds || []).map(s => String(s.name || '').toLowerCase()));
    if (!existingNames.has(baseName.toLowerCase())) return baseName;

    let index = 2;
    while (existingNames.has(`${baseName} ${index}`.toLowerCase())) {
        index += 1;
    }
    return `${baseName} ${index}`;
}

function clonePlain(value) {
    if (typeof foundry !== 'undefined' && foundry.utils?.deepClone) {
        return foundry.utils.deepClone(value);
    }
    return JSON.parse(JSON.stringify(value));
}

function generateId() {
    if (typeof foundry !== 'undefined' && foundry.utils?.randomID) {
        return foundry.utils.randomID();
    }
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
        return crypto.randomUUID().replace(/-/g, '').slice(0, 16);
    }
    return `${Date.now()}${Math.random().toString(36).slice(2, 10)}`;
}

function escapeHtml(value) {
    if (!value) return '';
    const div = document.createElement('div');
    div.textContent = String(value);
    return div.innerHTML;
}

function escapeAttribute(value) {
    return escapeHtml(value).replace(/"/g, '&quot;');
}

function cssEscape(value) {
    if (typeof CSS !== 'undefined' && CSS.escape) {
        return CSS.escape(String(value));
    }
    return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
}
