/**
 * Folder Listeners
 * Handles folder create/edit/collapse interactions and drag-to-folder flows.
 */

import * as Dialogs from '../app-dialogs.js';
import { debugError } from '../../utils/debug.js';

const DRAG_BLOCKED_SELECTOR = [
  'button',
  'input',
  'select',
  'textarea',
  'a',
  '.col-actions',
  '.track-select-col',
  '.track-visibility-btn',
  '.amb-card-controls',
  '.amb-volume-control',
  '.amb-toggle-btn',
  '.card-select-overlay',
  '.sb-card-controls',
  '.sb-loop-btn',
  '.sb-play-btn'
].join(', ');

const DRAG_CONFIGS = [
  {
    library: 'music',
    view: 'library',
    rootSelector: '#view-library',
    itemSelector: '.library-track-row[data-music-id]',
    datasetKey: 'musicId',
    collection: 'music',
    mime: 'application/x-narrator-jukebox-music',
    textPrefix: 'narrator-jukebox/music:',
    singleIcon: 'fas fa-music',
    multiIcon: 'fas fa-layer-group',
    singular: 'track',
    plural: 'tracks',
    previewSingle: 'Move to folder',
    previewMultiple: 'Move selected tracks'
  },
  {
    library: 'ambience',
    view: 'ambience',
    rootSelector: '#view-ambience',
    itemSelector: '.ambience-card[data-ambience-id]',
    datasetKey: 'ambienceId',
    collection: 'ambience',
    mime: 'application/x-narrator-jukebox-ambience',
    textPrefix: 'narrator-jukebox/ambience:',
    singleIcon: 'fas fa-layer-group',
    multiIcon: 'fas fa-layer-group',
    singular: 'sound',
    plural: 'sounds',
    previewSingle: 'Move to folder',
    previewMultiple: 'Move selected sounds'
  },
  {
    library: 'soundboard',
    view: 'soundboard',
    rootSelector: '#view-soundboard',
    itemSelector: '.soundboard-card[data-sound-id]',
    datasetKey: 'soundId',
    collection: 'soundboard',
    mime: 'application/x-narrator-jukebox-soundboard',
    textPrefix: 'narrator-jukebox/soundboard:',
    singleIcon: 'fas fa-bolt',
    multiIcon: 'fas fa-layer-group',
    singular: 'cue',
    plural: 'cues',
    previewSingle: 'Move to folder',
    previewMultiple: 'Move selected cues'
  }
];

/**
 * Activate folder-related listeners
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {jQuery} html - The HTML element
 */
export function activateFolderListeners(app, html) {
  activateFolderDragAndDrop(app, html);

  // Create folder button
  html.on('click', '.create-folder-btn', (e) => {
    e.preventDefault();
    e.stopPropagation();
    const library = $(e.currentTarget).data('library');
    if (!library) return;
    Dialogs.showFolderDialog({
      library,
      jukebox: app.jukebox,
      onSuccess: () => app.render()
    });
  });

  // Edit folder button
  html.on('click', '.folder-edit-btn', (e) => {
    e.preventDefault();
    e.stopPropagation();
    const folderId = $(e.currentTarget).data('folderId');
    const library = $(e.currentTarget).data('library');
    if (!folderId || !library) return;

    const folder = app.jukebox.getFolders(library).find(f => f.id === folderId);
    if (!folder) return;

    Dialogs.showFolderDialog({
      folder,
      library,
      jukebox: app.jukebox,
      onSuccess: () => app.render()
    });
  });

  // Move a single music track into a folder from the library row actions.
  html.on('click', '.move-track-to-folder-btn', (e) => {
    e.preventDefault();
    e.stopPropagation();

    const musicId = $(e.currentTarget).data('musicId');
    if (!musicId) return;

    Dialogs.showMoveToFolderDialog({
      trackIds: [musicId],
      library: 'music',
      jukebox: app.jukebox,
      onSuccess: () => app.render()
    });
  });

  // Toggle folder collapse via chevron button
  html.on('click', '.folder-toggle', (e) => {
    e.preventDefault();
    e.stopPropagation();
    toggleFolderCollapse(app, $(e.currentTarget).closest('.folder-section'));
  });

  // Toggle folder collapse via header click when not in selection mode
  html.on('click', '.folder-header', (e) => {
    if (app.selectionMode) return;

    if ($(e.target).closest('.folder-edit-btn, .folder-actions, .folder-toggle, .folder-select-btn').length) return;

    toggleFolderCollapse(app, $(e.currentTarget).closest('.folder-section'));
  });
}

function activateFolderDragAndDrop(app, html) {
  if (!game.user.isGM) return;

  for (const config of DRAG_CONFIGS) {
    html.on('dragstart', `${config.rootSelector} ${config.itemSelector}`, event => {
      handleDragStart(app, html, config, event);
    });

    html.on('dragend', `${config.rootSelector} ${config.itemSelector}`, () => {
      handleDragEnd(app, html, config);
    });

    html.on('dragenter dragover', `${config.rootSelector} .library-folder-item[data-folder-drop-target="true"]`, event => {
      handleFolderDragOver(app, config, event);
    });

    html.on('dragleave', `${config.rootSelector} .library-folder-item[data-folder-drop-target="true"]`, event => {
      const relatedTarget = event.originalEvent?.relatedTarget;
      if (relatedTarget && event.currentTarget.contains(relatedTarget)) return;
      clearFolderDropHover(event.currentTarget);
    });

    html.on('drop', `${config.rootSelector} .library-folder-item[data-folder-drop-target="true"]`, async event => {
      await handleFolderDrop(app, html, config, event);
    });
  }
}

function handleDragStart(app, html, config, event) {
  if (app.view !== config.view) {
    event.preventDefault();
    return;
  }

  if ($(event.target).closest(DRAG_BLOCKED_SELECTOR).length) {
    event.preventDefault();
    return;
  }

  const item = event.currentTarget;
  const sourceId = item.dataset[config.datasetKey];
  const dragData = getItemDragData(app, sourceId, config);
  if (!dragData.ids.length) {
    event.preventDefault();
    return;
  }

  const dataTransfer = event.originalEvent?.dataTransfer;
  if (!dataTransfer) return;

  app._folderDragState = {
    library: config.library,
    sourceId,
    ids: dragData.ids,
    selectionDrag: dragData.selectionDrag
  };

  dataTransfer.effectAllowed = 'move';
  try {
    dataTransfer.setData(config.mime, JSON.stringify({
      type: `narrator-jukebox/${config.library}`,
      ids: dragData.ids
    }));
  } catch (err) {
    debugError(`Failed to set ${config.library} drag payload:`, err);
  }
  dataTransfer.setData('text/plain', `${config.textPrefix}${dragData.ids.join(',')}`);

  const dragImage = createFolderDragPreview(app, dragData.ids, config);
  if (dragImage && dataTransfer.setDragImage) {
    dataTransfer.setDragImage(dragImage, 18, 18);
    setTimeout(() => dragImage.remove(), 0);
  }

  prepareFolderDragUI(app, html, config, dragData.ids, sourceId);
}

function handleDragEnd(app, html, config) {
  const suppressUntil = Date.now() + 250;
  app._folderDragSuppressClickUntil = suppressUntil;

  if (config.library === 'music') {
    app._librarySuppressNextTrackClickUntil = suppressUntil;
  } else if (config.library === 'ambience') {
    app._ambienceSuppressCardClickUntil = suppressUntil;
  } else if (config.library === 'soundboard') {
    app._soundboardSuppressCardClickUntil = suppressUntil;
  }

  clearFolderDragUI(app, html, config);
}

function handleFolderDragOver(app, config, event) {
  const ids = getDraggedItemIds(app, event, config);
  if (!ids.length) return;

  event.preventDefault();
  event.stopPropagation();

  const target = event.currentTarget;
  const changedIds = getChangedItemIds(app, ids, getDropFolderId(target), config);
  const dataTransfer = event.originalEvent?.dataTransfer;
  if (dataTransfer) dataTransfer.dropEffect = changedIds.length ? 'move' : 'none';

  setFolderDropHover(target, ids.length, changedIds.length, config);
}

async function handleFolderDrop(app, html, config, event) {
  const ids = getDraggedItemIds(app, event, config);
  if (!ids.length) return;

  event.preventDefault();
  event.stopPropagation();

  const target = event.currentTarget;
  const folderId = getDropFolderId(target);
  const changedIds = getChangedItemIds(app, ids, folderId, config);
  const selectionDrag = !!app._folderDragState?.selectionDrag;
  const suppressUntil = Date.now() + 250;

  app._folderDragSuppressClickUntil = suppressUntil;
  app._folderRailSuppressClickUntil = suppressUntil;
  if (config.library === 'music') {
    app._librarySuppressFolderFilterClickUntil = suppressUntil;
    app._librarySuppressNextTrackClickUntil = suppressUntil;
  } else if (config.library === 'ambience') {
    app._ambienceSuppressCardClickUntil = suppressUntil;
  } else if (config.library === 'soundboard') {
    app._soundboardSuppressCardClickUntil = suppressUntil;
  }

  if (!changedIds.length) {
    ui.notifications.info(ids.length === 1 ? `${capitalize(config.singular)} is already in that folder.` : `Selected ${config.plural} are already in that folder.`);
    clearFolderDragUI(app, html, config);
    return;
  }

  target.classList.add('folder-drop-saving');

  try {
    await app.jukebox.moveTracksToFolder(config.library, changedIds, folderId);
    notifyFolderMove(app, config, changedIds.length, folderId, target);

    clearFolderDragUI(app, html, config);

    if (selectionDrag) {
      app.exitSelectionMode();
    } else {
      app.render(false);
    }
  } catch (err) {
    debugError(`Failed to move ${config.library} items by drag and drop:`, err);
    ui.notifications.error(`Failed to update folder: ${err.message}`);
    clearFolderDragUI(app, html, config);
  }
}

function getItemDragData(app, sourceId, config) {
  const selectedIds = normalizeItemIds(app, app.getSelectedTrackIds?.() || [], config);
  const selectionDrag = selectedIds.includes(sourceId);

  return {
    ids: selectionDrag ? selectedIds : normalizeItemIds(app, [sourceId], config),
    selectionDrag
  };
}

function normalizeItemIds(app, ids, config) {
  const itemIds = new Set((app.jukebox[config.collection] || []).map(item => item.id));
  return [...new Set((ids || []).filter(id => id && itemIds.has(id)))];
}

function getDraggedItemIds(app, event, config) {
  if (app._folderDragState?.library === config.library) {
    return normalizeItemIds(app, app._folderDragState.ids, config);
  }

  const dataTransfer = event.originalEvent?.dataTransfer;
  if (!dataTransfer) return [];

  try {
    const typedData = dataTransfer.getData(config.mime);
    if (typedData) {
      const parsed = JSON.parse(typedData);
      if (parsed?.type === `narrator-jukebox/${config.library}`) {
        return normalizeItemIds(app, parsed.ids, config);
      }
    }
  } catch (err) {
    debugError(`Failed to parse ${config.library} drag payload:`, err);
  }

  const textData = dataTransfer.getData('text/plain') || '';
  if (!textData.startsWith(config.textPrefix)) return [];
  return normalizeItemIds(app, textData.slice(config.textPrefix.length).split(','), config);
}

function getDropFolderId(target) {
  return target.dataset.dropFolderId || null;
}

function getChangedItemIds(app, ids, folderId, config) {
  const targetFolderId = folderId || null;
  return normalizeItemIds(app, ids, config).filter(id => {
    const item = (app.jukebox[config.collection] || []).find(entry => entry.id === id);
    const currentFolderId = item?.folderId || null;
    return currentFolderId !== targetFolderId;
  });
}

function prepareFolderDragUI(app, html, config, ids, sourceId) {
  const root = html.find(config.rootSelector);
  root.addClass('folder-dragging');
  if (config.library === 'music') root.addClass('library-dragging');

  root.find(config.itemSelector).each((_, item) => {
    const id = item.dataset[config.datasetKey];
    item.setAttribute('aria-grabbed', id === sourceId ? 'true' : 'false');
    item.classList.toggle('folder-drag-source', id === sourceId);
    item.classList.toggle('folder-drag-peer', ids.includes(id) && id !== sourceId);
    if (config.library === 'music') {
      item.classList.toggle('library-drag-source', id === sourceId);
      item.classList.toggle('library-drag-peer', ids.includes(id) && id !== sourceId);
    }
  });

  root.find('.library-folder-item[data-folder-drop-target="true"]').each((_, target) => {
    const changedCount = getChangedItemIds(app, ids, getDropFolderId(target), config).length;
    target.classList.add('folder-drop-ready');
    target.classList.toggle('folder-drop-noop', changedCount === 0);
    target.dataset.dropLabel = getFolderDropLabel(target, ids.length, changedCount, config);
  });

  root.find('.library-folder-all').addClass('folder-drop-disabled');
}

function clearFolderDragUI(app, html, config) {
  const root = (app.element && app.element.length ? app.element : html).find(config.rootSelector);

  root.removeClass('folder-dragging library-dragging');
  root.find(config.itemSelector)
    .removeClass('folder-drag-source folder-drag-peer library-drag-source library-drag-peer')
    .attr('aria-grabbed', 'false');
  root.find('.library-folder-item')
    .removeClass('folder-drop-ready folder-drop-hover folder-drop-noop folder-drop-saving folder-drop-disabled')
    .removeAttr('data-drop-label');

  if (app._folderDragState?.library === config.library) {
    app._folderDragState = null;
  }
}

function setFolderDropHover(target, totalCount, changedCount, config) {
  target.classList.add('folder-drop-ready');
  target.classList.toggle('folder-drop-hover', changedCount > 0);
  target.classList.toggle('folder-drop-noop', changedCount === 0);
  target.dataset.dropLabel = getFolderDropLabel(target, totalCount, changedCount, config);
}

function clearFolderDropHover(target) {
  target.classList.remove('folder-drop-hover');
}

function getFolderDropLabel(target, totalCount, changedCount, config) {
  if (changedCount === 0) return 'Already here';

  const countLabel = formatItemCount(totalCount, config);
  if (!getDropFolderId(target)) return `Unfile ${countLabel}`;
  return `Drop ${countLabel}`;
}

function createFolderDragPreview(app, ids, config) {
  const preview = document.createElement('div');
  preview.className = `nj-library-drag-preview nj-folder-drag-preview ${config.library}-drag-preview`;

  const icon = document.createElement('i');
  icon.className = ids.length > 1 ? config.multiIcon : config.singleIcon;

  const body = document.createElement('span');
  const title = document.createElement('strong');
  const subtitle = document.createElement('small');

  if (ids.length === 1) {
    const item = (app.jukebox[config.collection] || []).find(entry => entry.id === ids[0]);
    title.textContent = item?.name || `1 ${config.singular}`;
    subtitle.textContent = config.previewSingle;
  } else {
    title.textContent = formatItemCount(ids.length, config);
    subtitle.textContent = config.previewMultiple;
  }

  body.append(title, subtitle);
  preview.append(icon, body);
  document.body.append(preview);

  return preview;
}

function notifyFolderMove(app, config, count, folderId, target) {
  const countLabel = formatItemCount(count, config);
  if (folderId) {
    const folder = app.jukebox.getFolders(config.library).find(f => f.id === folderId);
    ui.notifications.info(`Moved ${countLabel} to "${folder?.name || target.dataset.dropFolderLabel || 'folder'}".`);
  } else {
    ui.notifications.info(`Removed ${countLabel} from folder.`);
  }
}

function formatItemCount(count, config) {
  return `${count} ${count === 1 ? config.singular : config.plural}`;
}

function capitalize(value) {
  const text = String(value || '');
  return text ? text.charAt(0).toUpperCase() + text.slice(1) : text;
}

function toggleFolderCollapse(app, section) {
  const folderId = section.data('folderId');
  if (!folderId) return;

  if (app.collapsedFolders.has(folderId)) {
    app.collapsedFolders.delete(folderId);
  } else {
    app.collapsedFolders.add(folderId);
  }

  section.find('.folder-tracks').first().toggleClass('collapsed');
  section.find('.folder-chevron').first().toggleClass('collapsed');
}
