/**
 * Main Listeners Module
 * Handles navigation, search, tag filter, mode toggle, mood cards, load more, and suggestions
 *
 * @module ui/listeners/main-listeners
 */

import { debounce } from '../../utils/debounce.js';
import { format, localize } from '../../utils/i18n.js';

/**
 * Activate main navigation and UI listeners
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {jQuery} html - The HTML element
 */
export function activateMainListeners(app, html) {
    const jukebox = app.jukebox;

    // Cache frequently accessed elements
    const viewSections = html.find('.view-section');
    const navItems = html.find('.nav-item');

    // ========== NAVIGATION ==========
    navItems.click(e => {
        const view = e.currentTarget.dataset.view;
        app.showPlayerQueue = false;
        app.view = view;
        viewSections.addClass('hidden');
        html.find(`#view-${view}`).removeClass('hidden');
        navItems.removeClass('active');
        $(e.currentTarget).addClass('active');

        if (view === 'suggestions' && app._suggestionsDirty) {
            app._suggestionsDirty = false;
            app.render(false);
        }
    });

    html.find('.home-view-link, .player-view-shortcut').click(e => {
        const view = e.currentTarget.dataset.view;
        if (!view) return;
        app.showPlayerQueue = view === 'playlists' && e.currentTarget.dataset.panel === 'queue';
        app.view = view;
        app.render(false);
    });

    // ========== LOAD MORE PAGINATION ==========
    html.find('.load-more-btn').click(e => {
        const type = e.currentTarget.dataset.type;
        if (type === 'music') {
            app._musicDisplayLimit += 50;
        } else if (type === 'ambience') {
            app._ambienceDisplayLimit += 50;
        }
        app.render(false);
    });

    // ========== MOOD CARDS ==========
    html.find('.mood-card').click(async e => {
        const tag = String(e.currentTarget.dataset.tag || '').trim().toLowerCase();
        const trackCount = Number(e.currentTarget.dataset.trackCount || 0);

        if (!tag) {
            ui.notifications.warn(localize('Notifications.MoodNeedsTag'));
            return;
        }

        if (trackCount <= 0) {
            ui.notifications.warn(format('Notifications.MoodNoTracksForTag', { tag }));
            return;
        }

        jukebox.currentPlaylist = null;
        app.showPlayerQueue = false;
        app.tagFilter = tag;
        app._musicDisplayLimit = 50;

        const track = await jukebox.playRandomByTag(tag);
        if (!track) return;

        app.render(false);
    });

    html.find('.edit-moods-btn').click(() => app.showEditMoodsDialog());

    // ========== SUGGESTIONS ==========
    html.find('.suggestion-filter-btn').click(e => {
        app.suggestionFilter = e.currentTarget.dataset.suggestionFilter || 'all';
        app.render(false);
    });

    html.find('.suggestion-card').click(e => {
        if ($(e.target).closest('button, a').length) return;
        const key = e.currentTarget.dataset.suggestionKey;
        if (!key) return;
        app.selectedSuggestionKey = key;
        app.render(false);
    });

    html.find('.approve-suggestion, .reject-suggestion, .preview-suggestion, .copy-suggestion-url').click(async e => {
        e.stopPropagation();
        const button = e.currentTarget;
        const key = button.dataset.suggestionKey;
        if (!key || button.dataset.busy === 'true') return;

        button.dataset.busy = 'true';
        button.disabled = true;

        try {
            if (button.classList.contains('approve-suggestion')) {
                await app.approveSuggestion(key);
            } else if (button.classList.contains('reject-suggestion')) {
                await app.rejectSuggestion(key);
            } else if (button.classList.contains('preview-suggestion')) {
                await app.previewSuggestion(key);
            } else if (button.classList.contains('copy-suggestion-url')) {
                await app.copySuggestionUrl(key);
            }
        } finally {
            delete button.dataset.busy;
            button.disabled = false;
        }
    });

    // ========== SEARCH ==========
    activateSearchListeners(app, html);

    // ========== TAG FILTER ==========
    html.find('.tag-filter').on('change', e => {
        app.tagFilter = String(e.target.value || '').trim().toLowerCase();
        // Reset pagination when filter changes
        app._musicDisplayLimit = 50;
        app.render();
    });

    // ========== MUSIC LIBRARY FILTERS ==========
    html.on('click', '.library-folder-filter, .folder-rail-filter', e => {
        const suppressUntil = Math.max(app._folderRailSuppressClickUntil || 0, app._librarySuppressFolderFilterClickUntil || 0);
        if (Date.now() < suppressUntil) {
            e.preventDefault();
            e.stopPropagation();
            return;
        }

        if ($(e.target).closest('.folder-edit-btn').length) return;

        const folderId = e.currentTarget.dataset.folderFilter || 'all';
        const library = e.currentTarget.dataset.folderLibrary || 'music';

        if (library === 'ambience') {
            app.ambienceFolderFilter = folderId;
            app._ambienceDisplayLimit = 50;
        } else if (library === 'soundboard') {
            app.soundboardFolderFilter = folderId;
        } else {
            app.libraryFolderFilter = folderId;
            app._musicDisplayLimit = 50;
        }

        app.render(false);
    });

    html.on('keydown', '.library-folder-filter, .folder-rail-filter', e => {
        if (e.key !== 'Enter' && e.key !== ' ') return;
        e.preventDefault();
        $(e.currentTarget).trigger('click');
    });

    html.on('click', '.library-filter-chip, .library-filter-menu-item', e => {
        const filter = e.currentTarget.dataset.libraryFilter;
        if (!filter) return;

        if (filter === 'all') {
            app.libraryFolderFilter = 'all';
            app.librarySourceFilter = 'all';
            app.libraryVisibilityFilter = 'all';
            app.tagFilter = null;
            app.searchQuery = '';
        } else if (filter === 'unfiled') {
            app.libraryFolderFilter = app.libraryFolderFilter === 'unfiled' ? 'all' : 'unfiled';
        } else if (filter === 'hidden') {
            const enablingHiddenOnly = app.libraryVisibilityFilter !== 'hidden';
            app.libraryVisibilityFilter = enablingHiddenOnly ? 'hidden' : 'all';

            if (enablingHiddenOnly) {
                app.libraryFolderFilter = 'all';
                app.librarySourceFilter = 'all';
                app.tagFilter = null;
                app.searchQuery = '';
            }
        } else if (filter === 'local' || filter === 'youtube') {
            app.librarySourceFilter = app.librarySourceFilter === filter ? 'all' : filter;
        }

        app._musicDisplayLimit = 50;
        app.render(false);
    });

    html.on('click', '.library-clear-filters-btn', e => {
        e.preventDefault();
        e.stopPropagation();

        app.libraryFolderFilter = 'all';
        app.librarySourceFilter = 'all';
        app.libraryVisibilityFilter = 'all';
        app.tagFilter = null;
        app.searchQuery = '';
        app._musicDisplayLimit = 50;
        app.render(false);
    });

    html.on('change', '.library-sort-select', e => {
        app.librarySort = e.target.value || 'library';
        app._musicDisplayLimit = 50;
        app.render(false);
    });

    html.on('click', '.library-sort-option', e => {
        e.preventDefault();
        e.stopPropagation();

        const sort = e.currentTarget.dataset.librarySort;
        if (!['library', 'newest', 'title', 'source', 'duration'].includes(sort)) return;

        app.librarySort = sort;
        app._musicDisplayLimit = 50;
        app.render(false);
    });

    html.on('click', '.library-density-btn', e => {
        e.preventDefault();
        e.stopPropagation();

        const density = e.currentTarget.dataset.libraryDensity;
        if (!['comfortable', 'compact'].includes(density)) return;

        app.libraryDensity = density;
        app.render(false);
    });

    // ========== SOUNDBOARD FILTERS ==========
    html.on('change', '.soundboard-folder-filter-select', e => {
        app.soundboardFolderFilter = e.target.value || 'all';
        app.render(false);
    });

    html.on('change', '.soundboard-sort-select', e => {
        const sort = e.target.value || 'name';
        if (!['name', 'newest', 'source', 'volume'].includes(sort)) return;
        app.soundboardSort = sort;
        app.render(false);
    });

    // ========== MODE TOGGLE ==========
    activateModeToggleListeners(app, html, jukebox);

    // ========== ADD BUTTONS ==========
    html.find('.add-music-btn').not('.bulk-import-btn').click(() => app.showAddMusicDialog());
    html.find('.add-playlist-btn').click(() => app.showAddPlaylistDialog());
    html.find('.add-ambience-btn').click(() => app.showAddAmbienceDialog());
    html.find('.add-soundboard-btn').click(() => app.showAddSoundboardDialog());

    // ========== BULK IMPORT ==========
    html.find('.bulk-import-btn').click(e => {
        const type = $(e.currentTarget).data('type');
        app.showBulkImportDialog(type);
    });
}

/**
 * Activate search input listeners with debounce
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {jQuery} html - The HTML element
 */
function activateSearchListeners(app, html) {
    const searchInput = html.find('.search-input');
    const searchClear = html.find('.search-clear');
    const searchBar = html.find('.search-bar');

    // Debounced render for search
    const debouncedRender = debounce(() => app.render(false), 300);

    searchInput.on('input', e => {
        app.searchQuery = e.target.value;

        // Reset pagination when search changes (for the current view)
        app._musicDisplayLimit = 50;
        app._ambienceDisplayLimit = 50;

        // Update clear button visibility immediately
        if (app.searchQuery) {
            searchClear.removeClass('hidden');
            searchBar.addClass('has-query');
        } else {
            searchClear.addClass('hidden');
            searchBar.removeClass('has-query');
        }

        // Debounced filter update
        debouncedRender();
    });

    // Clear search button
    searchClear.on('click', () => {
        app.searchQuery = '';
        searchInput.val('');
        searchClear.addClass('hidden');
        searchBar.removeClass('has-query');
        searchInput.focus();
        app.render();
    });

    // ESC key to clear search
    searchInput.on('keydown', e => {
        if (e.key === 'Escape') {
            if (app.searchQuery) {
                app.searchQuery = '';
                searchInput.val('');
                searchClear.addClass('hidden');
                searchBar.removeClass('has-query');
                app.render();
            }
        }
    });
}

/**
 * Activate mode toggle (Preview/Broadcast) listeners
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {jQuery} html - The HTML element
 * @param {NarratorJukebox} jukebox - The jukebox instance
 */
function activateModeToggleListeners(app, html, jukebox) {
    const setMode = (isPreviewMode) => {
        jukebox.isPreviewMode = isPreviewMode;
        app._updateModeToggle();

        const modeText = isPreviewMode ? localize('Mode.PreviewMode') : localize('Mode.BroadcastMode');
        const modeDesc = isPreviewMode
            ? localize('Mode.PreviewDescription')
            : localize('Mode.BroadcastDescription');
        ui.notifications.info(`${modeText}: ${modeDesc}`);
    };

    // Toggle switch click
    html.find('.toggle-switch').click(e => {
        setMode(!jukebox.isPreviewMode);
    });

    // Clicking on labels to toggle
    html.find('.mode-label').click(e => {
        const isPreviewLabel = $(e.currentTarget).hasClass('preview-label');
        const isBroadcastLabel = $(e.currentTarget).hasClass('broadcast-label');

        // Only toggle if clicking the inactive label
        if ((isPreviewLabel && !jukebox.isPreviewMode) ||
            (isBroadcastLabel && jukebox.isPreviewMode)) {
            setMode(isPreviewLabel);
        }
    });

    html.find('.transport-preview-btn').click(() => {
        setMode(!jukebox.isPreviewMode);
        app.render(false);
    });

    html.find('.expand-player-btn').click(() => app._toggleFullscreen());
}
