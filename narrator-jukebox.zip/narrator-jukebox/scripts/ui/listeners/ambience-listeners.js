/**
 * Ambience Layer Mixer Listeners Module
 * Handles ambience layer interactions: toggle, volume, stop all, master controls
 *
 * @module ui/listeners/ambience-listeners
 */

import { MAX_AMBIENCE_LAYERS } from '../../core/constants.js';
import { debugLog } from '../../utils/debug.js';
import { localize, format } from '../../utils/i18n.js';
import * as Dialogs from '../app-dialogs.js';

const AMBIENCE_CONTEXT_MENU_SELECTOR = '.nj-ambience-context-menu';
const AMBIENCE_CONTEXT_MENU_NAMESPACE = '.njAmbienceContextMenu';
const AMBIENCE_CONTEXT_DIALOG_CLASSES = ['narrator-jukebox-dialog', 'add-track-dialog-window', 'ambience-theme', 'ambience-context-dialog'];

/**
 * Show layer limit warning toast
 * @private
 */
function showLayerLimitToast() {
    // Remove any existing toast
    const existing = document.querySelector('.ambience-limit-toast');
    if (existing) existing.remove();

    // Create toast element
    const toast = document.createElement('div');
    toast.className = 'ambience-limit-toast';
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'polite');
    toast.innerHTML = `<i class="fas fa-exclamation-triangle"></i> ${format('Notifications.MaxLayersReached', { count: MAX_AMBIENCE_LAYERS })}`;
    document.body.appendChild(toast);

    // Auto-remove after animation
    setTimeout(() => toast.remove(), 3000);
}

/**
 * Add activation animation to card
 * @private
 * @param {jQuery} card - The card element
 */
function animateLayerActivation(card) {
    card.addClass('layer-activating');
    setTimeout(() => card.removeClass('layer-activating'), 500);
}

/**
 * Add deactivation animation to card
 * @private
 * @param {jQuery} card - The card element
 */
function animateLayerDeactivation(card) {
    card.addClass('layer-deactivating');
    setTimeout(() => card.removeClass('layer-deactivating'), 300);
}

/**
 * Show shake animation for layer limit reached
 * @private
 * @param {jQuery} card - The card element
 */
function animateLayerLimitShake(card) {
    card.addClass('layer-limit-reached');
    setTimeout(() => card.removeClass('layer-limit-reached'), 400);
}

/**
 * Update layer limit visual state
 * @private
 * @param {jQuery} html - The HTML element
 * @param {Object} jukebox - The jukebox instance
 */
function updateLayerLimitState(html, jukebox) {
    const count = jukebox.getAmbienceLayerCount();
    const atLimit = count >= MAX_AMBIENCE_LAYERS;

    // Update badge state
    html.find('.ambience-layer-badge').toggleClass('at-limit', atLimit);

    // Update layers indicator
    html.find('.ambience-layers-indicator').toggleClass('at-limit', atLimit);

    // Update inactive cards disabled state
    html.find('.ambience-card').each(function() {
        const card = $(this);
        const isActive = card.hasClass('active');
        card.toggleClass('layer-disabled', atLimit && !isActive);
    });
}

async function toggleAmbienceLayerWithFeedback(jukebox, card, id) {
    try {
        await jukebox.toggleAmbienceLayer(id);
    } catch (err) {
        card.removeClass('layer-activating layer-deactivating');
        ui.notifications.error(`Narrator Jukebox: ${err?.message || 'Failed to toggle ambience layer.'}`);
        debugLog('Ambience layer toggle failed:', id, err);
    }
}

function normalizeRangePercent(value) {
    const percent = Number.parseInt(value, 10);
    if (!Number.isFinite(percent)) return 0;
    return Math.max(0, Math.min(100, percent));
}

function updateRangeFill(slider, percent) {
    const normalized = normalizeRangePercent(percent);
    slider.val(normalized);
    slider.attr('aria-valuenow', String(normalized));
    slider[0]?.style?.setProperty('--range-fill', `${normalized}%`);
}

function syncLayerVolumeControls(html, id, percent) {
    const normalized = normalizeRangePercent(percent);
    const targetId = String(id);

    html.find('.amb-layer-volume').filter(function() {
        return String($(this).data('ambienceId')) === targetId;
    }).each(function() {
        updateRangeFill($(this), normalized);
    });

    html.find('.ambience-active-layer').filter(function() {
        return String($(this).data('ambienceId')) === targetId;
    }).find('.amb-layer-volume-value').text(`${normalized}%`);
}

function updateMasterVolumeDisplays(html, jukebox, percent) {
    const normalized = normalizeRangePercent(percent);
    const isMuted = jukebox.isAmbienceMasterMuted?.() || false;

    html.find('.master-volume-value').text(`${normalized}%`);
    html.find('.ambience-master-section').attr('data-tooltip', `Local ambience volume: ${normalized}%`);
    html.find('.stat-master .ambience-stat-main strong').text(`${normalized}%`);
    html.find('.stat-master .ambience-stat-dots b').each(function(index) {
        $(this).toggleClass('active', index < Math.round(normalized / 10));
    });

    const muteButton = html.find('.ambience-master-mute-btn');
    const muteLabel = isMuted ? 'Unmute local ambience' : 'Mute local ambience';
    muteButton
        .attr('aria-label', muteLabel)
        .attr('aria-pressed', isMuted ? 'true' : 'false')
        .attr('data-tooltip', muteLabel);
    muteButton.find('i')
        .toggleClass('fa-volume-mute', isMuted)
        .toggleClass('fa-volume-up', !isMuted);
    html.find('.stat-master > i')
        .toggleClass('fa-volume-mute', isMuted)
        .toggleClass('fa-volume-up', !isMuted);
}

function scrollToAmbienceTarget(html, target) {
    const selectorByTarget = {
        active: '.ambience-active-mix',
        library: '.ambience-library-heading',
        folders: '.ambience-folder-panel, .folder-rail-panel, .folder-section'
    };
    const selector = selectorByTarget[target] || selectorByTarget.active;
    const element = html.find(selector).filter(':visible').first()[0] ||
        html.find('.ambience-library-heading').first()[0] ||
        html.find('.ambience-active-mix').first()[0];

    element?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function showAmbienceContextMenu(app, jukebox, track, x, y, targetElement) {
    closeAmbienceContextMenu();

    const target = $(targetElement);
    target.addClass('context-open');

    const isGM = game.user?.isGM;
    const isActive = jukebox.isAmbienceLayerActive(track.id);
    const atLayerLimit = !isActive && !jukebox.canAddAmbienceLayer();
    const volume = Math.round((jukebox.getAmbienceLayerVolume(track.id) ?? 0.8) * 100);
    const sourceLabel = track.source === 'youtube' ? 'YouTube ambience' : 'Local ambience';
    const folder = track.folderId ? jukebox.getFolders('ambience').find(f => f.id === track.folderId) : null;
    const folderLabel = folder?.name || 'Unfiled';
    const tagsLabel = track.tags?.length
        ? `${track.tags.length} tag${track.tags.length === 1 ? '' : 's'}`
        : 'No tags';
    const issue = jukebox.getAmbienceLayerIssue?.(track.id) || null;
    const artHtml = track.thumbnail
        ? `<img src="${escapeAttribute(track.thumbnail)}" alt="">`
        : '<i class="fas fa-layer-group"></i>';

    const menu = $(`
        <div class="nj-context-menu nj-ambience-context-menu" role="menu" aria-label="${escapeAttribute(track.name || 'Ambience sound')}">
            <div class="nj-context-header ambience-context-header">
                <div class="ambience-context-art">
                    ${artHtml}
                </div>
                <div class="ambience-context-copy">
                    <div class="nj-context-title">${escapeHtml(track.name || 'Ambience sound')}</div>
                    <div class="nj-context-subtitle">${escapeHtml(sourceLabel)} / ${escapeHtml(folderLabel)} / ${escapeHtml(tagsLabel)}</div>
                </div>
                ${issue ? '<span class="ambience-context-state issue-state"><i class="fas fa-triangle-exclamation"></i> Issue</span>' : isActive ? `<span class="ambience-context-state live-state"><i class="fas fa-wave-square"></i> ${volume}%</span>` : ''}
            </div>
            ${buildAmbienceMenuItem({
                action: 'toggle',
                icon: isActive ? 'fas fa-stop' : 'fas fa-play',
                label: isActive ? 'Stop Layer' : 'Start Layer',
                description: atLayerLimit ? `Layer limit reached (${MAX_AMBIENCE_LAYERS})` : isActive ? 'Remove this sound from the live mix' : 'Add this sound to the live mix',
                shortcut: isActive ? 'Live' : '',
                disabled: atLayerLimit
            })}
            ${buildAmbienceMenuItem({
                action: 'volume-50',
                icon: 'fas fa-volume-down',
                label: 'Set Volume 50%',
                description: 'Set this live layer to half volume',
                disabled: !isActive
            })}
            ${buildAmbienceMenuItem({
                action: 'volume-100',
                icon: 'fas fa-volume-up',
                label: 'Set Volume 100%',
                description: 'Set this live layer to full volume',
                disabled: !isActive
            })}
            ${isGM ? '<div class="nj-context-divider"></div>' : ''}
            ${isGM ? buildAmbienceMenuItem({
                action: 'move-folder',
                icon: 'fas fa-folder-open',
                label: 'Move to Folder',
                description: 'Organize this ambience sound'
            }) : ''}
            ${isGM ? buildAmbienceMenuItem({
                action: 'edit',
                icon: 'fas fa-edit',
                label: 'Edit Details',
                description: 'Change name, source, tags, and artwork'
            }) : ''}
            ${isGM ? buildAmbienceMenuItem({
                action: 'duplicate',
                icon: 'fas fa-copy',
                label: 'Duplicate Ambience',
                description: 'Create a copy with the same metadata'
            }) : ''}
            ${buildAmbienceMenuItem({
                action: 'copy-url',
                icon: 'fas fa-link',
                label: 'Copy URL',
                description: 'Copy the source path to clipboard',
                disabled: !track.url
            })}
            ${isGM ? '<div class="nj-context-divider"></div>' : ''}
            ${isGM ? buildAmbienceMenuItem({
                action: 'delete',
                icon: 'fas fa-trash',
                label: 'Delete Ambience',
                description: isActive ? 'Stop and remove from library' : 'Remove from library',
                danger: true
            }) : ''}
        </div>
    `);

    menu.css({ left: 0, top: 0, visibility: 'hidden' });
    $('body').append(menu);
    positionAmbienceContextMenu(menu, x, y);

    menu.on('click', '.nj-context-item', async evt => {
        const button = evt.currentTarget;
        if (button.disabled) return;

        const action = button.dataset.action;
        closeAmbienceContextMenu();
        await handleAmbienceContextAction(app, jukebox, track, action);
    });

    window.setTimeout(() => {
        $(document).on(`mousedown${AMBIENCE_CONTEXT_MENU_NAMESPACE} contextmenu${AMBIENCE_CONTEXT_MENU_NAMESPACE}`, event => {
            if (!menu[0]?.contains(event.target)) {
                closeAmbienceContextMenu();
            }
        });

        $(window).on(`resize${AMBIENCE_CONTEXT_MENU_NAMESPACE} scroll${AMBIENCE_CONTEXT_MENU_NAMESPACE}`, () => {
            closeAmbienceContextMenu();
        });
    }, 0);
}

async function handleAmbienceContextAction(app, jukebox, track, action) {
    const currentTrack = jukebox.ambience.find(a => a.id === track.id);
    if (!currentTrack) {
        ui.notifications.warn(localize('Notifications.AmbienceNotFound'));
        return;
    }

    switch (action) {
        case 'toggle':
            await toggleAmbienceFromContext(app, jukebox, currentTrack);
            break;

        case 'volume-50':
            setAmbienceLayerVolumeFromContext(app, jukebox, currentTrack, 50);
            break;

        case 'volume-100':
            setAmbienceLayerVolumeFromContext(app, jukebox, currentTrack, 100);
            break;

        case 'move-folder':
            Dialogs.showMoveToFolderDialog({
                trackIds: [currentTrack.id],
                library: 'ambience',
                jukebox,
                onSuccess: () => app.render()
            });
            break;

        case 'edit':
            app.showEditAmbienceDialog(currentTrack.id);
            break;

        case 'duplicate':
            await duplicateAmbienceTrack(app, jukebox, currentTrack);
            break;

        case 'copy-url':
            await copyAmbienceUrl(currentTrack);
            break;

        case 'delete':
            confirmAmbienceDeletion(app, jukebox, currentTrack);
            break;
    }
}

async function toggleAmbienceFromContext(app, jukebox, track) {
    const card = findAmbienceElements(app, track.id).first();
    const isActive = jukebox.isAmbienceLayerActive(track.id);

    if (!isActive && !jukebox.canAddAmbienceLayer()) {
        if (card.length) animateLayerLimitShake(card);
        showLayerLimitToast();
        return;
    }

    if (card.length) {
        if (isActive) {
            animateLayerDeactivation(card);
        } else {
            animateLayerActivation(card);
        }
    }

    await toggleAmbienceLayerWithFeedback(jukebox, card, track.id);
}

function setAmbienceLayerVolumeFromContext(app, jukebox, track, percent) {
    if (!jukebox.isAmbienceLayerActive(track.id)) {
        ui.notifications.warn('Start this ambience layer before setting its volume.');
        return;
    }

    const normalized = normalizeRangePercent(percent);
    jukebox.setAmbienceLayerVolume(track.id, normalized / 100);
    syncLayerVolumeControls(app.element || $(document), track.id, normalized);
    ui.notifications.info(`Set "${track.name}" to ${normalized}%.`);
}

async function duplicateAmbienceTrack(app, jukebox, track) {
    const copy = clonePlain(track);
    delete copy._libraryIndex;
    delete copy.displayIndex;
    delete copy.isLayerActive;
    delete copy.layerVolume;
    delete copy.layerIssue;
    delete copy.layerIssueSummary;
    delete copy.folderName;
    delete copy.folderColor;
    delete copy.folderIcon;
    delete copy.sourceLabel;
    delete copy.sourceIcon;
    delete copy.fallbackClass;
    copy.id = generateId();
    copy.name = getCopyName(track.name || 'Ambience sound', jukebox.ambience);

    const duplicate = await jukebox.addAmbience(copy);
    ui.notifications.info(`Duplicated ambience "${duplicate.name}".`);
    app.render();
}

async function copyAmbienceUrl(track) {
    if (!track.url) {
        ui.notifications.warn('This ambience sound has no source URL to copy.');
        return;
    }

    try {
        if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
            await navigator.clipboard.writeText(track.url);
        } else {
            fallbackCopyToClipboard(track.url);
        }
        ui.notifications.info('Ambience URL copied to clipboard.');
    } catch (err) {
        fallbackCopyToClipboard(track.url);
        ui.notifications.info('Ambience URL copied to clipboard.');
    }
}

function confirmAmbienceDeletion(app, jukebox, track) {
    const isActive = jukebox.isAmbienceLayerActive(track.id);
    const sourceLabel = track.source === 'youtube' ? 'YouTube ambience' : 'Local ambience';
    const folder = track.folderId ? jukebox.getFolders('ambience').find(f => f.id === track.folderId) : null;
    const folderLabel = folder?.name || 'Unfiled';
    const volume = Math.round((jukebox.getAmbienceLayerVolume(track.id) ?? 0.8) * 100);
    const artHtml = track.thumbnail
        ? `<img src="${escapeAttribute(track.thumbnail)}" alt="">`
        : '<i class="fas fa-layer-group"></i>';

    const modal = Dialogs.createModuleModal({
        title: localize('Dialog.Confirm.DeleteAmbience'),
        closeLabel: localize('Header.Close'),
        classes: [...AMBIENCE_CONTEXT_DIALOG_CLASSES, 'ambience-delete-confirm'],
        overlayClasses: ['ambience-context-modal-overlay'],
        initialFocus: '.ambience-dialog-cancel',
        content: `
            <div class="ambience-delete-panel">
                <div class="ambience-context-dialog-hero">
                    <div class="ambience-context-dialog-art ambience-delete-art">
                        ${artHtml}
                    </div>
                    <div class="ambience-context-dialog-copy">
                        <div class="ambience-context-dialog-kicker">
                            <i class="fas fa-trash"></i>
                            ${escapeHtml(localize('Dialog.Confirm.DeleteAmbience'))}
                        </div>
                        <h2>${escapeHtml(track.name || 'Ambience sound')}</h2>
                        <div class="ambience-context-dialog-meta">
                            <span>${escapeHtml(sourceLabel)}</span>
                            <span>${escapeHtml(folderLabel)}</span>
                            ${isActive ? `<span>Live at ${volume}%</span>` : '<span>Not live</span>'}
                        </div>
                    </div>
                </div>

                <p class="ambience-delete-warning">${escapeHtml(format('Dialog.Confirm.DeleteAmbienceContent', { name: track.name || localize('Common.ThisAmbience') }))}</p>

                <div class="ambience-premium-actions">
                    <button type="button" class="ambience-premium-btn secondary ambience-dialog-cancel">
                        ${escapeHtml(localize('Common.Cancel'))}
                    </button>
                    <button type="button" class="ambience-premium-btn danger ambience-dialog-delete">
                        <i class="fas fa-trash"></i>
                        ${escapeHtml(localize('Common.Delete'))}
                    </button>
                </div>
            </div>
        `,
        onRender: controller => {
            let isDeleting = false;

            controller.body.on('click', '.ambience-dialog-cancel', () => controller.close());
            controller.body.on('click', '.ambience-dialog-delete', async evt => {
                if (isDeleting) return;
                isDeleting = true;

                const button = evt.currentTarget;
                button.disabled = true;
                button.classList.add('is-loading');

                try {
                    const currentTrack = jukebox.ambience.find(a => a.id === track.id);
                    if (!currentTrack) {
                        ui.notifications.warn(localize('Notifications.AmbienceNotFound'));
                        controller.close();
                        return;
                    }

                    if (jukebox.isAmbienceLayerActive(currentTrack.id)) {
                        jukebox.stopAmbienceLayer(currentTrack.id, true);
                    }

                    await jukebox.deleteAmbience(currentTrack.id);
                    app.render();
                    controller.close();
                } catch (err) {
                    isDeleting = false;
                    button.disabled = false;
                    button.classList.remove('is-loading');
                    ui.notifications.error(format('Notifications.FailedToUpdate', { error: err.message }));
                }
            });
        }
    });

    if (!modal) {
        ui.notifications.error('Unable to open the delete confirmation dialog.');
    }
}

function closeAmbienceContextMenu() {
    $(AMBIENCE_CONTEXT_MENU_SELECTOR).remove();
    $(document).off(AMBIENCE_CONTEXT_MENU_NAMESPACE);
    $(window).off(AMBIENCE_CONTEXT_MENU_NAMESPACE);
    $('.ambience-card.context-open, .ambience-active-layer.context-open').removeClass('context-open');
}

function positionAmbienceContextMenu(menu, x, y) {
    const margin = 12;
    const width = menu.outerWidth();
    const height = menu.outerHeight();
    const left = Math.min(Math.max(margin, x), window.innerWidth - width - margin);
    const top = Math.min(Math.max(margin, y), window.innerHeight - height - margin);

    menu.css({
        left: `${left}px`,
        top: `${top}px`,
        visibility: 'visible'
    });
}

function buildAmbienceMenuItem({ action, icon, label, description = '', shortcut = '', danger = false, disabled = false }) {
    return `
        <button type="button" class="nj-context-item ${danger ? 'danger' : ''}" data-action="${action}" ${disabled ? 'disabled' : ''}>
            <span class="nj-context-item-main">
                <i class="${icon}"></i>
                <span class="nj-context-item-copy">
                    <span class="nj-context-label">${escapeHtml(label)}</span>
                    ${description ? `<span class="nj-context-description">${escapeHtml(description)}</span>` : ''}
                </span>
            </span>
            ${shortcut ? `<span class="nj-context-shortcut">${escapeHtml(shortcut)}</span>` : ''}
        </button>
    `;
}

function findAmbienceElements(app, id) {
    return app.element?.find(`#view-ambience [data-ambience-id="${cssEscape(id)}"]`) || $();
}

function getCopyName(name, tracks) {
    const baseName = `${name} Copy`;
    const existingNames = new Set((tracks || []).map(track => String(track.name || '').toLowerCase()));
    if (!existingNames.has(baseName.toLowerCase())) return baseName;

    let index = 2;
    let candidate = `${baseName} ${index}`;
    while (existingNames.has(candidate.toLowerCase())) {
        index += 1;
        candidate = `${baseName} ${index}`;
    }
    return candidate;
}

function generateId() {
    if (typeof foundry !== 'undefined' && foundry.utils?.randomID) {
        return foundry.utils.randomID();
    }
    return `${Date.now()}${Math.random().toString(36).slice(2, 10)}`;
}

function clonePlain(value) {
    if (typeof foundry !== 'undefined' && foundry.utils?.deepClone) {
        return foundry.utils.deepClone(value);
    }
    return JSON.parse(JSON.stringify(value));
}

function fallbackCopyToClipboard(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.left = '-9999px';
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    textarea.remove();
}

function escapeHtml(value) {
    if (!value) return '';
    const div = document.createElement('div');
    div.textContent = String(value);
    return div.innerHTML;
}

function escapeAttribute(value) {
    return escapeHtml(value).replace(/"/g, '&quot;');
}

function cssEscape(value) {
    if (typeof CSS !== 'undefined' && CSS.escape) {
        return CSS.escape(String(value));
    }
    return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
}

/**
 * Activate ambience layer mixer listeners
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {jQuery} html - The HTML element
 */
export function activateAmbienceListeners(app, html) {
    const jukebox = app.jukebox;

    // Initialize layer limit state
    updateLayerLimitState(html, jukebox);

    html.find('.ambience-master-volume, .amb-layer-volume').each(function() {
        updateRangeFill($(this), $(this).val());
    });

    // Initialize ARIA attributes for playable library cards
    html.find('.ambience-card').each(function() {
        const card = $(this);
        const id = card.data('ambienceId');
        const isActive = card.hasClass('active');
        const label = card.data('tooltip') || card.attr('aria-label') || 'Ambience layer';

        card.attr({
            'role': 'button',
            'tabindex': '0',
            'aria-pressed': isActive ? 'true' : 'false',
            'aria-label': label + (isActive && !String(label).includes('playing') ? ' (playing)' : '')
        });
    });

    html.on('contextmenu', '#view-ambience .ambience-card[data-ambience-id], #view-ambience .ambience-active-layer[data-ambience-id]', e => {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        const id = e.currentTarget.dataset.ambienceId || $(e.currentTarget).data('ambienceId');
        if (!id) return false;

        const track = jukebox.ambience.find(a => a.id === id);
        if (!track) return false;

        showAmbienceContextMenu(app, jukebox, track, e.clientX, e.clientY, e.currentTarget);
        return false;
    });

    html.on('click', '.ambience-hero-tab', e => {
        e.preventDefault();
        scrollToAmbienceTarget(html, $(e.currentTarget).data('ambienceJump'));
    });

    // ========== TOGGLE AMBIENCE LAYER (Card Click) ==========
    html.on('click', '.ambience-card', e => {
        if (Date.now() < Math.max(app._folderDragSuppressClickUntil || 0, app._ambienceSuppressCardClickUntil || 0)) {
            e.preventDefault();
            e.stopPropagation();
            return;
        }

        // Don't trigger if clicking on controls or selection overlay
        if ($(e.target).closest('.amb-card-controls, .amb-volume-control, .amb-edit-btn, .amb-delete-btn, .card-select-overlay, .amb-toggle-btn').length) {
            return;
        }

        // Don't trigger play/stop when in selection mode (selection-listeners handles it)
        if (app.selectionMode) {
            return;
        }

        const card = $(e.currentTarget);
        const id = card.data('ambienceId');
        if (!id) return;

        const isActive = jukebox.isAmbienceLayerActive(id);

        // Check layer limit before activating
        if (!isActive && !jukebox.canAddAmbienceLayer()) {
            animateLayerLimitShake(card);
            showLayerLimitToast();
            return;
        }

        // Animate based on action
        if (isActive) {
            animateLayerDeactivation(card);
        } else {
            animateLayerActivation(card);
        }

        void toggleAmbienceLayerWithFeedback(jukebox, card, id);
    });

    // ========== KEYBOARD NAVIGATION FOR CARDS ==========
    html.on('keydown', '.ambience-card', e => {
        // Don't trigger if inside controls
        if ($(e.target).closest('.amb-card-controls, .amb-volume-control').length) {
            return;
        }

        const card = $(e.currentTarget);
        const id = card.data('ambienceId');

        // Enter or Space to toggle
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();

            const isActive = jukebox.isAmbienceLayerActive(id);

            // Check layer limit before activating
            if (!isActive && !jukebox.canAddAmbienceLayer()) {
                animateLayerLimitShake(card);
                showLayerLimitToast();
                return;
            }

            // Animate based on action
            if (isActive) {
                animateLayerDeactivation(card);
            } else {
                animateLayerActivation(card);
            }

            void toggleAmbienceLayerWithFeedback(jukebox, card, id);
        }

        // Arrow key navigation
        if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
            e.preventDefault();
            const cards = html.find('.ambience-card');
            const currentIndex = cards.index(card);
            let nextIndex;

            // Calculate grid columns (approximate)
            const gridWidth = card.parent().width();
            const cardWidth = card.outerWidth(true);
            const columns = Math.floor(gridWidth / cardWidth) || 1;

            switch (e.key) {
                case 'ArrowRight':
                    nextIndex = (currentIndex + 1) % cards.length;
                    break;
                case 'ArrowLeft':
                    nextIndex = (currentIndex - 1 + cards.length) % cards.length;
                    break;
                case 'ArrowDown':
                    nextIndex = Math.min(currentIndex + columns, cards.length - 1);
                    break;
                case 'ArrowUp':
                    nextIndex = Math.max(currentIndex - columns, 0);
                    break;
            }

            cards.eq(nextIndex).trigger('focus');
        }
    });

    // ========== TOGGLE BUTTON (explicit toggle) ==========
    html.on('click', '.ambience-card .amb-toggle-btn, .ambience-active-layer .amb-toggle-btn', e => {
        e.stopPropagation();
        const card = $(e.currentTarget).closest('.ambience-card, .ambience-active-layer');
        const id = card.data('ambienceId');
        if (!id) return;

        const isActive = jukebox.isAmbienceLayerActive(id);

        // Check layer limit before activating
        if (!isActive && !jukebox.canAddAmbienceLayer()) {
            animateLayerLimitShake(card);
            showLayerLimitToast();
            return;
        }

        // Animate based on action
        if (isActive) {
            animateLayerDeactivation(card);
        } else {
            animateLayerActivation(card);
        }

        void toggleAmbienceLayerWithFeedback(jukebox, card, id);
    });

    // ========== LAYER VOLUME SLIDER ==========
    html.on('input', '.amb-layer-volume', e => {
        e.stopPropagation();
        const slider = $(e.currentTarget);
        const id = slider.data('ambienceId');
        const percent = normalizeRangePercent(slider.val());
        const volume = percent / 100;

        if (id) {
            jukebox.setAmbienceLayerVolume(id, volume);
            syncLayerVolumeControls(html, id, percent);
        }
    });

    // Prevent card toggle when interacting with volume slider
    html.on('click', '.amb-volume-control', e => {
        e.stopPropagation();
    });

    // ========== MASTER VOLUME SLIDER ==========
    // Prevent Foundry from capturing mousedown for window drag
    // Must use native addEventListener to catch before Foundry's capture phase
    html.find('.ambience-master-volume, .amb-layer-volume').each(function() {
        this.addEventListener('mousedown', e => e.stopPropagation(), true);
        this.addEventListener('pointerdown', e => e.stopPropagation(), true);
    });

    html.on('input', '.ambience-master-volume', e => {
        const slider = $(e.currentTarget);
        const percent = normalizeRangePercent(slider.val());
        const volume = percent / 100;
        jukebox.setAmbienceMasterVolume(volume);

        updateRangeFill(slider, percent);
        updateMasterVolumeDisplays(html, jukebox, percent);
    });

    // ========== MASTER MUTE BUTTON ==========
    html.on('click', '.ambience-master-mute-btn', e => {
        e.preventDefault();
        jukebox.toggleAmbienceMasterMute();
        app.render(false);
    });

    // ========== STOP ALL AMBIENCE LAYERS ==========
    html.on('click', '.stop-all-ambience-btn', e => {
        e.preventDefault();
        jukebox.stopAllAmbienceLayers();
        ui.notifications.info(localize('Notifications.AllAmbienceLayersStopped'));
    });

    // ========== TAG FILTER ==========
    html.on('change', '.ambience-tag-filter', e => {
        const tag = String($(e.currentTarget).val() || '').trim().toLowerCase();
        app.ambienceTagFilter = tag || null;
        app.render(false);
    });

    // ========== EDIT AMBIENCE ==========
    html.on('click', '.ambience-card .amb-edit-btn, .ambience-active-layer .amb-edit-btn', e => {
        e.stopPropagation();
        const id = $(e.currentTarget).data('ambienceId');
        if (id) app.showEditAmbienceDialog(id);
    });

    // ========== DELETE AMBIENCE ==========
    html.on('click', '.ambience-card .amb-delete-btn', e => {
        e.preventDefault();
        e.stopPropagation();
        const id = $(e.currentTarget).data('ambienceId');
        debugLog('Delete ambience clicked, id:', id);
        if (!id) return;

        const track = jukebox.ambience.find(a => a.id === id);
        if (track) confirmAmbienceDeletion(app, jukebox, track);
    });

    // NOTE: Add Ambience button click is handled in main-listeners.js

    // ========== PRESET: LOAD (dropdown change) ==========
    html.on('change', '.ambience-preset-select', async e => {
        const presetId = $(e.currentTarget).val();
        if (!presetId) {
            app.selectedPresetId = null;
            app.render(false);
            return;
        }

        // Store selected preset in app state so it persists across re-renders
        app.selectedPresetId = presetId;
        await jukebox.loadAmbiencePreset(presetId);
    });

    // ========== PRESET: SAVE BUTTON ==========
    html.on('click', '.preset-save-btn', e => {
        e.preventDefault();
        if (jukebox.getAmbienceLayerCount() === 0) {
            ui.notifications.warn(localize('Notifications.NoActiveLayersToSave'));
            return;
        }
        app.showSavePresetDialog();
    });

    // ========== PRESET: DELETE BUTTON ==========
    html.on('click', '.preset-delete-btn', async e => {
        e.preventDefault();
        const presetId = app.selectedPresetId;

        if (!presetId) {
            ui.notifications.warn(localize('Notifications.SelectPresetToDelete'));
            return;
        }

        const preset = jukebox.getAmbiencePreset(presetId);
        if (!preset) return;

        Dialog.confirm({
            title: localize('Dialog.Confirm.DeletePreset'),
            content: `<p>${format('Dialog.Confirm.DeletePresetContent', { name: preset.name })}</p>`,
            classes: ['narrator-jukebox-dialog'],
            yes: async () => {
                await jukebox.deleteAmbiencePreset(presetId);
                app.selectedPresetId = null; // Clear selection after delete
                ui.notifications.info(format('Notifications.DeletedPreset', { name: preset.name }));
                app.render();
            }
        });
    });
}
