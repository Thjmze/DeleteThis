/**
 * Player Listeners Module
 * Handles playback controls: play/pause, next/prev, shuffle, loop, volume, mute, progress bar
 *
 * @module ui/listeners/player-listeners
 */

import { formatTime } from '../../utils/time-format.js';
import { localize, format } from '../../utils/i18n.js';
import { syncService } from '../../core/jukebox-state.js';
import { MUSIC_REPEAT_MODES } from '../../core/constants.js';
import { normalizeBooleanFlag } from '../../services/track-data-service.js';
import * as Dialogs from '../app-dialogs.js';

const MUSIC_CONTEXT_MENU_SELECTOR = '.nj-music-context-menu';
const MUSIC_CONTEXT_MENU_NAMESPACE = '.njMusicContextMenu';
const MUSIC_CONTEXT_DIALOG_CLASSES = ['narrator-jukebox-dialog', 'add-track-dialog-window', 'music-theme', 'music-context-dialog'];

function getRepeatPresentation(mode) {
    switch (mode) {
        case MUSIC_REPEAT_MODES.TRACK:
            return {
                active: true,
                className: 'repeat-track',
                badge: '1',
                tooltip: localize('Player.RepeatTrackTooltip')
            };
        case MUSIC_REPEAT_MODES.QUEUE:
            return {
                active: true,
                className: 'repeat-queue',
                badge: 'Q',
                tooltip: localize('Player.RepeatQueueTooltip')
            };
        default:
            return {
                active: false,
                className: 'repeat-off',
                badge: '',
                tooltip: localize('Player.RepeatOffTooltip')
            };
    }
}

function updateRepeatButton(button, mode) {
    const presentation = getRepeatPresentation(mode);
    const btn = $(button);
    const icon = btn.find('i').first();
    let badge = btn.find('.repeat-mode-badge');

    btn.removeClass('active repeat-off repeat-track repeat-queue')
        .addClass(presentation.className)
        .toggleClass('active', presentation.active)
        .attr('data-repeat-mode', mode)
        .attr('data-tooltip', presentation.tooltip)
        .attr('aria-label', presentation.tooltip);

    icon.toggleClass('active', presentation.active);

    if (presentation.badge) {
        if (!badge.length) {
            badge = $('<span class="repeat-mode-badge" aria-hidden="true"></span>');
            btn.append(badge);
        }
        badge.text(presentation.badge);
    } else {
        badge.remove();
    }
}

/**
 * Activate music player control listeners
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {jQuery} html - The HTML element
 */
export function activatePlayerListeners(app, html) {
    const jukebox = app.jukebox;

    // Cache progress elements
    const progressFillEl = html.find('#progress-fill');
    const currentTimeEl = html.find('#current-time');
    const getQueueBoundaryTrack = (edge = 'first') => {
        const playlistIds = jukebox.currentPlaylist?.musicIds || [];
        const musicSourceIds = jukebox.currentMusicSourceContext?.musicIds || [];
        const sourceIds = playlistIds.length ? playlistIds : musicSourceIds.length ? musicSourceIds : (jukebox.music || []).map(track => track.id);
        const id = edge === 'last' ? sourceIds[sourceIds.length - 1] : sourceIds[0];
        return id ? jukebox.music.find(track => track.id === id) : null;
    };
    const getQueueBoundaryPlayOptions = () => {
        const playlistIds = jukebox.currentPlaylist?.musicIds || [];
        const sourceContext = !playlistIds.length ? jukebox.currentMusicSourceContext : null;
        return sourceContext ? { sourceContext } : {};
    };

    // ========== MUSIC PLAYBACK CONTROLS ==========

    // Play/Pause
    html.find('#play-pause-btn').click(async e => {
        try {
            if (!jukebox.channels.music.currentTrack && !jukebox.isPlaying) {
                if ((jukebox.getManualQueueCount?.() || 0) > 0) {
                    jukebox.next(true);
                    app.render(false);
                    return;
                }

                const firstTrack = getQueueBoundaryTrack('first');
                if (!firstTrack) {
                    ui.notifications.warn('Add music to the library before pressing play.');
                    return;
                }

                await jukebox.playMusic(firstTrack.id, 'music', getQueueBoundaryPlayOptions());
            } else {
                jukebox.togglePlay('music');
            }
        } catch (error) {
            return;
        }

        updatePlayButton(e.currentTarget, jukebox.isPlaying);
    });

    // Next (wrap=true: manual click always wraps around at end of library/playlist)
    html.find('#next-btn').click(async () => {
        try {
            if (!jukebox.channels.music.currentTrack && !jukebox.isPlaying) {
                if ((jukebox.getManualQueueCount?.() || 0) > 0) {
                    jukebox.next(true);
                    app.render(false);
                    return;
                }

                const firstTrack = getQueueBoundaryTrack('first');
                if (!firstTrack) {
                    ui.notifications.warn('Add music to the library before skipping.');
                    return;
                }
                await jukebox.playMusic(firstTrack.id, 'music', getQueueBoundaryPlayOptions());
                return;
            }

            jukebox.next(true);
        } catch (error) {}
    });

    // Prev
    html.find('#prev-btn').click(async () => {
        try {
            if (!jukebox.channels.music.currentTrack && !jukebox.isPlaying) {
                const lastTrack = getQueueBoundaryTrack('last');
                if (!lastTrack) {
                    ui.notifications.warn('Add music to the library before skipping.');
                    return;
                }
                await jukebox.playMusic(lastTrack.id, 'music', getQueueBoundaryPlayOptions());
                return;
            }

            jukebox.prev();
        } catch (error) {}
    });

    // Shuffle toggle
    html.find('#shuffle-btn').click(e => {
        jukebox.toggleShuffle();
        $(e.currentTarget).find('i').toggleClass('active', jukebox.shuffle);
        $(e.currentTarget).attr('data-tooltip', jukebox.shuffle ? localize('Player.ShuffleOn') : localize('Player.ShuffleOff'));
    });

    // Repeat mode toggle (music): off -> current track -> queue/source
    html.find('#loop-btn').click(e => {
        const mode = jukebox.cycleMusicRepeatMode ? jukebox.cycleMusicRepeatMode() : (jukebox.toggleMusicLoop(), jukebox.musicRepeatMode);
        updateRepeatButton(e.currentTarget, mode || (jukebox.musicLoop ? MUSIC_REPEAT_MODES.TRACK : MUSIC_REPEAT_MODES.OFF));
    });

    html.find('.favorite-current-btn').click(async e => {
        const currentTrack = jukebox.channels.music.currentTrack;
        if (!currentTrack?.id) {
            ui.notifications.warn('No current track to add to Favorites.');
            return;
        }

        await toggleTrackFavorite(app, jukebox, currentTrack.id);
        app.render(false);
    });

    html.on('click', '.favorite-track-btn', async e => {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        const id = e.currentTarget.dataset.musicId;
        if (!id) return;

        await toggleTrackFavorite(app, jukebox, id);
        app.render(false);
    });

    html.find('.edit-current-track-btn').click(() => {
        const currentTrack = jukebox.channels.music.currentTrack;
        if (!currentTrack?.id) {
            ui.notifications.warn('No current track to edit.');
            return;
        }

        app.showEditMusicDialog(currentTrack.id);
    });

    // ========== MUSIC VOLUME CONTROLS ==========

    const muteBtn = html.find('#mute-btn');
    const volumeSlider = html.find('#volume-slider');
    volumeSlider.css('--volume-level', `${parseFloat(volumeSlider.val()) || 0}%`);

    // Volume slider
    volumeSlider.on('input', e => {
        const vol = parseFloat(e.target.value) / 100;
        e.currentTarget.style.setProperty('--volume-level', `${e.target.value}%`);
        jukebox.setVolume(vol, 'music');
        updateVolumeIcon(muteBtn, vol * 100, jukebox.isMuted);
    });

    // Mute button
    html.find('#mute-btn').on('click', () => {
        jukebox.toggleMute('music');
        const vol = parseFloat(volumeSlider.val());
        volumeSlider.css('--volume-level', jukebox.isMuted ? '0%' : `${vol || 0}%`);
        updateVolumeIcon(muteBtn, vol, jukebox.isMuted);
    });

    // ========== MUSIC PROGRESS BAR ==========
    activateProgressBarListeners(app, html, jukebox, progressFillEl, currentTimeEl);

    // ========== AMBIENCE CONTROLS ==========
    activateAmbienceListeners(app, html, jukebox);

    // ========== TRACK LIST INTERACTIONS ==========
    activateTrackListListeners(app, html, jukebox);
}

/**
 * Activate progress bar interaction listeners
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {jQuery} html - The HTML element
 * @param {NarratorJukebox} jukebox - The jukebox instance
 * @param {jQuery} progressFillEl - Progress fill element
 * @param {jQuery} currentTimeEl - Current time display element
 */
function activateProgressBarListeners(app, html, jukebox, progressFillEl, currentTimeEl) {
    const progressBar = html.find('#progress-bar');

    // Initialize dragging state if not present
    if (app.isDragging === undefined) app.isDragging = false;

    progressBar.on('mousedown', () => {
        app.isDragging = true;
    });

    progressBar.on('input', e => {
        app.isDragging = true;
        const percent = e.target.value;
        progressFillEl.css('width', `${percent}%`);

        // Update time text while dragging
        const duration = jukebox.channels.music.duration;
        if (duration) {
            const currentTime = (percent / 100) * duration;
            currentTimeEl.text(formatTime(currentTime));
        }
    });

    progressBar.on('change', e => {
        const percent = e.target.value;
        jukebox.channels.music.seek(percent);

        // Broadcast seek to players (GM in broadcast mode only)
        if (game.user.isGM && !jukebox.isPreviewMode) {
            syncService.broadcastSeek('music', parseFloat(percent));
        }

        // Small delay to prevent timer from jumping back immediately
        setTimeout(() => {
            app.isDragging = false;
        }, 200);
    });

    progressBar.on('mouseup', () => {
        setTimeout(() => {
            app.isDragging = false;
        }, 200);
    });
}

/**
 * Activate ambience library management listeners
 * Note: Ambience player bar controls removed - now handled by Layer Mixer
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {jQuery} html - The HTML element
 * @param {NarratorJukebox} jukebox - The jukebox instance
 */
function activateAmbienceListeners(app, html, jukebox) {
    // Ambience track management (library buttons, not player bar)
    html.on('click', '.edit-ambience-btn', e => {
        e.stopPropagation();
        const id = e.currentTarget.dataset.ambienceId;
        if (id) app.showEditAmbienceDialog(id);
    });

    html.on('click', '.delete-ambience-btn', e => {
        e.stopPropagation();
        const id = e.currentTarget.dataset.ambienceId;
        if (!id) return;

        Dialog.confirm({
            title: localize('Dialog.Confirm.DeleteAmbience'),
            content: `<p>${localize('Dialog.Confirm.DeleteTrackContent')}</p>`,
            classes: ['narrator-jukebox-dialog'],
            yes: async () => {
                await jukebox.deleteAmbience(id);
                app.render();
            }
        });
    });
}

/**
 * Activate track list interaction listeners (event delegation)
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {jQuery} html - The HTML element
 * @param {NarratorJukebox} jukebox - The jukebox instance
 */
function activateTrackListListeners(app, html, jukebox) {
    // Premium Music Library context menu
    html.on('contextmenu', '#view-library .track-row[data-music-id]', e => {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        const id = e.currentTarget.dataset.musicId;
        if (!id) return false;

        const track = jukebox.music.find(m => m.id === id);
        if (!track) return false;

        showMusicContextMenu(app, jukebox, track, e.clientX, e.clientY);
        return false;
    });

    // Play music button (event delegation for dynamic content)
    html.on('click', '.play-music-btn', e => {
        if ($(e.target).closest('button, input, select, textarea, a, .col-actions, .track-select-col, .track-visibility-btn').length) {
            return;
        }

        const libraryRow = $(e.currentTarget).closest('#view-library .library-track-row[data-music-id]');
        if (libraryRow.length) {
            if (Date.now() < (app._librarySuppressNextTrackClickUntil || 0)) {
                e.preventDefault();
                e.stopImmediatePropagation();
                return;
            }

            if (app.selectionMode || e.ctrlKey || e.metaKey || e.shiftKey) {
                e.preventDefault();
                return;
            }
        }

        const id = e.currentTarget.dataset.musicId;
        if (!id) return;

        const playlistId = e.currentTarget.dataset.playlistId;
        const isQueueRow = e.currentTarget.classList.contains('queue-row') || $(e.currentTarget).closest('.queue-track-list').length > 0;
        const queueEntryId = e.currentTarget.dataset.queueEntryId;
        if (isQueueRow && queueEntryId) {
            app.showPlayerQueue = true;
            jukebox.playManualQueueEntry?.(queueEntryId);
            app.render(false);
            return;
        }

        let playOptions = {};

        if (playlistId) {
            const playlist = jukebox.playlists.find(p => p.id === playlistId);
            if (playlist) {
                jukebox.currentPlaylist = playlist;
                app.selectedPlaylistId = playlistId;
            }
        } else if (libraryRow.length && typeof app._getLibraryPlaybackContext === 'function') {
            const sourceContext = app._getLibraryPlaybackContext(id);
            if (sourceContext) playOptions.sourceContext = sourceContext;
            jukebox.currentPlaylist = null;
        } else {
            jukebox.currentPlaylist = null;
        }
        app.showPlayerQueue = !!isQueueRow;

        const currentTrackId = jukebox.channels.music.currentTrack?.id;
        if (id === currentTrackId) {
            // Toggle play/pause for current track
            jukebox.togglePlay('music');
            app.render(false);
        } else {
            // Play the new track
            jukebox.playMusic(id, 'music', playOptions);
        }
    });

    // Toggle track visibility (hide name/thumbnail from players)
    html.on('click', '.track-visibility-btn', async e => {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        const button = e.currentTarget;
        const id = button.dataset.musicId;
        if (!id) return;
        if (button.dataset.busy === 'true') return;

        const track = jukebox.music.find(m => m.id === id);
        if (!track) return;

        button.dataset.busy = 'true';

        try {
            const updatedTrack = await jukebox.updateMusic(id, { hidden: !normalizeBooleanFlag(track.hidden) });
            if (!updatedTrack) return;

            Hooks.call('narratorJukeboxStateChanged', { scope: 'library' });

            if (game.user.isGM && !jukebox.isPreviewMode && jukebox.channels.music.currentTrack?.id === id) {
                syncService.broadcastState();
            }
        } finally {
            delete button.dataset.busy;
        }
    });

    // Edit track button
    html.on('click', '.edit-track-btn', e => {
        e.stopPropagation();
        const id = e.currentTarget.dataset.musicId;
        if (id) app.showEditMusicDialog(id);
    });

    // Delete track button
    html.on('click', '.delete-track-btn', e => {
        e.stopPropagation();
        const id = e.currentTarget.dataset.musicId;
        if (!id) return;

        const track = jukebox.music.find(m => m.id === id);
        if (track) confirmMusicTrackDeletion(app, jukebox, track);
    });

    // Add to playlist button
    html.on('click', '.add-to-playlist-btn', e => {
        e.stopPropagation();
        const id = e.currentTarget.dataset.musicId;
        if (id) app.showAddToPlaylistDialog(id);
    });

    html.on('click', '.queue-add-next-btn, .queue-add-end-btn', e => {
        e.stopPropagation();
        const button = e.currentTarget;
        const id = button.dataset.musicId;
        if (!id) return;

        let options = {
            sourceType: button.dataset.sourceType,
            sourceName: button.dataset.sourceName,
            sourceId: button.dataset.sourceId
        };
        const libraryContext = $(button).closest('#view-library').length && typeof app._getLibraryPlaybackContext === 'function'
            ? app._getLibraryPlaybackContext(id)
            : null;
        if (libraryContext) options = libraryContext;

        const entry = button.classList.contains('queue-add-next-btn')
            ? jukebox.addNextToManualQueue?.(id, options)
            : jukebox.addToManualQueue?.(id, options);

        if (entry) {
            app.showPlayerQueue = true;
            ui.notifications.info(button.classList.contains('queue-add-next-btn') ? 'Added as next track.' : 'Added to queue.');
            app.render(false);
        }
    });

    html.on('click', '.queue-play-now-btn', async e => {
        e.stopPropagation();
        const id = e.currentTarget.dataset.musicId;
        if (!id) return;

        jukebox.currentPlaylist = null;
        app.showPlayerQueue = true;
        await jukebox.playMusic(id);
        app.render(false);
    });

    // Remove from playlist button
    html.on('click', '.remove-from-playlist-btn', async e => {
        e.stopPropagation();
        const musicId = e.currentTarget.dataset.musicId;
        const playlistId = e.currentTarget.dataset.playlistId;
        if (musicId && playlistId) {
            await jukebox.removeFromPlaylist(playlistId, musicId);
            app.render(false);
        }
    });
}

function showMusicContextMenu(app, jukebox, track, x, y) {
    closeMusicContextMenu();

    app.element?.find('.library-track-row.context-open').removeClass('context-open');
    app.element?.find(`#view-library .track-row[data-music-id="${cssEscape(track.id)}"]`).addClass('context-open');

    const isGM = game.user?.isGM;
    const isCurrentTrack = jukebox.channels.music.currentTrack?.id === track.id;
    const isPlaying = isCurrentTrack && jukebox.isPlaying;
    const sourceLabel = track.source === 'youtube' ? 'YouTube' : 'Local file';
    const playlistCount = (jukebox.playlists || []).filter(playlist => (playlist.musicIds || []).includes(track.id)).length;
    const playlistLabel = playlistCount === 1 ? '1 playlist' : `${playlistCount} playlists`;
    const folder = track.folderId ? jukebox.getFolders('music').find(f => f.id === track.folderId) : null;
    const folderLabel = folder?.name || 'Unfiled';
    const artHtml = track.thumbnail
        ? `<img src="${escapeAttribute(track.thumbnail)}" alt="">`
        : '<i class="fas fa-music"></i>';

    const menu = $(`
        <div class="nj-context-menu nj-music-context-menu" role="menu" aria-label="${escapeHtml(track.name)}">
            <div class="nj-context-header music-context-header">
                <div class="music-context-art">
                    ${artHtml}
                </div>
                <div class="music-context-copy">
                    <div class="nj-context-title">${escapeHtml(track.name || 'Music Track')}</div>
                    <div class="nj-context-subtitle">${escapeHtml(sourceLabel)} / ${escapeHtml(folderLabel)} / ${escapeHtml(playlistLabel)}</div>
                </div>
                ${normalizeBooleanFlag(track.hidden) ? '<span class="music-context-state hidden-state"><i class="fas fa-eye-slash"></i> Hidden</span>' : ''}
            </div>
            ${buildMusicMenuItem({
                action: 'play',
                icon: isPlaying ? 'fas fa-pause' : 'fas fa-play',
                label: isPlaying ? 'Pause Track' : isCurrentTrack ? 'Resume Track' : 'Play Track',
                description: isPlaying ? 'Pause the current music track' : 'Start playback from this track',
                shortcut: isCurrentTrack ? 'Current' : ''
            })}
            ${isGM ? buildMusicMenuItem({
                action: 'add-next',
                icon: 'fas fa-level-up-alt',
                label: 'Add Next',
                description: 'Put this track at the front of the Session Queue'
            }) : ''}
            ${isGM ? buildMusicMenuItem({
                action: 'add-queue',
                icon: 'fas fa-list-ol',
                label: 'Add to Queue',
                description: 'Append this track to the Session Queue'
            }) : ''}
            ${isGM ? buildMusicMenuItem({
                action: 'add-playlist',
                icon: 'fas fa-plus-square',
                label: 'Add to Playlist',
                description: 'Choose a playlist for this track'
            }) : ''}
            ${isGM ? buildMusicMenuItem({
                action: 'move-folder',
                icon: 'fas fa-folder-open',
                label: 'Move to Folder',
                description: 'Organize this track in the Music Library'
            }) : ''}
            ${isGM ? '<div class="nj-context-divider"></div>' : ''}
            ${isGM ? buildMusicMenuItem({
                action: 'edit',
                icon: 'fas fa-edit',
                label: 'Edit Details',
                description: 'Change title, source, tags, and artwork'
            }) : ''}
            ${isGM ? buildMusicMenuItem({
                action: 'duplicate',
                icon: 'fas fa-copy',
                label: 'Duplicate Track',
                description: 'Create a copy with the same metadata'
            }) : ''}
            ${isGM ? buildMusicMenuItem({
                action: 'toggle-hidden',
                icon: normalizeBooleanFlag(track.hidden) ? 'fas fa-eye' : 'fas fa-eye-slash',
                label: normalizeBooleanFlag(track.hidden) ? 'Show to Players' : 'Hide from Players',
                description: normalizeBooleanFlag(track.hidden) ? 'Reveal name and artwork to players' : 'Hide name and artwork from players'
            }) : ''}
            ${buildMusicMenuItem({
                action: 'copy-url',
                icon: 'fas fa-link',
                label: 'Copy URL',
                description: 'Copy the source path to clipboard',
                disabled: !track.url
            })}
            ${isGM ? '<div class="nj-context-divider"></div>' : ''}
            ${isGM ? buildMusicMenuItem({
                action: 'delete',
                icon: 'fas fa-trash',
                label: 'Delete Track',
                description: 'Remove from library and playlists',
                danger: true
            }) : ''}
        </div>
    `);

    menu.css({ left: 0, top: 0, visibility: 'hidden' });
    $('body').append(menu);
    positionMusicContextMenu(menu, x, y);

    menu.on('click', '.nj-context-item', async evt => {
        const button = evt.currentTarget;
        if (button.disabled) return;

        const action = button.dataset.action;
        closeMusicContextMenu();
        await handleMusicContextAction(app, jukebox, track, action);
    });

    window.setTimeout(() => {
        $(document).on(`mousedown${MUSIC_CONTEXT_MENU_NAMESPACE} contextmenu${MUSIC_CONTEXT_MENU_NAMESPACE}`, event => {
            if (!menu[0]?.contains(event.target)) {
                closeMusicContextMenu();
            }
        });

        $(window).on(`resize${MUSIC_CONTEXT_MENU_NAMESPACE} scroll${MUSIC_CONTEXT_MENU_NAMESPACE}`, () => {
            closeMusicContextMenu();
        });
    }, 0);
}

async function handleMusicContextAction(app, jukebox, track, action) {
    const currentTrack = jukebox.music.find(m => m.id === track.id);
    if (!currentTrack) {
        ui.notifications.warn('This track is no longer available.');
        return;
    }

    switch (action) {
        case 'play':
            app.showPlayerQueue = false;
            jukebox.currentPlaylist = null;
            if (jukebox.channels.music.currentTrack?.id === currentTrack.id) {
                jukebox.togglePlay('music');
                app.render(false);
            } else {
                await jukebox.playMusic(currentTrack.id);
            }
            break;

        case 'add-playlist':
            app.showAddToPlaylistDialog(currentTrack.id);
            break;

        case 'add-next': {
            const entry = jukebox.addNextToManualQueue?.(currentTrack.id, {
                sourceType: 'library',
                sourceName: 'Music Library'
            });
            if (entry) {
                app.showPlayerQueue = true;
                ui.notifications.info('Added as next track.');
                app.render(false);
            }
            break;
        }

        case 'add-queue': {
            const entry = jukebox.addToManualQueue?.(currentTrack.id, {
                sourceType: 'library',
                sourceName: 'Music Library'
            });
            if (entry) {
                app.showPlayerQueue = true;
                ui.notifications.info('Added to queue.');
                app.render(false);
            }
            break;
        }

        case 'move-folder':
            Dialogs.showMoveToFolderDialog({
                trackIds: [currentTrack.id],
                library: 'music',
                jukebox,
                onSuccess: () => app.render()
            });
            break;

        case 'edit':
            app.showEditMusicDialog(currentTrack.id);
            break;

        case 'duplicate':
            await duplicateMusicTrack(app, jukebox, currentTrack);
            break;

        case 'toggle-hidden':
            await toggleMusicTrackHidden(app, jukebox, currentTrack);
            break;

        case 'copy-url':
            await copyMusicTrackUrl(currentTrack);
            break;

        case 'delete':
            confirmMusicTrackDeletion(app, jukebox, currentTrack);
            break;
    }
}

async function duplicateMusicTrack(app, jukebox, track) {
    const copy = clonePlain(track);
    delete copy._libraryIndex;
    delete copy.displayIndex;
    delete copy.playlists;
    delete copy.folderName;
    delete copy.folderColor;
    delete copy.folderIcon;
    delete copy.sourceLabel;
    delete copy.sourceIcon;
    delete copy.fallbackClass;
    copy.id = generateId();
    copy.name = getCopyName(track.name || 'Music Track', jukebox.music);

    const duplicate = await jukebox.addMusic(copy);
    ui.notifications.info(`Duplicated track "${duplicate.name}".`);
    app.render();
}

async function toggleMusicTrackHidden(app, jukebox, track) {
    const updatedTrack = await jukebox.updateMusic(track.id, { hidden: !normalizeBooleanFlag(track.hidden) });
    if (!updatedTrack) {
        ui.notifications.warn('This track is no longer available.');
        return;
    }

    Hooks.call('narratorJukeboxStateChanged', { scope: 'library' });

    if (game.user?.isGM && !jukebox.isPreviewMode && jukebox.channels.music.currentTrack?.id === track.id) {
        syncService.broadcastState();
    }
}

async function copyMusicTrackUrl(track) {
    if (!track.url) {
        ui.notifications.warn('This track has no source URL to copy.');
        return;
    }

    try {
        if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
            await navigator.clipboard.writeText(track.url);
        } else {
            fallbackCopyToClipboard(track.url);
        }
        ui.notifications.info('Track URL copied to clipboard.');
    } catch (err) {
        fallbackCopyToClipboard(track.url);
        ui.notifications.info('Track URL copied to clipboard.');
    }
}

async function toggleTrackFavorite(app, jukebox, musicId) {
    const storedTrack = jukebox.music.find(track => track.id === musicId);
    if (!storedTrack) {
        ui.notifications.warn('Track is not in the music library.');
        return false;
    }

    const tags = new Set(Array.isArray(storedTrack.tags) ? storedTrack.tags : []);
    const favoriteTag = [...tags].find(tag => String(tag || '').trim().toLowerCase() === 'favorite');
    const isFavorite = !!favoriteTag;

    if (isFavorite) {
        tags.delete(favoriteTag);
    } else {
        tags.add('favorite');
    }

    const requestedTags = [...tags];
    const updatedTrack = await jukebox.updateMusic(storedTrack.id, { tags: requestedTags });
    const updatedTags = Array.isArray(updatedTrack?.tags) ? updatedTrack.tags : requestedTags;

    if (jukebox.channels.music.currentTrack?.id === storedTrack.id) {
        jukebox.channels.music.currentTrack.tags = updatedTags;
    }

    if (jukebox.currentPlaylist?.systemType === 'favorites') {
        jukebox.currentPlaylist = jukebox.playlists.find(playlist => playlist.systemType === 'favorites') || null;
    }

    Hooks.call('narratorJukeboxStateChanged', { scope: 'library' });
    ui.notifications.info(isFavorite ? 'Removed from Favorites.' : 'Added to Favorites.');
    return !isFavorite;
}

function confirmMusicTrackDeletion(app, jukebox, track) {
    const sourceLabel = track.source === 'youtube' ? 'YouTube' : 'Local file';
    const folder = track.folderId ? jukebox.getFolders('music').find(f => f.id === track.folderId) : null;
    const folderLabel = folder?.name || 'Unfiled';
    const playlistCount = (jukebox.playlists || []).filter(playlist => (playlist.musicIds || []).includes(track.id)).length;
    const playlistLabel = playlistCount === 1 ? '1 playlist' : `${playlistCount} playlists`;
    const artHtml = track.thumbnail
        ? `<img src="${escapeAttribute(track.thumbnail)}" alt="">`
        : '<i class="fas fa-music"></i>';

    const modal = Dialogs.createModuleModal({
        title: localize('Dialog.Confirm.DeleteTrack'),
        closeLabel: localize('Header.Close'),
        classes: [...MUSIC_CONTEXT_DIALOG_CLASSES, 'music-delete-confirm'],
        overlayClasses: ['music-context-modal-overlay'],
        initialFocus: '.music-dialog-cancel',
        content: `
            <div class="music-delete-panel">
                <div class="music-context-dialog-hero">
                    <div class="music-context-dialog-art music-delete-art">
                        ${artHtml}
                    </div>
                    <div class="music-context-dialog-copy">
                        <div class="music-context-dialog-kicker">
                            <i class="fas fa-trash"></i>
                            ${escapeHtml(localize('Dialog.Confirm.DeleteTrack'))}
                        </div>
                        <h2>${escapeHtml(track.name || 'Music Track')}</h2>
                        <div class="music-context-dialog-meta">
                            <span>${escapeHtml(sourceLabel)}</span>
                            <span>${escapeHtml(folderLabel)}</span>
                            <span>${escapeHtml(playlistLabel)}</span>
                        </div>
                    </div>
                </div>

                <p class="music-delete-warning">${escapeHtml(format('Dialog.Confirm.DeleteTrackContent', { name: track.name }))}</p>

                <div class="music-premium-actions">
                    <button type="button" class="music-premium-btn secondary music-dialog-cancel">
                        ${escapeHtml(localize('Common.Cancel'))}
                    </button>
                    <button type="button" class="music-premium-btn danger music-dialog-delete">
                        <i class="fas fa-trash"></i>
                        ${escapeHtml(localize('Common.Delete'))}
                    </button>
                </div>
            </div>
        `,
        onRender: controller => {
            let isDeleting = false;

            controller.body.on('click', '.music-dialog-cancel', () => controller.close());
            controller.body.on('click', '.music-dialog-delete', async evt => {
                if (isDeleting) return;
                isDeleting = true;

                const button = evt.currentTarget;
                button.disabled = true;
                button.classList.add('is-loading');

                try {
                    const currentTrack = jukebox.music.find(m => m.id === track.id);
                    if (!currentTrack) {
                        ui.notifications.warn('This track is no longer available.');
                        controller.close();
                        return;
                    }

                    if (jukebox.channels?.music?.currentTrack?.id === currentTrack.id) {
                        jukebox.stop('music');
                    }

                    await jukebox.deleteMusic(currentTrack.id);
                    app.render();
                    controller.close();
                } catch (err) {
                    isDeleting = false;
                    button.disabled = false;
                    button.classList.remove('is-loading');
                    ui.notifications.error(format('Notifications.FailedToUpdate', { error: err.message }));
                }
            });
        }
    });

    if (!modal) {
        ui.notifications.error('Unable to open the delete confirmation dialog.');
    }
}

function closeMusicContextMenu() {
    $(MUSIC_CONTEXT_MENU_SELECTOR).remove();
    $(document).off(MUSIC_CONTEXT_MENU_NAMESPACE);
    $(window).off(MUSIC_CONTEXT_MENU_NAMESPACE);
    $('.library-track-row.context-open').removeClass('context-open');
}

function positionMusicContextMenu(menu, x, y) {
    const margin = 12;
    const width = menu.outerWidth();
    const height = menu.outerHeight();
    const left = Math.min(Math.max(margin, x), window.innerWidth - width - margin);
    const top = Math.min(Math.max(margin, y), window.innerHeight - height - margin);

    menu.css({
        left: `${left}px`,
        top: `${top}px`,
        visibility: 'visible'
    });
}

function buildMusicMenuItem({ action, icon, label, description = '', shortcut = '', danger = false, disabled = false }) {
    return `
        <button type="button" class="nj-context-item ${danger ? 'danger' : ''}" data-action="${action}" ${disabled ? 'disabled' : ''}>
            <span class="nj-context-item-main">
                <i class="${icon}"></i>
                <span class="nj-context-item-copy">
                    <span class="nj-context-label">${escapeHtml(label)}</span>
                    ${description ? `<span class="nj-context-description">${escapeHtml(description)}</span>` : ''}
                </span>
            </span>
            ${shortcut ? `<span class="nj-context-shortcut">${escapeHtml(shortcut)}</span>` : ''}
        </button>
    `;
}

function getCopyName(name, tracks) {
    const baseName = `${name} Copy`;
    const existingNames = new Set((tracks || []).map(track => String(track.name || '').toLowerCase()));
    if (!existingNames.has(baseName.toLowerCase())) return baseName;

    let index = 2;
    while (existingNames.has(`${baseName} ${index}`.toLowerCase())) {
        index += 1;
    }
    return `${baseName} ${index}`;
}

function clonePlain(value) {
    if (typeof foundry !== 'undefined' && foundry.utils?.deepClone) {
        return foundry.utils.deepClone(value);
    }
    return JSON.parse(JSON.stringify(value));
}

function generateId() {
    if (typeof foundry !== 'undefined' && foundry.utils?.randomID) {
        return foundry.utils.randomID();
    }
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
        return crypto.randomUUID().replace(/-/g, '').slice(0, 16);
    }
    return `${Date.now()}${Math.random().toString(36).slice(2, 10)}`;
}

function fallbackCopyToClipboard(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.left = '-9999px';
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    textarea.remove();
}

function escapeHtml(value) {
    if (!value) return '';
    const div = document.createElement('div');
    div.textContent = String(value);
    return div.innerHTML;
}

function escapeAttribute(value) {
    return escapeHtml(value).replace(/"/g, '&quot;');
}

function cssEscape(value) {
    if (typeof CSS !== 'undefined' && CSS.escape) {
        return CSS.escape(String(value));
    }
    return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
}

/**
 * Update volume icon based on volume level and mute state
 * @param {jQuery} btn - The mute button element
 * @param {number} volume - Volume level (0-100)
 * @param {boolean} isMuted - Whether currently muted
 */
function updateVolumeIcon(btn, volume, isMuted) {
    const icon = btn.find('i');
    // Remove all volume classes
    icon.removeClass('fa-volume-mute fa-volume-off fa-volume-down fa-volume-up');

    if (isMuted || volume === 0) {
        icon.addClass('fa-volume-mute');
        btn.attr('data-tooltip', localize('Player.Unmute'));
    } else if (volume > 50) {
        icon.addClass('fa-volume-up');
        btn.attr('data-tooltip', localize('Player.Mute'));
    } else {
        icon.addClass('fa-volume-down');
        btn.attr('data-tooltip', localize('Player.Mute'));
    }
}

/**
 * Update play button icon based on playing state
 * @param {HTMLElement} btn - The button element
 * @param {boolean} isPlaying - Whether currently playing
 */
function updatePlayButton(btn, isPlaying) {
    const icon = $(btn).find('i');
    if (isPlaying) {
        icon.removeClass('fa-play fa-play-circle').addClass('fa-pause');
        $(btn).attr('data-tooltip', localize('Player.Pause'));
    } else {
        icon.removeClass('fa-pause fa-pause-circle').addClass('fa-play');
        $(btn).attr('data-tooltip', localize('Player.Play'));
    }
}

export { updatePlayButton, updateVolumeIcon };
