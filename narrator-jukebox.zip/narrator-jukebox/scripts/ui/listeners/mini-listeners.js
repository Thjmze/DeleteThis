/**
 * Mini Mode Listeners Module
 * Handles mini player interactions: tabs, search, track rows, player controls, drag
 *
 * @module ui/listeners/mini-listeners
 */

import { syncService } from '../../core/jukebox-state.js';
import { debounce } from '../../utils/debounce.js';
import { debugLog } from '../../utils/debug.js';
import { formatTime } from '../../utils/time-format.js';

/**
 * Activate mini mode listeners
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {jQuery} html - The HTML element
 */
export function activateMiniListeners(app, html) {
    const jukebox = app.jukebox;

    activateMiniTabs(app, html);
    activateMiniHeaderControls(app, html, jukebox);
    initMiniDrag(app, html);
    activateMiniSearchListeners(app, html);
    activateMiniFolderFilters(app, html);
    activateMiniTrackListeners(app, html, jukebox);
    activateMiniPlayerControls(app, html, jukebox);

    app._startProgressTimer();
    app._loadTrackDurations(html);
}

function activateMiniTabs(app, html) {
    html.find('.mini-tab').click(e => {
        const tab = e.currentTarget.dataset.tab;
        app._miniActiveTab = tab;

        html.find('.mini-tab').removeClass('active');
        $(e.currentTarget).addClass('active');

        html.find('.mini-tab-panel').addClass('hidden');
        html.find(`[data-panel="${tab}"]`).removeClass('hidden');

        html.find('.mini-player-section').addClass('hidden');
        html.find(`.${tab}-player`).removeClass('hidden');
    });

    html.find('.mini-subtab').click(e => {
        const subtab = e.currentTarget.dataset.subtab;
        if ($(e.currentTarget).hasClass('disabled')) return;

        app._miniMusicView = subtab;

        html.find('.mini-subtab').removeClass('active');
        $(e.currentTarget).addClass('active');

        html.find('.mini-music-view').addClass('hidden');
        html.find(`[data-view="${subtab}"]`).removeClass('hidden');
    });
}

function activateMiniHeaderControls(app, html, jukebox) {
    html.find('.mini-expand-btn').click(() => app._exitMiniMode());
    html.find('.mini-collapse-btn').click(() => app._enterMicroMode());

    html.find('#mini-broadcast-toggle, .mini-broadcast-action').on('click', e => {
        e.stopPropagation();
        e.preventDefault();

        jukebox.isPreviewMode = !jukebox.isPreviewMode;

        debugLog('Broadcast mode toggled:', {
            isPreviewMode: jukebox.isPreviewMode,
            soundboardBroadcastMode: jukebox.soundboardBroadcastMode
        });

        app.render(false);
    });

    html.find('.mini-filter-btn').on('click', e => {
        e.stopPropagation();
        const activeTab = app._miniActiveTab;

        if (activeTab === 'ambience') {
            app.view = 'ambience';
        } else if (activeTab === 'soundboard') {
            app.view = 'soundboard';
        } else if (app._miniMusicView === 'queue') {
            app.view = 'playlists';
            app.showPlayerQueue = true;
        } else {
            app.view = 'library';
            app.showPlayerQueue = false;
        }

        app._exitMiniMode();
    });
}

/**
 * Initialize mini mode drag functionality
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {jQuery} html - The HTML element
 */
function initMiniDrag(app, html) {
    const header = html.find('.mini-header');
    const windowEl = app.element[0];

    let isDragging = false;
    let startX, startY, startLeft, startTop;

    header.on('mousedown', e => {
        const $target = $(e.target);
        if ($target.closest('button, input, .mini-tab, .mini-broadcast-toggle, .mini-control-btn, .mini-tabs, .mini-header-controls, .session-health-bar').length) {
            return;
        }

        isDragging = true;
        startX = e.clientX;
        startY = e.clientY;
        startLeft = app.position.left;
        startTop = app.position.top;

        windowEl.style.cursor = 'grabbing';
        e.preventDefault();
    });

    $(document).on('mousemove.miniDrag', e => {
        if (!isDragging) return;

        const dx = e.clientX - startX;
        const dy = e.clientY - startY;

        app.setPosition({
            left: startLeft + dx,
            top: startTop + dy
        });
    });

    $(document).on('mouseup.miniDrag', () => {
        if (isDragging) {
            isDragging = false;
            windowEl.style.cursor = '';
        }
    });
}

/**
 * Activate mini mode search listeners
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {jQuery} html - The HTML element
 */
function activateMiniSearchListeners(app, html) {
    const searchInput = html.find('.mini-search-input');
    const searchClear = html.find('.mini-search-clear');

    const debouncedSearch = debounce(() => {
        app._miniSearchQuery = searchInput.val();

        if (app._miniSearchQuery) {
            searchClear.removeClass('hidden');
        } else {
            searchClear.addClass('hidden');
        }

        app.render(false);
    }, 200);

    searchInput.on('input', debouncedSearch);

    searchInput.on('keydown', e => {
        if (e.key === 'Escape') {
            app._miniSearchQuery = '';
            searchInput.val('');
            searchClear.addClass('hidden');
            app.render(false);
        }
    });

    searchClear.click(() => {
        app._miniSearchQuery = '';
        searchInput.val('');
        searchClear.addClass('hidden');
        app.render(false);
    });
}

function activateMiniFolderFilters(app, html) {
    html.on('click', '.mini-folder-chip', e => {
        e.preventDefault();
        e.stopPropagation();

        const library = e.currentTarget.dataset.miniFolderLibrary;
        const folderId = e.currentTarget.dataset.miniFolderFilter || 'all';

        switch (library) {
            case 'music':
                app.libraryFolderFilter = folderId;
                break;
            case 'ambience':
                app.ambienceFolderFilter = folderId;
                break;
            case 'soundboard':
                app.soundboardFolderFilter = folderId;
                break;
            default:
                return;
        }

        app.render(false);
    });
}

/**
 * Activate mini mode track interaction listeners
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {jQuery} html - The HTML element
 * @param {NarratorJukebox} jukebox - The jukebox instance
 */
function activateMiniTrackListeners(app, html, jukebox) {
    html.on('click', '.mini-track-row[data-music-id]', async e => {
        if ($(e.target).closest('button, input, .mini-row-action').length) return;

        const id = e.currentTarget.dataset.musicId;
        if (!id) return;

        const isQueueRow = e.currentTarget.classList.contains('queue-row') || $(e.currentTarget).closest('.queue-list').length > 0;
        const queueEntryId = e.currentTarget.dataset.queueEntryId;
        if (isQueueRow && queueEntryId) {
            jukebox.playManualQueueEntry?.(queueEntryId);
            app.render(false);
            return;
        }

        if (!isQueueRow) {
            jukebox.currentPlaylist = null;
        }

        const currentId = jukebox.channels.music.currentTrack?.id;
        if (id === currentId) {
            jukebox.togglePlay('music');
        } else {
            await jukebox.playMusic(id);
        }
        app.render(false);
    });

    html.on('click', '.mini-row-favorite', async e => {
        e.stopPropagation();
        const id = e.currentTarget.dataset.musicId;
        if (id) await toggleMiniFavorite(app, jukebox, id);
    });

    html.on('click', '.mini-row-add-playlist', e => {
        e.stopPropagation();
        const id = e.currentTarget.dataset.musicId;
        if (id) app.showAddToPlaylistDialog(id);
    });

    html.on('click', '.mini-row-edit', e => {
        e.stopPropagation();
        const id = e.currentTarget.dataset.musicId;
        if (id) app.showEditMusicDialog(id);
    });

    html.on('click', '.mini-track-row[data-ambience-id]', e => {
        if ($(e.target).closest('.mini-layer-volume, button, input').length) return;

        const id = e.currentTarget.dataset.ambienceId;
        if (!id) return;

        jukebox.toggleAmbienceLayer(id);
        app.render(false);
    });

    html.on('input', '.mini-layer-volume', e => {
        e.stopPropagation();
        const id = e.currentTarget.dataset.layerId;
        const value = parseFloat(e.target.value) || 0;
        const vol = value / 100;
        e.currentTarget.style.setProperty('--range-fill', `${value}%`);
        $(e.currentTarget).siblings('.mini-layer-value').text(`${Math.round(value)}%`);
        jukebox.setAmbienceLayerVolume(id, vol);
    });

    html.on('keydown', '.mini-sound-card', e => {
        if (e.key !== 'Enter' && e.key !== ' ') return;
        e.preventDefault();
        e.currentTarget.click();
    });

    html.on('click', '.mini-sound-card', async e => {
        const id = e.currentTarget.dataset.soundId;
        if (!id) return;

        const card = $(e.currentTarget);
        if (card.hasClass('starting')) return;

        try {
            if (jukebox.isSoundboardSoundPlaying(id)) {
                card.removeClass('playing starting').attr('aria-pressed', 'false');
                jukebox.stopSoundboardSound(id);
            } else {
                const sound = jukebox.soundboard.find(s => s.id === id);
                const isBroadcast = jukebox.soundboardBroadcastMode;
                card.addClass('starting').attr('aria-busy', 'true');
                await jukebox.playSoundboardSound(id, { loop: !!sound?.loop, preview: !isBroadcast });
            }
        } finally {
            card.removeAttr('aria-busy').removeClass('starting');
            app.render(false);
        }
    });
}

/**
 * Activate mini mode player control listeners
 * @param {NarratorsJukeboxApp} app - The application instance
 * @param {jQuery} html - The HTML element
 * @param {NarratorJukebox} jukebox - The jukebox instance
 */
function activateMiniPlayerControls(app, html, jukebox) {
    const getQueueBoundaryTrack = (edge = 'first') => {
        const playlistIds = jukebox.currentPlaylist?.musicIds || [];
        const sourceIds = playlistIds.length ? playlistIds : (jukebox.music || []).map(track => track.id);
        const id = edge === 'last' ? sourceIds[sourceIds.length - 1] : sourceIds[0];
        return id ? jukebox.music.find(track => track.id === id) : null;
    };

    html.find('#mini-play-pause').click(async () => {
        try {
            if (!jukebox.channels.music.currentTrack && !jukebox.isPlaying) {
                if ((jukebox.getManualQueueCount?.() || 0) > 0) {
                    jukebox.next(true);
                    app.render(false);
                    return;
                }

                const firstTrack = getQueueBoundaryTrack('first');
                if (!firstTrack) {
                    ui.notifications.warn('Add music to the library before pressing play.');
                    return;
                }

                await jukebox.playMusic(firstTrack.id, 'music');
            } else {
                jukebox.togglePlay('music');
            }
        } catch (error) {
            return;
        }

        app.render(false);
    });

    html.find('#mini-prev').click(async () => {
        try {
            if (!jukebox.channels.music.currentTrack && !jukebox.isPlaying) {
                const lastTrack = getQueueBoundaryTrack('last');
                if (!lastTrack) {
                    ui.notifications.warn('Add music to the library before skipping.');
                    return;
                }
                await jukebox.playMusic(lastTrack.id, 'music');
                return;
            }

            jukebox.prev();
        } catch (error) {}
    });

    html.find('#mini-next').click(async () => {
        try {
            if (!jukebox.channels.music.currentTrack && !jukebox.isPlaying) {
                if ((jukebox.getManualQueueCount?.() || 0) > 0) {
                    jukebox.next(true);
                    app.render(false);
                    return;
                }

                const firstTrack = getQueueBoundaryTrack('first');
                if (!firstTrack) {
                    ui.notifications.warn('Add music to the library before skipping.');
                    return;
                }
                await jukebox.playMusic(firstTrack.id, 'music');
                return;
            }

            jukebox.next(true);
        } catch (error) {}
    });

    html.find('#mini-mute').click(() => {
        jukebox.toggleMute('music');
        app.render(false);
    });

    html.find('#mini-volume-slider').on('input', e => {
        const value = parseFloat(e.target.value) || 0;
        const vol = value / 100;
        e.currentTarget.style.setProperty('--volume-level', `${value}%`);
        jukebox.setVolume(vol, 'music');
    });

    activateMiniProgressBarListeners(app, html, jukebox);

    html.find('.mini-current-favorite-btn').click(async e => {
        e.stopPropagation();
        const id = jukebox.channels.music.currentTrack?.id;
        if (!id) {
            ui.notifications.warn('No current track to favorite.');
            return;
        }

        await toggleMiniFavorite(app, jukebox, id);
    });

    html.find('.mini-current-add-playlist-btn').click(e => {
        e.stopPropagation();
        const id = jukebox.channels.music.currentTrack?.id;
        if (!id) {
            ui.notifications.warn('No current track to add.');
            return;
        }

        app.showAddToPlaylistDialog(id);
    });

    html.find('.mini-current-edit-btn').click(e => {
        e.stopPropagation();
        const id = jukebox.channels.music.currentTrack?.id;
        if (!id) {
            ui.notifications.warn('No current track to edit.');
            return;
        }

        app.showEditMusicDialog(id);
    });

    html.find('#mini-stop-all-layers').click(() => {
        jukebox.stopAllAmbienceLayers();
        app.render(false);
    });

    html.find('#mini-ambience-master-mute').click(() => {
        jukebox.toggleAmbienceMasterMute();
        app.render(false);
    });

    html.find('#mini-ambience-master-volume').on('input', e => {
        const value = parseFloat(e.target.value) || 0;
        const vol = value / 100;
        e.currentTarget.style.setProperty('--volume-level', `${value}%`);
        jukebox.setAmbienceMasterVolume(vol);
    });

    html.on('click', '.mini-layer-thumb', e => {
        e.stopPropagation();
        const id = e.currentTarget.dataset.layerId;
        if (id) {
            jukebox.stopAmbienceLayer(id);
            app.render(false);
        }
    });

    html.find('#mini-stop-all-sounds').click(e => {
        if (e.currentTarget.disabled) return;
        jukebox.stopAllSoundboardSounds();
        app.render(false);
    });
}

function activateMiniProgressBarListeners(app, html, jukebox) {
    const progressFillEl = html.find('#progress-fill');
    const currentTimeEl = html.find('#current-time');
    const progressBar = html.find('#progress-bar');

    if (!progressBar.length) return;
    if (app.isDragging === undefined) app.isDragging = false;

    progressBar.on('mousedown', () => {
        app.isDragging = true;
    });

    progressBar.on('input', e => {
        app.isDragging = true;
        const percent = e.target.value;
        progressFillEl.css('width', `${percent}%`);

        const duration = jukebox.channels.music.duration;
        if (duration) {
            const currentTime = (percent / 100) * duration;
            currentTimeEl.text(formatTime(currentTime));
        }
    });

    progressBar.on('change', e => {
        const percent = e.target.value;
        jukebox.channels.music.seek(percent);

        if (game.user.isGM && !jukebox.isPreviewMode) {
            syncService.broadcastSeek('music', parseFloat(percent));
        }

        setTimeout(() => {
            app.isDragging = false;
        }, 200);
    });

    progressBar.on('mouseup', () => {
        setTimeout(() => {
            app.isDragging = false;
        }, 200);
    });
}

async function toggleMiniFavorite(app, jukebox, musicId) {
    const storedTrack = jukebox.music.find(track => track.id === musicId);
    if (!storedTrack) {
        ui.notifications.warn('Track is not in the music library.');
        return;
    }

    const tags = new Set(Array.isArray(storedTrack.tags) ? storedTrack.tags : []);
    const favoriteTag = [...tags].find(tag => String(tag || '').trim().toLowerCase() === 'favorite');
    const isFavorite = !!favoriteTag;

    if (isFavorite) {
        tags.delete(favoriteTag);
    } else {
        tags.add('favorite');
    }

    const requestedTags = [...tags];
    const updatedTrack = await jukebox.updateMusic(storedTrack.id, { tags: requestedTags });
    const updatedTags = Array.isArray(updatedTrack?.tags) ? updatedTrack.tags : requestedTags;

    if (jukebox.channels.music.currentTrack?.id === storedTrack.id) {
        jukebox.channels.music.currentTrack.tags = updatedTags;
    }

    if (jukebox.currentPlaylist?.systemType === 'favorites') {
        jukebox.currentPlaylist = jukebox.playlists.find(playlist => playlist.systemType === 'favorites') || null;
    }

    Hooks.call('narratorJukeboxStateChanged', { scope: 'library' });
    ui.notifications.info(isFavorite ? 'Removed from Favorites.' : 'Added to Favorites.');
    app.render(false);
}

export { initMiniDrag };
