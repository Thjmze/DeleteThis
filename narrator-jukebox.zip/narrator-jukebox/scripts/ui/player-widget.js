/**
 * Player Widget - Compact player for non-GM users
 * Shows current track, progress, and volume control with tabs for Music/Ambience
 */

import { JUKEBOX, PROGRESS_UPDATE_INTERVAL } from '../core/constants.js';
import { formatTime } from '../utils/time-format.js';
import { playbackService } from '../services/playback-service.js';
import { syncService } from '../services/sync-service.js';
import { ambienceLayerManager } from '../core/ambience-layer-manager.js';
import { normalizeBooleanFlag } from '../services/track-data-service.js';
import { debugLog, debugWarn, debugError } from '../utils/debug.js';
import { localize } from '../utils/i18n.js';
import { NarratorJukebox } from '../core/jukebox-state.js';
import { showAddMusicDialog } from '../dialogs/add-music-dialog.js';

const WIDGET_POSITION_KEY = 'narrator-jukebox-player-widget-position';

export class PlayerWidget {
  constructor() {
    this.element = null;
    this.isVisible = false;
    this.isDragging = false;
    this.isCompact = false; // Compact mode (micro bar)
    this.activeTab = 'music';
    this.position = this._loadPosition() || { left: window.innerWidth - 160, top: 100 };
    this._progressInterval = null;
    this._audioBlocked = false; // True if autoplay was blocked
    this._expectedLayerCount = 0; // Expected layer count when autoplay blocked
    this._userHasInteracted = false; // True after first user interaction
    this._pendingSync = null; // Pending sync state to apply after interaction
    this._lastResyncRequestAt = 0;
    this._domListenersBound = false;
    this._dragListenersBound = false;
    this._dragContext = null;

    // Bind methods
    this._onRemoteCommand = this._onRemoteCommand.bind(this);
    this._onStateChanged = this._onStateChanged.bind(this);
    this._onWindowResize = this._onWindowResize.bind(this);
    this._onAutoplayBlocked = this._onAutoplayBlocked.bind(this);
    this._onFirstInteraction = this._onFirstInteraction.bind(this);
    this._onWindowFocus = this._onWindowFocus.bind(this);
    this._onVisibilityChange = this._onVisibilityChange.bind(this);
    this._onPageShow = this._onPageShow.bind(this);
    this._onWidgetClick = this._onWidgetClick.bind(this);
    this._onWidgetInput = this._onWidgetInput.bind(this);
    this._onWidgetMouseDown = this._onWidgetMouseDown.bind(this);
    this._onWidgetMouseMove = this._onWidgetMouseMove.bind(this);
    this._onWidgetMouseUp = this._onWidgetMouseUp.bind(this);
  }

  /**
   * Initialize the widget - call this for non-GM users only
   */
  initialize() {
    // Only for non-GM players
    if (game.user.isGM) {
      return;
    }

    debugLog('Initializing PlayerWidget for player');

    // Register hook listeners
    Hooks.on('narratorJukeboxRemoteCommand', this._onRemoteCommand);
    Hooks.on('narratorJukeboxStateChanged', this._onStateChanged);
    Hooks.on('narratorJukeboxAutoplayBlocked', this._onAutoplayBlocked);

    // Listen for window resize
    window.addEventListener('resize', this._onWindowResize);
    window.addEventListener('focus', this._onWindowFocus);
    window.addEventListener('pageshow', this._onPageShow);
    document.addEventListener('visibilitychange', this._onVisibilityChange);

    // Listen for first user interaction to unlock audio
    document.addEventListener('click', this._onFirstInteraction, { once: true });
    document.addEventListener('keydown', this._onFirstInteraction, { once: true });

    // Create the DOM element (hidden initially)
    this._createWidget();

    // Check if something is already playing (player joined mid-session)
    const layerCount = this._getAmbienceLayerCount();
    if (playbackService.isPlaying || layerCount > 0) {
      this.show();
      // If layers are active but no music, switch to ambience tab
      if (!playbackService.isPlaying && layerCount > 0) {
        this.activeTab = 'ambience';
        this._render();
      }
    }
  }

  /**
   * Handle first user interaction - unlocks audio context
   */
  async _onFirstInteraction() {
    if (this._userHasInteracted) return;

    debugLog('First user interaction detected, audio unlocked');
    this._userHasInteracted = true;

    // Mark interaction in the ambience layer manager - this will apply deferred state
    ambienceLayerManager.markUserInteracted();

    try {
      await playbackService.retryAmbiencePendingLayers?.();
    } catch (err) {
      debugWarn('Failed to retry pending ambience layers after first interaction:', err);
    }

    // Clear our local pending state since ambienceLayerManager handles it now
    this._pendingSync = null;
    this._audioBlocked = false;
    this._expectedLayerCount = 0;

    // Remove the other listener
    document.removeEventListener('click', this._onFirstInteraction);
    document.removeEventListener('keydown', this._onFirstInteraction);

    // Re-render to update UI
    this._render();
  }

  /**
   * Create the widget DOM element
   */
  _createWidget() {
    this.element = document.createElement('div');
    this.element.className = 'narrator-jukebox-player-widget hidden';
    this.element.innerHTML = this._renderHTML();

    // Set initial position
    this._applyPosition();

    // Append to body
    document.body.appendChild(this.element);

    // Activate listeners
    this._activateListeners();
  }

  /**
   * Apply position to element with bounds checking
   */
  _applyPosition() {
    const bounds = this._getPositionBounds();

    this.position.left = Math.max(10, Math.min(this.position.left, bounds.maxLeft));
    this.position.top = Math.max(10, Math.min(this.position.top, bounds.maxTop));

    this.element.style.left = `${this.position.left}px`;
    this.element.style.top = `${this.position.top}px`;
  }

  _getPositionBounds() {
    const width = this.element?.offsetWidth || (this.isCompact ? 118 : 236);
    const height = this.element?.offsetHeight || (this.isCompact ? 48 : 390);

    return {
      maxLeft: Math.max(10, window.innerWidth - width - 10),
      maxTop: Math.max(10, window.innerHeight - height - 10)
    };
  }

  /**
   * Get current track based on active tab
   */
  _getCurrentTrack() {
    if (this.activeTab === 'music') {
      return playbackService.getCurrentMusicTrack();
    } else {
      return playbackService.getCurrentAmbienceTrack();
    }
  }

  /**
   * Get current playing state based on active tab
   */
  _isCurrentlyPlaying() {
    if (this.activeTab === 'music') {
      return playbackService.isPlaying;
    } else {
      return playbackService.isAmbiencePlaying;
    }
  }

  /**
   * Get current volume based on active tab
   */
  _getCurrentVolume() {
    if (this.activeTab === 'music') {
      return playbackService.channels?.music?.volume ?? 0.8;
    } else {
      // Ambience tab uses a player-local global volume for ambience layers
      return playbackService.getAmbienceClientVolume?.() ?? 1;
    }
  }

  /**
   * Get muted state based on active tab
   */
  _isMuted() {
    if (this.activeTab === 'music') {
      return playbackService.isMuted;
    } else {
      // Ambience tab uses a player-local mute for ambience layers
      return playbackService.isAmbienceClientMuted?.() ?? false;
    }
  }

  /**
   * Get active ambience layers data
   */
  _getActiveAmbienceLayers() {
    return playbackService.getActiveAmbienceLayers?.() || [];
  }

  /**
   * Get ambience layer count (includes deferred/pending layers if audio is blocked)
   */
  _getAmbienceLayerCount() {
    const active = playbackService.getAmbienceLayerCount?.() || 0;

    // Check for deferred state in ambienceLayerManager
    const deferred = ambienceLayerManager.getDeferredLayerCount?.() || 0;
    if (deferred > 0) {
      return Math.max(active, deferred);
    }

    // Fallback to local tracking if audio is blocked
    if (this._audioBlocked && this._expectedLayerCount) {
      return Math.max(active, this._expectedLayerCount);
    }
    return active;
  }

  /**
   * Render HTML content
   */
  _renderHTML() {
    const isMusicPlaying = playbackService.isPlaying;
    const ambienceLayerCount = this._getAmbienceLayerCount();
    const activeLayers = this._getActiveAmbienceLayers();
    const visibleLayerCount = Math.max(activeLayers.length, ambienceLayerCount);

    if (this.isCompact) {
      return `
        <div class="pw-compact-bar">
          <div class="pw-compact-indicators">
            <span class="pw-compact-icon pw-compact-music ${isMusicPlaying ? 'active' : ''}" title="Music">
              <i class="fas fa-music"></i>
            </span>
            <span class="pw-compact-icon pw-compact-ambience ${visibleLayerCount > 0 ? 'active' : ''}" title="${visibleLayerCount} Ambience Layer${visibleLayerCount !== 1 ? 's' : ''}">
              <i class="fas fa-water"></i>
              ${visibleLayerCount > 0 ? `<span class="pw-layer-badge">${visibleLayerCount}</span>` : ''}
            </span>
          </div>
          <button class="pw-expand-btn" title="Expand">
            <i class="fas fa-chevron-down"></i>
          </button>
        </div>
      `;
    }

    return `
      <div class="pw-panel-frame">
        ${this._renderWidgetHeader(isMusicPlaying, visibleLayerCount)}
        <div class="pw-content">
          ${this.activeTab === 'music'
            ? this._renderMusicPanel()
            : this._renderAmbiencePanel(activeLayers, visibleLayerCount)}
        </div>
        <div class="pw-drag-dots" aria-hidden="true">
          <span></span><span></span><span></span><span></span><span></span>
        </div>
      </div>
    `;
  }

  _renderWidgetHeader(isMusicPlaying, layerCount) {
    const musicActive = this.activeTab === 'music';
    const ambienceActive = this.activeTab === 'ambience';

    return `
      <div class="pw-header">
        <div class="pw-tabs" role="tablist" aria-label="Narrator Jukebox player tabs">
          <button type="button" class="pw-tab pw-tab-music ${musicActive ? 'active' : ''}" data-tab="music" title="Music" aria-label="Music" aria-pressed="${musicActive}">
            <i class="fas fa-music"></i>
            <span class="pw-indicator ${isMusicPlaying ? 'active' : ''}"></span>
          </button>
          <button type="button" class="pw-tab pw-tab-ambience ${ambienceActive ? 'active' : ''}" data-tab="ambience" title="Ambience Layers" aria-label="Ambience Layers" aria-pressed="${ambienceActive}">
            <i class="fas fa-water"></i>
            <span class="pw-indicator ${layerCount > 0 ? 'active' : ''}"></span>
            ${layerCount > 0 ? `<span class="pw-tab-badge">${layerCount}</span>` : ''}
          </button>
        </div>
        <div class="pw-header-actions">
          <button type="button" class="pw-suggest-btn" title="${this._escapeAttribute(localize('Widget.SuggestTrack'))}" aria-label="${this._escapeAttribute(localize('Widget.SuggestTrack'))}">
            <i class="fas fa-plus-circle"></i>
          </button>
          <button type="button" class="pw-minimize-btn" title="Minimize" aria-label="Minimize player widget">
            <i class="fas fa-minus"></i>
          </button>
          <button type="button" class="pw-close" title="Hide widget" aria-label="Hide player widget">
            <i class="fas fa-times"></i>
          </button>
        </div>
      </div>
    `;
  }

  _renderMusicPanel() {
    const currentTrack = playbackService.getCurrentMusicTrack();
    const isPlaying = playbackService.isPlaying;
    const volume = playbackService.channels?.music?.volume ?? 0.8;
    const isMuted = playbackService.isMuted;
    const progress = playbackService.getMusicProgress();
    const { displayName, displayThumb, iconClass } = this._getTrackDisplayData(currentTrack);
    const safeName = this._escapeHTML(displayName);
    const safeTitle = this._escapeAttribute(displayName);
    const liveLabel = isPlaying ? 'Broadcast Live' : currentTrack ? 'Broadcast Paused' : 'Waiting for Broadcast';

    return `
      <section class="pw-music-panel" aria-label="Broadcast music">
        <div class="pw-cover-stage ${isPlaying ? 'is-live' : ''}">
          <div class="pw-cover-glow">${this._renderGlowImage(displayThumb, displayName)}</div>
          <div class="pw-cover pw-artwork ${isPlaying ? 'pulsing' : ''}">
            ${this._renderArtworkContent(displayThumb, displayName, iconClass)}
          </div>
        </div>

        <div class="pw-now-playing">
          <div class="pw-track-title" title="${safeTitle}">${safeName}</div>
          <div class="pw-status-pill ${isPlaying ? 'is-live' : 'is-idle'}">
            <i class="fas ${isPlaying ? 'fa-broadcast-tower' : 'fa-satellite-dish'}"></i>
            <span>${liveLabel}</span>
          </div>
        </div>

        <div class="pw-progress" aria-label="Music progress">
          <span class="pw-time pw-current">${formatTime(progress.current)}</span>
          <div class="pw-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(progress.percent || 0)}">
            <div class="pw-progress-fill" style="width: ${this._clampPercent(progress.percent)}%"></div>
          </div>
          <span class="pw-time pw-duration">${formatTime(progress.duration)}</span>
        </div>

        ${this._renderVolumeControl({
          channel: 'music',
          volume,
          isMuted,
          label: 'Local music volume'
        })}
      </section>
    `;
  }

  _renderAmbiencePanel(activeLayers, layerCount) {
    const ambienceVolume = playbackService.getAmbienceClientVolume?.() ?? 1;
    const isAmbienceMuted = playbackService.isAmbienceClientMuted?.() ?? false;
    const needsAudioUnlock = this._audioBlocked || this._pendingSync || ambienceLayerManager.hasDeferredState?.();

    return `
      <section class="pw-ambience-panel" aria-label="Broadcast ambience">
        <div class="pw-scene-card">
          <div class="pw-scene-icon">
            <i class="fas fa-cloud"></i>
          </div>
          <div class="pw-scene-copy">
            <div class="pw-scene-title">Scene Ambience</div>
            <div class="pw-scene-subtitle">${layerCount > 0 ? 'Broadcast mix active' : 'No active mix'}</div>
          </div>
          <div class="pw-scene-level" aria-hidden="true">
            <span></span><span></span><span></span><span></span>
          </div>
        </div>

        ${needsAudioUnlock ? `
          <div class="pw-audio-blocked">
            <button type="button" class="pw-enable-audio-btn" title="Click to enable audio">
              <i class="fas fa-volume-up"></i>
              <span>Enable Audio</span>
            </button>
            <span class="pw-audio-blocked-hint">Unlock this browser before the mix can play.</span>
          </div>
        ` : ''}

        <div class="pw-layers-section">
          ${activeLayers.length > 0 ? `
            <div class="pw-layers-list">
              ${activeLayers.map(layer => this._renderLayerRow(layer)).join('')}
            </div>
          ` : `
            <div class="pw-no-layers">
              <i class="fas fa-water"></i>
              <span>${needsAudioUnlock && layerCount > 0 ? `${layerCount} layer${layerCount !== 1 ? 's' : ''} waiting` : 'No ambience layers'}</span>
            </div>
          `}
        </div>

        <div class="pw-layers-count">
          <span></span>
          ${layerCount} layer${layerCount !== 1 ? 's' : ''} active
          <span></span>
        </div>

        ${this._renderVolumeControl({
          channel: 'ambience',
          volume: ambienceVolume,
          isMuted: isAmbienceMuted,
          label: 'Local ambience volume'
        })}
      </section>
    `;
  }

  _renderLayerRow(layer) {
    const isLayerHidden = normalizeBooleanFlag(layer.track?.hidden);
    const name = isLayerHidden ? 'Ambience' : (layer.track?.name || 'Unknown');
    const thumbnail = isLayerHidden ? null : layer.track?.thumbnail;
    const iconClass = isLayerHidden ? 'fa-mask' : 'fa-water';
    const volume = layer.volume ?? 0.8;
    const percent = this._getVolumePercent(volume, false);
    const safeName = this._escapeHTML(name);
    const safeTitle = this._escapeAttribute(name);

    return `
      <div class="pw-layer-item">
        <div class="pw-layer-thumb">
          ${thumbnail
            ? `<img src="${this._escapeAttribute(thumbnail)}" alt="${safeTitle}">`
            : `<i class="fas ${iconClass}"></i>`
          }
        </div>
        <div class="pw-layer-body">
          <div class="pw-layer-line">
            <span class="pw-layer-name" title="${safeTitle}">${safeName}</span>
            <span class="pw-layer-percent">${percent}%</span>
          </div>
          <div class="pw-layer-vol-indicator" style="--vol: ${percent}%"></div>
        </div>
      </div>
    `;
  }

  _renderVolumeControl({ channel, volume, isMuted, label }) {
    const percent = this._getVolumePercent(volume, isMuted);
    const safeLabel = this._escapeAttribute(label);
    const muteLabel = isMuted ? `Unmute ${channel}` : `Mute ${channel}`;

    return `
      <div class="pw-volume pw-volume-${channel}">
        <button type="button" class="pw-vol-btn" id="pw-mute" title="${muteLabel}" aria-label="${muteLabel}">
          <i class="fas ${this._getVolumeIcon(volume, isMuted)}"></i>
        </button>
        <input type="range" class="pw-vol-slider" id="pw-volume-slider" min="0" max="100" value="${percent}" style="--pw-slider-fill: ${percent}%" aria-label="${safeLabel}" aria-valuetext="${percent}%">
        <span class="pw-volume-chip">${percent}%</span>
      </div>
    `;
  }

  _getVolumeIcon(volume, isMuted) {
    if (isMuted || volume === 0) return 'fa-volume-mute';
    if (volume > 0.5) return 'fa-volume-up';
    return 'fa-volume-down';
  }

  _clampPercent(value) {
    const number = Number.isFinite(value) ? value : parseFloat(value);
    if (!Number.isFinite(number)) return 0;
    return Math.max(0, Math.min(number, 100));
  }

  _getVolumePercent(volume, isMuted) {
    if (isMuted) return 0;
    const number = Number.isFinite(volume) ? volume : parseFloat(volume);
    if (!Number.isFinite(number)) return 0;
    return Math.round(Math.max(0, Math.min(number, 1)) * 100);
  }

  _escapeHTML(value) {
    const map = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return String(value ?? '').replace(/[&<>"']/g, char => map[char]);
  }

  _escapeAttribute(value) {
    return this._escapeHTML(value);
  }

  _getTrackDisplayData(track, fallbackName = 'No Track', hiddenName = 'Now Playing') {
    const isHidden = normalizeBooleanFlag(track?.hidden);
    return {
      displayName: isHidden ? hiddenName : (track?.name || fallbackName),
      displayThumb: isHidden ? null : track?.thumbnail,
      iconClass: isHidden ? 'fa-mask' : 'fa-music'
    };
  }

  _renderArtworkContent(displayThumb, displayName, iconClass) {
    return displayThumb
      ? `<img src="${this._escapeAttribute(displayThumb)}" alt="${this._escapeAttribute(displayName)}">`
      : `<div class="pw-art-placeholder"><i class="fas ${iconClass}"></i></div>`;
  }

  _renderGlowImage(displayThumb, displayName) {
    return displayThumb
      ? `<img src="${this._escapeAttribute(displayThumb)}" alt="" aria-hidden="true">`
      : '';
  }

  _updateMusicDisplay() {
    if (!this.element || this.activeTab !== 'music' || this.isCompact) {
      return;
    }

    const track = this._getCurrentTrack();
    const isPlaying = this._isCurrentlyPlaying();
    const { displayName, displayThumb, iconClass } = this._getTrackDisplayData(track);

    const coverStage = this.element.querySelector('.pw-cover-stage');
    if (coverStage) {
      coverStage.classList.toggle('is-live', isPlaying);
    }

    const glowEl = this.element.querySelector('.pw-cover-glow');
    if (glowEl) {
      glowEl.innerHTML = this._renderGlowImage(displayThumb, displayName);
    }

    const coverEl = this.element.querySelector('.pw-cover');
    if (coverEl) {
      coverEl.classList.toggle('pulsing', isPlaying);
      coverEl.innerHTML = this._renderArtworkContent(displayThumb, displayName, iconClass);
    }

    const nameEl = this.element.querySelector('.pw-track-title');
    if (nameEl) {
      nameEl.textContent = displayName;
      nameEl.title = displayName;
    }

    const statusEl = this.element.querySelector('.pw-status-pill');
    if (statusEl) {
      statusEl.classList.toggle('is-live', isPlaying);
      statusEl.classList.toggle('is-idle', !isPlaying);
      statusEl.querySelector('i')?.classList.toggle('fa-broadcast-tower', isPlaying);
      statusEl.querySelector('i')?.classList.toggle('fa-satellite-dish', !isPlaying);
      const statusText = statusEl.querySelector('span');
      if (statusText) {
        statusText.textContent = isPlaying ? 'Broadcast Live' : track ? 'Broadcast Paused' : 'Waiting for Broadcast';
      }
    }

    this._updateProgress();
    this._updateVolumeIcon();
    this._updateVolumeSlider();
  }

  /**
   * Activate widget event listeners
   */
  _activateListeners() {
    if (!this.element || this._domListenersBound) {
      return;
    }

    this.element.addEventListener('click', this._onWidgetClick);
    this.element.addEventListener('input', this._onWidgetInput);
    this.element.addEventListener('mousedown', this._onWidgetMouseDown);
    this._domListenersBound = true;

    if (!this._dragListenersBound) {
      document.addEventListener('mousemove', this._onWidgetMouseMove);
      document.addEventListener('mouseup', this._onWidgetMouseUp);
      this._dragListenersBound = true;
    }
  }

  _onWidgetClick(event) {
    const expandBtn = event.target.closest('.pw-expand-btn');
    if (expandBtn) {
      this.isCompact = false;
      this._updateCompactClass();
      this._render();
      return;
    }

    if (event.target.closest('.pw-suggest-btn')) {
      this._openSuggestDialog();
      return;
    }

    const tab = event.target.closest('.pw-tab');
    if (tab) {
      const newTab = tab.dataset.tab;
      if (newTab && newTab !== this.activeTab) {
        this.activeTab = newTab;
        this._render();
      }
      return;
    }

    const minimizeBtn = event.target.closest('.pw-minimize-btn');
    if (minimizeBtn) {
      this.isCompact = true;
      this._updateCompactClass();
      this._render();
      return;
    }

    if (event.target.closest('.pw-close')) {
      this.hide();
      return;
    }

    if (event.target.closest('#pw-mute')) {
      if (this.activeTab === 'music') {
        playbackService.toggleMute('music');
      } else {
        playbackService.toggleAmbienceClientMute?.();
      }
      this._updateVolumeIcon();
      this._updateVolumeSlider();
      return;
    }

    if (event.target.closest('.pw-enable-audio-btn')) {
      void this._enableAudio();
    }
  }

  /**
   * Open the Add Music dialog in player "Suggest" mode.
   * Reuses the existing showAddMusicDialog flow which already adapts its
   * button label, title, and submit behavior based on game.user.isGM.
   */
  _openSuggestDialog() {
    try {
      showAddMusicDialog({
        jukebox: NarratorJukebox.instance,
        onSuccess: () => {
          // Suggestions are GM-managed; nothing to refresh on the player widget.
        }
      });
    } catch (err) {
      debugError('Failed to open suggest dialog from player widget:', err);
      ui.notifications?.error(localize('Notifications.SuggestDialogFailed'));
    }
  }

  _onWidgetInput(event) {
    const slider = event.target.closest('#pw-volume-slider');
    if (!slider) return;

    const vol = parseFloat(slider.value) / 100;

    if (this.activeTab === 'music') {
      playbackService.setVolume('music', vol);
      void game.settings.set(JUKEBOX.ID, JUKEBOX.SETTINGS.VOLUME, vol);
    } else {
      playbackService.setAmbienceClientVolume?.(vol);
    }

    this._paintVolumeSlider(slider, Math.round(vol * 100));
    this._updateVolumeChip(Math.round(vol * 100));
    this._updateVolumeIcon();
  }

  _onWidgetMouseDown(event) {
    if (!this.element || event.target.closest('button, input, .pw-tab')) {
      return;
    }

    this.isDragging = true;
    this._dragContext = {
      startX: event.clientX,
      startY: event.clientY,
      startLeft: this.position.left,
      startTop: this.position.top
    };
    this.element.classList.add('dragging');
    event.preventDefault();
  }

  _onWidgetMouseMove(event) {
    if (!this.isDragging || !this._dragContext || !this.element) return;

    const dx = event.clientX - this._dragContext.startX;
    const dy = event.clientY - this._dragContext.startY;
    const bounds = this._getPositionBounds();

    this.position.left = Math.max(10, Math.min(bounds.maxLeft, this._dragContext.startLeft + dx));
    this.position.top = Math.max(10, Math.min(bounds.maxTop, this._dragContext.startTop + dy));

    this.element.style.left = `${this.position.left}px`;
    this.element.style.top = `${this.position.top}px`;
  }

  _onWidgetMouseUp() {
    if (!this.isDragging || !this.element) return;

    this.isDragging = false;
    this._dragContext = null;
    this.element.classList.remove('dragging');
    this._savePosition();
  }

  /**
   * Update compact class on element
   */
  _updateCompactClass() {
    if (!this.element) return;
    if (this.isCompact) {
      this.element.classList.add('compact');
    } else {
      this.element.classList.remove('compact');
    }
    this.element.classList.toggle('music-active', this.activeTab === 'music');
    this.element.classList.toggle('ambience-active', this.activeTab === 'ambience');
  }

  /**
   * Save position to localStorage
   */
  _savePosition() {
    localStorage.setItem(WIDGET_POSITION_KEY, JSON.stringify(this.position));
  }

  /**
   * Load position from localStorage
   */
  _loadPosition() {
    const saved = localStorage.getItem(WIDGET_POSITION_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        debugWarn('Failed to parse player widget position');
      }
    }
    return null;
  }

  /**
   * Show the widget
   */
  show() {
    if (this.isVisible) return;

    this.isVisible = true;
    this.element.classList.remove('hidden');
    this.element.classList.add('appearing');

    // Remove animation class after it completes
    setTimeout(() => {
      this.element.classList.remove('appearing');
    }, 300);

    // Start progress updates
    this._startProgressUpdates();

    // Re-render to get latest state
    this._render();
  }

  /**
   * Hide the widget
   */
  hide() {
    this.isVisible = false;
    this.element.classList.add('hidden');
    this._stopProgressUpdates();
  }

  /**
   * Re-render the widget content
   */
  _render() {
    if (!this.element) return;
    this.element.innerHTML = this._renderHTML();
    this._updateCompactClass();
    this._updateVolumeSlider();
    this._applyPosition();
    this._activateListeners();
  }

  /**
   * Start progress bar updates
   */
  _startProgressUpdates() {
    if (this._progressInterval) return;

    this._progressInterval = setInterval(() => {
      if (this.isVisible && this.activeTab === 'music') {
        this._updateProgress();
      }
    }, PROGRESS_UPDATE_INTERVAL);
  }

  /**
   * Stop progress bar updates
   */
  _stopProgressUpdates() {
    if (this._progressInterval) {
      clearInterval(this._progressInterval);
      this._progressInterval = null;
    }
  }

  /**
   * Update just the progress bar (partial update for performance)
   */
  _updateProgress() {
    const { current, duration, percent } = playbackService.getMusicProgress();

    const fillEl = this.element.querySelector('.pw-progress-fill');
    const barEl = this.element.querySelector('.pw-progress-bar');
    const currentEl = this.element.querySelector('.pw-current');
    const durationEl = this.element.querySelector('.pw-duration');

    if (fillEl) fillEl.style.width = `${percent}%`;
    if (barEl) barEl.setAttribute('aria-valuenow', String(Math.round(percent || 0)));
    if (currentEl) currentEl.textContent = formatTime(current);
    if (durationEl) durationEl.textContent = formatTime(duration);
  }

  /**
   * Update tab indicators
   */
  _updateTabIndicators() {
    const musicIndicator = this.element.querySelector('.pw-tab-music .pw-indicator');
    const ambienceIndicator = this.element.querySelector('.pw-tab-ambience .pw-indicator');
    const ambienceBadge = this.element.querySelector('.pw-tab-ambience .pw-tab-badge');
    const layerCount = this._getAmbienceLayerCount();

    if (musicIndicator) {
      musicIndicator.classList.toggle('active', playbackService.isPlaying);
    }
    if (ambienceIndicator) {
      ambienceIndicator.classList.toggle('active', layerCount > 0);
    }
    // Update layer count badge
    if (ambienceBadge) {
      ambienceBadge.textContent = layerCount;
      ambienceBadge.style.display = layerCount > 0 ? '' : 'none';
    }
  }

  /**
   * Update volume icon based on current state
   */
  _updateVolumeIcon() {
    const vol = this._getCurrentVolume();
    const isMuted = this._isMuted();
    const icon = this.element.querySelector('#pw-mute i');
    if (icon) {
      icon.className = `fas ${this._getVolumeIcon(vol, isMuted)}`;
    }
  }

  /**
   * Update volume slider value
   */
  _updateVolumeSlider() {
    const vol = this._getCurrentVolume();
    const isMuted = this._isMuted();
    const slider = this.element.querySelector('#pw-volume-slider');
    if (slider) {
      const percent = this._getVolumePercent(vol, isMuted);
      slider.value = percent;
      this._paintVolumeSlider(slider, percent);
      slider.setAttribute('aria-valuetext', `${percent}%`);
      this._updateVolumeChip(percent);
    }
  }

  _paintVolumeSlider(slider, percent) {
    if (!slider) return;
    slider.style.setProperty('--pw-slider-fill', `${this._clampPercent(percent)}%`);
  }

  _updateVolumeChip(percent = null) {
    const chip = this.element?.querySelector('.pw-volume-chip');
    if (!chip) return;

    const value = percent ?? this._getVolumePercent(this._getCurrentVolume(), this._isMuted());
    chip.textContent = `${value}%`;
  }

  _requestStateRefresh(reason = 'manual') {
    if (game.user.isGM || document.visibilityState === 'hidden') return;
    if (!syncService?.socket) return;

    const now = Date.now();
    if ((now - this._lastResyncRequestAt) < 1500) return;
    this._lastResyncRequestAt = now;

    debugLog(`PlayerWidget requesting sync refresh after ${reason}`);
    syncService.requestState();
  }

  _onWindowFocus() {
    this._requestStateRefresh('window focus');
  }

  _onVisibilityChange() {
    if (document.visibilityState === 'visible') {
      this._requestStateRefresh('tab visible');
    }
  }

  _onPageShow() {
    this._requestStateRefresh('page show');
  }

  // ==========================================
  // Event Handlers
  // ==========================================

  /**
   * Handle remote command received from GM
   */
  _onRemoteCommand(payload) {
    // Show widget when playback starts
    if (payload.action === 'play' || payload.action === 'resume') {
      this.show();
      // Auto-switch to the channel that started playing
      if (payload.channel) {
        this.activeTab = payload.channel;
      }
      this._render();
    }
    // Keep visible but update when paused
    else if (payload.action === 'pause') {
      this._render();
    }
    // Update on stop
    else if (payload.action === 'stop') {
      this._render();
    }
    // Update slider when GM broadcasts volume change
    else if (payload.action === 'volume') {
      this._updateVolumeSlider();
      this._updateVolumeIcon();
    }
    // Handle ambience layers sync
    else if (payload.action === 'ambienceLayers' || payload.action === 'ambienceLayersStopAll') {
      const layerCount = this._getAmbienceLayerCount();
      if (layerCount > 0) {
        this.show();
        this.activeTab = 'ambience';
      }
      this._render();
    }
    // Handle state sync (player joining mid-session)
    else if (payload.action === 'syncState') {
      const layerCount = this._getAmbienceLayerCount();
      const expectedLayers = payload.ambienceLayersState?.layers?.length || 0;

      // Check if ambienceLayerManager has deferred state (audio blocked)
      if (ambienceLayerManager.hasDeferredState?.()) {
        debugLog(`Deferred state detected, showing audio banner`);
        this._audioBlocked = true;
        this._expectedLayerCount = ambienceLayerManager.getDeferredLayerCount?.() || expectedLayers;
        this.activeTab = 'ambience';
      }
      // Fallback: If there are expected layers but none playing and user hasn't interacted
      else if (expectedLayers > 0 && !this._userHasInteracted) {
        debugLog(`Sync received before interaction, expected ${expectedLayers} layers`);
        this._pendingSync = { expectedLayers, pendingCount: expectedLayers };
        this._audioBlocked = true;
        this._expectedLayerCount = expectedLayers;
        this.activeTab = 'ambience';
      }

      if (payload.isPlaying || layerCount > 0 || payload.musicTrackId || expectedLayers > 0) {
        this.show();
      }
      this._render();
    }

    // Always update indicators
    this._updateTabIndicators();
  }

  /**
   * Handle general state changes
   */
  _onStateChanged(payload = {}) {
    if (!this.isVisible || !this.element) {
      return;
    }

    const scope = payload.scope || 'full';

    if (this.isCompact) {
      if (scope !== 'soundboard' && scope !== 'mode') {
        this._render();
      }
      return;
    }

    if (scope === 'playback') {
      this._updateTabIndicators();
      if (this.activeTab === 'music') {
        this._updateMusicDisplay();
      }
      return;
    }

    if (scope === 'ambienceLayers') {
      if (this.activeTab === 'ambience') {
        this._render();
      } else {
        this._updateTabIndicators();
      }
      return;
    }

    if (scope === 'soundboard' || scope === 'mode') {
      return;
    }

    this._render();
  }

  /**
   * Handle autoplay blocked event
   */
  _onAutoplayBlocked({ count, expected, actual, deferred }) {
    debugLog(`Autoplay blocked - expected: ${expected}, actual: ${actual}, pending: ${count}, deferred: ${deferred}`);

    // Store pending sync info
    this._pendingSync = {
      expectedLayers: expected || count,
      pendingCount: count,
      deferred: deferred || false
    };

    this._audioBlocked = true;
    this._expectedLayerCount = expected || count;
    this.show();
    this.activeTab = 'ambience';
    this._render();
  }

  /**
   * Handle click to enable audio after autoplay block
   */
  async _enableAudio() {
    debugLog('User clicked to enable audio');
    this._audioBlocked = false;
    this._pendingSync = null;
    this._userHasInteracted = true;

    try {
      // Mark interaction - this will apply deferred state in ambienceLayerManager
      ambienceLayerManager.markUserInteracted();

      // Also try any pending layers from playbackService (fallback)
      await playbackService.retryAmbiencePendingLayers?.();

      // Check if we have layers now
      const currentCount = playbackService.getAmbienceLayerCount?.() || 0;
      if (currentCount > 0) {
        ui.notifications.info('Narrator Jukebox: Audio enabled!');
      } else if (this._expectedLayerCount > 0) {
        // If still no layers, request a full re-sync from GM
        debugLog('No layers after retry, requesting full re-sync');
        const syncService = game.modules.get('narrator-jukebox')?.api?._syncService;
        if (syncService) {
          syncService.requestState();
        }
        ui.notifications.info('Narrator Jukebox: Syncing audio...');
      }

      this._expectedLayerCount = 0;
    } catch (err) {
      debugError('Failed to enable audio:', err);
      // Still try re-sync as fallback
      const syncService = game.modules.get('narrator-jukebox')?.api?._syncService;
      if (syncService) {
        syncService.requestState();
      }
    }

    this._render();
  }

  /**
   * Handle window resize
   */
  _onWindowResize() {
    if (this.isVisible) {
      this._applyPosition();
    }
  }

  /**
   * Cleanup - call when module is disabled
   */
  destroy() {
    this._stopProgressUpdates();
    Hooks.off('narratorJukeboxRemoteCommand', this._onRemoteCommand);
    Hooks.off('narratorJukeboxStateChanged', this._onStateChanged);
    Hooks.off('narratorJukeboxAutoplayBlocked', this._onAutoplayBlocked);
    window.removeEventListener('resize', this._onWindowResize);
    window.removeEventListener('focus', this._onWindowFocus);
    window.removeEventListener('pageshow', this._onPageShow);
    document.removeEventListener('visibilitychange', this._onVisibilityChange);
    document.removeEventListener('click', this._onFirstInteraction);
    document.removeEventListener('keydown', this._onFirstInteraction);
    if (this.element && this._domListenersBound) {
      this.element.removeEventListener('click', this._onWidgetClick);
      this.element.removeEventListener('input', this._onWidgetInput);
      this.element.removeEventListener('mousedown', this._onWidgetMouseDown);
      this._domListenersBound = false;
    }
    if (this._dragListenersBound) {
      document.removeEventListener('mousemove', this._onWidgetMouseMove);
      document.removeEventListener('mouseup', this._onWidgetMouseUp);
      this._dragListenersBound = false;
    }
    this._dragContext = null;
    this.isDragging = false;
    if (this.element) {
      this.element.remove();
      this.element = null;
    }
  }
}

// Export singleton
export const playerWidget = new PlayerWidget();
