/**
 * Narrator's Jukebox - Main Application
 * Refactored modular version of NarratorsJukeboxApp
 *
 * @module ui/jukebox-app
 */

// Core imports
import {
  JUKEBOX,
  MAX_AMBIENCE_LAYERS,
  MUSIC_REPEAT_MODES,
  SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MAX,
  SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MIN
} from '../core/constants.js';
import { syncService } from '../services/sync-service.js';
import { debounce } from '../utils/debounce.js';
import { formatTime } from '../utils/time-format.js';
import { localize, format } from '../utils/i18n.js';
import { findDuplicateTrack, normalizeBooleanFlag } from '../services/track-data-service.js';

// Dialog imports
import * as Dialogs from './app-dialogs.js';

// Listener imports
import { activateListeners as activateModularListeners } from './app-listeners.js';

// Mode management imports
import * as ModeManager from './mode-manager.js';

// Progress management imports
import * as ProgressManager from './progress-manager.js';

// Partial updates imports
import * as PartialUpdates from './partial-updates.js';

// Duration loader
import { loadAndDisplayDurations } from '../utils/duration-loader.js';

function normalizeSuggestedTrack(suggestion) {
  if (!suggestion) return null;

  const url = String(suggestion.url || suggestion.path || '').trim();
  const source = suggestion.source || (/youtu\.be|youtube\.com|music\.youtube\.com/i.test(url) ? 'youtube' : 'local');
  const rawTags = suggestion.tags;
  const tags = Array.isArray(rawTags)
    ? rawTags
    : String(rawTags || '')
      .split(',')
      .map(tag => tag.trim())
      .filter(Boolean);

  return {
    ...suggestion,
    name: String(suggestion.name || 'Untitled Suggestion').trim(),
    url,
    source,
    tags
  };
}

function hashSuggestionValue(value) {
  const text = String(value || '');
  let hash = 0;
  for (let i = 0; i < text.length; i += 1) {
    hash = ((hash << 5) - hash) + text.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash).toString(36);
}

function getSuggestionKey(suggestion) {
  if (!suggestion) return '';
  if (suggestion.id) return `id-${String(suggestion.id)}`;
  const signature = [
    suggestion.user,
    suggestion.suggestedAt,
    suggestion.name,
    suggestion.url || suggestion.path,
    suggestion.source
  ].join('|');
  return `legacy-${hashSuggestionValue(signature)}`;
}

function formatSuggestionAge(timestamp) {
  if (!timestamp) return 'Pending';
  const submitted = Number(timestamp);
  if (!Number.isFinite(submitted)) return 'Pending';

  const elapsedSeconds = Math.max(0, Math.floor((Date.now() - submitted) / 1000));
  if (elapsedSeconds < 60) return 'Just now';

  const elapsedMinutes = Math.floor(elapsedSeconds / 60);
  if (elapsedMinutes < 60) return `${elapsedMinutes} min ago`;

  const elapsedHours = Math.floor(elapsedMinutes / 60);
  if (elapsedHours < 24) return `${elapsedHours} hr ago`;

  const elapsedDays = Math.floor(elapsedHours / 24);
  return `${elapsedDays} day${elapsedDays === 1 ? '' : 's'} ago`;
}

function copyTextToClipboard(text) {
  if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
    return navigator.clipboard.writeText(text).catch(() => copyTextToClipboardFallback(text));
  }

  return copyTextToClipboardFallback(text);
}

function copyTextToClipboardFallback(text) {
  const textarea = document.createElement('textarea');
  textarea.value = text;
  textarea.setAttribute('readonly', '');
  textarea.style.position = 'fixed';
  textarea.style.left = '-9999px';
  document.body.appendChild(textarea);
  textarea.select();
  document.execCommand('copy');
  textarea.remove();
  return Promise.resolve();
}

function isImageIcon(icon) {
  const value = String(icon || '');
  return value.includes('/') || /\.(avif|gif|jpe?g|png|svg|webp)$/i.test(value);
}

function normalizeTagValue(value) {
  return String(value || '').trim().toLowerCase();
}

function itemHasTag(item, tag) {
  const tagKey = normalizeTagValue(tag);
  if (!tagKey || !Array.isArray(item?.tags)) return false;
  return item.tags.some(trackTag => normalizeTagValue(trackTag) === tagKey);
}

function getPositiveSeconds(value, fallback) {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? seconds : fallback;
}

function getSoundboardIntervalSettings(sound = {}) {
  const min = getPositiveSeconds(sound.randomIntervalMin, SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MIN);
  const max = Math.max(min, getPositiveSeconds(sound.randomIntervalMax, SOUNDBOARD_RANDOM_INTERVAL_DEFAULT_MAX));

  return {
    enabled: normalizeBooleanFlag(sound.randomIntervalEnabled),
    min,
    max
  };
}

function formatDelayLabel(seconds) {
  const value = Math.max(0, Math.round(Number(seconds) || 0));
  if (value < 60) return `${value}s`;

  const mins = Math.floor(value / 60);
  const secs = value % 60;
  return secs ? `${mins}:${secs.toString().padStart(2, '0')}` : `${mins}m`;
}

function formatIntervalLabel(interval) {
  return `${formatDelayLabel(interval.min)}-${formatDelayLabel(interval.max)}`;
}

function formatRemainingInterval(nextFireAt) {
  const timestamp = Number(nextFireAt);
  if (!Number.isFinite(timestamp) || timestamp <= 0) return '';
  return formatDelayLabel(Math.max(0, (timestamp - Date.now()) / 1000));
}

const NORMAL_WINDOW_DIMENSIONS = Object.freeze({
  width: 1680,
  height: 900,
  minWidth: 1680,
  minHeight: 760,
  compactBreakpoint: 1120,
  narrowBreakpoint: 860,
  shortBreakpoint: 680,
  tinyHeightBreakpoint: 560
});

const NORMAL_WINDOW_VIEWPORT_MARGIN = 10;
const WINDOW_SIZE_TRANSITION_MS = 190;

function getViewportSize() {
  if (typeof window === 'undefined') {
    return {
      width: NORMAL_WINDOW_DIMENSIONS.width,
      height: NORMAL_WINDOW_DIMENSIONS.height
    };
  }

  return {
    width: Number(window.innerWidth) || NORMAL_WINDOW_DIMENSIONS.width,
    height: Number(window.innerHeight) || NORMAL_WINDOW_DIMENSIONS.height
  };
}

function getEffectiveNormalMinimums() {
  const viewport = getViewportSize();
  const availableWidth = Math.max(320, viewport.width - (NORMAL_WINDOW_VIEWPORT_MARGIN * 2));
  const availableHeight = Math.max(240, viewport.height - (NORMAL_WINDOW_VIEWPORT_MARGIN * 2));

  return {
    minWidth: Math.min(NORMAL_WINDOW_DIMENSIONS.minWidth, availableWidth),
    minHeight: Math.min(NORMAL_WINDOW_DIMENSIONS.minHeight, availableHeight)
  };
}

function getInitialNormalWindowDimensions() {
  const viewport = getViewportSize();
  const minimums = getEffectiveNormalMinimums();
  const availableWidth = Math.max(minimums.minWidth, viewport.width - (NORMAL_WINDOW_VIEWPORT_MARGIN * 2));
  const availableHeight = Math.max(minimums.minHeight, viewport.height - (NORMAL_WINDOW_VIEWPORT_MARGIN * 2));

  return {
    width: Math.min(NORMAL_WINDOW_DIMENSIONS.width, availableWidth),
    height: Math.min(NORMAL_WINDOW_DIMENSIONS.height, availableHeight),
    minWidth: minimums.minWidth,
    minHeight: minimums.minHeight
  };
}

function getMaximizedWindowPosition(margin = NORMAL_WINDOW_VIEWPORT_MARGIN) {
  const viewport = getViewportSize();
  const inset = Math.max(0, margin * 2);

  return {
    left: margin,
    top: margin,
    width: Math.max(320, viewport.width - inset),
    height: Math.max(240, viewport.height - inset)
  };
}

function clampNumber(value, min, max) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return min;
  return Math.min(Math.max(numeric, min), max);
}

function hasOwnPositionValue(position, key) {
  if (!position) return false;
  return Object.prototype.hasOwnProperty.call(position, key);
}

/**
 * Main Jukebox Application Window
 * @extends Application
 */
export class NarratorsJukeboxApp extends Application {
  constructor(options = {}) {
    super(options);

    // Reference Singleton (will be set externally after initialization)
    this.jukebox = null;

    // Local UI State
    this.view = 'home';
    this.searchQuery = '';
    this.tagFilter = null;
    this.libraryFolderFilter = 'all';
    this.librarySourceFilter = 'all';
    this.libraryVisibilityFilter = 'all';
    this.librarySort = 'library';
    this.libraryDensity = 'comfortable';
    this.ambienceSearchQuery = '';
    this.ambienceTagFilter = null;
    this.ambienceFolderFilter = 'all';
    this.soundboardFolderFilter = 'all';
    this.soundboardSort = 'name';
    this.playlistSearchQuery = '';
    this.queueSearchQuery = '';
    this._focusPlaylistSearchAfterRender = false;
    this.selectedPlaylistId = null;
    this.selectedPresetId = null;
    this.showPlayerQueue = false;
    this.suggestionFilter = 'all';
    this.selectedSuggestionKey = null;
    this._suggestionsDirty = false;

    // Multi-selection state
    this.selectionMode = false;
    this.selectedMusicIds = new Set();
    this.selectedAmbienceIds = new Set();
    this.selectedSoundboardIds = new Set();

    // Folder collapse state (in-memory only)
    this.collapsedFolders = new Set();

    // Pagination state for large libraries
    this._musicDisplayLimit = 50;
    this._ambienceDisplayLimit = 50;
    this._miniDisplayLimit = 50;

    // Window mode state
    this._windowState = 'normal';
    this._preNormalPosition = null;
    this._preMiniPosition = null;
    this._microPosition = null;
    this._miniActiveTab = 'music';
    this._miniMusicView = 'library'; // 'library' or 'queue'
    this._miniSearchQuery = '';

    // Fullscreen/minimize state
    this._isFullscreen = false;
    this._preFullscreenPosition = null;
    this._isMaximized = false;
    this._preMaximizePosition = null;
    this._isApplyingWindowPreset = false;
    this._sizeTransitionTimeout = null;

    // Progress tracking flags
    this._progressRAF = false;
    this._progressRAFId = null;
    this._ambienceProgressRAF = false;
    this._ambienceProgressRAFId = null;
    this.isDragging = false;
    this.isAmbienceDragging = false;
    this._responsiveObserver = null;

    // Debounced render for search
    this._debouncedRender = debounce(() => this.render(), 300);
  }

  /**
   * Set the jukebox singleton reference
   * @param {NarratorJukebox} jukebox - The jukebox singleton
   */
  setJukebox(jukebox) {
    this.jukebox = jukebox;
  }

  static get defaultOptions() {
    const dimensions = getInitialNormalWindowDimensions();

    return foundry.utils.mergeObject(super.defaultOptions, {
      id: 'narrator-jukebox',
      template: 'modules/narrator-jukebox/templates/jukebox-app.html',
      title: "Narrator's Jukebox",
      width: dimensions.width,
      height: dimensions.height,
      minWidth: dimensions.minWidth,
      minHeight: dimensions.minHeight,
      resizable: true,
      classes: ['narrator-jukebox-window', 'narrator-jukebox-app']
    });
  }

  setPosition(position = {}) {
    this._syncNormalWindowConstraints();

    const nextPosition = this._enforceNormalWindowBounds(position);
    const result = super.setPosition(nextPosition);

    if (!this._isApplyingWindowPreset) {
      this._clearMaximizedStateForManualPosition(position);
    }

    return result;
  }

  _enforceNormalWindowBounds(position = {}) {
    if (this._windowState !== 'normal' || this._isFullscreen) {
      return position;
    }

    // Foundry's built-in minimize (double-click on titlebar) collapses the
    // window to just the titlebar. Skip the minimum enforcement while
    // minimized so Foundry can shrink it freely; on un-minimize, the saved
    // pre-minimize position is restored and our normal bounds kick in again.
    if (this._minimized) {
      return position;
    }

    const nextPosition = { ...position };
    const current = this.position || {};
    const minimums = getEffectiveNormalMinimums();
    const requestedWidth = Number(nextPosition.width ?? current.width ?? this.options.width);
    const requestedHeight = Number(nextPosition.height ?? current.height ?? this.options.height);

    if (Number.isFinite(requestedWidth) && requestedWidth < minimums.minWidth) {
      nextPosition.width = minimums.minWidth;
    }

    if (Number.isFinite(requestedHeight) && requestedHeight < minimums.minHeight) {
      nextPosition.height = minimums.minHeight;
    }

    const finalWidth = Number(nextPosition.width ?? requestedWidth);
    const finalHeight = Number(nextPosition.height ?? requestedHeight);
    const viewport = getViewportSize();

    if (hasOwnPositionValue(nextPosition, 'left') && Number.isFinite(finalWidth)) {
      nextPosition.left = clampNumber(nextPosition.left, 0, Math.max(0, viewport.width - finalWidth));
    }

    if (hasOwnPositionValue(nextPosition, 'top') && Number.isFinite(finalHeight)) {
      nextPosition.top = clampNumber(nextPosition.top, 0, Math.max(0, viewport.height - finalHeight));
    }

    return nextPosition;
  }

  _syncNormalWindowConstraints() {
    if (this._windowState !== 'normal' || this._isFullscreen || this._minimized) return;

    const minimums = getEffectiveNormalMinimums();
    this.options.minWidth = minimums.minWidth;
    this.options.minHeight = minimums.minHeight;
  }

  /**
   * Override Foundry's minimize so the premium window minimums
   * (1680x760) don't prevent the window from collapsing to its titlebar.
   * Foundry reads this.options.minWidth/minHeight directly when applying
   * inline styles, so we have to swap those out and restore on maximize.
   */
  async minimize() {
    if (!this._minimized) {
      this._preMinimizeBounds = {
        minWidth: this.options.minWidth,
        minHeight: this.options.minHeight
      };
      this.options.minWidth = 0;
      this.options.minHeight = 0;
    }
    return super.minimize();
  }

  async maximize() {
    const result = await super.maximize();
    if (this._preMinimizeBounds) {
      this.options.minWidth = this._preMinimizeBounds.minWidth;
      this.options.minHeight = this._preMinimizeBounds.minHeight;
      this._preMinimizeBounds = null;
      // Re-apply our normal-window enforcement now that bounds are restored.
      this._syncNormalWindowConstraints();
    }
    return result;
  }

  _setPositionWithSizeTransition(position) {
    const element = this.element?.[0];
    this._clearWindowSizeTransition();

    if (element) {
      element.classList.add('jb-window-size-transition');
    }

    this._isApplyingWindowPreset = true;
    try {
      return this.setPosition(position);
    } finally {
      this._isApplyingWindowPreset = false;

      if (element && typeof window !== 'undefined') {
        this._sizeTransitionTimeout = window.setTimeout(() => {
          element.classList.remove('jb-window-size-transition');
          this._sizeTransitionTimeout = null;
        }, WINDOW_SIZE_TRANSITION_MS + 40);
      }
    }
  }

  _clearWindowSizeTransition() {
    if (this._sizeTransitionTimeout && typeof window !== 'undefined') {
      window.clearTimeout(this._sizeTransitionTimeout);
    }

    this._sizeTransitionTimeout = null;
    this.element?.[0]?.classList.remove('jb-window-size-transition');
  }

  _clearMaximizedStateForManualPosition(position = {}) {
    if (!this._isMaximized || this._windowState !== 'normal') return;
    if (!hasOwnPositionValue(position, 'width') && !hasOwnPositionValue(position, 'height')) return;

    this._isMaximized = false;
    this._preMaximizePosition = null;
    this._syncWindowControlState();
  }

  _syncWindowControlState(root = this.element) {
    if (!root?.find) return;

    const maximizeButton = root.find('.header-button.jb-maximize');
    const maximizeIcon = maximizeButton.find('i');
    maximizeButton.attr('data-tooltip', this._isMaximized ? 'Restore' : 'Maximize');
    maximizeIcon.toggleClass('fa-window-restore', this._isMaximized);
    maximizeIcon.toggleClass('fa-window-maximize', !this._isMaximized);

    const fullscreenButton = root.find('.header-button.jb-fullscreen');
    const fullscreenIcon = fullscreenButton.find('i');
    fullscreenButton.attr('data-tooltip', this._isFullscreen ? 'Exit Fullscreen' : 'Fullscreen');
    fullscreenIcon.toggleClass('fa-compress', this._isFullscreen);
    fullscreenIcon.toggleClass('fa-expand', !this._isFullscreen);
  }

  _initResizeInteractionPolish() {
    if (!this.element?.length) return;

    const handle = this.element.find('.window-resizable-handle');
    handle.off('.jbResizePolish');
    handle.on('mousedown.jbResizePolish touchstart.jbResizePolish', () => {
      this._clearWindowSizeTransition();

      if (this._isMaximized) {
        this._isMaximized = false;
        this._preMaximizePosition = null;
        this._syncWindowControlState();
      }

      this.element.addClass('jb-manual-resizing');
      $(document)
        .off('.jbResizePolishActive')
        .on('mouseup.jbResizePolishActive touchend.jbResizePolishActive touchcancel.jbResizePolishActive', () => {
          this.element?.removeClass('jb-manual-resizing');
          $(document).off('.jbResizePolishActive');
          this._syncNormalWindowConstraints();
        });
    });
  }

  /**
   * Override template based on current window mode
   * @returns {string} Path to the appropriate template
   */
  get template() {
    switch (this._windowState) {
      case 'mini':
        return 'modules/narrator-jukebox/templates/mini-player.html';
      case 'micro':
        return 'modules/narrator-jukebox/templates/micro-player.html';
      default:
        return 'modules/narrator-jukebox/templates/jukebox-app.html';
    }
  }

  // ==========================================
  // Header Buttons
  // ==========================================

  _getHeaderButtons() {
    const buttons = super._getHeaderButtons();

    if (this._windowState === 'normal') {
      buttons.unshift(
        {
          label: "Mini Mode",
          class: "jb-minimize",
          icon: "fas fa-compress",
          onclick: () => this._enterMiniMode()
        },
        {
          label: "Maximize",
          class: "jb-maximize",
          icon: "fas fa-window-maximize",
          onclick: () => this._toggleMaximize()
        },
        {
          label: "Fullscreen",
          class: "jb-fullscreen",
          icon: "fas fa-expand",
          onclick: () => this._toggleFullscreen()
        }
      );
    }

    return buttons;
  }

  async _renderOuter() {
    const html = await super._renderOuter();

    if (this._windowState === 'normal') {
      html.find('.header-button.close').attr('data-tooltip', 'Close');
      html.find('.header-button.jb-minimize').attr('data-tooltip', 'Mini Mode');
      html.find('.header-button.jb-maximize').attr('data-tooltip', 'Maximize');
      html.find('.header-button.jb-fullscreen').attr('data-tooltip', 'Fullscreen');
      this._syncWindowControlState(html);
    }

    return html;
  }

  // ==========================================
  // Window Mode Transitions (delegate to ModeManager)
  // ==========================================

  _enterMiniMode() {
    ModeManager.enterMiniMode(this);
  }

  _exitMiniMode() {
    ModeManager.exitMiniMode(this);
  }

  _enterMicroMode() {
    ModeManager.enterMicroMode(this);
  }

  _exitMicroMode() {
    ModeManager.exitMicroMode(this);
  }

  _exitMicroToNormal() {
    ModeManager.exitMicroToNormal(this);
  }

  _saveMicroPosition() {
    ModeManager.saveMicroPosition(this);
  }

  _loadMicroPosition() {
    return ModeManager.loadMicroPosition(this);
  }

  _initMicroDrag() {
    ModeManager.initMicroDrag(this);
  }

  _toggleMinimize() {
    if (this._windowState === 'mini') {
      this._exitMiniMode();
    } else {
      this._enterMiniMode();
    }
  }

  _toggleMaximize() {
    if (this._isFullscreen) {
      this._toggleFullscreen();
      return;
    }

    if (this._windowState !== 'normal') return;

    if (this._isMaximized) {
      const defaultDimensions = getInitialNormalWindowDimensions();
      const restorePosition = this._preMaximizePosition || {
        left: NORMAL_WINDOW_VIEWPORT_MARGIN,
        top: NORMAL_WINDOW_VIEWPORT_MARGIN,
        width: defaultDimensions.width,
        height: defaultDimensions.height
      };
      this._isMaximized = false;
      this._preMaximizePosition = null;
      this._setPositionWithSizeTransition(restorePosition);
    } else {
      this._preMaximizePosition = { ...this.position };
      this._isMaximized = true;
      this._setPositionWithSizeTransition(getMaximizedWindowPosition());
    }

    this._syncWindowControlState();
  }

  _toggleFullscreen() {
    if (this._windowState !== 'normal') return;

    if (this._isFullscreen) {
      this._isFullscreen = false;
      this.element.removeClass('jb-fullscreen-mode');
      const defaultDimensions = getInitialNormalWindowDimensions();
      const restorePosition = this._preFullscreenPosition || {
        left: NORMAL_WINDOW_VIEWPORT_MARGIN,
        top: NORMAL_WINDOW_VIEWPORT_MARGIN,
        width: defaultDimensions.width,
        height: defaultDimensions.height
      };
      this._preFullscreenPosition = null;
      this._setPositionWithSizeTransition(restorePosition);
    } else {
      this._preFullscreenPosition = { ...this.position };
      this._isFullscreen = true;
      this.element.addClass('jb-fullscreen-mode');
      this._setPositionWithSizeTransition(getMaximizedWindowPosition(0));
    }

    this._syncWindowControlState();
  }

  // ==========================================
  // Progress Timers (delegate to ProgressManager)
  // ==========================================

  _startProgressTimer() {
    ProgressManager.startMusicProgress(this);
  }

  _stopProgressTimer() {
    ProgressManager.stopMusicProgress(this);
  }

  _startAmbienceProgressTimer() {
    ProgressManager.startAmbienceProgress(this);
  }

  _stopAmbienceProgressTimer() {
    ProgressManager.stopAmbienceProgress(this);
  }

  // ==========================================
  // Partial Updates (delegate to PartialUpdates)
  // ==========================================

  _updateNowPlaying(track) {
    PartialUpdates.updateNowPlayingInfo(this, track);
  }

  _updateAmbienceNowPlaying(track) {
    PartialUpdates.updateAmbienceInfo(this, track);
  }

  _updatePlaybackState() {
    PartialUpdates.updatePlaybackState(this);
  }

  _updatePlayButton(btn, isPlaying) {
    PartialUpdates.updatePlayButton(btn, isPlaying);
  }

  _updateModeToggle() {
    PartialUpdates.updateModeToggle(this);
  }

  _initResponsiveState() {
    if (!this.element || !this.element.length) return;

    this._responsiveObserver?.disconnect();

    const windowElement = this.element[0];
    const container = this.element.find('.narrator-jukebox-container')[0];
    if (!windowElement || !container) return;

    const updateResponsiveClasses = () => {
      const rect = windowElement.getBoundingClientRect();
      const width = rect.width || this.position.width || 0;
      const height = rect.height || this.position.height || 0;

      container.classList.toggle('jb-app-compact', width < NORMAL_WINDOW_DIMENSIONS.compactBreakpoint);
      container.classList.toggle('jb-app-narrow', width < NORMAL_WINDOW_DIMENSIONS.narrowBreakpoint);
      container.classList.toggle('jb-app-short', height < NORMAL_WINDOW_DIMENSIONS.shortBreakpoint);
      container.classList.toggle('jb-app-tiny-height', height < NORMAL_WINDOW_DIMENSIONS.tinyHeightBreakpoint);
    };

    updateResponsiveClasses();

    if (typeof ResizeObserver !== 'undefined') {
      this._responsiveObserver = new ResizeObserver(updateResponsiveClasses);
      this._responsiveObserver.observe(windowElement);
    } else {
      window.setTimeout(updateResponsiveClasses, 0);
    }
  }

  handleStateChange(payload = {}) {
    if (!this.element || !this.element.length) return;

    const scope = payload?.scope || 'full';

    if (this._windowState !== 'normal') {
      this.render(false);
      return;
    }

    if (scope === 'health') {
      this.render(false);
      return;
    }

    if (scope === 'playback') {
      this._updateNowPlaying(this.jukebox.channels.music.currentTrack);
      this._updateAmbienceNowPlaying(this.jukebox.channels.ambience.currentTrack);
      this._updatePlaybackState();
      PartialUpdates.updateMusicVolume(this);
      PartialUpdates.updateMusicTrackRows(this);
      PartialUpdates.updateSidebarBadges(this);
      return;
    }

    if (scope === 'mode') {
      this._updateModeToggle();
      return;
    }

    if (scope === 'suggestions') {
      if (this.view === 'suggestions') {
        this._suggestionsDirty = false;
        this.render(false);
      } else {
        this._suggestionsDirty = true;
        PartialUpdates.updateSidebarBadges(this);
      }
      return;
    }

    if (scope === 'ambienceLayers' && this.view !== 'ambience') {
      PartialUpdates.updateSidebarBadges(this);
      return;
    }

    if (scope === 'soundboard' && this.view !== 'soundboard') {
      PartialUpdates.updateSidebarBadges(this);
      return;
    }

    this.render(false);
  }

  // ==========================================
  // Duration Loading
  // ==========================================

  _loadTrackDurations(html) {
    loadAndDisplayDurations(this, html);
  }

  // ==========================================
  // Dialog Methods (delegate to Dialogs)
  // ==========================================

  async showAddMusicDialog() {
    Dialogs.showAddMusicDialog({
      jukebox: this.jukebox,
      onSuccess: () => this.render()
    });
  }

  async showEditMusicDialog(id) {
    const track = this.jukebox.music.find(m => m.id === id);
    if (!track) return;

    Dialogs.showEditMusicDialog({
      trackId: id,
      jukebox: this.jukebox,
      onSuccess: () => this.render(),
      onDelete: () => this.render()
    });
  }

  async showAddAmbienceDialog() {
    Dialogs.showAddAmbienceDialog({
      jukebox: this.jukebox,
      onSuccess: () => this.render()
    });
  }

  async showEditAmbienceDialog(id) {
    const track = this.jukebox.ambience.find(a => a.id === id);
    if (!track) return;

    Dialogs.showEditAmbienceDialog({
      trackId: id,
      jukebox: this.jukebox,
      onSuccess: () => this.render(),
      onDelete: () => this.render()
    });
  }

  async showAddSoundboardDialog() {
    Dialogs.showAddSoundboardDialog({
      jukebox: this.jukebox,
      onSuccess: () => this.render()
    });
  }

  async showEditSoundboardDialog(id) {
    const sound = this.jukebox.soundboard.find(s => s.id === id);
    if (!sound) return;

    Dialogs.showEditSoundboardDialog({
      soundId: id,
      jukebox: this.jukebox,
      onSuccess: () => this.render(),
      onDelete: () => this.render()
    });
  }

  async showAddPlaylistDialog() {
    Dialogs.showAddPlaylistDialog({
      jukebox: this.jukebox,
      onSuccess: playlist => {
        if (playlist?.id) {
          this.selectedPlaylistId = playlist.id;
          this.showPlayerQueue = false;
          this.playlistSearchQuery = '';
        }
        this.render();
      }
    });
  }

  async showEditPlaylistDialog(playlistId) {
    Dialogs.showEditPlaylistDialog({
      playlistId,
      jukebox: this.jukebox,
      onSuccess: () => this.render()
    });
  }

  async showAddToPlaylistDialog(musicId) {
    Dialogs.showAddToPlaylistDialog({
      musicId,
      jukebox: this.jukebox,
      onSuccess: () => this.render()
    });
  }

  async showAddSelectedToPlaylistDialog(musicIds) {
    Dialogs.showAddSelectedToPlaylistDialog({
      musicIds,
      jukebox: this.jukebox,
      onSuccess: () => {
        this.exitSelectionMode();
        this.render();
      }
    });
  }

  async showBulkImportDialog(type = 'music') {
    Dialogs.showBulkImportDialog({
      type,
      jukebox: this.jukebox,
      onSuccess: () => this.render()
    });
  }

  async showEditMoodsDialog() {
    Dialogs.showEditMoodsDialog({
      jukebox: this.jukebox,
      music: this.jukebox.music || [],
      onSuccess: () => this.render()
    });
  }

  async showSavePresetDialog() {
    Dialogs.showSavePresetDialog({
      jukebox: this.jukebox,
      onSuccess: () => this.render()
    });
  }

  // ==========================================
  // Suggestions
  // ==========================================

  _getSuggestionIndex(identifier, suggestions = null) {
    const list = suggestions || game.settings.get(JUKEBOX.ID, "suggestions") || [];
    const key = String(identifier ?? '');
    let index = list.findIndex(suggestion => getSuggestionKey(suggestion) === key);

    if (index === -1 && /^\d+$/.test(key)) {
      index = Number(key);
    }

    return index >= 0 && index < list.length ? index : -1;
  }

  _getSuggestionEntry(identifier) {
    const suggestions = game.settings.get(JUKEBOX.ID, "suggestions") || [];
    const index = this._getSuggestionIndex(identifier, suggestions);
    if (index === -1) {
      return { suggestions, index: -1, suggestion: null, key: '' };
    }

    const suggestion = normalizeSuggestedTrack(suggestions[index]);
    return {
      suggestions,
      index,
      suggestion,
      key: getSuggestionKey(suggestions[index])
    };
  }

  async approveSuggestion(identifier) {
    const { suggestions, index, suggestion, key } = this._getSuggestionEntry(identifier);
    if (!suggestion) {
      ui.notifications.warn('This suggestion is no longer available.');
      return;
    }

    if (!suggestion.url) {
      ui.notifications.error(`Cannot approve "${suggestion.name || 'suggestion'}": missing track URL.`);
      return;
    }

    let duplicate = null;
    try {
      duplicate = findDuplicateTrack(this.jukebox, 'music', suggestion);
    } catch (err) {
      duplicate = null;
    }

    if (duplicate) {
      ui.notifications.warn(`"${suggestion.name}" is already in your library as "${duplicate.name || 'a track'}".`);
      return;
    }

    let addedTrack = null;
    try {
      addedTrack = await this.jukebox.addMusic({
        name: suggestion.name,
        url: suggestion.url,
        source: suggestion.source,
        tags: suggestion.tags,
        thumbnail: suggestion.thumbnail
      });
    } catch (err) {
      ui.notifications.error(`Could not approve "${suggestion.name}": ${err.message}`);
      return;
    }

    suggestions.splice(index, 1);
    await game.settings.set(JUKEBOX.ID, "suggestions", suggestions);

    if (this.selectedSuggestionKey === key) {
      const nextSuggestion = suggestions[index] || suggestions[index - 1] || null;
      this.selectedSuggestionKey = nextSuggestion ? getSuggestionKey(nextSuggestion) : null;
    }

    ui.notifications.info(`Added "${suggestion.name}" to your library`);
    Hooks.call('narratorJukeboxStateChanged', { scope: 'suggestions', addedTrackId: addedTrack?.id });
  }

  async rejectSuggestion(identifier) {
    const { suggestions, index, suggestion, key } = this._getSuggestionEntry(identifier);
    if (!suggestion) {
      ui.notifications.warn('This suggestion is no longer available.');
      return;
    }

    suggestions.splice(index, 1);
    await game.settings.set(JUKEBOX.ID, "suggestions", suggestions);

    if (this.selectedSuggestionKey === key) {
      const nextSuggestion = suggestions[index] || suggestions[index - 1] || null;
      this.selectedSuggestionKey = nextSuggestion ? getSuggestionKey(nextSuggestion) : null;
    }

    Hooks.call('narratorJukeboxStateChanged', { scope: 'suggestions' });
  }

  async previewSuggestion(identifier) {
    const { suggestion, key } = this._getSuggestionEntry(identifier);
    if (!suggestion) {
      ui.notifications.warn('This suggestion is no longer available.');
      return;
    }

    if (!suggestion.url) {
      ui.notifications.error(`Cannot preview "${suggestion.name || 'suggestion'}": missing track URL.`);
      return;
    }

    try {
      const previewTrack = {
        ...suggestion,
        id: suggestion.id || key,
        hidden: false
      };

      this.jukebox.currentPlaylist = null;
      this.selectedSuggestionKey = key;
      this.jukebox.isPlaying = true;
      await this.jukebox.channels.music.play(previewTrack);
      ui.notifications.info(`Previewing suggestion: ${suggestion.name}`);
      Hooks.call('narratorJukeboxStateChanged', { scope: 'playback' });
      if (this.view === 'suggestions') this.render(false);
    } catch (err) {
      this.jukebox.isPlaying = false;
      ui.notifications.error(`Preview failed: ${err.message}`);
    }
  }

  async copySuggestionUrl(identifier) {
    const { suggestion } = this._getSuggestionEntry(identifier);
    if (!suggestion) {
      ui.notifications.warn('This suggestion is no longer available.');
      return;
    }

    if (!suggestion.url) {
      ui.notifications.warn('This suggestion has no source URL to copy.');
      return;
    }

    await copyTextToClipboard(suggestion.url);
    ui.notifications.info('Suggestion URL copied to clipboard.');
  }

  // ==========================================
  // Multi-Selection Methods
  // ==========================================

  /**
   * Get the active selection Set for the current view
   * @returns {Set} The selection Set for the current view
   * @private
   */
  _getActiveSelectionSet() {
    if (this.view === 'ambience') return this.selectedAmbienceIds;
    if (this.view === 'soundboard') return this.selectedSoundboardIds;
    return this.selectedMusicIds;
  }

  /**
   * Toggle selection mode on/off
   */
  toggleSelectionMode() {
    this.selectionMode = !this.selectionMode;
    if (!this.selectionMode) {
      this._getActiveSelectionSet().clear();
    }
    this.render();
  }

  /**
   * Exit selection mode and clear all selections
   */
  exitSelectionMode() {
    this.selectionMode = false;
    this.selectedMusicIds.clear();
    this.selectedAmbienceIds.clear();
    this.selectedSoundboardIds.clear();
    this.render();
  }

  /**
   * Toggle selection of a single item
   * @param {string} id - Item ID
   */
  toggleTrackSelection(id) {
    const set = this._getActiveSelectionSet();
    if (set.has(id)) {
      set.delete(id);
    } else {
      set.add(id);
    }
    this._updateSelectionUI();
  }

  /**
   * Select a single item (for Ctrl+Click when not in selection mode)
   * @param {string} id - Item ID
   */
  selectTrack(id) {
    if (!this.selectionMode) {
      this.selectionMode = true;
    }
    this._getActiveSelectionSet().add(id);
    this.render();
  }

  /**
   * Select a range of items (for Shift+Click)
   * @param {string} id - Target item ID
   * @param {string[]} visibleIds - Array of currently visible item IDs in order
   */
  selectRange(id, visibleIds) {
    const set = this._getActiveSelectionSet();
    if (set.size === 0) {
      set.add(id);
      this._updateSelectionUI();
      return;
    }

    const lastSelectedId = [...set].reverse().find(sid => visibleIds.includes(sid));
    if (!lastSelectedId) {
      set.add(id);
      this._updateSelectionUI();
      return;
    }

    const startIndex = visibleIds.indexOf(lastSelectedId);
    const endIndex = visibleIds.indexOf(id);

    if (startIndex === -1 || endIndex === -1) return;

    const [from, to] = startIndex < endIndex ? [startIndex, endIndex] : [endIndex, startIndex];

    for (let i = from; i <= to; i++) {
      set.add(visibleIds[i]);
    }

    this._updateSelectionUI();
  }

  /**
   * Select all currently visible items
   * @param {string[]} visibleIds - Array of visible item IDs
   */
  selectAllVisible(visibleIds) {
    const set = this._getActiveSelectionSet();
    visibleIds.forEach(id => set.add(id));
    this._updateSelectionUI();
  }

  /**
   * Deselect all items in the current view
   */
  deselectAll() {
    this._getActiveSelectionSet().clear();
    this._updateSelectionUI();
  }

  /**
   * Check if an item is selected
   * @param {string} id - Item ID
   * @returns {boolean}
   */
  isTrackSelected(id) {
    return this._getActiveSelectionSet().has(id);
  }

  /**
   * Get array of selected item IDs for the current view
   * @returns {string[]}
   */
  getSelectedTrackIds() {
    return [...this._getActiveSelectionSet()];
  }

  /**
   * Set selection state for multiple items at once.
   * @param {string[]} ids - Item IDs
   * @param {boolean} selected - Whether the items should be selected
   */
  setTrackSelection(ids, selected = true) {
    const set = this._getActiveSelectionSet();

    for (const id of ids) {
      if (!id) continue;
      if (selected) {
        set.add(id);
      } else {
        set.delete(id);
      }
    }

    this._updateSelectionUI();
  }

  /**
   * Toggle selection state for a group of items.
   * If every item is already selected, deselect them all; otherwise select them all.
   * @param {string[]} ids - Item IDs
   */
  toggleTrackGroup(ids) {
    const uniqueIds = [...new Set((ids || []).filter(Boolean))];
    if (!uniqueIds.length) return;

    const set = this._getActiveSelectionSet();
    const allSelected = uniqueIds.every(id => set.has(id));

    uniqueIds.forEach(id => {
      if (allSelected) {
        set.delete(id);
      } else {
        set.add(id);
      }
    });

    this._updateSelectionUI();
  }

  /**
   * Get root-level visible IDs from the current DOM, excluding items inside folders.
   * Used by Select All and Ctrl+A so folders behave as their own selectable groups.
   * @returns {string[]}
   * @private
   */
  _getRootSelectionIdsFromDOM() {
    if (!this.element || !this.element.length) return [];

    if (this.view === 'library') {
      return this.element.find('#view-library .track-list > .track-row[data-music-id]')
        .map((_, el) => $(el).data('musicId'))
        .get()
        .filter(Boolean);
    }

    if (this.view === 'ambience') {
      return this.element.find('#view-ambience .ambience-cards-panel > .ambience-layer-grid > .ambience-card[data-ambience-id], #view-ambience > .ambience-layer-grid > .ambience-card[data-ambience-id]')
        .map((_, el) => $(el).data('ambienceId'))
        .get()
        .filter(Boolean);
    }

    if (this.view === 'soundboard') {
      return this.element.find('#view-soundboard .soundboard-cards-panel > .soundboard-grid > .soundboard-card[data-sound-id], #view-soundboard > .soundboard-grid > .soundboard-card[data-sound-id]')
        .map((_, el) => $(el).data('soundId'))
        .get()
        .filter(Boolean);
    }

    return [];
  }

  /**
   * Get item IDs contained within a folder section for the current view.
   * @param {HTMLElement|JQuery} section - Folder section element
   * @returns {string[]}
   * @private
   */
  _getFolderItemIdsFromSection(section) {
    const root = $(section);

    if (this.view === 'library') {
      return root.find('.track-row[data-music-id]')
        .map((_, el) => $(el).data('musicId'))
        .get()
        .filter(Boolean);
    }

    if (this.view === 'ambience') {
      return root.find('.ambience-card[data-ambience-id]')
        .map((_, el) => $(el).data('ambienceId'))
        .get()
        .filter(Boolean);
    }

    if (this.view === 'soundboard') {
      return root.find('.soundboard-card[data-sound-id]')
        .map((_, el) => $(el).data('soundId'))
        .get()
        .filter(Boolean);
    }

    return [];
  }

  /**
   * Update folder selection affordances for the current view.
   * @param {Set<string>} set - Active selection set
   * @private
   */
  _updateFolderSelectionUI(set) {
    this.element.find('.folder-section').each((_, section) => {
      const ids = this._getFolderItemIdsFromSection(section);
      const selectedCount = ids.filter(id => set.has(id)).length;
      const allSelected = ids.length > 0 && selectedCount === ids.length;
      const partiallySelected = selectedCount > 0 && selectedCount < ids.length;

      const header = $(section).find('.folder-header').first();
      const button = header.find('.folder-select-btn').first();

      header.toggleClass('is-selected', allSelected);
      header.toggleClass('is-partial', partiallySelected);

      if (!button.length) return;

      button.toggleClass('selected', allSelected);
      button.toggleClass('partial', partiallySelected);
      button.attr('aria-pressed', allSelected ? 'true' : 'false');

      const icon = button.find('i');
      icon.removeClass('fa-square fa-square-check fa-square-minus');
      icon.addClass(allSelected ? 'fa-square-check' : partiallySelected ? 'fa-square-minus' : 'fa-square');

      const actionLabel = allSelected ? 'Deselect folder' : partiallySelected ? 'Select remaining items in folder' : 'Select folder';
      const detailLabel = ids.length
        ? `${selectedCount}/${ids.length} selected`
        : 'Empty folder';

      button.attr('aria-label', actionLabel);
      button.attr('data-tooltip', `${actionLabel} (${detailLabel})`);
      button.attr('title', `${actionLabel} (${detailLabel})`);
    });
  }

  /**
   * Update selection UI without full re-render (for performance)
   * @private
   */
  _updateSelectionUI() {
    if (!this.element || !this.element.length) return;

    const set = this._getActiveSelectionSet();
    const count = set.size;

    if (this.view === 'library') {
      // Music: update checkboxes and row highlights
      this.element.find('.track-select-checkbox').each((i, el) => {
        const id = $(el).closest('.track-row').data('musicId');
        el.checked = set.has(id);
      });
      this.element.find('.track-row').each((i, el) => {
        const id = $(el).data('musicId');
        $(el).toggleClass('selected', set.has(id));
      });
      this._updateFolderSelectionUI(set);

      // Update select all checkbox
      const rootIds = this._getRootSelectionIdsFromDOM();
      const selectedRootCount = rootIds.filter(id => set.has(id)).length;
      const selectAllCheckbox = this.element.find('.select-all-checkbox');
      if (selectAllCheckbox.length) {
        selectAllCheckbox.prop('checked', rootIds.length > 0 && selectedRootCount === rootIds.length);
        selectAllCheckbox.prop('indeterminate', selectedRootCount > 0 && selectedRootCount < rootIds.length);
      }
    } else if (this.view === 'ambience') {
      // Ambience: update card checkboxes and highlights
      this.element.find('.amb-select-checkbox').each((i, el) => {
        const id = $(el).closest('.ambience-card').data('ambienceId');
        el.checked = set.has(id);
      });
      this.element.find('.ambience-card').each((i, el) => {
        const id = $(el).data('ambienceId');
        $(el).toggleClass('selected', set.has(id));
      });
      this._updateFolderSelectionUI(set);
    } else if (this.view === 'soundboard') {
      // Soundboard: update card checkboxes and highlights
      this.element.find('.sb-select-checkbox').each((i, el) => {
        const id = $(el).closest('.soundboard-card').data('soundId');
        el.checked = set.has(id);
      });
      this.element.find('.soundboard-card').each((i, el) => {
        const id = $(el).data('soundId');
        $(el).toggleClass('selected', set.has(id));
      });
      this._updateFolderSelectionUI(set);
    }

    // Update toolbar (shared)
    const toolbar = this.element.find('.selection-toolbar');
    if (count > 0) {
      toolbar.addClass('visible');
      toolbar.find('.selection-count').text(`${count} selected`);
    } else {
      toolbar.removeClass('visible');
    }

    const tableSelectionLabel = count === 1 ? '1 selected' : `${count} selected`;
    this.element.find('.library-selection-count-inline').text(tableSelectionLabel);
    this.element.find('.library-selection-count-badge').text(count);
    this.element.find('.library-table-actions .selection-mode-btn').toggleClass('has-selection', count > 0);
    this.element.find('.library-table-actions .btn-add-to-playlist, .library-table-actions .btn-move-to-folder, .library-table-actions .btn-clear-selection, .library-table-actions .btn-bulk-tag, .library-table-actions .btn-bulk-delete')
      .prop('disabled', count === 0);
  }

  // ==========================================
  // Helper Methods
  // ==========================================

  formatTime(seconds) {
    return formatTime(seconds);
  }

  _getNextTrack() {
    const nextManualEntry = this.jukebox.getManualQueue?.()[0];
    if (nextManualEntry?.musicId) {
      return this.jukebox.music.find(m => m.id === nextManualEntry.musicId) || null;
    }

    if (this.jukebox.shuffle) return null;
    if (this.jukebox.musicRepeatMode === MUSIC_REPEAT_MODES.TRACK) return null;

    const currentId = this.jukebox.channels.music.currentTrack?.id;
    if (!currentId) return null;

    const playlistIds = (this.jukebox.currentPlaylist?.musicIds || [])
      .filter(id => this.jukebox.music?.some(track => track.id === id));
    if (playlistIds.length > 1 && playlistIds.includes(currentId)) {
      const currentIndex = playlistIds.indexOf(currentId);
      let nextIndex = currentIndex + 1;

      if (nextIndex >= playlistIds.length) {
        if (this.jukebox.musicRepeatMode === MUSIC_REPEAT_MODES.QUEUE || this.jukebox.currentPlaylist?.loop) {
          nextIndex = 0;
        } else {
          return null;
        }
      }

      const nextId = playlistIds[nextIndex];
      return this.jukebox.music.find(m => m.id === nextId) || null;
    }

    const sourceContext = this.jukebox.currentMusicSourceContext;
    const sourceIds = (sourceContext?.musicIds || [])
      .filter(id => this.jukebox.music?.some(track => track.id === id));
    if (sourceIds.length && sourceIds.includes(currentId)) {
      const currentIndex = sourceIds.indexOf(currentId);
      let nextIndex = currentIndex + 1;

      if (nextIndex >= sourceIds.length) {
        if (this.jukebox.musicRepeatMode === MUSIC_REPEAT_MODES.QUEUE) {
          nextIndex = 0;
        } else {
          return null;
        }
      }

      const nextId = sourceIds[nextIndex];
      return this.jukebox.music.find(m => m.id === nextId) || null;
    }

    if (this.jukebox.music && this.jukebox.music.length > 1) {
      const currentIndex = this.jukebox.music.findIndex(m => m.id === currentId);
      let nextIndex = currentIndex + 1;

      if (nextIndex >= this.jukebox.music.length) {
        if (this.jukebox.musicRepeatMode === MUSIC_REPEAT_MODES.QUEUE) {
          nextIndex = 0;
        } else {
          return null;
        }
      }

      return this.jukebox.music[nextIndex] || null;
    }

    return null;
  }

  _getMusicRepeatPresentation() {
    const mode = this.jukebox.musicRepeatMode || (this.jukebox.musicLoop ? MUSIC_REPEAT_MODES.TRACK : MUSIC_REPEAT_MODES.OFF);

    switch (mode) {
      case MUSIC_REPEAT_MODES.TRACK:
        return {
          mode,
          active: true,
          isTrack: true,
          isQueue: false,
          className: 'repeat-track',
          badge: '1',
          label: 'Repeat Track',
          tooltip: 'Repeat Track - replay only the current track when it ends'
        };
      case MUSIC_REPEAT_MODES.QUEUE:
        return {
          mode,
          active: true,
          isTrack: false,
          isQueue: true,
          className: 'repeat-queue',
          badge: 'Q',
          label: 'Repeat Queue',
          tooltip: 'Repeat Queue - loop the current source queue (playlist, folder, or music library); manual queue items play once first'
        };
      default:
        return {
          mode: MUSIC_REPEAT_MODES.OFF,
          active: false,
          isTrack: false,
          isQueue: false,
          className: 'repeat-off',
          badge: '',
          label: 'Repeat Off',
          tooltip: 'Repeat Off - play the current source once, then stop at the end'
        };
    }
  }

  _getPlayerQueue(music) {
    const currentTrack = this.jukebox.channels.music.currentTrack;
    const currentPlaylist = this.jukebox.currentPlaylist;
    const currentTrackId = currentTrack?.id || null;
    const playlists = this.jukebox.playlists || [];
    const musicFolders = this.jukebox.musicFolders || [];
    const musicById = new Map((music || []).map(track => [track.id, track]));
    const folderById = new Map(musicFolders.map(folder => [folder.id, folder]));
    const returnContext = this.jukebox.getManualQueueReturnContext?.() || null;

    const decorateTrack = (track, index = 0) => {
      if (!track) return null;
      const folder = track.folderId ? folderById.get(track.folderId) : null;
      const playlistMembership = playlists
        .filter(playlist => (playlist.musicIds || []).includes(track.id))
        .map(playlist => ({ id: playlist.id, name: playlist.name }));

      return {
        ...track,
        sourceLabel: track.source === 'youtube' ? 'YouTube' : 'Local',
        sourceIcon: track.source === 'youtube' ? 'fab fa-youtube' : 'fas fa-file-audio',
        folderName: folder?.name || 'Unfiled',
        folderColor: folder?.color || '#ffb13d',
        folderIcon: folder?.icon || 'fas fa-inbox',
        playlists: playlistMembership,
        tagSummary: Array.isArray(track.tags) && track.tags.length ? track.tags.slice(0, 3).join(', ') : 'No tags',
        fallbackClass: `fallback-${(index % 6) + 1}`
      };
    };

    const contextPlaylist = returnContext?.sourceType === 'playlist'
      ? playlists.find(playlist => playlist.id === returnContext.sourceId)
      : currentPlaylist;
    const contextAnchorId = returnContext?.anchorTrackId || currentTrackId;
    const playlistTracks = (contextPlaylist?.musicIds || [])
      .map(id => musicById.get(id))
      .filter(Boolean);

    const playlistHasContext = !!(playlistTracks.length && (
      returnContext?.sourceType === 'playlist' ||
      (!currentTrackId || playlistTracks.some(track => track.id === currentTrackId))
    ));
    const activeSourceContext = !playlistHasContext
      ? (returnContext?.sourceType === 'library' && Array.isArray(returnContext.musicIds)
        ? returnContext
        : this.jukebox.currentMusicSourceContext)
      : null;
    const contextSourceTracks = (activeSourceContext?.musicIds || [])
      .map(id => musicById.get(id))
      .filter(Boolean);
    const sourceTracks = playlistHasContext
      ? playlistTracks
      : contextSourceTracks.length
        ? contextSourceTracks
        : music;
    const sourceIds = sourceTracks.map(track => track.id);
    const sourceName = playlistHasContext
      ? contextPlaylist.name
      : contextSourceTracks.length
        ? activeSourceContext.sourceName || 'Music Library'
        : 'Music Library';
    const sourceType = playlistHasContext
      ? 'Playlist'
      : activeSourceContext?.sourceSubType === 'folder'
        ? 'Folder'
        : activeSourceContext?.sourceSubType === 'unfiled'
          ? 'Unfiled'
          : activeSourceContext?.sourceSubType === 'filtered'
            ? 'Filtered Library'
            : 'Library';
    const currentIndex = contextAnchorId ? sourceIds.indexOf(contextAnchorId) : -1;
    const nextTrack = this._getNextTrack();
    const repeat = this._getMusicRepeatPresentation();
    const playlistLoopActive = !!(playlistHasContext && contextPlaylist?.loop);
    const repeatLabel = repeat.isTrack
      ? repeat.label
      : repeat.isQueue
        ? repeat.label
        : playlistLoopActive
          ? 'Playlist Loop'
          : '';

    const manualEntries = (this.jukebox.getManualQueue?.() || [])
      .map((entry, index) => {
        const track = decorateTrack(musicById.get(entry.musicId), index);
        if (!track) return null;
        return {
          ...track,
          queueEntryId: entry.entryId,
          queuePosition: index + 1,
          manualQueueIndex: index,
          addedBy: entry.addedBy || 'GM',
          addedAt: entry.addedAt || 0,
          queueSourceName: entry.sourceName || 'Music Library',
          queueSourceType: entry.sourceType === 'playlist'
            ? 'Playlist'
            : entry.sourceSubType === 'folder'
              ? 'Folder'
              : entry.sourceSubType === 'unfiled'
                ? 'Unfiled'
                : entry.sourceSubType === 'filtered'
                  ? 'Filtered Library'
                  : 'Library',
          isManual: true,
          isNextManual: index === 0,
          isLaterManual: index > 0
        };
      })
      .filter(Boolean);
    const nextManualTrack = manualEntries[0] || null;
    const laterManualTracks = manualEntries.slice(1);
    const queuedCountByMusicId = manualEntries.reduce((counts, entry) => {
      counts[entry.id] = (counts[entry.id] || 0) + 1;
      return counts;
    }, {});

    const tracks = sourceTracks
      .map((track, index) => ({
        ...decorateTrack(track, index),
        queuePosition: index + 1,
        isActive: track.id === currentTrackId,
        isPlaying: track.id === currentTrackId && this.jukebox.isPlaying,
        isUpcoming: currentIndex === -1 ? index > 0 : index > currentIndex,
        isPlayed: currentIndex !== -1 && index < currentIndex,
        isNext: !!nextTrack && track.id === nextTrack.id
      }));
    const sourceLooping = repeat.isQueue || playlistLoopActive;
    const afterQueueTracks = [];
    const maxAfterQueue = Math.min(sourceTracks.length, 6);

    for (let offset = 1; offset <= maxAfterQueue; offset += 1) {
      if (!sourceTracks.length) break;
      let index = (currentIndex === -1 ? -1 : currentIndex) + offset;
      if (index >= sourceTracks.length) {
        if (!sourceLooping) break;
        index %= sourceTracks.length;
      }
      const track = sourceTracks[index];
      if (!track || track.id === contextAnchorId) break;
      const decorated = decorateTrack(track, index);
      if (decorated) {
        afterQueueTracks.push({
          ...decorated,
          queuePosition: afterQueueTracks.length + 1,
          isNextSource: afterQueueTracks.length === 0 && !nextManualTrack
        });
      }
    }

    const sourceSearchQuery = (this.queueSearchQuery || '').trim();
    const sourceSearchLower = sourceSearchQuery.toLowerCase();
    const sourcePanelTracks = (music || [])
      .filter(track => {
        if (!sourceSearchLower) return true;
        return [
          track.name,
          track.source,
          ...(Array.isArray(track.tags) ? track.tags : [])
        ].some(value => String(value || '').toLowerCase().includes(sourceSearchLower));
      })
      .slice(0, 18)
      .map((track, index) => ({
        ...decorateTrack(track, index),
        queuedCount: queuedCountByMusicId[track.id] || 0,
        isCurrent: track.id === currentTrackId,
        isNextManual: nextManualTrack?.id === track.id
      }));

    return {
      sourceName,
      sourceType,
      sourcePlaylistId: playlistHasContext ? contextPlaylist.id : null,
      tracks,
      manualEntries,
      nextManualTrack,
      laterManualTracks,
      afterQueueTracks,
      sourcePanelTracks,
      sourceSearchQuery,
      sourceSearchActive: !!sourceSearchQuery,
      manualCount: manualEntries.length,
      afterQueueCount: afterQueueTracks.length,
      currentTrack,
      nextTrack,
      currentIndex,
      isShuffle: this.jukebox.shuffle,
      repeatMode: repeat.mode,
      repeatLabel,
      isRepeatTrack: repeat.isTrack,
      isRepeatQueue: repeat.isQueue,
      isLooping: repeat.active || playlistLoopActive,
      hasManualQueue: manualEntries.length > 0,
      hasCurrentTrack: !!currentTrack,
      hasTracks: tracks.length > 0 || manualEntries.length > 0
    };
  }

  _durationToSeconds(value) {
    if (typeof value === 'number' && Number.isFinite(value)) {
      return Math.max(0, Math.floor(value));
    }

    if (typeof value !== 'string') return null;

    const normalized = value.trim();
    if (!normalized || normalized === '--:--') return null;

    if (/^\d+(\.\d+)?$/.test(normalized)) {
      return Math.max(0, Math.floor(Number(normalized)));
    }

    const parts = normalized.split(':').map(part => Number(part));
    if (!parts.length || parts.some(part => !Number.isFinite(part))) return null;

    return parts.reduce((total, part) => (total * 60) + part, 0);
  }

  _formatPlaylistDuration(tracks) {
    let totalSeconds = 0;
    let hasDuration = false;

    for (const track of tracks) {
      const seconds = this._durationToSeconds(track?.duration);
      if (seconds === null) continue;
      totalSeconds += seconds;
      hasDuration = true;
    }

    if (!hasDuration) return '';

    const totalMinutes = Math.max(1, Math.floor(totalSeconds / 60));
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;

    if (hours > 0) {
      return minutes > 0 ? `${hours} hr ${minutes} min` : `${hours} hr`;
    }

    return `${totalMinutes} min`;
  }

  // ==========================================
  // Mini Mode Filter Helpers
  // ==========================================

  _getMiniTrackPresentation(track) {
    const tags = Array.isArray(track?.tags)
      ? track.tags.map(tag => String(tag || '').trim()).filter(Boolean)
      : [];
    const duration = this._getDisplayDuration(track);

    return {
      tags,
      miniTags: tags.slice(0, 3),
      tagSummary: tags.length ? tags.join(', ') : 'No tags',
      extraTagCount: Math.max(0, tags.length - 3),
      isFavorite: tags.some(tag => normalizeTagValue(tag) === 'favorite'),
      duration
    };
  }

  _getDisplayDuration(track) {
    const storedDuration = track?.duration;
    if (typeof storedDuration === 'number' && Number.isFinite(storedDuration) && storedDuration > 0) {
      return formatTime(storedDuration);
    }

    if (typeof storedDuration === 'string') {
      const trimmed = storedDuration.trim();
      if (trimmed && trimmed !== '--:--') return trimmed;
    }

    const cachedDuration = Number(track?.cachedDuration);
    if (Number.isFinite(cachedDuration) && cachedDuration > 0) {
      return formatTime(cachedDuration);
    }

    return '';
  }

  _getMiniFilteredMusic(music) {
    const query = this._miniSearchQuery?.toLowerCase()?.trim() || '';
    const currentTrackId = this.jukebox.channels.music.currentTrack?.id;
    const folderFiltered = this._filterMiniItemsByFolder(
      music,
      this.jukebox.musicFolders || [],
      this.libraryFolderFilter
    );

    const filtered = folderFiltered.filter(track => {
      if (!query) return true;
      return String(track.name || '').toLowerCase().includes(query) ||
             (track.tags || []).some(t => String(t || '').toLowerCase().includes(query));
    });

    return filtered.slice(0, this._miniDisplayLimit).map(track => ({
      ...track,
      ...this._getMiniTrackPresentation(track),
      isActive: track.id === currentTrackId,
      isPlaying: track.id === currentTrackId && this.jukebox.isPlaying
    }));
  }

  _getMiniFilteredAmbience(ambience) {
    const query = this._miniSearchQuery?.toLowerCase()?.trim() || '';
    const currentAmbienceId = this.jukebox.channels.ambience.currentTrack?.id;
    const folderFiltered = this._filterMiniItemsByFolder(
      ambience,
      this.jukebox.ambienceFolders || [],
      this.ambienceFolderFilter
    );

    const filtered = folderFiltered.filter(track => {
      if (!query) return true;
      return String(track.name || '').toLowerCase().includes(query) ||
             (track.tags || []).some(t => String(t || '').toLowerCase().includes(query));
    });

    return filtered.slice(0, this._miniDisplayLimit).map(track => ({
      ...track,
      ...this._getMiniTrackPresentation(track),
      isActive: track.id === currentAmbienceId,
      isPlaying: track.id === currentAmbienceId && this.jukebox.isAmbiencePlaying,
      // Layer Mixer data
      isLayerActive: this.jukebox.isAmbienceLayerActive(track.id),
      layerVolume: Math.round((this.jukebox.getAmbienceLayerVolume(track.id) ?? 0.8) * 100)
    }));
  }

  /**
   * Get active ambience layers with full track data for mini mode display
   */
  _getMiniActiveAmbienceLayers(ambience) {
    const activeLayers = this.jukebox.getActiveAmbienceLayers();
    return activeLayers.map(layer => {
      const track = ambience.find(a => a.id === layer.trackId);
      return {
        ...layer,
        name: track?.name || 'Unknown',
        thumbnail: track?.thumbnail || null
      };
    });
  }

  _getActiveAmbienceLayers(ambience) {
    const activeLayers = this.jukebox.getActiveAmbienceLayers?.() || [];

    return activeLayers.map(layer => {
      const track = ambience.find(a => a.id === layer.trackId) || layer.track || {};
      const issue = this.jukebox.getAmbienceLayerIssue?.(layer.trackId) || null;
      const tags = Array.isArray(track.tags) ? track.tags : [];
      const volume = Number.isFinite(layer.volume)
        ? layer.volume
        : (this.jukebox.getAmbienceLayerVolume?.(layer.trackId) ?? 0.8);

      return {
        ...track,
        trackId: layer.trackId,
        id: layer.trackId,
        name: track.name || 'Unknown ambience',
        thumbnail: track.thumbnail || null,
        source: track.source || 'local',
        tags,
        layerVolume: Math.round(volume * 100),
        layerIssue: issue,
        layerIssueSummary: this._summarizeAmbienceIssue(issue)
      };
    });
  }

  _summarizeAmbienceIssue(issue) {
    if (!issue) return null;

    switch (issue.reason) {
      case 'embed_not_allowed':
        return 'YouTube embed blocked';
      case 'autoplay_blocked':
        return 'Waiting for audio unlock';
      case 'video_not_found':
        return 'Video unavailable';
      default:
        return issue.message || 'Playback issue detected';
    }
  }

  _getMiniFilteredSoundboard(soundboard) {
    const query = this._miniSearchQuery?.toLowerCase()?.trim() || '';
    const folderFiltered = this._filterMiniItemsByFolder(
      soundboard,
      this.jukebox.soundboardFolders || [],
      this.soundboardFolderFilter
    );

    const filtered = folderFiltered.filter(sound => {
      if (!query) return true;
      return String(sound.name || '').toLowerCase().includes(query);
    });

    return filtered.slice(0, this._miniDisplayLimit).map(sound => {
      const activeState = this.jukebox.activeSoundboardSounds.get(sound.id);
      const interval = getSoundboardIntervalSettings(sound);
      const isRandomIntervalActive = !!activeState?.isRandomInterval;
      const isIntervalWaiting = isRandomIntervalActive && !!activeState?.isIntervalWaiting;

      return {
        ...sound,
        isPlaying: !!activeState,
        isAudible: !!activeState && !isIntervalWaiting,
        isLooping: activeState ? !!activeState.isLooping : (!!sound.loop && !interval.enabled),
        isPreview: activeState?.isPreview || false,
        randomIntervalEnabled: interval.enabled,
        randomIntervalLabel: formatIntervalLabel(interval),
        isRandomIntervalActive,
        isIntervalWaiting,
        nextIntervalLabel: formatRemainingInterval(activeState?.nextFireAt)
      };
    });
  }

  _filterMiniItemsByFolder(items, folders, activeFolderFilter) {
    const folderFilter = activeFolderFilter || 'all';
    if (folderFilter === 'all') return items || [];

    const validFolderIds = new Set((folders || []).map(folder => folder.id));
    if (folderFilter === 'unfiled') {
      return (items || []).filter(item => !item.folderId || !validFolderIds.has(item.folderId));
    }

    if (!validFolderIds.has(folderFilter)) return items || [];
    return (items || []).filter(item => item.folderId === folderFilter);
  }

  /**
   * Get tracks in the current playlist queue for mini mode display
   */
  _getMiniQueueTracks(music) {
    const manualEntries = this.jukebox.getManualQueue?.() || [];
    const playlist = this.jukebox.currentPlaylist;
    const currentTrackId = this.jukebox.channels.music.currentTrack?.id;
    const query = this._miniSearchQuery?.toLowerCase()?.trim() || '';

    if (manualEntries.length) {
      return manualEntries
        .map((entry, index) => {
          const track = music.find(m => m.id === entry.musicId);
          if (!track) return null;
          return {
            ...track,
            ...this._getMiniTrackPresentation(track),
            queueEntryId: entry.entryId,
            queuePosition: index + 1,
            queueSourceName: entry.sourceName || 'Music Library',
            isManual: true,
            isActive: track.id === currentTrackId,
            isPlaying: track.id === currentTrackId && this.jukebox.isPlaying,
            isUpcoming: true,
            isPlayed: false
          };
        })
        .filter(Boolean)
        .filter(track => {
          if (!query) return true;
          return track.name.toLowerCase().includes(query) ||
            (track.tags || []).some(t => t.toLowerCase().includes(query));
        });
    }

    if (!playlist || !playlist.musicIds) return [];

    // Get tracks in playlist order
    let queueTracks = playlist.musicIds
      .map(id => music.find(m => m.id === id))
      .filter(t => t);

    // Apply search filter if any
    if (query) {
      queueTracks = queueTracks.filter(track =>
        track.name.toLowerCase().includes(query) ||
        (track.tags || []).some(t => t.toLowerCase().includes(query))
      );
    }

    // Find current track index
    const currentIndex = currentTrackId
      ? playlist.musicIds.indexOf(currentTrackId)
      : -1;

    return queueTracks.map((track, index) => {
      const originalIndex = playlist.musicIds.indexOf(track.id);
      return {
        ...track,
        ...this._getMiniTrackPresentation(track),
        isActive: track.id === currentTrackId,
        isPlaying: track.id === currentTrackId && this.jukebox.isPlaying,
        queuePosition: originalIndex + 1,
        isUpcoming: originalIndex > currentIndex,
        isPlayed: originalIndex < currentIndex
      };
    });
  }

  // ==========================================
  // Folder Grouping Helper
  // ==========================================

  _groupByFolders(tracks, folders, hasActiveFilter) {
    const folderMap = new Map(folders.map(f => [f.id, { folder: f, tracks: [], collapsed: this.collapsedFolders.has(f.id) }]));
    const unfiled = [];

    for (const track of tracks) {
      if (track.folderId && folderMap.has(track.folderId)) {
        folderMap.get(track.folderId).tracks.push(track);
      } else {
        unfiled.push(track);
      }
    }

    // When filtering, hide empty folders; when not filtering, show all folders
    const groups = [...folderMap.values()]
      .sort((a, b) => a.folder.order - b.folder.order)
      .filter(g => hasActiveFilter ? g.tracks.length > 0 : true);

    return { unfiled, groups };
  }

  _getLibraryCoverItems(tracks, count = 8, fallbackIconsOverride = null) {
    const source = [...(tracks || [])]
      .filter(track => track?.thumbnail)
      .slice(-count)
      .reverse();

    const fallbackIcons = fallbackIconsOverride || ['fa-dragon', 'fa-mountain', 'fa-moon', 'fa-fire', 'fa-water', 'fa-tree', 'fa-skull', 'fa-music'];

    while (source.length < count) {
      const index = source.length;
      source.push({
        id: `library-cover-placeholder-${index}`,
        name: 'Library artwork',
        thumbnail: '',
        fallbackIcon: fallbackIcons[index % fallbackIcons.length],
        fallbackClass: `fallback-${(index % 6) + 1}`
      });
    }

    return source.map((track, index) => ({
      id: track.id || `library-cover-${index}`,
      name: track.name || 'Track artwork',
      thumbnail: track.thumbnail || '',
      fallbackIcon: track.fallbackIcon || fallbackIcons[index % fallbackIcons.length],
      fallbackClass: track.fallbackClass || `fallback-${(index % 6) + 1}`
    }));
  }

  _getLibraryFolderSummaries(music, folders, activeFolderFilter, options = {}) {
    const items = music || [];
    const {
      allName = 'All Tracks',
      allIcon = 'fas fa-music',
      allColor = '#1ed760',
      unfiledName = 'Unfiled',
      unfiledIcon = 'fas fa-inbox',
      unfiledColor = '#ffb13d',
      unfiledNeedsLabel = 'need a folder',
      unfiledEmptySubtitle = 'Everything is filed',
      itemSingular = 'track',
      itemPlural = 'tracks',
      fallbackFolderColors = ['#1db954', '#f39c12', '#9b59b6', '#e74c3c', '#1abc9c', '#3498db', '#e91e63', '#00bcd4'],
      fallbackCoverIcons = null
    } = options;
    const folderMap = new Map((folders || []).map(folder => [folder.id, { ...folder, tracks: [] }]));
    const unfiledTracks = [];

    const countLabel = count => `${count} ${count === 1 ? itemSingular : itemPlural}`;

    for (const track of items) {
      if (track.folderId && folderMap.has(track.folderId)) {
        folderMap.get(track.folderId).tracks.push(track);
      } else {
        unfiledTracks.push(track);
      }
    }

    return {
      all: {
        id: 'all',
        name: allName,
        count: items.length,
        subtitle: countLabel(items.length),
        icon: allIcon,
        color: allColor,
        active: activeFolderFilter === 'all',
        covers: this._getLibraryCoverItems(items, 4, fallbackCoverIcons)
      },
      unfiled: {
        id: 'unfiled',
        name: unfiledName,
        count: unfiledTracks.length,
        subtitle: unfiledTracks.length ? `${unfiledTracks.length} ${unfiledNeedsLabel}` : unfiledEmptySubtitle,
        icon: unfiledIcon,
        color: unfiledColor,
        active: activeFolderFilter === 'unfiled',
        covers: this._getLibraryCoverItems(unfiledTracks, 4, fallbackCoverIcons)
      },
      folders: [...folderMap.values()]
        .sort((a, b) => a.order - b.order)
        .map((folder, index) => ({
          ...folder,
          color: folder.color || fallbackFolderColors[index % fallbackFolderColors.length],
          icon: folder.icon || 'fas fa-folder',
          count: folder.tracks.length,
          subtitle: countLabel(folder.tracks.length),
          active: activeFolderFilter === folder.id,
          covers: this._getLibraryCoverItems(folder.tracks, 4, fallbackCoverIcons)
        }))
    };
  }

  _getLibrarySortLabel(sortKey = this.librarySort) {
    switch (sortKey) {
      case 'newest': return 'Newest Added';
      case 'title': return 'Title';
      case 'source': return 'Source';
      case 'duration': return 'Duration';
      default: return 'Library Order';
    }
  }

  _sortLibraryMusic(tracks) {
    const sortable = [...tracks];

    switch (this.librarySort) {
      case 'newest':
        return sortable.sort((a, b) => b._libraryIndex - a._libraryIndex);
      case 'title':
        return sortable.sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), undefined, { sensitivity: 'base' }));
      case 'source':
        return sortable.sort((a, b) => String(a.source || '').localeCompare(String(b.source || '')) || a._libraryIndex - b._libraryIndex);
      case 'duration':
        return sortable.sort((a, b) => this._parseDurationForSort(a.duration) - this._parseDurationForSort(b.duration));
      default:
        return sortable.sort((a, b) => a._libraryIndex - b._libraryIndex);
    }
  }

  _getLibraryPlaybackContext(musicId = null) {
    const music = this.jukebox.music || [];
    const musicFolders = this.jukebox.musicFolders || [];
    const validMusicFolderIds = new Set(musicFolders.map(folder => folder.id));
    const q = this.searchQuery?.toLowerCase() || '';

    let tracks = music.map((track, index) => ({ ...track, _libraryIndex: index }));

    if (q && this.view === 'library') {
      tracks = tracks.filter(track =>
        String(track.name || '').toLowerCase().includes(q) ||
        (Array.isArray(track.tags) && track.tags.some(tag => String(tag || '').toLowerCase().includes(q)))
      );
    }

    if (this.tagFilter) {
      tracks = tracks.filter(track => itemHasTag(track, this.tagFilter));
    }

    if (this.libraryFolderFilter === 'unfiled') {
      tracks = tracks.filter(track => !track.folderId || !validMusicFolderIds.has(track.folderId));
    } else if (this.libraryFolderFilter !== 'all') {
      tracks = tracks.filter(track => track.folderId === this.libraryFolderFilter);
    }

    if (this.librarySourceFilter === 'youtube') {
      tracks = tracks.filter(track => track.source === 'youtube');
    } else if (this.librarySourceFilter === 'local') {
      tracks = tracks.filter(track => track.source !== 'youtube');
    }

    if (this.libraryVisibilityFilter === 'hidden') {
      tracks = tracks.filter(track => normalizeBooleanFlag(track.hidden));
    }

    tracks = this._sortLibraryMusic(tracks);

    const musicIds = tracks.map(track => track.id).filter(Boolean);
    if (!musicIds.length || (musicId && !musicIds.includes(musicId))) return null;

    const hasSecondaryFilter = !!(q && this.view === 'library') ||
      !!this.tagFilter ||
      this.librarySourceFilter !== 'all' ||
      this.libraryVisibilityFilter !== 'all';

    let sourceSubType = 'library';
    let sourceName = 'Music Library';
    let sourceId = null;

    if (this.libraryFolderFilter === 'unfiled') {
      sourceSubType = 'unfiled';
      sourceName = 'Unfiled';
    } else if (this.libraryFolderFilter !== 'all') {
      const folder = musicFolders.find(entry => entry.id === this.libraryFolderFilter);
      sourceSubType = 'folder';
      sourceName = folder?.name || 'Folder';
      sourceId = this.libraryFolderFilter;
    } else if (hasSecondaryFilter) {
      sourceSubType = 'filtered';
      sourceName = 'Filtered Music Library';
    }

    if (hasSecondaryFilter && sourceSubType !== 'filtered') {
      sourceName = `${sourceName} (filtered)`;
    }

    return {
      sourceType: 'library',
      sourceSubType,
      sourceName,
      sourceId,
      musicIds
    };
  }

  _sortSoundboardSounds(sounds) {
    const sortable = [...sounds];

    switch (this.soundboardSort) {
      case 'newest':
        return sortable.sort((a, b) => b._soundboardIndex - a._soundboardIndex);
      case 'source':
        return sortable.sort((a, b) => String(a.source || '').localeCompare(String(b.source || '')) || a._soundboardIndex - b._soundboardIndex);
      case 'volume':
        return sortable.sort((a, b) => (Number(b.volume) || 0) - (Number(a.volume) || 0) || a._soundboardIndex - b._soundboardIndex);
      case 'name':
      default:
        return sortable.sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), undefined, { sensitivity: 'base' }));
    }
  }

  _parseDurationForSort(duration) {
    if (!duration) return Number.MAX_SAFE_INTEGER;
    if (typeof duration === 'number') return duration;

    const parts = String(duration).split(':').map(part => Number(part));
    if (parts.some(Number.isNaN)) return Number.MAX_SAFE_INTEGER;

    return parts.reduce((total, part) => total * 60 + part, 0);
  }

  _getLibraryScopeTitle(folderSummaries, activeFolderFilter, visibilityFilter = this.libraryVisibilityFilter) {
    if (visibilityFilter === 'hidden') return 'Hidden Tracks';
    if (activeFolderFilter === 'unfiled') return 'Unfiled Tracks';
    if (activeFolderFilter !== 'all') {
      return folderSummaries.folders.find(folder => folder.id === activeFolderFilter)?.name || 'Folder';
    }
    return 'All Music';
  }

  _enrichSuggestion(suggestion, index) {
    const normalized = normalizeSuggestedTrack(suggestion);
    if (!normalized) return null;

    let duplicate = null;
    try {
      duplicate = normalized.url ? findDuplicateTrack(this.jukebox, 'music', normalized) : null;
    } catch (err) {
      duplicate = null;
    }

    const missingUrl = !normalized.url;
    const isDuplicate = !!duplicate;
    const hasIssue = missingUrl || isDuplicate;
    const requester = String(normalized.user || 'Unknown Player').trim();
    const sourceClass = normalized.source === 'youtube' ? 'youtube' : 'local';
    const statusLabel = missingUrl
      ? 'Missing URL'
      : (isDuplicate ? 'Duplicate' : 'Ready to approve');

    return {
      ...normalized,
      suggestionKey: getSuggestionKey(suggestion),
      displayIndex: index + 1,
      requester,
      requesterInitial: requester.charAt(0).toUpperCase() || '?',
      submittedLabel: formatSuggestionAge(normalized.suggestedAt),
      sourceClass,
      sourceLabel: normalized.source === 'youtube' ? 'YouTube' : 'Local',
      sourceIcon: normalized.source === 'youtube' ? 'fab fa-youtube' : 'fas fa-file-audio',
      tagSummary: normalized.tags.length ? normalized.tags.join(' / ') : 'No tags',
      tagPreview: normalized.tags.slice(0, 3),
      extraTagCount: Math.max(0, normalized.tags.length - 3),
      thumbnail: normalized.thumbnail || '',
      duplicateName: duplicate?.name || '',
      missingUrl,
      isDuplicate,
      hasIssue,
      statusLabel,
      statusClass: hasIssue ? 'issue' : 'ready',
      approvalDisabled: hasIssue
    };
  }

  _filterSuggestions(suggestions, query, tagFilter) {
    const normalizedQuery = String(query || '').trim().toLowerCase();
    let filtered = suggestions;

    if (normalizedQuery) {
      filtered = filtered.filter(suggestion => {
        const searchable = [
          suggestion.name,
          suggestion.requester,
          suggestion.sourceLabel,
          suggestion.url,
          ...(suggestion.tags || [])
        ].join(' ').toLowerCase();
        return searchable.includes(normalizedQuery);
      });
    }

    if (tagFilter) {
      filtered = filtered.filter(suggestion => itemHasTag(suggestion, tagFilter));
    }

    switch (this.suggestionFilter) {
      case 'needs-review':
        return filtered.filter(suggestion => !suggestion.hasIssue);
      case 'youtube':
        return filtered.filter(suggestion => suggestion.source === 'youtube');
      case 'local':
        return filtered.filter(suggestion => suggestion.source !== 'youtube');
      default:
        return filtered;
    }
  }

  _getSuggestionStats(suggestions) {
    const players = new Set(suggestions.map(suggestion => suggestion.requester).filter(Boolean));

    return {
      pending: suggestions.length,
      youtube: suggestions.filter(suggestion => suggestion.source === 'youtube').length,
      local: suggestions.filter(suggestion => suggestion.source !== 'youtube').length,
      issues: suggestions.filter(suggestion => suggestion.hasIssue).length,
      players: players.size
    };
  }

  // ==========================================
  // getData - Template Data Provider
  // ==========================================

  getData() {
    const music = this.jukebox.music || [];
    const ambience = this.jukebox.ambience || [];
    const soundboard = this.jukebox.soundboard || [];
    const playlists = this.jukebox.playlists || [];
    const favoritePlaylist = playlists.find(playlist => playlist.systemType === 'favorites') || null;
    const userPlaylists = playlists.filter(playlist => !playlist.system);
    const moodSetting = game.settings.get(JUKEBOX.ID, "moods");
    const moods = Array.isArray(moodSetting) ? moodSetting : [];
    const suggestions = game.settings.get(JUKEBOX.ID, "suggestions") || [];

    const musicFolders = this.jukebox.musicFolders || [];
    const ambienceFolders = this.jukebox.ambienceFolders || [];
    const soundboardFolders = this.jukebox.soundboardFolders || [];
    const validMusicFolderIds = new Set(musicFolders.map(folder => folder.id));
    if (this.libraryFolderFilter !== 'all' && this.libraryFolderFilter !== 'unfiled' && !validMusicFolderIds.has(this.libraryFolderFilter)) {
      this.libraryFolderFilter = 'all';
    }
    const validAmbienceFolderIds = new Set(ambienceFolders.map(folder => folder.id));
    const ambienceFolderMap = new Map(ambienceFolders.map(folder => [folder.id, folder]));
    if (this.ambienceFolderFilter !== 'all' && this.ambienceFolderFilter !== 'unfiled' && !validAmbienceFolderIds.has(this.ambienceFolderFilter)) {
      this.ambienceFolderFilter = 'all';
    }
    const validSoundboardFolderIds = new Set(soundboardFolders.map(folder => folder.id));
    const soundboardFolderMap = new Map(soundboardFolders.map(folder => [folder.id, folder]));
    if (this.soundboardFolderFilter !== 'all' && this.soundboardFolderFilter !== 'unfiled' && !validSoundboardFolderIds.has(this.soundboardFolderFilter)) {
      this.soundboardFolderFilter = 'all';
    }

    const getFolderBadge = (folderMap, folderId, fallbackColor) => {
      const folder = folderMap.get(folderId);
      if (!folder) return null;

      return {
        name: folder.name || 'Folder',
        color: folder.color || fallbackColor,
        icon: folder.icon || 'fas fa-folder'
      };
    };

    const enrichedSuggestions = suggestions
      .map((suggestion, index) => this._enrichSuggestion(suggestion, index))
      .filter(Boolean);

    // Get all unique tags
    const allTags = [...new Set([
      ...music.flatMap(m => (m.tags && Array.isArray(m.tags)) ? m.tags : []),
      ...enrichedSuggestions.flatMap(s => (s.tags && Array.isArray(s.tags)) ? s.tags : [])
    ].map(normalizeTagValue).filter(Boolean))].sort();
    const allAmbienceTags = [...new Set(ambience
      .flatMap(a => (a.tags && Array.isArray(a.tags)) ? a.tags : [])
      .map(normalizeTagValue)
      .filter(Boolean))].sort();
    const libraryFolderSummaries = this._getLibraryFolderSummaries(music, musicFolders, this.libraryFolderFilter);
    const ambienceFolderSummaries = this._getLibraryFolderSummaries(ambience, ambienceFolders, this.ambienceFolderFilter, {
      allName: 'All Sounds',
      allIcon: 'fas fa-layer-group',
      allColor: '#6c8cff',
      unfiledName: 'Unfiled',
      unfiledColor: '#ffb13d',
      unfiledNeedsLabel: 'need a folder',
      unfiledEmptySubtitle: 'All sounds filed',
      itemSingular: 'sound',
      itemPlural: 'sounds',
      fallbackCoverIcons: ['fa-tree', 'fa-cloud-rain', 'fa-water', 'fa-mountain', 'fa-moon', 'fa-fire', 'fa-wind', 'fa-layer-group']
    });
    const soundboardFolderSummaries = this._getLibraryFolderSummaries(soundboard, soundboardFolders, this.soundboardFolderFilter, {
      allName: 'All Cues',
      allIcon: 'fas fa-bolt',
      allColor: '#ff7b3d',
      unfiledName: 'Loose Cues',
      unfiledColor: '#ffb13d',
      unfiledNeedsLabel: 'need a set',
      unfiledEmptySubtitle: 'All cues filed',
      itemSingular: 'cue',
      itemPlural: 'cues',
      fallbackCoverIcons: ['fa-bolt', 'fa-volume-up', 'fa-dice-d20', 'fa-skull', 'fa-cloud-bolt', 'fa-drum', 'fa-fire', 'fa-door-open']
    });
    const libraryHeroCovers = this._getLibraryCoverItems(music, 18);
    const libraryStats = {
      total: music.length,
      folders: musicFolders.length,
      tags: allTags.length,
      youtube: music.filter(track => track.source === 'youtube').length,
      local: music.filter(track => track.source !== 'youtube').length,
      unfiled: libraryFolderSummaries.unfiled.count,
      hidden: music.filter(track => normalizeBooleanFlag(track.hidden)).length
    };

    // Use the main search query for the current view
    const q = this.searchQuery?.toLowerCase() || '';
    const filteredSuggestions = this._filterSuggestions(enrichedSuggestions, this.view === 'suggestions' ? q : '', this.tagFilter);
    const suggestionStats = this._getSuggestionStats(enrichedSuggestions);
    const hasActiveSuggestionFilter = this.suggestionFilter !== 'all' ||
      !!this.tagFilter ||
      !!(q && this.view === 'suggestions');
    const selectedSuggestion = filteredSuggestions.find(suggestion => suggestion.suggestionKey === this.selectedSuggestionKey) ||
      filteredSuggestions[0] ||
      null;
    this.selectedSuggestionKey = selectedSuggestion?.suggestionKey || null;

    // Filter music (for library and playlists views)
    let filteredMusic = music.map((track, index) => ({ ...track, _libraryIndex: index }));
    if (q && (this.view === 'library' || this.view === 'home' || this.view === 'playlists')) {
      filteredMusic = filteredMusic.filter(m =>
        m.name.toLowerCase().includes(q) ||
        (m.tags && m.tags.some(t => t.toLowerCase().includes(q)))
      );
    }
    if (this.tagFilter) {
      filteredMusic = filteredMusic.filter(m => itemHasTag(m, this.tagFilter));
    }

    if (this.libraryFolderFilter === 'unfiled') {
      filteredMusic = filteredMusic.filter(m => !m.folderId || !validMusicFolderIds.has(m.folderId));
    } else if (this.libraryFolderFilter !== 'all') {
      filteredMusic = filteredMusic.filter(m => m.folderId === this.libraryFolderFilter);
    }

    if (this.librarySourceFilter === 'youtube') {
      filteredMusic = filteredMusic.filter(m => m.source === 'youtube');
    } else if (this.librarySourceFilter === 'local') {
      filteredMusic = filteredMusic.filter(m => m.source !== 'youtube');
    }

    if (this.libraryVisibilityFilter === 'hidden') {
      filteredMusic = filteredMusic.filter(m => normalizeBooleanFlag(m.hidden));
    }

    filteredMusic = this._sortLibraryMusic(filteredMusic);

    // Track if filter is active
    const hasActiveFilter = (q && this.view === 'library') ||
      this.tagFilter ||
      this.libraryFolderFilter !== 'all' ||
      this.librarySourceFilter !== 'all' ||
      this.libraryVisibilityFilter !== 'all';
    const totalMusicCountUnfiltered = music.length;

    // Filter ambience (for ambience view)
    let filteredAmbience = ambience;
    if (q && this.view === 'ambience') {
      filteredAmbience = filteredAmbience.filter(a =>
        a.name.toLowerCase().includes(q) ||
        (a.tags && a.tags.some(t => t.toLowerCase().includes(q)))
      );
    }
    if (this.ambienceTagFilter) {
      filteredAmbience = filteredAmbience.filter(a => itemHasTag(a, this.ambienceTagFilter));
    }
    if (this.ambienceFolderFilter === 'unfiled') {
      filteredAmbience = filteredAmbience.filter(a => !a.folderId || !validAmbienceFolderIds.has(a.folderId));
    } else if (this.ambienceFolderFilter !== 'all') {
      filteredAmbience = filteredAmbience.filter(a => a.folderId === this.ambienceFolderFilter);
    }

    // Filter soundboard (for soundboard view)
    let filteredSoundboard = soundboard.map((sound, index) => ({ ...sound, _soundboardIndex: index }));
    if (q && this.view === 'soundboard') {
      filteredSoundboard = filteredSoundboard.filter(s =>
        String(s.name || '').toLowerCase().includes(q)
      );
    }
    if (this.soundboardFolderFilter === 'unfiled') {
      filteredSoundboard = filteredSoundboard.filter(s => !s.folderId || !validSoundboardFolderIds.has(s.folderId));
    } else if (this.soundboardFolderFilter !== 'all') {
      filteredSoundboard = filteredSoundboard.filter(s => s.folderId === this.soundboardFolderFilter);
    }
    filteredSoundboard = this._sortSoundboardSounds(filteredSoundboard);

    // Pagination
    const totalAmbienceCount = filteredAmbience.length;
    const paginatedAmbience = filteredAmbience.slice(0, this._ambienceDisplayLimit);
    const hasMoreAmbience = totalAmbienceCount > this._ambienceDisplayLimit;
    const ambienceLayerIssues = this.jukebox.getAmbienceLayerIssues?.() || [];

    // Enrich ambience with layer state
    const enrichedAmbience = paginatedAmbience.map(a => ({
      ...a,
      isLayerActive: this.jukebox.isAmbienceLayerActive(a.id),
      layerVolume: Math.round((this.jukebox.getAmbienceLayerVolume(a.id) ?? 0.8) * 100),
      layerIssue: this.jukebox.getAmbienceLayerIssue?.(a.id) || null,
      layerIssueSummary: this._summarizeAmbienceIssue(this.jukebox.getAmbienceLayerIssue?.(a.id) || null),
      folderBadge: getFolderBadge(ambienceFolderMap, a.folderId, '#6c8cff')
    }));
    const activeAmbienceLayers = this._getActiveAmbienceLayers(ambience);
    const ambienceHeroCover = activeAmbienceLayers.find(layer => layer.thumbnail) ||
      ambience.find(track => track.thumbnail) ||
      null;
    const ambienceMasterVolume = Math.round(this.jukebox.getAmbienceMasterVolume() * 100);
    const ambienceMasterDotCount = Math.max(0, Math.min(10, Math.round(ambienceMasterVolume / 10)));

    const totalMusicCount = filteredMusic.length;
    const paginatedMusic = filteredMusic.slice(0, this._musicDisplayLimit);
    const hasMoreMusic = totalMusicCount > this._musicDisplayLimit;

    // Recent music
    const recentMusic = [...music].reverse().slice(0, 6);

    // Enrich mood boards with lightweight library stats for the home dashboard.
    const enrichedMoods = moods.map(mood => {
      const tag = normalizeTagValue(mood.tag);
      const color = String(mood.color || '').trim() || 'linear-gradient(135deg, #667eea, #764ba2)';
      const icon = String(mood.icon || '').trim() || 'fas fa-music';
      const label = String(mood.label || '').trim() || 'Untitled';
      const tracks = tag
        ? music.filter(track => itemHasTag(track, tag))
        : [];

      return {
        ...mood,
        tag,
        color,
        icon,
        label,
        trackCount: tracks.length,
        trackCountLabel: tag ? `${tracks.length} ${tracks.length === 1 ? 'Track' : 'Tracks'}` : 'No tag set',
        hasTag: !!tag,
        hasTracks: tracks.length > 0,
        isPlayable: !!tag && tracks.length > 0,
        isActive: !!tag && tag === normalizeTagValue(this.tagFilter),
        iconIsImage: isImageIcon(icon)
      };
    });

    // Auto-select first valid playlist
    if (this.selectedPlaylistId && !playlists.some(playlist => playlist.id === this.selectedPlaylistId)) {
      this.selectedPlaylistId = userPlaylists[0]?.id || favoritePlaylist?.id || null;
      this.showPlayerQueue = playlists.length === 0 ? true : this.showPlayerQueue;
    }

    if (!this.selectedPlaylistId && playlists.length > 0) {
      this.selectedPlaylistId = userPlaylists[0]?.id || favoritePlaylist?.id || null;
    }

    const playlistSearchQuery = (this.playlistSearchQuery || '').trim();
    const playlistSearchLower = playlistSearchQuery.toLowerCase();

    const enrichPlaylistForBrowser = (pl, index) => {
      const tracks = (pl.musicIds || []).map(id => music.find(m => m.id === id)).filter(Boolean);
      const tagSummary = [...new Set(tracks.flatMap(track => Array.isArray(track.tags) ? track.tags : []))]
        .slice(0, 2)
        .join(', ');
      const searchText = [
        String(pl.name || ''),
        tagSummary,
        ...tracks.flatMap(track => [
          String(track.name || ''),
          ...(Array.isArray(track.tags) ? track.tags : [])
        ])
      ].join(' ').toLowerCase();

      return {
        ...pl,
        trackCount: tracks.length,
        trackCountLabel: `${tracks.length} ${tracks.length === 1 ? 'track' : 'tracks'}`,
        durationLabel: this._formatPlaylistDuration(tracks),
        tagSummary,
        fallbackClass: `fallback-${(index % 6) + 1}`,
        _searchText: searchText
      };
    };

    const favoritePlaylistData = favoritePlaylist
      ? enrichPlaylistForBrowser(favoritePlaylist, 0)
      : null;
    const enrichedPlaylistsForBrowser = userPlaylists.map((pl, index) => enrichPlaylistForBrowser(pl, index + 1));

    const visiblePlaylists = playlistSearchLower
      ? enrichedPlaylistsForBrowser.filter(pl => pl._searchText.includes(playlistSearchLower))
      : enrichedPlaylistsForBrowser;

    // Enrich playlists
    let currentPlaylistData = null;
    const currentTrackId = this.jukebox.channels.music.currentTrack?.id || null;
    const currentPlaylistIsActive = !!(this.jukebox.currentPlaylist?.musicIds?.length && (!currentTrackId || this.jukebox.currentPlaylist.musicIds.includes(currentTrackId)));
    if (currentPlaylistIsActive) {
      currentPlaylistData = {
        ...this.jukebox.currentPlaylist,
        tracks: this.jukebox.currentPlaylist.musicIds
          .map(id => music.find(m => m.id === id))
          .filter(m => m)
          .map(track => ({
            ...track,
            hidden: normalizeBooleanFlag(track.hidden),
            isFavorite: itemHasTag(track, 'favorite')
          }))
      };
    }

    let selectedPlaylistData = null;
    if (this.selectedPlaylistId) {
      const selectedPl = playlists.find(p => p.id === this.selectedPlaylistId);
      if (selectedPl) {
        // Build a trackId → loop boolean map for Handlebars lookup
        const trackLoopMap = {};
        if (selectedPl.trackSettings) {
          for (const [musicId, settings] of Object.entries(selectedPl.trackSettings)) {
            if (settings.loop) trackLoopMap[musicId] = true;
          }
        }
        const selectedTracks = (selectedPl.musicIds || [])
          .map(id => music.find(m => m.id === id))
          .filter(m => m)
          .map(track => ({
            ...track,
            hidden: normalizeBooleanFlag(track.hidden),
            isFavorite: itemHasTag(track, 'favorite')
          }));
        selectedPlaylistData = {
          ...selectedPl,
          tracks: selectedTracks,
          isPlaying: this.jukebox.currentPlaylist?.id === selectedPl.id && this.jukebox.isPlaying,
          durationLabel: this._formatPlaylistDuration(selectedTracks),
          trackLoopMap,
          isSystem: !!selectedPl.system,
          isFavorites: selectedPl.systemType === 'favorites',
          playlistTypeLabel: selectedPl.systemType === 'favorites' ? 'FAVORITES' : 'PLAYLIST',
          emptyTitle: selectedPl.systemType === 'favorites' ? 'No favorites yet' : 'This playlist is empty',
          emptySubtitle: selectedPl.systemType === 'favorites'
            ? 'Click the heart on any track to add it here.'
            : 'Add tracks from the Library using the plus button.'
        };
      }
    }

    // Playlist covers
    const playlistCovers = {};
    playlists.forEach(pl => {
      const tracks = (pl.musicIds || []).map(id => music.find(m => m.id === id)).filter(m => m);
      const thumbnails = tracks.slice(0, 4).map(t => t.thumbnail || null);
      while (thumbnails.length < 4) thumbnails.push(null);
      playlistCovers[pl.id] = thumbnails;
    });

    // Music -> playlists map
    const musicPlaylistMap = {};
    playlists.forEach(pl => {
      (pl.musicIds || []).forEach(musicId => {
        if (!musicPlaylistMap[musicId]) musicPlaylistMap[musicId] = [];
        musicPlaylistMap[musicId].push({ id: pl.id, name: pl.name });
      });
    });

    const musicFolderMap = new Map(musicFolders.map(folder => [folder.id, folder]));

    // Enrich music with playlist and library presentation info
    const enrichedMusic = paginatedMusic.map((m, index) => {
      const folder = m.folderId ? musicFolderMap.get(m.folderId) : null;
      return {
        ...m,
        hidden: normalizeBooleanFlag(m.hidden),
        displayIndex: index + 1,
        playlists: musicPlaylistMap[m.id] || [],
        isFavorite: itemHasTag(m, 'favorite'),
        folderName: folder?.name || 'Unfiled',
        folderColor: folder?.color || '#ffb13d',
        folderIcon: folder?.icon || 'fas fa-inbox',
        sourceLabel: m.source === 'youtube' ? 'YouTube' : 'Local',
        sourceIcon: m.source === 'youtube' ? 'fab fa-youtube' : 'fas fa-file-audio',
        fallbackClass: `fallback-${(index % 6) + 1}`
      };
    });

    const enrichSoundboardSound = (sound, index = 0) => {
      const volume = typeof sound.volume === 'number' ? sound.volume : 0.8;
      const isYouTube = sound.source === 'youtube';
      const activeState = this.jukebox.activeSoundboardSounds.get(sound.id);
      const interval = getSoundboardIntervalSettings(sound);
      const isRandomIntervalActive = !!activeState?.isRandomInterval;
      const isIntervalWaiting = isRandomIntervalActive && !!activeState?.isIntervalWaiting;

      return {
        ...sound,
        isPlaying: this.jukebox.isSoundboardSoundPlaying(sound.id),
        isAudible: !!activeState && !isIntervalWaiting,
        isLooping: activeState ? !!activeState.isLooping : (!!sound.loop && !interval.enabled),
        loopDefault: !!sound.loop && !interval.enabled,
        randomIntervalEnabled: interval.enabled,
        randomIntervalMin: interval.min,
        randomIntervalMax: interval.max,
        randomIntervalLabel: formatIntervalLabel(interval),
        isRandomIntervalActive,
        isIntervalWaiting,
        nextIntervalLabel: formatRemainingInterval(activeState?.nextFireAt),
        sourceLabel: isYouTube ? 'YouTube' : 'Local',
        sourceIcon: isYouTube ? 'fab fa-youtube' : 'fas fa-file-audio',
        sourceClass: isYouTube ? 'youtube' : 'local',
        volumePercent: Math.round(Math.max(0, Math.min(1, volume)) * 100),
        fallbackClass: `fallback-${(index % 6) + 1}`,
        folderBadge: getFolderBadge(soundboardFolderMap, sound.folderId, '#ff7b3d')
      };
    };

    // Enrich soundboard (use filtered list)
    const enrichedSoundboard = filteredSoundboard.map((s, index) => enrichSoundboardSound(s, index));
    const activeSoundboardCues = soundboard
      .filter(sound => this.jukebox.isSoundboardSoundPlaying(sound.id))
      .map((sound, index) => enrichSoundboardSound(sound, index));

    // Group tracks by folders
    const hasActiveMusicFilter = !!hasActiveFilter;
    const hasActiveAmbienceFilter = !!(q && this.view === 'ambience') || !!this.ambienceTagFilter || this.ambienceFolderFilter !== 'all';
    const hasActiveSoundboardFilter = !!(q && this.view === 'soundboard') || this.soundboardFolderFilter !== 'all';

    const { unfiled: unfiledMusic, groups: musicFolderGroups } = this._groupByFolders(enrichedMusic, musicFolders, hasActiveMusicFilter);
    const { unfiled: unfiledAmbience, groups: ambienceFolderGroups } = this._groupByFolders(enrichedAmbience, ambienceFolders, hasActiveAmbienceFilter);
    const { unfiled: unfiledSoundboard, groups: soundboardFolderGroups } = this._groupByFolders(enrichedSoundboard, soundboardFolders, hasActiveSoundboardFilter);
    const soundboardFolderOptions = [
      { id: 'all', name: 'All Folders', count: soundboard.length },
      {
        id: 'unfiled',
        name: 'Loose Cues',
        count: soundboard.filter(sound => !sound.folderId || !validSoundboardFolderIds.has(sound.folderId)).length
      },
      ...soundboardFolders
        .slice()
        .sort((a, b) => a.order - b.order)
        .map(folder => ({
          id: folder.id,
          name: folder.name || 'Folder',
          count: soundboard.filter(sound => sound.folderId === folder.id).length
        }))
    ];
    const libraryScopeTitle = this._getLibraryScopeTitle(libraryFolderSummaries, this.libraryFolderFilter, this.libraryVisibilityFilter);
    const libraryScopeSubtitle = hasActiveFilter
      ? `Showing ${totalMusicCount} of ${totalMusicCountUnfiltered} tracks`
      : `${totalMusicCount} ${totalMusicCount === 1 ? 'track' : 'tracks'} in ${this._getLibrarySortLabel(this.librarySort).toLowerCase()}`;
    const libraryFilterState = {
      allActive: this.libraryFolderFilter === 'all' &&
        this.librarySourceFilter === 'all' &&
        this.libraryVisibilityFilter === 'all' &&
        !this.tagFilter &&
        !(q && this.view === 'library'),
      unfiledActive: this.libraryFolderFilter === 'unfiled',
      hiddenActive: this.libraryVisibilityFilter === 'hidden',
      localActive: this.librarySourceFilter === 'local',
      youtubeActive: this.librarySourceFilter === 'youtube',
      moreActive: this.libraryFolderFilter === 'unfiled' ||
        this.libraryVisibilityFilter === 'hidden' ||
        !!this.tagFilter
    };
    const currentTrack = this.jukebox.channels.music.currentTrack;
    const nowPlayingHidden = !game.user.isGM && normalizeBooleanFlag(currentTrack?.hidden);
    const currentTrackPresentation = nowPlayingHidden
      ? { miniTags: [], tagSummary: 'Music Library', isFavorite: false }
      : this._getMiniTrackPresentation(currentTrack);
    const miniFilteredMusic = this._getMiniFilteredMusic(music);
    const miniQueueTracks = this._getMiniQueueTracks(music);
    const miniFilteredAmbience = this._getMiniFilteredAmbience(ambience);
    const miniFilteredSoundboard = this._getMiniFilteredSoundboard(soundboard);
    const hasMiniMusicFolders = musicFolders.length > 0 || this.libraryFolderFilter !== 'all';
    const hasMiniAmbienceFolders = ambienceFolders.length > 0 || this.ambienceFolderFilter !== 'all';
    const hasMiniSoundboardFolders = soundboardFolders.length > 0 || this.soundboardFolderFilter !== 'all';
    const musicRepeat = this._getMusicRepeatPresentation();
    const playerQueue = this._getPlayerQueue(music);
    const currentMusicSourceContext = this.jukebox.currentMusicSourceContext;
    const currentMusicSourceName = currentPlaylistData?.name || currentMusicSourceContext?.sourceName || 'Music Library';
    const currentMusicSourceIcon = currentPlaylistData
      ? (currentPlaylistData.systemType === 'favorites' ? 'fas fa-heart' : 'fas fa-list')
      : currentMusicSourceContext?.sourceSubType === 'folder'
        ? 'fas fa-folder'
        : currentMusicSourceContext?.sourceSubType === 'unfiled'
          ? 'fas fa-inbox'
          : currentMusicSourceContext?.sourceSubType === 'filtered'
            ? 'fas fa-filter'
            : 'fas fa-music';
    const isPreviewMode = this.jukebox.isPreviewMode;
    const playerbarModeTooltip = localize(isPreviewMode
      ? 'Mode.PlayerbarPreviewTooltip'
      : 'Mode.PlayerbarBroadcastTooltip');

    return {
      view: this.view,
      isGM: game.user.isGM,
      syncHealth: syncService.getHealthSummary(),
      music: enrichedMusic,
      ambience: enrichedAmbience,
      soundboard: enrichedSoundboard,
      soundboardBroadcastMode: this.jukebox.soundboardBroadcastMode,
      soundboardSize: game.settings.get(JUKEBOX.ID, JUKEBOX.SETTINGS.SOUNDBOARD_SIZE) || 'medium',
      activeSoundboardCount: this.jukebox.activeSoundboardSounds.size,
      activeSoundboardCues,
      totalSoundboardCount: filteredSoundboard.length,
      totalSoundboardCountUnfiltered: soundboard.length,
      soundboardFolderCount: soundboardFolders.length,
      soundboardFolderOptions,
      soundboardFolderSummaries,
      soundboardFolderFilter: this.soundboardFolderFilter,
      soundboardSort: this.soundboardSort,
      hasActiveSoundboardFilter,
      recentMusic: recentMusic,
      playlists: visiblePlaylists,
      favoritePlaylist: favoritePlaylistData,
      playlistSearchQuery,
      playlistSearchActive: !!playlistSearchQuery,
      playlistBrowserCount: visiblePlaylists.length,
      playlistTotalCount: userPlaylists.length,
      playlistCovers: playlistCovers,
      currentPlaylist: currentPlaylistData,
      currentMusicSourceContext,
      currentMusicSourceName,
      currentMusicSourceIcon,
      selectedPlaylist: selectedPlaylistData,
      showPlayerQueue: this.showPlayerQueue,
      playerQueue,
      suggestions: filteredSuggestions,
      totalSuggestionsCount: enrichedSuggestions.length,
      visibleSuggestionsCount: filteredSuggestions.length,
      suggestionStats,
      selectedSuggestion,
      suggestionFilter: this.suggestionFilter,
      suggestionFilterAll: this.suggestionFilter === 'all',
      suggestionFilterNeedsReview: this.suggestionFilter === 'needs-review',
      suggestionFilterYoutube: this.suggestionFilter === 'youtube',
      suggestionFilterLocal: this.suggestionFilter === 'local',
      hasActiveSuggestionFilter,
      moods: enrichedMoods,
      totalMusicCount,
      totalMusicCountUnfiltered,
      hasActiveFilter,
      libraryStats,
      libraryHeroCovers,
      libraryFolderSummaries,
      libraryScopeTitle,
      libraryScopeSubtitle,
      libraryFilterState,
      librarySort: this.librarySort,
      librarySortLabel: this._getLibrarySortLabel(this.librarySort),
      libraryDensity: this.libraryDensity,
      libraryDensityCompact: this.libraryDensity === 'compact',
      libraryFolderFilter: this.libraryFolderFilter,
      librarySourceFilter: this.librarySourceFilter,
      libraryVisibilityFilter: this.libraryVisibilityFilter,
      hasMoreMusic,
      musicDisplayLimit: this._musicDisplayLimit,
      totalAmbienceCount,
      hasMoreAmbience,
      ambienceDisplayLimit: this._ambienceDisplayLimit,
      ambienceIssueCount: ambienceLayerIssues.length,
      isPlaying: this.jukebox.isPlaying,
      isPreviewMode,
      playerbarModeTooltip,
      volume: this.jukebox.channels.music.volume * 100,
      shuffle: this.jukebox.shuffle,
      musicLoop: this.jukebox.musicLoop,
      musicRepeatMode: musicRepeat.mode,
      musicRepeatActive: musicRepeat.active,
      musicRepeatTrack: musicRepeat.isTrack,
      musicRepeatQueue: musicRepeat.isQueue,
      musicRepeatClass: musicRepeat.className,
      musicRepeatBadge: musicRepeat.badge,
      musicRepeatLabel: musicRepeat.label,
      musicRepeatTooltip: musicRepeat.tooltip,
      isMuted: this.jukebox.isMuted,
      isAmbiencePlaying: this.jukebox.isAmbiencePlaying,
      ambienceVolume: this.jukebox.channels.ambience.volume * 100,
      ambienceLoop: this.jukebox.ambienceLoop,
      isAmbienceMuted: this.jukebox.isAmbienceMuted,
      currentTrack: this.jukebox.channels.music.currentTrack,
      currentMusic: this.jukebox.channels.music.currentTrack,
      currentTrackMiniTags: currentTrackPresentation.miniTags,
      currentTrackTagSummary: currentTrackPresentation.tagSummary,
      currentTrackIsFavorite: currentTrackPresentation.isFavorite,
      nowPlayingHidden,
      hasTrack: !!this.jukebox.channels.music.currentTrack,
      currentAmbience: this.jukebox.channels.ambience.currentTrack,
      hasAmbience: !!this.jukebox.channels.ambience.currentTrack,
      nextMusic: this._getNextTrack(),
      searchQuery: this.searchQuery,
      tagFilter: this.tagFilter,
      allTags: allTags,
      ambienceSearchQuery: this.ambienceSearchQuery,
      ambienceTagFilter: this.ambienceTagFilter,
      ambienceFolderSummaries,
      ambienceFolderFilter: this.ambienceFolderFilter,
      hasActiveAmbienceFilter,
      allAmbienceTags: allAmbienceTags,
      windowMode: this._windowState,
      miniActiveTab: this._miniActiveTab,
      miniMusicView: this._miniMusicView,
      miniSearchQuery: this._miniSearchQuery,
      miniFilteredMusic,
      miniQueueTracks,
      hasQueue: playerQueue.hasManualQueue || currentPlaylistIsActive,
      miniFilteredAmbience,
      miniFilteredSoundboard,
      hasMiniMusicFolders,
      hasMiniAmbienceFolders,
      hasMiniSoundboardFolders,
      // Mini mode active layers (with track data)
      miniActiveAmbienceLayers: this._getMiniActiveAmbienceLayers(ambience),
      // Ambience Layer Mixer data
      activeAmbienceLayers,
      ambienceLayerCount: this.jukebox.getAmbienceLayerCount(),
      maxAmbienceLayers: MAX_AMBIENCE_LAYERS,
      ambienceMasterVolume,
      ambienceMasterDotCount,
      ambienceHeroCover,
      isAmbienceMasterMuted: this.jukebox.isAmbienceMasterMuted(),
      // Ambience Presets
      ambiencePresets: this.jukebox.getAmbiencePresets(),
      selectedPresetId: this.selectedPresetId,
      // Multi-selection state
      selectionMode: this.selectionMode,
      selectedMusicIds: [...this.selectedMusicIds],
      selectedAmbienceIds: [...this.selectedAmbienceIds],
      selectedSoundboardIds: [...this.selectedSoundboardIds],
      selectedCount: this._getActiveSelectionSet().size,
      selectedCountText: format('Selection.CountSelected', { count: this._getActiveSelectionSet().size }),
      // Folder grouping data
      unfiledMusic,
      musicFolderGroups,
      unfiledAmbience,
      ambienceFolderGroups,
      unfiledSoundboard,
      soundboardFolderGroups,
      collapsedFolders: [...this.collapsedFolders],
      hasMusicFolders: this.jukebox.musicFolders.length > 0,
      hasAmbienceFolders: this.jukebox.ambienceFolders.length > 0,
      hasSoundboardFolders: this.jukebox.soundboardFolders.length > 0
    };
  }

  // ==========================================
  // Render Override - Preserve Scroll Position
  // ==========================================

  async _render(force = false, options = {}) {
    // Save scroll positions and focus state before re-render
    const scrollPositions = {};
    let searchWasFocused = false;
    let searchCursorPosition = 0;
    let searchSelector = '.search-input';

    if (this.element && this.element.length) {
      // Save scroll positions
      const scrollableSelectors = ['.jb-main', '.content-area', '.soundboard-grid', '.track-list', '.playlist-tracks', '.library-folder-list', '.mini-tab-panel'];
      scrollableSelectors.forEach(selector => {
        const el = this.element.find(selector);
        if (el.length && el[0].scrollTop > 0) {
          scrollPositions[selector] = el[0].scrollTop;
        }
      });

      // Save search input focus state
      const searchInput = this.element.find('.search-input, .mini-search-input').filter(':focus').first();
      if (searchInput.length) {
        searchWasFocused = true;
        searchSelector = searchInput.hasClass('mini-search-input') ? '.mini-search-input' : '.search-input';
        searchCursorPosition = searchInput[0].selectionStart || 0;
      }
    }

    // Call parent render
    await super._render(force, options);

    // Restore scroll positions after render
    if (Object.keys(scrollPositions).length > 0) {
      for (const [selector, scrollTop] of Object.entries(scrollPositions)) {
        const el = this.element.find(selector);
        if (el.length) {
          el[0].scrollTop = scrollTop;
        }
      }
    }

    // Restore search input focus
    if (searchWasFocused) {
      const searchInput = this.element.find(searchSelector);
      if (searchInput.length) {
        searchInput.focus();
        // Restore cursor position
        try {
          searchInput[0].setSelectionRange(searchCursorPosition, searchCursorPosition);
        } catch (e) {
          // Some browsers may not support setSelectionRange
        }
      }
    }
  }

  // ==========================================
  // activateListeners - Delegate to Modular System
  // ==========================================

  activateListeners(html) {
    super.activateListeners(html);

    // Use modular listener system
    activateModularListeners(this, html);

    this._initResponsiveState();
    this._initResizeInteractionPolish();
  }

  // ==========================================
  // Cleanup on Close
  // ==========================================

  async close(options = {}) {
    // Stop all progress timers
    ProgressManager.stopAllProgress(this);
    this._responsiveObserver?.disconnect();
    this._responsiveObserver = null;
    this._clearWindowSizeTransition();
    $(document).off('.jbResizePolishActive');

    return super.close(options);
  }
}
