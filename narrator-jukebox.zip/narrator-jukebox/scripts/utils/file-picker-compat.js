/**
 * FilePicker Compatibility Helper (v11-v13)
 * Extracted from narrator-jukebox.js for modular architecture
 */

/**
 * Get the appropriate FilePicker class for the current Foundry version
 * @returns {FilePicker} The FilePicker class/constructor
 */
export function getFilePicker() {
  // Foundry v13+ uses namespaced FilePicker
  if (foundry?.applications?.apps?.FilePicker?.implementation) {
    return foundry.applications.apps.FilePicker.implementation;
  }
  // Fallback for v11/v12
  return FilePicker;
}

const FILE_PICKER_SELECTOR = [
  '.app.filepicker',
  '.window-app.filepicker',
  '.application.filepicker',
  '.app.file-picker',
  '.window-app.file-picker',
  '.application.file-picker',
  '.filepicker',
  '.file-picker'
].join(',');

/**
 * Open Foundry's FilePicker and force it above Narrator Jukebox module modals.
 * Foundry versions differ in class names and stacking APIs, so this combines
 * the native "bring to top" methods with a conservative z-index fallback.
 *
 * @param {object} options - FilePicker constructor options
 * @returns {object} The FilePicker instance
 */
export function browseFilePicker(options = {}) {
  const picker = new (getFilePicker())(options);
  const browseResult = picker.browse();
  bringFilePickerToFront(picker);
  Promise.resolve(browseResult)
    .then(() => bringFilePickerToFront(picker))
    .catch(() => {});
  return picker;
}

/**
 * Bring an already-opened FilePicker to the top of the Foundry UI stack.
 * @param {object} picker - FilePicker instance
 */
export function bringFilePickerToFront(picker) {
  for (const delay of [0, 16, 60, 160]) {
    window.setTimeout(() => promoteFilePicker(picker), delay);
  }
}

function promoteFilePicker(picker) {
  picker?.bringToTop?.();
  picker?.bringToFront?.();

  const element = getFilePickerElement(picker);
  if (!element) return;

  element.classList.add('narrator-jukebox-filepicker-front');
  element.style.setProperty('z-index', String(getNextUiZIndex()), 'important');
  element.focus?.({ preventScroll: true });
}

function getFilePickerElement(picker) {
  const directElement = unwrapElement(picker?.element) || unwrapElement(picker?.window?.element);
  if (directElement?.isConnected) return directElement;

  const candidates = Array.from(document.querySelectorAll(FILE_PICKER_SELECTOR))
    .filter(element => element.offsetParent !== null);
  return candidates[candidates.length - 1] || null;
}

function unwrapElement(value) {
  if (!value) return null;
  if (value instanceof HTMLElement) return value;
  if (value[0] instanceof HTMLElement) return value[0];
  return null;
}

function getNextUiZIndex() {
  const zIndexes = Array.from(document.body.children)
    .map(element => Number(getComputedStyle(element).zIndex))
    .filter(Number.isFinite);
  return Math.max(100050, ...zIndexes) + 10;
}
