/**
 * Tag Overflow Handler
 *
 * The Music Library track rows render every tag as a pill inside the
 * .col-tags flex container. When a track has many tags, the visible width
 * of the column is not enough for all of them. Without intervention the
 * pills either shrink to illegible 1-2 character circles (default flex
 * shrinking) or get half-truncated by the column's overflow:hidden.
 *
 * This utility measures which pills actually fit horizontally, hides the
 * ones that do not, and inserts a "+N" indicator pill at the cutoff point.
 * The indicator carries a Foundry data-tooltip listing every hidden tag,
 * so the user can hover to discover what was clipped.
 *
 * The overflow logic re-runs whenever the container resizes (window
 * resize, sidebar collapse, density toggle, etc.) via ResizeObserver.
 */

const RESERVE_FOR_INDICATOR_PX = 44; // approx width of "+N" pill including padding/border
const PILL_GAP_PX = 5; // matches the CSS gap on .col-tags
const INDICATOR_CLASS = 'tag-overflow-indicator';
const PROCESSED_FLAG = 'data-tag-overflow';

const observers = new WeakMap();

function applyOverflow(container) {
  if (!container || !container.isConnected) return;

  // Reset previous state so measurements reflect the natural pill widths.
  container.querySelectorAll(`.${INDICATOR_CLASS}`).forEach(el => el.remove());
  container.querySelectorAll('.tag-pill[data-overflow-hidden]').forEach(el => {
    el.removeAttribute('data-overflow-hidden');
    el.style.display = '';
  });

  const pills = Array.from(container.querySelectorAll(`.tag-pill:not(.${INDICATOR_CLASS})`));
  if (pills.length === 0) return;

  const containerWidth = container.clientWidth;
  if (containerWidth === 0) return; // container is hidden, defer to next observer tick

  let usedWidth = 0;

  for (let i = 0; i < pills.length; i++) {
    const pill = pills[i];
    const pillWidth = pill.offsetWidth;
    const remaining = pills.length - i - 1;
    const needsReserve = remaining > 0;
    const limit = containerWidth - (needsReserve ? (RESERVE_FOR_INDICATOR_PX + PILL_GAP_PX) : 0);

    // Always show at least the first pill; otherwise hide overflowing ones.
    if (usedWidth + pillWidth > limit && i > 0) {
      const hiddenTags = [];
      for (let j = i; j < pills.length; j++) {
        pills[j].setAttribute('data-overflow-hidden', '');
        pills[j].style.display = 'none';
        const text = pills[j].textContent.trim();
        if (text) hiddenTags.push(text);
      }

      if (hiddenTags.length > 0) {
        const indicator = document.createElement('span');
        indicator.className = `tag-pill ${INDICATOR_CLASS}`;
        indicator.setAttribute('data-tooltip', hiddenTags.join(' / '));
        indicator.textContent = `+${hiddenTags.length}`;
        container.appendChild(indicator);
      }
      return;
    }

    usedWidth += pillWidth + PILL_GAP_PX;
  }
}

/**
 * Apply tag overflow handling to every .col-tags inside the given root.
 * Idempotent: safe to call after every render.
 *
 * @param {Element|jQuery} rootEl - The application's root HTML element
 */
export function setupTagOverflow(rootEl) {
  const root = rootEl?.[0] || rootEl;
  if (!root || typeof root.querySelectorAll !== 'function') return;

  const containers = root.querySelectorAll('.col-tags');
  for (const container of containers) {
    applyOverflow(container);

    if (container.getAttribute(PROCESSED_FLAG) === 'true') continue;
    container.setAttribute(PROCESSED_FLAG, 'true');

    if (typeof ResizeObserver !== 'undefined') {
      const observer = new ResizeObserver(() => applyOverflow(container));
      observer.observe(container);
      observers.set(container, observer);
    }
  }
}
