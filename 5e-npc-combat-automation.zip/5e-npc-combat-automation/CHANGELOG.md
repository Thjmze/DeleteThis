# Changelog

## 0.19.3 — Door movement realism (real fix)

The 0.19.2 proximity opener was necessary but not sufficient. Trace logs
showed the actual halt: a **double-door / wide doorway** whose far leaf sat
**2.1 cells** from the NPC, just beyond the **1.75-cell** opening reach. The
planned diagonal step clipped that leaf one cell early, the door was correctly
found but rejected as out of reach, and the move stopped with dash budget
(2.0c of 12.0c) and the whole action unspent.

### Fixed
- **Door opening reach raised from ~1.75 to ~2.25 cells.** A creature standing
  diagonally adjacent to a doorway (≈1.4c to a single door, up to ~2.1c to a
  far double-door leaf) can now reach out and open it — directly covering the
  logged failure.
- **Door-approach recovery.** If a step is blocked *only* by a closed door
  that is still out of reach, the executor now steps to an adjacent walkable
  cell that brings the door into reach, opens it, and resumes — instead of
  halting. Distinguishes door-only blocks from real walls (`_doorsBlockingStep`)
  and is loop-guarded per step. Applies to the engage executor; retreat keeps
  the two-stage opener from 0.19.2.

### Tests
- Added the exact log scenario as a regression (double-door leaf at 2.12c on a
  diagonal approach) plus updated reach/heading boundary tests (29 total).


## 0.19.2 — Door movement realism

### Fixed
- **NPCs no longer halt at doorways with full action and movement remaining.**
  Root cause: the door opener only considered a door whose closed leaf the
  *immediate one-cell step ray* intersected. On diagonal or corner-hugging
  approaches that ray grazes past the leaf, so the step stayed blocked and the
  move loop stopped early. Added a proximity-based opener (`openReachableDoors`)
  that opens any reachable closed door ahead of the NPC — matching how a
  creature actually reaches out, opens the door, and keeps walking. Both the
  forward (engage) and retreat executors now use a two-stage open (ray opener
  → proximity opener) and re-test the step after each.
- Proximity opener respects reach, travel heading (never backtracks to open a
  door behind the NPC, except one it is standing against), and locked doors
  (left closed, logged).

### Tests
- Five new harness assertions for door opening: diagonal-approach success,
  out-of-reach/behind/locked refusals, and resulting door state (28 total).


## 0.19.1 — Tooling & AOE Threat Memory

### AOE threat memory (refinement Task 9)
- New setting (default **off**, Tactical AI tab): freshly-placed measured
  templates leave a 2-round danger zone; NPCs with INT 10+ pay extra
  pathfinding cost inside the footprint and route around it on their own
  turns. No movement-as-reaction is invented — only the NPC's next move is
  shaped. Works independently of cover-aware pathing; zones clear on template
  deletion and combat end.

### Headless regression harness (`tools/harness/`)
- `node tools/harness/run-tests.mjs` — 23 executed assertions against the
  real module code under a mocked Foundry surface (settings defaults parsed
  from source): BFS correctness, wall blocking, the single-flood tier
  invariant, smart partial advance, flanking geometry, target persistence,
  grudge weighting and cap, priority/blacklist flags.
- **Found and fixed a real 0.19.0 bug**: an NPC's own focus-fire pressure
  accumulated against its held target across repeated selectTarget calls
  (no-LOS retries, legendary boundaries), eventually overwhelming the sticky
  bonus and causing the exact ping-pong persistence exists to prevent. The
  NPC's own per-round assignment contributions are now discounted when
  scoring its held target.

### Trace analyzer (`tools/analyze-trace.mjs`)
- `node tools/analyze-trace.mjs trace.jsonl` — offline tuning report over
  JSONL trace exports: behavior/archetype/morale distributions, target
  hold/switch rates and grudge magnitudes, flood counts/timings and
  single-flood savings, partial-advance exposure, scoot/kite/dash rates,
  spell slot mix, legendary/OA events, retarget forfeits, and error rollup —
  with inline tuning warnings (e.g. switch rate >50%, grudge pinned at cap,
  forfeit-heavy retargets).


## 0.19.0 — AI Refinement Pass (Pathfinding · Tracking · Reactivity)

### Pathfinding
- **Single-flood tiering** (`Pathfinding: single-flood tiering`, default on):
  the normal/dash/double-dash reachability tiers are derived by filtering one
  flood instead of running up to three. Decisions are provably identical
  (Dijkstra cost invariance); per-move flood stats are recorded in the trace.
- **Smart partial advance** (default on): when no attack position is
  reachable, the fallback cell weighs threat exposure (5× weight, capped at
  ~2 cells) alongside distance, and tie-breaks the top candidates on line of
  sight — ranged NPCs keep it, stranded melee breaks it. No more ending the
  turn one cell "closer" in a killing field.
- **Per-turn sightline cache** (default on): wall-collision LOS tests are
  memoised across approach/kite/scoot within a turn; invalidated on any
  wall or door change and cleared at every turn start.

### Tracking
- **Persistent targets** (default on): NPCs prefer last turn's target with a
  bonus decaying over 2–3 turns (pack/focus-fire archetypes hold 1.5× harder),
  ending target ping-pong. Always overridden by drops, priority-target flags,
  forced targets, or clearly better candidates. Off-turn legendary targeting
  does not inflate the decay clock.
- **Grudge memory** (default on): a per-combat damage ledger (fed by
  midi-qol damage application) gives attackers a capped targeting bonus
  (max 12 — below finishing-blow range), and a single hit over 25% max HP
  registers as a −8 morale shock through the existing morale-event channel.
- **Shared last-known positions** (default on): any NPC sighting refreshes a
  per-target shared LKP. NPCs with INT 10+ can pursue ally-reported positions
  (3-round expiry); dim creatures rely only on what they personally saw.

### Reactivity
- **Opportunity attacks** (default **off**): automated NPCs react to hostile
  player-driven tokens leaving their melee reach without Disengaging — best
  melee weapon, shared one-reaction-per-round tracker, skipped when midi-qol's
  own OA rule is detected, never triggered by the module's own NPC movement.
- **Retarget on kill** (default on): when a multiattack drops its target
  mid-sequence, remaining attacks retarget the best enemy already within this
  weapon's reach from the current position — or are forfeited, never swung
  pointlessly across the map.

All nine behaviours have independent toggles (Movement / Tactical AI / Combat
Behaviour tabs); with every toggle off, decisions match 0.18.0 exactly.


## 0.18.0 — "The Full Gameplan"

This release completes every feature in the Developer Expansion Guide (§1–§11)
and resolves the module's headline housekeeping debt: the rename to
`automated-npcs`.

### Internal

- Hardcoded module-id strings replaced with `MODULE_ID` reads throughout.
  (A planned rename to `automated-npcs` was reverted; the module id remains
  `5e-npc-combat-automation`.)

### Legendary Actions (§7)

- Legendary NPCs spend legendary actions at the end of other combatants'
  turns — one option per trigger (RAW), pool refresh at the start of their own
  turn, never on the boundary into their own turn.
- Costs read from activities, legacy activation fields, or "(Costs N
  Actions)" text; per-item 1/day uses respected.
- Scoring: damage > control > utility, cost-normalised (√cost) so the pool
  spreads across the round; out-of-reach melee options penalised.
- Points are spent before execution; GM whisper per action; standalone
  `legendary` rows in the AI trace (`trace.recordEvent`).
- Setting: **Enable legendary actions** (default on).

### Tabbed Settings UI (§10)

- New configuration window (Module Settings → *Open Configuration*) with
  eight tabs: General, Combat Behaviour, Movement, Spellcasting, Dialogue,
  AI & Morale, Tactical AI, Debug.
- Live search across all settings, world/client scope badges, range sliders
  with live values, per-tab reset-to-defaults, diff-based save.
- All metadata is read live from setting registration — zero duplication.
- The native Foundry panel now shows only the master toggle and the menu
  buttons; deprecated/runtime settings are hidden everywhere.
- The dialogue-journal menu was migrated off the deprecated `FormApplication`.
- Macro access: `game.modules.get("automated-npcs").api.openSettings()`.

### Per-Actor Configuration (§3)

New **Combat Configuration** section on the NPC sheet's Automated NPCs tab:

- **Always target token named** — short-circuits target scoring (the
  no-LOS retry still falls back to normal scoring).
- **Never target** — comma-separated blacklist, applied to enemy targeting
  *and* ally heal/buff routing (hostages, quest NPCs).
- **Spell AI overrides** (checkbox-gated): per-NPC slot conservation and
  minimum AOE targets, winning over world/archetype settings.
- **Starting morale** (0–100 seed) and **Morale immune** (fearless).
- All values persist as actor flags; absent flags mean unchanged behaviour.

### Undo NPC Block — Resource Restore (§4)

- The snapshot now also captures **spell slots, item charges** (both
  ≤5.0 `uses.value` and 5.1+ `uses.spent` shapes), and the active-effect set.
- Restore is diff-based; effects gained during the block are deleted
  (delete-only — expired effects stay expired), guarded by
  `createdTime` where available.
- Setting: **Undo NPC Block: restore resources** (default on).

### Deep Spell-List Inference (§5)

- Inference Pass 3b classifies every spell on the actor via the spell AI's
  own classifier: 2+ AOE damage → blaster, 2+ AOE control → controller,
  2+ heals → warpriest, any summon → summoner, 2+ self-buffs → tactician.
  Each adds +10% confidence.
- Adding/editing/removing a spell on an NPC invalidates the cached profile
  (manual GM overrides are never clobbered). Inference cache version bumped —
  all profiles rebuild once on first load.

### Dialogue (§6)

- Eleven new archetype phrase pools: defensive, bodyguard, pack-hunter,
  pack-flanker, hunter, artillery, territorial, controller, warpriest,
  summoner, blaster.
- New **spell-cast barks**: caster archetypes have dedicated spell lines;
  all other archetypes fall back to their tactical pool.

### Flanking Movement (§8)

- Pack archetypes (and strong focus-fire NPCs) try the melee cell opposite
  an engaged ally first; if it isn't reachable this turn, behaviour is
  identical to before (the flank cell is just an injected goal candidate
  tested against the already-computed reach map — no extra pathfinding).
- Setting: **Enable flanking movement** (default **off**).

### Swim / Climb Budgets (§9)

- NPCs standing in water-tagged regions or tiles budget movement from their
  swim speed; creatures whose climb speed exceeds their walk use it when
  hugging walls (the greater-than guard prevents "standing near a wall"
  from shrinking budgets).
- Setting: **Swim/climb movement budgets** (default on).

### Spell Classifier Polish (§11)

- Upcast detection strips HTML before scanning and recognises the 2024
  phrasings ("for each additional spell level", "using a higher-level
  spell slot").
- Concentration-expiry awareness: a held spell with ≤1 round remaining makes
  breaking concentration near-free instead of demanding the full +20 score
  improvement.

### Bonus Actions & Morale (§1–§2, shipped in 0.17)

Carried forward unchanged: bonus-action economy (attacks, Healing Word,
self-buffs with ally routing) and morale recovery (crit/rout/reinforcement
events, real leader detection, rout propagation, GM morale whispers).
