/**
 * settings.js
 * Registers all module settings with Foundry's Settings API.
 * Settings are grouped by category via a custom ApplicationV2 submenu.
 */

export const MODULE_ID = "5e-npc-combat-automation";

/**
 * Pre-rename module id. Used ONLY by migration.js (one-time flag/setting copy)
 * and as a read fallback for flags written before 0.18. Never write to it.
 */
export const LEGACY_MODULE_ID = "5e-npc-combat-automation";

// ─── Setting key constants ──────────────────────────────────────────────────
export const SETTINGS = {
  // General
  ENABLED_BY_DEFAULT:   "enabledByDefault",
  ACTION_DELAY:         "actionDelay",
  ATTACK_DELAY:         "attackDelay",
  AUTO_END_TURN:        "autoEndTurn",
  ENABLE_MOVEMENT:      "enableMovement",
  ENABLE_CHAT_LOG:      "enableChatLog",

  // Combat Behaviour
  PREFER_MULTIATTACK:   "preferMultiattack",
  PREFER_MELEE:         "preferMelee",
  PREFER_RANGED:        "preferRanged",
  IGNORE_UNCONSCIOUS:   "ignoreUnconscious",
  IGNORE_HIDDEN:        "ignoreHidden",
  MAX_MOVEMENT:         "maxMovement",

  // Safety
  PAUSE_ON_ERROR:       "pauseOnError",
  LETHAL_CONFIRM:       "lethalConfirm",
  MAX_ACTIONS_PER_TURN: "maxActionsPerTurn",

  // Movement — Dash
  ENABLE_DASH:          "enableDash",

  // Movement — Pursuit
  ENABLE_PURSUIT:       "enablePursuit",

  // Movement — Natural pathing
  NATURAL_MOVEMENT:     "naturalMovement",

  // Movement — Animation / rotation
  MOVEMENT_STEP_DELAY:  "movementStepDelay",
  FACE_MOVEMENT:        "faceMovement",
  FACE_TARGET:          "faceTarget",
  ROTATION_OFFSET:      "rotationOffset",

  // Behaviour — retreat / fear
  ENABLE_FRIGHTENED_RETREAT: "enableFrightenedRetreat",
  ENABLE_BLOODIED_RETREAT:   "enableBloodiedRetreat",
  RETREAT_SUBTYPE_KEYWORDS:  "retreatSubtypeKeywords",

  // Movement — Doors
  NPC_OPEN_DOORS:       "npcOpenDoors",

  // Debug
  VERBOSE_LOGGING:           "verboseLogging",         // legacy boolean — kept for back-compat
  PATHFINDING_DEBUG_LEVEL:   "pathfindingDebugLevel",  // Feature 20: off|minimal|verbose|trace
  DRAW_MOVEMENT_PATH:        "drawMovementPath",

  // Combat Behaviour — CR filter
  MAX_AUTOMATED_CR:     "maxAutomatedCR",

  // Runtime (non-config, in-memory/world storage)
  AUTOMATION_ACTIVE:    "automationActive",

  // ── Tactical AI layer (behavior.js / morale.js / archetypes.js) ──────────
  ENABLE_BEHAVIOR_AI:        "enableBehaviorAI",
  ENABLE_AI_INFERENCE:       "enableAiInference",
  ENABLE_MORALE:             "enableMorale",
  BEHAVIOR_AI_SPELLCASTER_FOCUS: "behaviorAISpellcasterFocus",
  BEHAVIOR_AI_PACK_TACTICS:  "behaviorAIPackTactics",
  BEHAVIOR_AI_OPPORTUNISM:   "behaviorAIOpportunism",

  // ── Movement Imperfection & Space Rules ───────────────────────────────────
  MOVEMENT_IMPERFECTION:     "movementImperfection",
  PASS_THROUGH_FALLEN:       "passThroughFallen",
  DIFFICULT_TERRAIN:         "difficultTerrain",
  KITE_REQUIRES_DISENGAGE:   "kiteRequiresDisengage",
  DISPOSITION_TARGETING:     "dispositionTargeting",

  // ── Elevation & 3D Movement ──────────────────────────────────────────────
  ENABLE_ELEVATION:          "enableElevation",

  // ── Behavioral Effects (Charm, Confusion, midi overrides) ────────────────
  ENABLE_EFFECT_OVERRIDES:   "enableEffectOverrides",

  // ── midi-qol / Spellcaster Integration (DEPRECATED — kept for back-compat) ─
  /** @deprecated Use SPELL_ENABLED instead */
  ENABLE_MIDI_SPELLS:        "enableMidiSpells",
  /** @deprecated Replaced by archetype and cognitive profile system */
  SPELL_OVER_ATTACK_CR:      "spellOverAttackCR",

  // ── Spell AI (new in v1.0 spellcasting overhaul) ─────────────────────────
  SPELL_ENABLED:             "spellEnabled",
  SPELL_FRIENDLY_FIRE:       "spellFriendlyFire",
  SPELL_MIN_AOE_TARGETS:     "spellMinAOETargets",
  SPELL_SLOT_CONSERVATION:   "spellSlotConservation",
  SPELL_DEBUG_SCORING:       "spellDebugScoring",
  // ── Reaction Support ─────────────────────────────────────────────────────
  ENABLE_REACTIONS:          "enableReactions",
  ENABLE_BONUS_ACTIONS:      "enableBonusActions",
  ENABLE_LEGENDARY_ACTIONS:  "enableLegendaryActions",

  // ── Snapshot / Undo ───────────────────────────────────────────────────────
  SNAPSHOT_INCLUDE_RESOURCES: "snapshotIncludeResources",

  // ── Tactical movement (0.18) ──────────────────────────────────────────────
  ENABLE_FLANKING_MOVEMENT:  "enableFlankingMovement",
  ENABLE_SWIM_CLIMB_SPEED:   "enableSwimClimbSpeed",

  // ── Pathfinding refinement (0.19) ─────────────────────────────────────────
  PATHFIND_SINGLE_FLOOD:     "pathfindSingleFlood",
  PATHFIND_SMART_PARTIAL:    "pathfindSmartPartial",
  PATHFIND_LOS_MEMO:         "pathfindLosMemo",

  // ── Tracking refinement (0.19) ────────────────────────────────────────────
  TARGET_PERSISTENCE:        "targetPersistence",
  TARGET_GRUDGE_MEMORY:      "targetGrudgeMemory",
  SHARED_TARGET_MEMORY:      "sharedTargetMemory",

  // ── Reactivity refinement (0.19) ──────────────────────────────────────────
  ENABLE_OPPORTUNITY_ATTACKS: "enableOpportunityAttacks",
  RETARGET_ON_KILL:          "retargetOnKill",
  AOE_THREAT_MEMORY:         "aoeThreatMemory",

  // ── Morale visibility ─────────────────────────────────────────────────────
  MORALE_VISIBLE:            "moraleVisible",
  MORALE_VISIBLE_AUDIENCE:   "moraleVisibleAudience",

  // ── Dialogue / Combat Barks ──────────────────────────────────────────────
  DIALOGUE_ENABLED:          "dialogueEnabled",
  DIALOGUE_SPEECH_BUBBLES:   "dialogueSpeechBubbles",
  DIALOGUE_MIRROR_CHAT:      "dialogueMirrorChat",
  DIALOGUE_EFFORT_NOISES:    "dialogueEffortNoises",
  DIALOGUE_TRANSLATE_LANGUAGES: "dialogueTranslateLanguages",
  DIALOGUE_FREQUENCY:           "dialogueFrequency",
  DIALOGUE_COMBAT_ONLY:         "dialogueCombatOnly",
  DIALOGUE_JOURNAL_NAME:        "dialogueJournalName",
  DIALOGUE_BUBBLE_SCALE:        "dialogueBubbleScale",

  // ── AI Trace (observability) ──────────────────────────────────────────────
  AI_TRACE_ENABLED:          "aiTraceEnabled",
  AI_TRACE_AUTO_LOG:         "aiTraceAutoLog",
  AI_TRACE_BUFFER_SIZE:      "aiTraceBufferSize",

  // ── AI Behavior Iteration v1 (toggleable practical improvements) ──────────
  // Each can be flipped independently to A/B test feel at the table.
  AI_FINISHING_BLOW_BIAS:    "aiFinishingBlowBias",
  AI_REACHABILITY_PENALTY:   "aiReachabilityPenalty",
  AI_COVER_AWARE_PATHING:    "aiCoverAwarePathing",
  AI_SCOOT_TO_COVER:         "aiScootToCover",
};

// ─── getSetting / setSetting helpers ───────────────────────────────────────
export function getSetting(key) {
  return game.settings.get(MODULE_ID, key);
}

export function setSetting(key, value) {
  return game.settings.set(MODULE_ID, key, value);
}

// ─── Registration ───────────────────────────────────────────────────────────
export function registerSettings() {
  const loc = (key) => `NCA.Settings.${key}`;

  // ── General ──────────────────────────────────────────────────────────────

  game.settings.register(MODULE_ID, SETTINGS.ENABLED_BY_DEFAULT, {
    name: loc("EnableByDefault"),
    hint: loc("EnableByDefaultHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: false,
  });

  game.settings.register(MODULE_ID, SETTINGS.ACTION_DELAY, {
    name: loc("ActionDelay"),
    hint: loc("ActionDelayHint"),
    scope: "world",
    config: true,
    type: Number,
    default: 800,
    range: { min: 0, max: 5000, step: 100 },
  });

  game.settings.register(MODULE_ID, SETTINGS.ATTACK_DELAY, {
    name: loc("AttackDelay"),
    hint: loc("AttackDelayHint"),
    scope: "world",
    config: true,
    type: Number,
    default: 1200,
    range: { min: 0, max: 5000, step: 100 },
  });

  game.settings.register(MODULE_ID, SETTINGS.AUTO_END_TURN, {
    name: loc("AutoEndTurn"),
    hint: loc("AutoEndTurnHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.ENABLE_MOVEMENT, {
    name: loc("EnableMovement"),
    hint: loc("EnableMovementHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.ENABLE_CHAT_LOG, {
    name: loc("EnableChatLog"),
    hint: loc("EnableChatLogHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  // ── Combat Behaviour ──────────────────────────────────────────────────────

  game.settings.register(MODULE_ID, SETTINGS.PREFER_MULTIATTACK, {
    name: loc("PreferMultiattack"),
    hint: loc("PreferMultiattackHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.PREFER_MELEE, {
    name: loc("PreferMelee"),
    hint: loc("PreferMeleeHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.PREFER_RANGED, {
    name: loc("PreferRanged"),
    hint: loc("PreferRangedHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.IGNORE_UNCONSCIOUS, {
    name: loc("IgnoreUnconscious"),
    hint: loc("IgnoreUnconsciousHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.IGNORE_HIDDEN, {
    name: loc("IgnoreHidden"),
    hint: loc("IgnoreHiddenHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: false,
  });

  game.settings.register(MODULE_ID, SETTINGS.MAX_MOVEMENT, {
    name: loc("MaxMovement"),
    hint: loc("MaxMovementHint"),
    scope: "world",
    config: true,
    type: Number,
    default: 60,
    range: { min: 5, max: 300, step: 5 },
  });

  game.settings.register(MODULE_ID, SETTINGS.ENABLE_DASH, {
    name: loc("EnableDash"),
    hint: loc("EnableDashHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.NPC_OPEN_DOORS, {
    name: loc("NpcOpenDoors"),
    hint: loc("NpcOpenDoorsHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.ENABLE_PURSUIT, {
    name: loc("EnablePursuit"),
    hint: loc("EnablePursuitHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.NATURAL_MOVEMENT, {
    name: loc("NaturalMovement"),
    hint: loc("NaturalMovementHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.MOVEMENT_STEP_DELAY, {
    name: loc("MovementStepDelay"),
    hint: loc("MovementStepDelayHint"),
    scope: "world",
    config: true,
    type: Number,
    default: 225,
    range: { min: 0, max: 1000, step: 25 },
  });

  game.settings.register(MODULE_ID, SETTINGS.FACE_MOVEMENT, {
    name: loc("FaceMovement"),
    hint: loc("FaceMovementHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.FACE_TARGET, {
    name: loc("FaceTarget"),
    hint: loc("FaceTargetHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.ROTATION_OFFSET, {
    name: loc("RotationOffset"),
    hint: loc("RotationOffsetHint"),
    scope: "world",
    config: true,
    type: Number,
    default: 180,
    range: { min: 0, max: 360, step: 15 },
  });

  game.settings.register(MODULE_ID, SETTINGS.ENABLE_FRIGHTENED_RETREAT, {
    name: loc("EnableFrightenedRetreat"),
    hint: loc("EnableFrightenedRetreatHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.ENABLE_BLOODIED_RETREAT, {
    name: loc("EnableBloodiedRetreat"),
    hint: loc("EnableBloodiedRetreatHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.RETREAT_SUBTYPE_KEYWORDS, {
    name: loc("RetreatSubtypeKeywords"),
    hint: loc("RetreatSubtypeKeywordsHint"),
    scope: "world",
    config: true,
    type: String,
    default: "coward, skittish, fearful, prey, survivalist",
  });

  game.settings.register(MODULE_ID, SETTINGS.MAX_AUTOMATED_CR, {
    name: loc("MaxAutomatedCR"),
    hint: loc("MaxAutomatedCRHint"),
    scope: "world",
    config: true,
    type: Number,
    default: 5,
    range: { min: 0, max: 30, step: 1 },
  });

  // ── Safety ────────────────────────────────────────────────────────────────

  game.settings.register(MODULE_ID, SETTINGS.PAUSE_ON_ERROR, {
    name: loc("PauseOnError"),
    hint: loc("PauseOnErrorHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.LETHAL_CONFIRM, {
    name: loc("LethalConfirm"),
    hint: loc("LethalConfirmHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: false,
  });

  game.settings.register(MODULE_ID, SETTINGS.MAX_ACTIONS_PER_TURN, {
    name: loc("MaxActionsPerTurn"),
    hint: loc("MaxActionsPerTurnHint"),
    scope: "world",
    config: true,
    type: Number,
    default: 6,
    range: { min: 1, max: 20, step: 1 },
  });

  // ── Debug ─────────────────────────────────────────────────────────────────

  // Feature 20 — replaces the old boolean verboseLogging toggle.
  game.settings.register(MODULE_ID, SETTINGS.PATHFINDING_DEBUG_LEVEL, {
    name: loc("PathfindingDebugLevel"),
    hint: loc("PathfindingDebugLevelHint"),
    scope: "world",
    config: true,
    type: String,
    // Foundry localizes choices values at render time when they are i18n keys.
    // Calling game.i18n.localize() here during `init` is fragile — the
    // language pack may not be loaded yet, and the cached strings won't
    // update if the user changes language mid-session.
    choices: {
      off:     "NCA.Settings.DebugLevel.Off",
      minimal: "NCA.Settings.DebugLevel.Minimal",
      verbose: "NCA.Settings.DebugLevel.Verbose",
      trace:   "NCA.Settings.DebugLevel.Trace",
    },
    default: "minimal",
  });

  // Legacy boolean kept for back-compat — hidden from menu.
  game.settings.register(MODULE_ID, SETTINGS.VERBOSE_LOGGING, {
    name: "Verbose Logging (Legacy)",
    hint: "Deprecated — use Pathfinding Debug Level instead.",
    scope: "world",
    config: false,
    type: Boolean,
    default: false,
  });

  game.settings.register(MODULE_ID, SETTINGS.DRAW_MOVEMENT_PATH, {
    name: loc("DrawMovementPath"),
    hint: loc("DrawMovementPathHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: false,
  });

  // ── Runtime state (world-scoped so all clients share it) ──────────────────
  game.settings.register(MODULE_ID, SETTINGS.AUTOMATION_ACTIVE, {
    name: "Automation Active (Runtime)",
    scope: "world",
    config: false,    // hidden from normal settings menu
    type: Boolean,
    default: false,
  });

  // ── Tactical AI Layer ─────────────────────────────────────────────────────

  game.settings.register(MODULE_ID, SETTINGS.ENABLE_BEHAVIOR_AI, {
    name: loc("EnableBehaviorAI"),
    hint: loc("EnableBehaviorAIHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.ENABLE_AI_INFERENCE, {
    name: loc("EnableAiInference"),
    hint: loc("EnableAiInferenceHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.ENABLE_MORALE, {
    name: loc("EnableMorale"),
    hint: loc("EnableMoraleHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.BEHAVIOR_AI_SPELLCASTER_FOCUS, {
    name: loc("BehaviorAISpellcasterFocus"),
    hint: loc("BehaviorAISpellcasterFocusHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.BEHAVIOR_AI_PACK_TACTICS, {
    name: loc("BehaviorAIPackTactics"),
    hint: loc("BehaviorAIPackTacticsHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.BEHAVIOR_AI_OPPORTUNISM, {
    name: loc("BehaviorAIOpportunism"),
    hint: loc("BehaviorAIOpportunismHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });
}

// ── Movement Imperfection / Space Rules / Disposition Targeting ───────────────
// These registrations are appended after the closing brace of registerSettings()
// and called via a second pass in main.js (or by reopening the function export).
// In practice, splice these three blocks inside registerSettings() above the
// final closing brace when integrating into the shipped file.

export function registerExtendedSettings() {
  const loc = (key) => `NCA.Settings.${key}`;

  game.settings.register(MODULE_ID, "movementImperfection", {
    name: loc("MovementImperfection"),
    hint: loc("MovementImperfectionHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, "passThroughFallen", {
    name: loc("PassThroughFallen"),
    hint: loc("PassThroughFallenHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.DIFFICULT_TERRAIN, {
    name: loc("DifficultTerrain"),
    hint: loc("DifficultTerrainHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.KITE_REQUIRES_DISENGAGE, {
    name: loc("KiteRequiresDisengage"),
    hint: loc("KiteRequiresDisengageHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, "dispositionTargeting", {
    name: loc("DispositionTargeting"),
    hint: loc("DispositionTargetingHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  // ── Elevation / 3D Movement ───────────────────────────────────────────────

  game.settings.register(MODULE_ID, "enableElevation", {
    name: loc("EnableElevation"),
    hint: loc("EnableElevationHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  // ── Behavioral Effects ────────────────────────────────────────────────────

  game.settings.register(MODULE_ID, "enableEffectOverrides", {
    name: loc("EnableEffectOverrides"),
    hint: loc("EnableEffectOverridesHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  // ── Spell AI (NCA v1.0 Spellcasting Overhaul) ────────────────────────────

  game.settings.register(MODULE_ID, SETTINGS.SPELL_ENABLED, {
    name: loc("SpellEnabled"),
    hint: loc("SpellEnabledHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.SPELL_FRIENDLY_FIRE, {
    name: loc("SpellFriendlyFire"),
    hint: loc("SpellFriendlyFireHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: false,
  });

  game.settings.register(MODULE_ID, SETTINGS.SPELL_MIN_AOE_TARGETS, {
    name: loc("SpellMinAOETargets"),
    hint: loc("SpellMinAOETargetsHint"),
    scope: "world",
    config: true,
    type: Number,
    default: 2,
    range: { min: 1, max: 6, step: 1 },
  });

  game.settings.register(MODULE_ID, SETTINGS.SPELL_SLOT_CONSERVATION, {
    name: loc("SpellSlotConservation"),
    hint: loc("SpellSlotConservationHint"),
    scope: "world",
    config: true,
    type: String,
    // Use localization KEYS here — Foundry localizes them at render time.
    // Calling game.i18n.localize() during `init` is unreliable (language pack
    // load order) and caches stale strings if the user changes language.
    choices: {
      archetype: "NCA.Settings.SpellConservation.Archetype",
      none:      "NCA.Settings.SpellConservation.None",
      moderate:  "NCA.Settings.SpellConservation.Moderate",
      strong:    "NCA.Settings.SpellConservation.Strong",
    },
    default: "archetype",
  });

  game.settings.register(MODULE_ID, SETTINGS.SPELL_DEBUG_SCORING, {
    name: loc("SpellDebugScoring"),
    hint: loc("SpellDebugScoringHint"),
    scope: "client",
    config: true,
    type: Boolean,
    default: false,
  });

  // ── midi-qol legacy settings — kept so existing worlds don't error on load ─

  game.settings.register(MODULE_ID, SETTINGS.ENABLE_MIDI_SPELLS, {
    name: "Enable midi-qol Spell Automation (Legacy)",
    hint: "Deprecated — spell AI is now always active. This setting is ignored.",
    scope: "world",
    config: false,   // hidden; migrated users won't see it
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.SPELL_OVER_ATTACK_CR, {
    name: "Minimum CR for Spell Preference (Legacy)",
    hint: "Deprecated — replaced by archetype and cognitive profile system.",
    scope: "world",
    config: false,
    type: Number,
    default: 3,
    range: { min: 0, max: 30, step: 1 },
  });

  // ── Reaction Support ──────────────────────────────────────────────────────

  game.settings.register(MODULE_ID, SETTINGS.ENABLE_REACTIONS, {
    name: loc("EnableReactions"),
    hint: loc("EnableReactionsHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.ENABLE_BONUS_ACTIONS, {
    name: "Enable bonus actions",
    hint: "After its main action, an NPC spends a bonus action if it has one available (off-hand attack, Healing Word, self-buff, etc.). Beneficial bonus spells route to allies/self via disposition; bonus heals only fire when someone is hurt. Off → NPCs never take bonus actions (pre-0.17 behaviour).",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.ENABLE_LEGENDARY_ACTIONS, {
    name: "Enable legendary actions",
    hint: "Legendary NPCs spend legendary actions at the end of other combatants' turns (one option per trigger, RAW). Costs are read from the item ('Costs N Actions'), the pool refreshes at the start of the creature's own turn, and decisions are recorded in the AI trace. Off → legendary actions are never automated.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.SNAPSHOT_INCLUDE_RESOURCES, {
    name: "Undo NPC Block: restore resources",
    hint: "The pre-block snapshot also captures spell slots, item charges, and the set of active effects, restoring them on undo (effects gained during the block are removed; effects that expired stay expired). Off → undo restores positions and HP only (pre-0.18 behaviour).",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.ENABLE_FLANKING_MOVEMENT, {
    name: "Enable flanking movement",
    hint: "Pack archetypes (pack-flanker, pack-hunter) and strong focus-fire NPCs try to reach the melee cell opposite an engaged ally before falling back to the nearest one. Off by default — not all tables use the optional flanking rule, and the movement pattern reads as flanking even without the mechanical advantage.",
    scope: "world",
    config: true,
    type: Boolean,
    default: false,
  });

  game.settings.register(MODULE_ID, SETTINGS.ENABLE_SWIM_CLIMB_SPEED, {
    name: "Swim/climb movement budgets",
    hint: "NPCs standing in water-tagged regions or tiles budget movement from their swim speed; creatures whose climb speed exceeds their walk use it when hugging walls. Off → all movement budgets use walking speed (pre-0.18 behaviour).",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  // ─── 0.19 AI refinement pass ────────────────────────────────────────────

  game.settings.register(MODULE_ID, SETTINGS.PATHFIND_SINGLE_FLOOD, {
    name: "Pathfinding: single-flood tiering",
    hint: "Compute one reachability flood to the largest needed budget and derive the normal/dash/double-dash tiers by filtering, instead of up to three separate floods per turn. Pure optimisation — decisions are identical; turn this off only when diagnosing pathfinding issues.",
    scope: "world", config: true, type: Boolean, default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.PATHFIND_SMART_PARTIAL, {
    name: "Pathfinding: smart partial advance",
    hint: "When no attack position is reachable this turn, the fallback cell weighs threat exposure alongside distance, and tie-breaks on line of sight (ranged NPCs keep it, stranded melee breaks it) — instead of blindly picking the geometrically closest cell.",
    scope: "world", config: true, type: Boolean, default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.PATHFIND_LOS_MEMO, {
    name: "Pathfinding: per-turn sightline cache",
    hint: "Memoise wall-collision sightline tests for the duration of each automated turn (invalidated on any wall/door change). Significant speed-up on wall-dense maps; identical results.",
    scope: "world", config: true, type: Boolean, default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.TARGET_PERSISTENCE, {
    name: "Targeting: persistent targets",
    hint: "NPCs prefer to keep attacking last turn's target (decaying bonus over 2–3 turns) instead of ping-ponging between equidistant enemies. Always overridden by: target dropped, priority-target flag, forced targets (charm/taunt), or a clearly better candidate.",
    scope: "world", config: true, type: Boolean, default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.TARGET_GRUDGE_MEMORY, {
    name: "Targeting: grudge memory",
    hint: "NPCs track who has damaged them this combat. Attackers gain a capped targeting bonus proportional to damage dealt, and a single hit over 25% max HP registers as a morale shock.",
    scope: "world", config: true, type: Boolean, default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.SHARED_TARGET_MEMORY, {
    name: "Tracking: shared last-known positions",
    hint: "When a target hides, every NPC that saw it records the last known position. NPCs with INT 10+ can use positions reported by allies (they shout); dim creatures only remember what they personally saw. Entries expire after 3 rounds or on re-sighting.",
    scope: "world", config: true, type: Boolean, default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.ENABLE_OPPORTUNITY_ATTACKS, {
    name: "Enable opportunity attacks",
    hint: "Automated NPCs take opportunity attacks when a hostile token leaves their melee reach without Disengaging (one reaction per round, skipped if midi-qol's own OA handling is detected). OFF by default: this interrupts player actions — playtest before enabling.",
    scope: "world", config: true, type: Boolean, default: false,
  });

  game.settings.register(MODULE_ID, SETTINGS.RETARGET_ON_KILL, {
    name: "Retarget remaining attacks on kill",
    hint: "When a multiattack drops its target mid-sequence, remaining attacks retarget the best valid enemy already within reach from the current position (no extra movement) instead of being wasted.",
    scope: "world", config: true, type: Boolean, default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.AOE_THREAT_MEMORY, {
    name: "AOE threat memory",
    hint: "Recently-placed damage templates (Spirit Guardians, Wall of Fire, etc.) leave a 2-round danger zone that NPCs with INT 10+ path around on their own turns. Off by default — adds template rasterisation work; enable on tables with heavy area-control casters.",
    scope: "world", config: true, type: Boolean, default: false,
  });


  game.settings.register(MODULE_ID, SETTINGS.MORALE_VISIBLE, {
    name: "Visible morale",
    hint: "Show morale gains and losses as floating green (+) / red (−) bubbles above creatures, using the dialogue bubble framework. Off → morale stays hidden in the log.",
    scope: "world",
    config: true,
    type: Boolean,
    default: false,
  });

  game.settings.register(MODULE_ID, SETTINGS.MORALE_VISIBLE_AUDIENCE, {
    name: "Visible morale — shown to",
    hint: "Which users see the floating morale bubbles. Each tier includes everyone above it.",
    scope: "world",
    config: true,
    type: String,
    choices: {
      gm:        "GM only",
      assistant: "GM & Assistant GM",
      trusted:   "GM, Assistant & Trusted Players",
      player:    "Everyone (all players)",
    },
    default: "gm",
  });

  // ── Dialogue / Combat Barks ───────────────────────────────────────────────

  game.settings.register(MODULE_ID, "dialogueEnabled", {
    name: loc("DialogueEnabled"),
    hint: loc("DialogueEnabledHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, "dialogueSpeechBubbles", {
    name: loc("DialogueSpeechBubbles"),
    hint: loc("DialogueSpeechBubblesHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, "dialogueMirrorChat", {
    name: loc("DialogueMirrorChat"),
    hint: loc("DialogueMirrorChatHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: false,
  });

  game.settings.register(MODULE_ID, "dialogueCombatOnly", {
    name: loc("DialogueCombatOnly"),
    hint: loc("DialogueCombatOnlyHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, "dialogueEffortNoises", {
    name: loc("DialogueEffortNoises"),
    hint: loc("DialogueEffortNoisesHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, "dialogueTranslateLanguages", {
    name: loc("DialogueTranslateLanguages"),
    hint: loc("DialogueTranslateLanguagesHint"),
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, "dialogueFrequency", {
    name: loc("DialogueFrequency"),
    hint: loc("DialogueFrequencyHint"),
    scope: "world",
    config: true,
    type: Number,
    default: 5,
    range: { min: 1, max: 10, step: 1 },
  });

  game.settings.register(MODULE_ID, "dialogueJournalName", {
    name: loc("DialogueJournalName"),
    hint: loc("DialogueJournalNameHint"),
    scope: "world",
    config: true,
    type: String,
    default: "NCA Dialogue",
  });

  game.settings.register(MODULE_ID, "dialogueBubbleScale", {
    name: loc("DialogueBubbleScale"),
    hint: loc("DialogueBubbleScaleHint"),
    scope: "client",
    config: true,
    type: Number,
    default: 1.0,
    range: { min: 0.5, max: 3.0, step: 0.1 },
    onChange: value => {
      document.documentElement.style.setProperty("--nca-bubble-scale", String(value));
    },
  });

  // "Open Dialogue Journal" button — creates it if needed, then opens it.
  //
  // Migrated from the deprecated FormApplication pattern to ApplicationV2
  // (V13-native). The class is a pure action trigger: render() performs the
  // journal open/create and never actually mounts a window. _renderHTML /
  // _replaceHTML are stubbed because ApplicationV2 is abstract without them,
  // even though they are never reached.
  game.settings.registerMenu(MODULE_ID, "openDialogueJournal", {
    name: loc("OpenDialogueJournal"),
    label: loc("OpenDialogueJournalLabel"),
    hint: loc("OpenDialogueJournalHint"),
    icon: "fas fa-book-open",
    type: class extends foundry.applications.api.ApplicationV2 {
      async _renderHTML() { return ""; }
      _replaceHTML() {}
      async render() {
        // Lazy import avoids circular deps at registration time
        try {
          const { openOrCreateDialogueJournal } = await import("./dialogue-journal.js");
          await openOrCreateDialogueJournal();
        } catch (err) {
          console.error("[NCA] Failed to open dialogue journal:", err);
          ui.notifications?.error("Failed to open NCA Dialogue Journal — see console.");
        }
        return this;
      }
    },
    restricted: true,
  });

  // ── AI Trace ──────────────────────────────────────────────────────────────
  // Client-scoped: individual GMs flip this on per session without
  // committing the choice to world data.
  game.settings.register(MODULE_ID, SETTINGS.AI_TRACE_ENABLED, {
    name: "AI Trace: enable per-turn decision capture",
    hint: "Records one structured row per NPC turn (archetype, scores, target, movement, action). Zero overhead when off. Access via game.modules.get('5e-npc-combat-automation').api.trace.",
    scope: "client",
    config: true,
    type: Boolean,
    default: false,
  });

  game.settings.register(MODULE_ID, SETTINGS.AI_TRACE_AUTO_LOG, {
    name: "AI Trace: also auto-log to console",
    hint: "When enabled along with AI Trace, each completed turn is also emitted as a single-line JSON to the dev console. Useful for tailing decisions in real time.",
    scope: "client",
    config: true,
    type: Boolean,
    default: false,
  });

  game.settings.register(MODULE_ID, SETTINGS.AI_TRACE_BUFFER_SIZE, {
    name: "AI Trace: ring buffer size",
    hint: "Maximum number of turns held in memory before the oldest are dropped. 500 covers ~50 rounds of a typical encounter. Range 50-5000.",
    scope: "client",
    config: true,
    type: Number,
    default: 500,
    range: { min: 50, max: 5000, step: 50 },
  });

  // ── AI Behavior Iteration v1 ──────────────────────────────────────────────
  // Three practical, individually-toggleable changes. Default ON so they take
  // effect immediately on install, but each can be disabled to compare feel.
  game.settings.register(MODULE_ID, SETTINGS.AI_FINISHING_BLOW_BIAS, {
    name: "AI v1: finishing-blow bias",
    hint: "NPCs aggressively prioritise targets near zero HP. Replaces the linear wounded-target weight with a steep curve — a target at 10% HP gets ~24 bonus, a target at 50% HP gets ~7.5. Disable to revert to the linear preference.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.AI_REACHABILITY_PENALTY, {
    name: "AI v1: reachability penalty",
    hint: "Penalises target candidates that the NPC cannot reach this turn (even with Dash). Stops melee NPCs from fixating on far-away targets they could not engage. The penalty is overridden by focus-fire, pack tactics, and spellcaster-focus hints, so signature behaviours still take precedence.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.AI_COVER_AWARE_PATHING, {
    name: "AI v1: cover-aware pathfinding",
    hint: "Adds a small movement-cost penalty for cells exposed to line-of-sight from ranged enemies. NPCs naturally prefer routes through cover when the cost difference is small, but will still cross open ground when speed matters. Off → behaves identically to v0.10.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTINGS.AI_SCOOT_TO_COVER, {
    name: "AI v1: scoot-to-cover after action",
    hint: "After a high-INT ranged NPC (mage, sniper, controller) successfully attacks, it uses leftover movement to step behind cover — breaking the target's line of sight to itself. Self-preserving for the caster and clears the lane for melee allies who would otherwise be blocked. Only fires when INT ≥ 14 and the NPC has a ranged-leaning archetype. Off → behaves identically to v0.12.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });
}
