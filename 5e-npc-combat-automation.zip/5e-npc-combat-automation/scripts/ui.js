/**
 * ui.js
 * Combat Tracker UI controls:
 *  - Toggle button for enabling/disabling NPC automation
 *  - Active-state indicator pip on the current combatant row
 *
 * Uses Foundry v13 Application V2 patterns where relevant.
 * The combat tracker itself is rendered by core; we inject minimally via
 * the renderCombatTracker hook to avoid brittle DOM hacks.
 */

import { getSetting, setSetting, SETTINGS, MODULE_ID } from "./settings.js";
import { log } from "./utils.js";
import { ARCHETYPES } from "./archetypes.js";
import { inferAndCacheAiProfile, getCachedAiProfile } from "./ai-inference.js";
import { takeSnapshot, hasSnapshot, clearSnapshot, restoreSnapshot } from "./snapshot.js";

// ─── Public API ───────────────────────────────────────────────────────────────

// Re-export snapshot utilities so main.js can wire them into hooks and the
// global API without importing snapshot.js directly (avoiding duplicate imports).
export { takeSnapshot, hasSnapshot, clearSnapshot, restoreSnapshot };

/**
 * Register all UI hooks. Called once during module initialisation.
 */
export function registerUIHooks() {
  // Inject toggle button whenever the combat tracker renders
  Hooks.on("renderCombatTracker", _onRenderCombatTracker);
  // Inject AI Profile tab into NPC actor sheets
  registerAiTabHooks();
}

/**
 * Returns the current automation enabled state.
 * @returns {boolean}
 */
export function isAutomationActive() {
  try {
    return getSetting(SETTINGS.AUTOMATION_ACTIVE);
  } catch {
    return false;
  }
}

/**
 * Set automation state and refresh the combat tracker.
 * @param {boolean} active
 */
export async function setAutomationActive(active) {
  await setSetting(SETTINGS.AUTOMATION_ACTIVE, active);
  log(`Automation ${active ? "enabled" : "disabled"} by GM.`);
  ui.combat?.render(false); // re-render the combat tracker to update button state
}

// ─── Hook handler ─────────────────────────────────────────────────────────────

/**
 * Inject the automation toggle button into the combat tracker header controls.
 * Also injects the "Undo NPC Block" button when a snapshot is available,
 * and the "▶ Force Automate" button on the active NPC combatant row.
 * Only shown to GMs.
 *
 * @param {CombatTracker} app   - The CombatTracker Application instance.
 * @param {jQuery}        html  - The rendered jQuery HTML.
 */
function _onRenderCombatTracker(app, html) {
  if (!game.user.isGM) return;

  const active = isAutomationActive();
  const combat = game.combat;

  const root = html instanceof jQuery ? html[0] : html;

  // ── Automation toggle button ─────────────────────────────────────────────
  const btn = document.createElement("a");
  btn.classList.add("combat-control", "nca-toggle-btn");
  if (active) btn.classList.add("active");
  btn.setAttribute("data-tooltip", game.i18n.localize("NCA.UI.ToggleButton"));
  btn.setAttribute("aria-label", game.i18n.localize("NCA.UI.ToggleButton"));
  btn.setAttribute("role", "button");
  btn.title = active
    ? game.i18n.localize("NCA.UI.AutomationEnabled")
    : game.i18n.localize("NCA.UI.AutomationDisabled");

  const icon = document.createElement("i");
  icon.classList.add("fas", "fa-robot");
  btn.appendChild(icon);

  btn.addEventListener("click", async (e) => {
    e.preventDefault();
    await setAutomationActive(!isAutomationActive());
  });

  // ── Undo NPC Block button ─────────────────────────────────────────────────
  // Only shown when a snapshot exists for this combat.
  let undoBtn = null;
  if (combat && hasSnapshot(combat)) {
    undoBtn = document.createElement("a");
    undoBtn.classList.add("combat-control", "nca-undo-btn");
    undoBtn.setAttribute("data-tooltip", game.i18n.localize("NCA.UI.UndoNPCBlock"));
    undoBtn.setAttribute("aria-label", game.i18n.localize("NCA.UI.UndoNPCBlock"));
    undoBtn.setAttribute("role", "button");
    undoBtn.title = game.i18n.localize("NCA.UI.UndoNPCBlock");
    undoBtn.innerHTML = `<i class="fas fa-undo"></i>`;

    undoBtn.addEventListener("click", async (e) => {
      e.preventDefault();
      if (combat) await restoreSnapshot(combat);
    });
  }

  // Find the combat tracker header controls bar
  const headerNav = root.querySelector(".encounter-controls, nav.encounters, .combat-tracker-header");

  if (headerNav) {
    headerNav.appendChild(btn);
    if (undoBtn) headerNav.appendChild(undoBtn);
  } else {
    root?.appendChild?.(btn);
    if (undoBtn) root?.appendChild?.(undoBtn);
  }

  // ── Active-turn pip ─────────────────────────────────────────────────────
  _injectActivePip(html, active);

  // ── Force Automate button on active NPC row ──────────────────────────────
  if (combat) _injectForceAutomateButton(root, combat);
}

/**
 * Place a small animated pip next to the active combatant's name
 * to indicate their turn is being automated.
 *
 * @param {jQuery|HTMLElement} html
 * @param {boolean}            automationActive
 */
function _injectActivePip(html, automationActive) {
  if (!automationActive) return;

  const root = html instanceof jQuery ? html[0] : html;
  const activeLi = root?.querySelector?.("li.active");
  if (!activeLi) return;

  // Don't duplicate
  if (activeLi.querySelector(".nca-active-pip")) return;

  // Only pip NPC combatants
  const combatantId = activeLi.dataset?.combatantId;
  if (!combatantId) return;

  const combatant = game.combat?.combatants.get(combatantId);
  if (!combatant) return;

  // Skip player-owned tokens
  if (combatant.actor?.hasPlayerOwner) return;

  const pip = document.createElement("span");
  pip.classList.add("nca-active-pip");
  pip.title = "NPC turn being automated";

  const nameEl = activeLi.querySelector(".token-name, .combatant-name");
  if (nameEl) nameEl.appendChild(pip);
}

/**
 * Inject a "▶ Force Automate" button onto every visible NPC combatant row.
 * Clicking it runs that combatant's turn immediately, bypassing all gate
 * checks (CR limit, automation-off, enabledByDefault) while preserving safety
 * guards (0 HP, player-character block, token-on-canvas).
 *
 * The button is GM-only and NPC-only; player-character rows are skipped.
 *
 * @param {HTMLElement} root   - The combat tracker root element.
 * @param {Combat}      combat
 */
function _injectForceAutomateButton(root, combat) {
  // Lazily import the force-automate function to avoid circular imports.
  // We use a closure so the import promise is shared across rows.
  const getForceAutomate = (() => {
    let cached = null;
    return async () => {
      if (!cached) {
        const mod = await import("./automation.js");
        cached = mod.forceAutomateTurn;
      }
      return cached;
    };
  })();

  const rows = root.querySelectorAll("li.combatant");
  for (const li of rows) {
    const combatantId = li.dataset?.combatantId;
    if (!combatantId) continue;

    const combatant = combat.combatants.get(combatantId);
    if (!combatant) continue;

    // NPC-only: skip player characters and player-owned actors
    const actor = combatant.actor;
    if (!actor || actor.type === "character" || actor.hasPlayerOwner) continue;

    // Don't duplicate
    if (li.querySelector(".nca-force-btn")) continue;

    // Defeated combatants: still show button but disable it
    const defeated = combatant.defeated || (actor.system?.attributes?.hp?.value ?? 1) <= 0;

    const forceBtn = document.createElement("a");
    forceBtn.classList.add("combatant-control", "nca-force-btn");
    if (defeated) forceBtn.classList.add("nca-force-btn--defeated");
    forceBtn.setAttribute("data-tooltip", game.i18n.localize("NCA.UI.ForceAutomate"));
    forceBtn.setAttribute("aria-label", game.i18n.localize("NCA.UI.ForceAutomate"));
    forceBtn.setAttribute("role", "button");
    forceBtn.title = game.i18n.localize("NCA.UI.ForceAutomate");
    forceBtn.innerHTML = `<i class="fas fa-play-circle"></i>`;

    if (!defeated) {
      forceBtn.addEventListener("click", async (e) => {
        e.preventDefault();
        e.stopPropagation();
        const forceAutomateTurn = await getForceAutomate();
        log(`Force Automate clicked for ${combatant.name}`);
        try {
          await forceAutomateTurn(combatant, combat);
        } catch (err) {
          console.error(`[NCA] Force automate failed for ${combatant.name}:`, err);
          ui.notifications.error(`NCA: Force automate failed for ${combatant.name}. Check the console.`);
        }
      });
    }

    // Insert before the existing controls (initiative, etc.) or append
    const controls = li.querySelector(".combatant-controls");
    if (controls) {
      controls.insertBefore(forceBtn, controls.firstChild);
    } else {
      li.appendChild(forceBtn);
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// AI PROFILE TAB — NPC Actor Sheet Integration
// ═══════════════════════════════════════════════════════════════════════════════



/**
 * Register all actor-sheet hooks for the AI Profile tab.
 * Called from registerUIHooks().
 */
export function registerAiTabHooks() {
  Hooks.on("renderActorSheet", _onRenderActorSheet);
  Hooks.on("renderActorSheetV2", _onRenderActorSheet);

  // When items are added/removed (e.g. imported from a compendium), Foundry
  // re-renders the sheet but may do so before the old injected DOM is torn
  // down — causing the duplicate-guard to block re-injection on the new DOM.
  // We track a set of actor IDs that need a forced re-injection on the next
  // renderActorSheet call, bypassing the duplicate guard just once.
  Hooks.on("createItem", (item) => {
    if (item.parent?.type === "npc") _flagActorForReinjection(item.parent.id);
  });
  Hooks.on("deleteItem", (item) => {
    if (item.parent?.type === "npc") _flagActorForReinjection(item.parent.id);
  });
}

// Track actor IDs that must bypass the duplicate-injection guard once.
// Populated when items are added/removed so the tab is re-injected after
// Foundry re-renders the sheet following a compendium import.
const _reinjectionPending = new Set();

function _flagActorForReinjection(actorId) {
  _reinjectionPending.add(actorId);
}

const ARCHETYPE_GROUPS = {
  "Aggressive": ["berserker", "brute", "zealot", "fearless", "sadistic"],
  "Cautious":   ["coward", "cautious", "defensive"],
  "Tactical":   ["disciplined", "tactician", "guardian", "bodyguard"],
  "Ranged":     ["skirmisher", "sniper", "artillery"],
  "Predatory":  ["predator", "hunter", "beast-instinctive"],
  "Pack":       ["pack-hunter", "pack-flanker", "hive-minded"],
  "Stealth":    ["opportunist", "assassin", "ambusher"],
  "Special":    ["territorial", "undead-mindless", "undead-disciplined", "mob-walker", "panicked"],
};

const ARCHETYPE_LABELS = {
  "berserker":         "Berserker",
  "brute":             "Brute",
  "zealot":            "Zealot",
  "fearless":          "Fearless",
  "sadistic":          "Sadistic",
  "coward":            "Coward",
  "cautious":          "Cautious",
  "defensive":         "Defensive",
  "disciplined":       "Disciplined",
  "tactician":         "Tactician",
  "guardian":          "Guardian",
  "bodyguard":         "Bodyguard",
  "skirmisher":        "Skirmisher",
  "sniper":            "Sniper",
  "artillery":         "Artillery",
  "predator":          "Predator",
  "hunter":            "Hunter",
  "beast-instinctive": "Beast (Instinctive)",
  "pack-hunter":       "Pack Hunter",
  "pack-flanker":      "Pack Flanker",
  "hive-minded":       "Hive-Minded",
  "opportunist":       "Opportunist",
  "assassin":          "Assassin",
  "ambusher":          "Ambusher",
  "territorial":       "Territorial",
  "undead-mindless":   "Undead (Mindless)",
  "undead-disciplined":"Undead (Disciplined)",
  "mob-walker":        "Mob Walker",
  "panicked":          "Panicked",
};

// ─── Sheet render hook ────────────────────────────────────────────────────────

async function _onRenderActorSheet(app, html, data) {
  const actor = app.actor ?? app.document;
  if (!actor || actor.type !== "npc") return;
  if (!game.user.isGM) return;
  if (!getSetting(SETTINGS.ENABLE_BEHAVIOR_AI)) return;

  const root = html instanceof jQuery ? html[0] : html;
  if (!root) return;

  // Find the sheet's tab nav (works for dnd5e v3+ ApplicationV2 and legacy sheets)
  const tabNav = root.querySelector(".tabs[data-group='primary'], .sheet-tabs, nav.tabs");
  if (!tabNav) return;

  // ── LAYOUT FIX: Find the correct tab body container ──────────────────────
  // In dnd5e V3+ (ApplicationV2), the tab body is a direct child of the
  // sheet body. The sidebar (.sheet-sidebar) is a SIBLING in a flex/grid
  // layout — not a child of tab-body.
  //
  // We must inject into the actual tab switching container, NOT the
  // sheet-body wrapper that includes the sidebar.
  //
  // Selector priority:
  //   1. .tab-body   — dnd5e V3+ ApplicationV2 (tabs live here, sidebar is sibling)
  //   2. .sheet-body — dnd5e V2 legacy (tabs are children, sidebar may be inside)
  // In case 2, we scope further to avoid injecting beside the sidebar.
  let tabBody = root.querySelector(".tab-body");
  if (!tabBody) {
    // Legacy fallback: find a flex/grid container that has .tab children
    // but is NOT the outer wrapper that contains .sheet-sidebar
    const sheetBody = root.querySelector(".sheet-body, section.sheet-body");
    if (!sheetBody) return;
    // Prefer a child div that actually contains existing .tab elements
    const innerTabContainer = sheetBody.querySelector(":scope > div:not(.sheet-sidebar)");
    tabBody = innerTabContainer ?? sheetBody;
  }

  // Don't inject twice — UNLESS a re-injection was requested (e.g. after
  // importing an item from a compendium caused Foundry to re-render the sheet).
  const needsReinjection = _reinjectionPending.has(actor.id);
  if (needsReinjection) {
    _reinjectionPending.delete(actor.id);
    // Remove any stale injected tab so we start clean
    root.querySelector(".nca-ai-tab")?.remove();
    root.querySelector(".nca-ai-tab-nav")?.remove();
  } else if (root.querySelector(".nca-ai-tab")) {
    return;
  }

  // ── Tab nav entry ────────────────────────────────────────────────────────
  const tabGroup = tabNav.dataset.group ?? "primary";
  const tabItem = document.createElement("a");
  tabItem.classList.add("item", "nca-ai-tab-nav");
  tabItem.dataset.tab = "nca-ai";
  tabItem.dataset.group = tabGroup;
  tabItem.setAttribute("data-tooltip", "Automated NPCs");
  tabItem.setAttribute("aria-label", "Automated NPCs");
  tabItem.title = "Automated NPCs";
  tabItem.innerHTML = `<i class="fas fa-robot"></i>`;
  tabNav.appendChild(tabItem);

  // ── Tab content ──────────────────────────────────────────────────────────
  const profile   = getCachedAiProfile(actor) ?? await inferAndCacheAiProfile(actor, false);
  const manualArr = actor.getFlag?.(MODULE_ID, "archetypes") ?? [];
  const isManual  = Array.isArray(manualArr) && manualArr.length > 0;

  const tabSection = document.createElement("div");
  tabSection.classList.add("tab", "nca-ai-tab");
  tabSection.dataset.tab = "nca-ai";
  tabSection.dataset.group = tabGroup;

  // ── LAYOUT FIX: Ensure tab is in normal flow, not overlapping sidebar ─────
  // Force the tab into the same flex/grid track as peer tabs.
  // The `contain: layout style` in CSS already isolates it from the
  // sidebar — this JS ensures it's positioned correctly in the DOM flow.
  tabSection.style.cssText = [
    "position: relative",       // normal flow, not absolute
    "flex: 1 1 auto",           // fill available tab body space
    "min-width: 0",             // prevent flex overflow
    "align-self: stretch",      // match sibling tab height
  ].join("; ");

  const automationActive = isAutomationActive();
  tabSection.innerHTML = _buildTabHTML(actor, profile, isManual, manualArr, automationActive);
  tabBody.appendChild(tabSection);

  // ── Wire up events ───────────────────────────────────────────────────────
  _bindTabEvents(tabSection, actor, app);

  // ── Tab click handler ────────────────────────────────────────────────────
  // Hides all sibling tabs; shows ours. Compatible with Foundry V13
  // ApplicationV2 (which uses its own Tabs API) and legacy sheets.
  tabItem.addEventListener("click", (e) => {
    e.preventDefault();

    // Deactivate all tabs in same group
    const groupSelector = `[data-group="${tabGroup}"]`;
    root.querySelectorAll(`.tab${groupSelector}`).forEach(t => t.classList.remove("active"));
    root.querySelectorAll(`.tabs a.item${groupSelector}, .tabs .item${groupSelector}`)
        .forEach(t => t.classList.remove("active"));

    // Activate ours
    tabSection.classList.add("active");
    tabItem.classList.add("active");

    // Notify Foundry's Tab system if available (V13 ApplicationV2)
    try {
      app._tabs?.find(t => t._group === tabGroup)?._activate?.("nca-ai", { triggerCallback: false });
    } catch (_) { /* non-critical */ }
  });
}

// ─── HTML builder ─────────────────────────────────────────────────────────────

function _buildTabHTML(actor, profile, isManual, manualArr, automationActive) {
  const activeKeys = isManual ? manualArr : (profile?.archetypes ?? []);
  const confidence  = profile?.confidence ?? 0;
  const reasons     = profile?.reasons ?? [];

  // Automation toggle panel (replaces the combat tracker header button)
  const toggleLabel  = automationActive
    ? game.i18n?.localize?.("NCA.UI.AutomationEnabled")  ?? "NPC Automation: Enabled"
    : game.i18n?.localize?.("NCA.UI.AutomationDisabled") ?? "NPC Automation: Disabled";
  const togglePanel = `
    <div class="nca-automation-toggle-panel">
      <div class="nca-section-header"><i class="fas fa-robot"></i> NPC Automation</div>
      <div class="nca-toggle-row">
        <button type="button"
                class="nca-btn nca-automation-master-btn ${automationActive ? "active" : ""}"
                title="${toggleLabel}"
                data-nca-master-toggle>
          <i class="fas fa-${automationActive ? "toggle-on" : "toggle-off"}"></i>
          ${automationActive ? "Automation Enabled" : "Automation Disabled"}
        </button>
      </div>
    </div>
    <div class="nca-divider"></div>`;
  const confPct   = Math.round(confidence * 100);
  const confBar   = `<div class="nca-conf-track"><div class="nca-conf-bar" style="width:${confPct}%"></div></div>`;
  const confLabel = confidence >= 0.8 ? "High" : confidence >= 0.4 ? "Medium" : "Low";

  // Status banner
  const banner = isManual
    ? `<div class="nca-ai-banner nca-ai-manual"><i class="fas fa-lock"></i> Manual override active — inference bypassed</div>`
    : `<div class="nca-ai-banner nca-ai-inferred"><i class="fas fa-robot"></i> Auto-inferred profile — confidence: ${confLabel} (${confPct}%) ${confBar}</div>`;

  // Explain section
  const reasonLines = reasons.map(r => `<li>${r}</li>`).join("");
  const explain = `
    <details class="nca-explain">
      <summary><i class="fas fa-lightbulb"></i> Why this profile?</summary>
      <ul class="nca-reason-list">${reasonLines || "<li>No reasoning data available.</li>"}</ul>
    </details>`;

  // Archetype checkboxes
  let archetypeHTML = `<div class="nca-section-header">Archetypes</div>
    <p class="nca-section-hint">Check archetypes to manually override the inferred profile. Uncheck all to revert to auto-inference.</p>
    <div class="nca-archetype-grid">`;

  for (const [group, keys] of Object.entries(ARCHETYPE_GROUPS)) {
    archetypeHTML += `<div class="nca-archetype-group"><div class="nca-group-label">${group}</div>`;
    for (const key of keys) {
      const checked = activeKeys.includes(key) ? "checked" : "";
      const label   = ARCHETYPE_LABELS[key] ?? key;
      archetypeHTML += `
        <label class="nca-archetype-check ${checked ? "nca-active" : ""}">
          <input type="checkbox" class="nca-archetype-cb" data-key="${key}" ${checked}>
          ${label}
        </label>`;
    }
    archetypeHTML += `</div>`;
  }
  archetypeHTML += `</div>`;

  // Active profile summary
  const activeSummary = activeKeys.length > 0
    ? `<div class="nca-active-summary"><span class="nca-label">Active:</span> ${activeKeys.map(k =>
        `<span class="nca-tag">${ARCHETYPE_LABELS[k] ?? k}</span>`).join("")}</div>`
    : `<div class="nca-active-summary nca-empty">No archetypes active — using INT/WIS defaults only.</div>`;

  // Action buttons
  const buttons = `
    <div class="nca-ai-actions">
      <button type="button" class="nca-btn nca-rebuild-btn" title="Re-run inference from scratch">
        <i class="fas fa-sync"></i> Rebuild AI Profile
      </button>
      <button type="button" class="nca-btn nca-clear-btn" title="Clear manual overrides and re-infer">
        <i class="fas fa-eraser"></i> Clear Overrides
      </button>
    </div>`;

  // ── Per-actor combat configuration (priority target, blacklist, morale,
  //    spell overrides). All values persist as actor flags under MODULE_ID
  //    and every consumer defaults safely when a flag is absent.
  const configHTML = _buildCombatConfigHTML(actor);

  return `<div class="nca-ai-tab-inner">
    ${togglePanel}
    ${banner}
    ${activeSummary}
    ${explain}
    <div class="nca-divider"></div>
    ${archetypeHTML}
    <div class="nca-divider"></div>
    ${configHTML}
    ${buttons}
  </div>`;
}

/**
 * Build the per-actor "Combat Configuration" panel: priority target, target
 * blacklist, morale overrides, and spell-AI overrides.
 */
function _buildCombatConfigHTML(actor) {
  const esc = (v) => {
    const div = document.createElement("div");
    div.textContent = String(v ?? "");
    return div.innerHTML;
  };

  const priorityTarget = actor.getFlag?.(MODULE_ID, "priorityTargetName") ?? "";
  const blacklist      = actor.getFlag?.(MODULE_ID, "targetBlacklist") ?? "";
  const startingMorale = actor.getFlag?.(MODULE_ID, "startingMorale");
  const moraleImmune   = actor.getFlag?.(MODULE_ID, "moraleImmune") === true;
  const spellOv        = actor.getFlag?.(MODULE_ID, "spellOverrides") ?? {};
  const spellOvOn      = spellOv.enabled === true;

  const consChoices = [
    ["",          "World default"],
    ["none",      "None — spend freely"],
    ["moderate",  "Moderate"],
    ["strong",    "Strong — hoard slots"],
  ].map(([v, lbl]) =>
    `<option value="${v}" ${String(spellOv.conservation ?? "") === v ? "selected" : ""}>${lbl}</option>`
  ).join("");

  return `
    <div class="nca-section-header"><i class="fas fa-crosshairs"></i> Combat Configuration</div>
    <p class="nca-section-hint">Per-NPC overrides. Blank fields fall back to normal AI behaviour and world settings.</p>

    <div class="nca-config-grid">
      <label class="nca-config-row" title="When a visible token with this exact name is a valid target, the NPC always attacks it — skipping target scoring. The no-line-of-sight retry still applies.">
        <span>Always target token named</span>
        <input type="text" class="nca-cfg" data-flag="priorityTargetName" value="${esc(priorityTarget)}" placeholder="(none)">
      </label>

      <label class="nca-config-row" title="Comma-separated token names this NPC will never target — as an enemy OR as an ally for heals/buffs.">
        <span>Never target (comma-separated)</span>
        <input type="text" class="nca-cfg" data-flag="targetBlacklist" value="${esc(blacklist)}" placeholder="(none)">
      </label>

      <label class="nca-config-row" title="Seed morale at this value (0–100) when combat starts, instead of the default base. Blank = default.">
        <span>Starting morale (0–100)</span>
        <input type="number" class="nca-cfg" data-flag="startingMorale" data-dtype="Number"
               min="0" max="100" step="1" value="${Number.isFinite(Number(startingMorale)) ? Number(startingMorale) : ""}" placeholder="default">
      </label>

      <label class="nca-config-row" title="This NPC never loses morale and never routs — fearless regardless of creature type or archetype.">
        <span>Morale immune</span>
        <input type="checkbox" class="nca-cfg" data-flag="moraleImmune" data-dtype="Boolean" ${moraleImmune ? "checked" : ""}>
      </label>
    </div>

    <label class="nca-config-row nca-spell-ov-gate" title="Enable per-NPC spell AI overrides below. Off → world settings apply unchanged.">
      <span><i class="fas fa-hat-wizard"></i> Spell AI overrides</span>
      <input type="checkbox" class="nca-cfg nca-spell-ov-toggle" data-flag="spellOverrides.enabled" data-dtype="Boolean" ${spellOvOn ? "checked" : ""}>
    </label>

    <div class="nca-config-grid nca-spell-ov-body" ${spellOvOn ? "" : "style='display:none'"}>
      <label class="nca-config-row" title="How reluctantly this NPC spends levelled spell slots, overriding the world/archetype setting.">
        <span>Slot conservation</span>
        <select class="nca-cfg" data-flag="spellOverrides.conservation">${consChoices}</select>
      </label>

      <label class="nca-config-row" title="Minimum enemies an AOE must catch before this NPC will cast it, overriding the world setting. Blank = world default.">
        <span>Min. AOE targets</span>
        <input type="number" class="nca-cfg" data-flag="spellOverrides.minAOETargets" data-dtype="Number"
               min="1" max="10" step="1" value="${Number.isFinite(Number(spellOv.minAOETargets)) ? Number(spellOv.minAOETargets) : ""}" placeholder="world">
      </label>
    </div>`;
}

// ─── Event binding ────────────────────────────────────────────────────────────

function _bindTabEvents(tabSection, actor, app) {

  // Master automation toggle (replaces combat tracker header button)
  tabSection.querySelector("[data-nca-master-toggle]")?.addEventListener("click", async () => {
    const newState = !isAutomationActive();
    await setAutomationActive(newState);
    // Update button appearance immediately without full sheet re-render
    const btn = tabSection.querySelector("[data-nca-master-toggle]");
    if (btn) {
      btn.classList.toggle("active", newState);
      btn.querySelector("i").className = `fas fa-${newState ? "toggle-on" : "toggle-off"}`;
      const label = newState
        ? (game.i18n?.localize?.("NCA.UI.AutomationEnabled")  ?? "Automation Enabled")
        : (game.i18n?.localize?.("NCA.UI.AutomationDisabled") ?? "Automation Disabled");
      btn.childNodes[btn.childNodes.length - 1].textContent = ` ${label.replace(/^NPC Automation: /, "")}`;
      btn.title = label;
    }
  });
  tabSection.querySelectorAll(".nca-archetype-cb").forEach(cb => {
    cb.addEventListener("change", async () => {
      const checked = [...tabSection.querySelectorAll(".nca-archetype-cb:checked")].map(c => c.dataset.key);
      if (checked.length > 0) {
        await actor.setFlag(MODULE_ID, "archetypes", checked);
      } else {
        await actor.unsetFlag(MODULE_ID, "archetypes");
      }
      // Update visual state
      tabSection.querySelectorAll(".nca-archetype-check").forEach(lbl => {
        const key = lbl.querySelector(".nca-archetype-cb")?.dataset.key;
        lbl.classList.toggle("nca-active", checked.includes(key));
      });
      // Refresh active summary without full re-render
      _refreshActiveSummary(tabSection, checked);
    });
  });

  // ── Combat Configuration fields ────────────────────────────────────────
  // Each control persists to an actor flag on change. Dotted data-flag paths
  // ("spellOverrides.conservation") merge into the parent object flag so a
  // single edit never clobbers sibling values. Empty values unset the flag
  // (back-compat: absent flag = default behaviour everywhere).
  tabSection.querySelectorAll(".nca-cfg").forEach(el => {
    el.addEventListener("change", async () => {
      const path  = el.dataset.flag;
      const dtype = el.dataset.dtype ?? "String";

      let value;
      if (dtype === "Boolean")     value = el.checked;
      else if (dtype === "Number") value = el.value === "" ? null : Number(el.value);
      else                         value = el.value.trim();

      try {
        if (path.includes(".")) {
          const [parent, child] = path.split(".");
          const current = foundry.utils.deepClone(actor.getFlag(MODULE_ID, parent) ?? {});
          if (value === null || value === "" || (dtype === "Boolean" && value === false && child === "enabled")) {
            delete current[child];
            if (dtype === "Boolean") current[child] = false;
          } else {
            current[child] = value;
          }
          if (Object.keys(current).length === 0 || (Object.keys(current).length === 1 && current.enabled === false)) {
            await actor.unsetFlag(MODULE_ID, parent);
          } else {
            await actor.setFlag(MODULE_ID, parent, current);
          }
        } else if (value === null || value === "" || value === false) {
          await actor.unsetFlag(MODULE_ID, path);
        } else {
          await actor.setFlag(MODULE_ID, path, value);
        }
      } catch (err) {
        ui.notifications.warn(`NCA: failed to save "${path}" — ${err.message}`);
      }

      // Spell-override gate: show/hide the dependent fields live.
      if (el.classList.contains("nca-spell-ov-toggle")) {
        const body = tabSection.querySelector(".nca-spell-ov-body");
        if (body) body.style.display = el.checked ? "" : "none";
      }
    });
  });

  // Rebuild button
  tabSection.querySelector(".nca-rebuild-btn")?.addEventListener("click", async () => {
    const profile = await inferAndCacheAiProfile(actor, true);
    ui.notifications.info(`AI profile rebuilt for ${actor.name}: [${profile.archetypes.join(", ")}]`);
    app.render(false);
  });

  // Clear overrides button
  tabSection.querySelector(".nca-clear-btn")?.addEventListener("click", async () => {
    await actor.unsetFlag(MODULE_ID, "archetypes");
    const profile = await inferAndCacheAiProfile(actor, true);
    ui.notifications.info(`Overrides cleared — re-inferred profile for ${actor.name}.`);
    app.render(false);
  });
}

function _refreshActiveSummary(tabSection, activeKeys) {
  const summary = tabSection.querySelector(".nca-active-summary");
  if (!summary) return;
  if (activeKeys.length > 0) {
    summary.className = "nca-active-summary";
    summary.innerHTML = `<span class="nca-label">Active:</span> ${activeKeys.map(k =>
      `<span class="nca-tag">${ARCHETYPE_LABELS[k] ?? k}</span>`).join("")}`;
  } else {
    summary.className = "nca-active-summary nca-empty";
    summary.textContent = "No archetypes active — using INT/WIS defaults only.";
  }
}
