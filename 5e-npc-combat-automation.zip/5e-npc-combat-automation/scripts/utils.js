/**
 * utils.js
 * Shared utility functions used throughout the module.
 */

import { getSetting, SETTINGS, MODULE_ID } from "./settings.js";

// ─── Logging ─────────────────────────────────────────────────────────────────

/**
 * Legacy log helper — still used by non-movement scripts.
 * Respects the new pathfindingDebugLevel setting (minimal or above = enabled).
 * Always logs errors/warnings regardless of setting.
 * @param {string} msg
 * @param {"log"|"warn"|"error"} [level="log"]
 */
export function log(msg, level = "log") {
  if (level === "error" || level === "warn") {
    console[level](`[NCA] ${msg}`);
    return;
  }
  let enabled = false;
  try {
    const dlevel = getSetting(SETTINGS.PATHFINDING_DEBUG_LEVEL) ?? "minimal";
    enabled = dlevel !== "off";
    if (!enabled) {
      // Fallback: honour legacy verboseLogging boolean if set
      enabled = getSetting(SETTINGS.VERBOSE_LOGGING) ?? false;
    }
  } catch {
    enabled = true; // before settings registered
  }
  if (enabled) console.log(`[NCA] ${msg}`);
}

// ─── Timing ──────────────────────────────────────────────────────────────────

/**
 * Async delay helper.
 * @param {number} ms
 * @returns {Promise<void>}
 */
export function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ─── Distance ────────────────────────────────────────────────────────────────

/**
 * Measure the distance in feet between two tokens using Foundry's v13 grid API.
 * Uses token.center for accurate centre-point measurement.
 * Falls back to a pixel-based estimate if canvas measurement is unavailable.
 *
 * @param {Token} tokenA
 * @param {Token} tokenB
 * @returns {number} distance in feet
 */
export function distanceBetweenTokens(tokenA, tokenB) {
  if (!tokenA || !tokenB) return Infinity;
  try {
    const a = tokenA.center ?? { x: tokenA.x + (tokenA.w ?? 0) / 2, y: tokenA.y + (tokenA.h ?? 0) / 2 };
    const b = tokenB.center ?? { x: tokenB.x + (tokenB.w ?? 0) / 2, y: tokenB.y + (tokenB.h ?? 0) / 2 };
    // canvas.grid.measurePath is the v13-canonical distance API; no Ray needed.
    const result = canvas.grid.measurePath([a, b]);
    if (typeof result?.distance === "number") return result.distance;
    return _pixelDistance(tokenA, tokenB);
  } catch {
    return _pixelDistance(tokenA, tokenB);
  }
}

function _pixelDistance(tokenA, tokenB) {
  const gridSize  = canvas.grid.size;
  const gridScale = canvas.grid.distance; // feet per grid unit
  const ax = tokenA.center?.x ?? tokenA.x + (tokenA.w ?? 0) / 2;
  const ay = tokenA.center?.y ?? tokenA.y + (tokenA.h ?? 0) / 2;
  const bx = tokenB.center?.x ?? tokenB.x + (tokenB.w ?? 0) / 2;
  const by = tokenB.center?.y ?? tokenB.y + (tokenB.h ?? 0) / 2;
  const pixels = Math.hypot(ax - bx, ay - by);
  return (pixels / gridSize) * gridScale;
}

// ─── Item helpers ─────────────────────────────────────────────────────────────

/**
 * Get the effective attack range (in feet) for an item.
 * Handles melee, ranged, and thrown weapons.
 *
 * @param {Item5e} item
 * @returns {number} range in feet (5 for melee, or ranged short range)
 */
export function getItemRange(item) {
  const range = item.system?.range;
  if (!range) return 5;

  if (range.value && range.value > 0) return range.value;

  // Melee reach
  if (item.system?.properties?.has?.("reach")) return 10;

  return 5; // default melee
}

/**
 * Determine if an item is a melee attack.
 * @param {Item5e} item
 * @returns {boolean}
 */
export function isMeleeItem(item) {
  const actionType = item.system?.actionType;
  return actionType === "mwak" || actionType === "msak";
}

/**
 * Determine if an item is a ranged attack.
 * @param {Item5e} item
 * @returns {boolean}
 */
export function isRangedItem(item) {
  const actionType = item.system?.actionType;
  return actionType === "rwak" || actionType === "rsak";
}

/**
 * Normalise a string for fuzzy name matching.
 * @param {string} str
 * @returns {string}
 */
export function normalize(str) {
  return String(str).toLowerCase().trim();
}

/**
 * Return the activities of an item as a plain array.
 *
 * dnd5e v3+ stores activities in a Foundry Collection (extends Map). Calling
 * Object.values()/Object.keys() on a Map returns [] because the Map's entries
 * are NOT own-enumerable properties — only the inherited Map prototype methods
 * are. This is the single source of truth helper used by every file that needs
 * to iterate activities; without it, v3 stat blocks silently fail capability
 * detection.
 *
 * Supported shapes:
 *   - Plain array            (unusual but legal)
 *   - Foundry Collection     (.contents array property — dnd5e v3+)
 *   - Plain Map              (fallback)
 *   - Plain object           (legacy / migrated worlds — entries are values)
 *
 * @param {Item5e} item
 * @returns {object[]}
 */
export function getActivities(item) {
  const acts = item?.system?.activities;
  if (!acts) return [];
  if (Array.isArray(acts)) return acts;
  // Foundry Collection — .contents is a defined array of values
  if (Array.isArray(acts.contents)) return acts.contents;
  // Plain Map — spread its values
  if (typeof acts.values === "function") {
    try { return [...acts.values()]; } catch (_) { /* fall through */ }
  }
  // Plain object — last resort (also handles migrated v2 → v3 worlds)
  try { return Object.values(acts).filter(v => v && typeof v === "object"); }
  catch (_) { return []; }
}

/**
 * Determine if an item/feature/spell has any offensive capability.
 * Detection is capability-based and system-agnostic:
 *   1. Explicit dnd5e actionType values
 *   2. item.hasAttack flag (computed by dnd5e)
 *   3. v13 Activities with attack/damage/activation data
 *   4. Generic damage formula / attackBonus fields
 *
 * @param {Item5e} item
 * @returns {boolean}
 */
function isOffensiveItem(item) {
  // 1. Explicit attack action types (dnd5e legacy + current)
  const actionType = item.system?.actionType;
  if (["mwak", "rwak", "msak", "rsak"].includes(actionType)) return true;

  // 2. dnd5e computed flag
  if (item.hasAttack) return true;

  // 3. v13 Activity-based attack detection
  for (const activity of getActivities(item)) {
    if (activity?.type === "attack" || activity?.attack) return true;
  }

  // 4. Stable attack bonus fallback for spells/features with attack rolls.
  if (item.system?.attackBonus !== undefined && item.system?.attackBonus !== null &&
      item.system?.attackBonus !== "" && item.system?.attackBonus !== 0) return true;

  return false;
}

function isUsableActionItem(item) {
  if (!item) return false;
  if (["class", "subclass", "background", "species", "container", "loot", "equipment"].includes(item.type)) return false;
  if (isOffensiveItem(item)) return true;

  const activities = getActivities(item);
  if (activities.length > 0 && activities.some(a => {
    if (!a) return false;
    if (["attack", "damage", "save", "heal", "utility", "summon"].includes(a.type)) return true;
    return !!(a.activation || a.damage || a.save || a.consumption);
  })) return true;

  const activation = item.system?.activation;
  if (activation?.type && activation.type !== "none") return true;

  const uses = item.system?.uses;
  if (uses && (typeof uses.max !== "undefined" || typeof uses.value !== "undefined")) return true;

  return false;
}

/**
 * Get all items on an actor that are capable of making an offensive action.
 * Covers weapons, features, spells, feats, and activity-based items.
 *
 * @param {Actor5e} actor
 * @returns {Item5e[]}
 */
export function getAttackItems(actor) {
  // Heavy introspection log — only build it if a verbose-or-higher debug level
  // is active. The previous unconditional JSON.stringify happened on every NPC
  // turn at "minimal" level, which is the default — measurable cost on actors
  // with 30+ items (compendium dragons, demigods, etc.).
  if (_verboseLoggingEnabled()) {
    log("Scanning offensive items: " + JSON.stringify(actor.items.map(i => ({
      name: i.name,
      type: i.type,
      actionType: i.system?.actionType,
      hasAttack: i.hasAttack,
    }))));
  }

  return actor.items.filter(isOffensiveItem);
}

export function getUsableActionItems(actor) {
  if (_verboseLoggingEnabled()) {
    log("Scanning usable action items: " + JSON.stringify(actor.items.map(i => ({
      name: i.name,
      type: i.type,
      actionType: i.system?.actionType,
      hasAttack: i.hasAttack,
      activities: getActivities(i).map(a => a?.type).filter(Boolean),
    }))));
  }

  return actor.items.filter(isUsableActionItem);
}

/**
 * Returns true when the pathfinding debug level is "verbose" or "trace".
 * Used to gate expensive per-actor JSON introspection in hot paths.
 */
function _verboseLoggingEnabled() {
  try {
    const dlevel = getSetting(SETTINGS.PATHFINDING_DEBUG_LEVEL);
    return dlevel === "verbose" || dlevel === "trace";
  } catch {
    return false;
  }
}

// ─── Chat ────────────────────────────────────────────────────────────────────

/**
 * Post a styled automation chat message.
 * Only posts if chat logging is enabled.
 *
 * @param {string} body   - Message body text.
 * @param {object} [opts] - Optional overrides.
 */
export async function postChatMessage(body, opts = {}) {
  if (!getSetting(SETTINGS.ENABLE_CHAT_LOG)) return;

  const content = `
    <div class="nca-msg-header">⚔ NPC Automation</div>
    <div class="nca-msg-body">${body}</div>
  `;

  await ChatMessage.create({
    content,
    speaker: opts.speaker ?? ChatMessage.getSpeaker(),
    flags: { [MODULE_ID]: { automated: true } },
    type: CONST.CHAT_MESSAGE_STYLES?.OTHER ?? 0,
    ...opts,
  });
}
