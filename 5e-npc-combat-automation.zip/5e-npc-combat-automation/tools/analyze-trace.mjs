#!/usr/bin/env node
/**
 * analyze-trace.mjs — offline analyzer for the module's AI-trace JSONL export.
 *
 *   node tools/analyze-trace.mjs path/to/trace.jsonl [more.jsonl ...]
 *
 * Ingests one or more JSONL exports (Combat Tracker → trace export, or
 * `game.modules.get("5e-npc-combat-automation").api.trace.export()`) and
 * reports the decision distributions that drive tuning:
 *
 *   - behavior decisions, archetype mix, morale brackets
 *   - targeting: hold/switch rates, grudge magnitudes (sticky-bonus tuning)
 *   - pathfinding: flood counts/timings, single-flood savings, partial
 *     advances and their exposure (PARTIAL_THREAT_WEIGHT tuning)
 *   - scoot/kite/no-LOS-retry/dash rates
 *   - spellcasting: category mix, slot levels, concentration breaks
 *   - off-turn events: legendary actions, opportunity attacks, retarget
 *     forfeits
 *
 * Tolerant of missing fields — older-version rows simply contribute less.
 */

import { readFileSync } from "node:fs";

const files = process.argv.slice(2);
if (!files.length) {
  console.error("usage: node tools/analyze-trace.mjs <trace.jsonl> [...]");
  process.exit(1);
}

const rows = [];
for (const f of files) {
  for (const line of readFileSync(f, "utf8").split("\n")) {
    const s = line.trim();
    if (!s) continue;
    try { rows.push(JSON.parse(s)); } catch { /* skip malformed line */ }
  }
}

const turns  = rows.filter(r => !r.event);
const events = rows.filter(r => r.event);

const num = (v) => (Number.isFinite(Number(v)) ? Number(v) : null);
const pct = (n, d) => (d ? `${((n / d) * 100).toFixed(1)}%` : "n/a");
const avg = (xs) => (xs.length ? (xs.reduce((a, b) => a + b, 0) / xs.length) : null);
const fmt = (v, digits = 1) => (v === null ? "n/a" : v.toFixed(digits));
const tally = (xs) => {
  const t = {};
  for (const x of xs) if (x != null) t[x] = (t[x] ?? 0) + 1;
  return Object.entries(t).sort((a, b) => b[1] - a[1]);
};
const printTally = (entries, total, max = 10) => {
  for (const [k, n] of entries.slice(0, max)) console.log(`    ${k}: ${n} (${pct(n, total)})`);
};

console.log(`\n═══ Trace analysis: ${rows.length} rows (${turns.length} turns, ${events.length} events) from ${files.length} file(s) ═══`);

// ─── Behavior & morale ────────────────────────────────────────────────────────
console.log("\n■ Behavior");
printTally(tally(turns.map(r => r.decision ?? r.behavior?.decision)), turns.length);
console.log("  Archetypes:");
printTally(tally(turns.flatMap(r => r.archetypes ?? r.archetype ?? [])), turns.length, 8);
const moraleVals = turns.map(r => num(r.morale ?? r.moraleScore)).filter(v => v !== null);
if (moraleVals.length) {
  console.log(`  Morale: avg ${fmt(avg(moraleVals))}, min ${Math.min(...moraleVals)}, ` +
              `routs(<25) ${moraleVals.filter(v => v < 25).length}`);
}

// ─── Targeting (sticky / grudge tuning) ───────────────────────────────────────
console.log("\n■ Targeting");
const tg = turns.map(r => r.targeting).filter(Boolean);
if (tg.length) {
  const held = tg.filter(t => t.held).length;
  const switched = tg.filter(t => t.switched).length;
  console.log(`  Annotated selections: ${tg.length}`);
  console.log(`  Held previous target: ${held} (${pct(held, tg.length)}) | switched: ${switched} (${pct(switched, tg.length)})`);
  const holds = tg.map(t => num(t.turnsHeld)).filter(v => v !== null);
  console.log(`  turnsHeld: avg ${fmt(avg(holds))}, max ${holds.length ? Math.max(...holds) : "n/a"}`);
  const grudges = tg.map(t => num(t.grudge)).filter(v => v > 0);
  console.log(`  Grudge applied on ${grudges.length} picks (avg ${fmt(avg(grudges))}, cap is 12 — ` +
              `if avg pins at 12, lower the 0.4×damage slope or raise the cap)`);
  if (switched / Math.max(1, tg.length) > 0.5) {
    console.log("  ⚠ switch rate >50% — sticky bonus (15/8/0) may be too weak for this table.");
  }
} else console.log("  (no targeting annotations — pre-0.19 trace?)");

// ─── Pathfinding (Task 1–3 tuning) ────────────────────────────────────────────
console.log("\n■ Pathfinding");
const pf = turns.map(r => r.pathfind).filter(Boolean);
if (pf.length) {
  const floods = pf.map(p => num(p.floods)).filter(v => v !== null);
  const ms     = pf.map(p => num(p.ms)).filter(v => v !== null);
  const cells  = pf.map(p => num(p.cells)).filter(v => v !== null);
  const filt   = pf.map(p => num(p.filtered) ?? 0);
  console.log(`  Engage moves: ${pf.length}`);
  console.log(`  Floods/move: avg ${fmt(avg(floods), 2)} (pre-0.19 baseline ≈ up to 3); ` +
              `tier-filters used: ${filt.reduce((a, b) => a + b, 0)}`);
  console.log(`  Flood time: avg ${fmt(avg(ms))}ms, worst ${ms.length ? Math.max(...ms).toFixed(1) : "n/a"}ms ` +
              `| avg reachable cells ${fmt(avg(cells), 0)}`);
  if (avg(ms) > 50) console.log("  ⚠ avg flood >50ms — consider tightening MAX_MOVEMENT or map wall density.");
} else console.log("  (no pathfind annotations)");

const partials = turns.map(r => r.partialAdvance).filter(Boolean);
if (partials.length) {
  const exp = partials.map(p => num(p.exposure)).filter(v => v !== null);
  const kept = partials.filter(p => p.kept_los).length;
  console.log(`  Partial advances: ${partials.length} (avg exposure ${fmt(avg(exp), 2)}, kept LOS ${pct(kept, partials.length)})`);
}

// ─── Movement outcomes ────────────────────────────────────────────────────────
console.log("\n■ Movement outcomes");
const count = (pred) => turns.filter(pred).length;
const dash      = count(r => r.usedDash || r.movement?.usedDash || r.dashMode && r.dashMode !== "none");
const noLos     = count(r => r.noLosRetry || r.retriedTarget);
const scoots    = count(r => r.scoot?.moved || r.scootResult?.moved);
const kites     = count(r => r.kite?.moved || r.kited);
const lkpAlly   = count(r => r.lkp?.source === "ally");
console.log(`  Dash: ${dash} (${pct(dash, turns.length)}) | no-LOS retries: ${noLos} | ` +
            `scoot-to-cover: ${scoots} | kite: ${kites} | ally-LKP pursuits: ${lkpAlly}`);

// ─── Spellcasting ─────────────────────────────────────────────────────────────
console.log("\n■ Spellcasting");
const spells = turns.map(r => r.spell ?? r.spellDecision).filter(Boolean);
if (spells.length) {
  console.log(`  Spell actions: ${spells.length} (${pct(spells.length, turns.length)} of turns)`);
  console.log("  Slot levels:");
  printTally(tally(spells.map(s => s.slotLevel ?? s.slot)), spells.length, 10);
  const concBreaks = spells.filter(s => s.concentrationBreak || s.concBreak).length;
  console.log(`  Concentration breaks: ${concBreaks}`);
} else console.log("  (no spell decisions)");

const bonus = turns.map(r => r.bonusAction).filter(Boolean);
if (bonus.length) {
  console.log(`  Bonus actions: ${bonus.length} (${pct(bonus.length, turns.length)} of turns)`);
  printTally(tally(bonus.map(b => b.kind ?? b.type ?? b.item ?? b.name)), bonus.length, 6);
}

// ─── Off-turn events ──────────────────────────────────────────────────────────
console.log("\n■ Off-turn events");
printTally(tally(events.map(e => e.event)), events.length);
const leg = events.filter(e => e.event === "legendary");
if (leg.length) {
  const errs = leg.filter(e => e.error).length;
  console.log(`  Legendary: ${leg.length} actions, ${errs} errors; cost mix:`);
  printTally(tally(leg.map(e => e.cost)), leg.length, 4);
  console.log("  Most used:");
  printTally(tally(leg.map(e => e.item)), leg.length, 5);
}
const oa = events.filter(e => e.event === "opportunityAttack");
if (oa.length) console.log(`  Opportunity attacks: ${oa.length} (${oa.filter(e => e.error).length} errors)`);

const forfeits = turns.map(r => r.retargetedMidTurn).filter(Boolean);
if (forfeits.length) {
  const lost = forfeits.filter(f => f.reason === "out_of_reach");
  console.log(`  Mid-turn retargets: ${forfeits.length}; forfeited (out of reach): ${lost.length}` +
              (lost.length / forfeits.length > 0.5
                ? " ⚠ — most retargets are forfeiting; consider allowing a step toward the new target."
                : ""));
}

// ─── Errors ───────────────────────────────────────────────────────────────────
const errored = rows.filter(r => r.error);
console.log(`\n■ Errors: ${errored.length}`);
printTally(tally(errored.map(r => String(r.error).slice(0, 60))), errored.length, 5);

console.log("");
