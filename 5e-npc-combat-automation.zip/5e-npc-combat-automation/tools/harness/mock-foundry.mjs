/**
 * mock-foundry.mjs — minimal Foundry VTT global surface for headless testing
 * of the module's pure-logic subsystems (pathfinding, targeting) in Node.
 *
 * Scope: exactly what movement.js / targeting.js / settings.js / utils.js /
 * ai-trace.js touch at import time and during the tested code paths. This is
 * NOT a Foundry emulator — anything outside that surface throws loudly so a
 * new dependency is caught immediately rather than silently mocked wrong.
 *
 * Setting defaults are PARSED FROM settings.js at load, so new settings never
 * require harness edits. Tests override via `settingsOverrides`.
 */

import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const SCRIPTS = join(__dirname, "..", "..", "scripts");

// ─── Setting defaults parsed from source ──────────────────────────────────────

function parseSettingDefaults() {
  const src = readFileSync(join(SCRIPTS, "settings.js"), "utf8");

  // 1. SETTINGS constant map: KEY → "camelKey"
  const constBlock = src.match(/export const SETTINGS = \{([\s\S]*?)\n\};/)[1];
  const constants = {};
  for (const m of constBlock.matchAll(/([A-Z0-9_]+):\s*"([^"]+)"/g)) constants[m[1]] = m[2];

  // 2. Each register call: SETTINGS.KEY ... default: <literal>
  const defaults = {};
  const re = /register\(MODULE_ID,\s*SETTINGS\.([A-Z0-9_]+),\s*\{([\s\S]*?)\n  \}\);/g;
  for (const m of src.matchAll(re)) {
    const key = constants[m[1]];
    const dm = m[2].match(/default:\s*("(?:[^"\\]|\\.)*"|[\d.]+|true|false)/);
    if (!key || !dm) continue;
    const raw = dm[1];
    defaults[key] =
      raw === "true" ? true :
      raw === "false" ? false :
      raw.startsWith('"') ? JSON.parse(raw) :
      Number(raw);
  }
  return defaults;
}

// ─── Wall collision: segment intersection over a test wall list ──────────────

function segIntersect(p1, p2, p3, p4) {
  const d = (p2.x - p1.x) * (p4.y - p3.y) - (p2.y - p1.y) * (p4.x - p3.x);
  if (Math.abs(d) < 1e-9) return false;
  const t = ((p3.x - p1.x) * (p4.y - p3.y) - (p3.y - p1.y) * (p4.x - p3.x)) / d;
  const u = ((p3.x - p1.x) * (p2.y - p1.y) - (p3.y - p1.y) * (p2.x - p1.x)) / d;
  return t > 1e-9 && t < 1 - 1e-9 && u > 1e-9 && u < 1 - 1e-9;
}

// ─── World builder ────────────────────────────────────────────────────────────

export function buildWorld({
  gridSize = 100,
  gridDistance = 5,
  sceneCells = 40,
  walls = [],            // [{x1,y1,x2,y2}] in pixels — block move AND sight
  tokens = [],           // see makeToken
  settingsOverrides = {},
  combat = null,         // { round, turn }
  diagonals = 0,         // CONST.GRID_DIAGONALS value (0 = equidistant)
} = {}) {
  const defaults = parseSettingDefaults();
  const settingsStore = new Map();

  // Walls/doors: each may be {x1,y1,x2,y2, door?:1, ds?:0} (ds: 0 closed,1 open,2 locked)
  const wallPlaceables = walls.map((w, i) => {
    const doc = {
      id: `wall-${i}`, c: [w.x1, w.y1, w.x2, w.y2],
      door: w.door ?? 0, ds: w.ds ?? 0,
      update: async (changes) => { Object.assign(doc, changes); },
    };
    return { id: doc.id, document: doc };
  });
  const collides = (src, dst) =>
    wallPlaceables.some(w => {
      // Open doors don't block.
      if (w.document.door === 1 && w.document.ds === 1) return false;
      return segIntersect(src, dst, { x: w.document.c[0], y: w.document.c[1] },
                                     { x: w.document.c[2], y: w.document.c[3] });
    });

  const tokenObjs = tokens.map(makeTokenInternal.bind(null, gridSize));

  // Hooks is a SINGLETON across buildWorld calls: module-level Hooks.on
  // registrations (movement/targeting/ai-trace) happen once at import and
  // must keep firing for every subsequent world, exactly as in Foundry.
  if (!globalThis.Hooks) {
    globalThis.Hooks = {
      _handlers: {},
      on(name, fn)   { (this._handlers[name] ??= []).push(fn); },
      once(name, fn) { (this._handlers[name] ??= []).push(fn); },
      callAll(name, ...args) {
        for (const fn of this._handlers[name] ?? []) {
          try { fn(...args); } catch (e) { console.error(`[mock hook ${name}]`, e.message); }
        }
      },
      call(name, ...args) { this.callAll(name, ...args); return true; },
    };
  }

  globalThis.CONST = {
    GRID_DIAGONALS: { EQUIDISTANT: 0, EXACT: 1, APPROXIMATE: 2, ALTERNATING_1: 3, ALTERNATING_2: 4, RECTILINEAR: 5, ILLEGAL: 6 },
    TOKEN_DISPOSITIONS: { FRIENDLY: 1, NEUTRAL: 0, HOSTILE: -1, SECRET: -2 },
    WALL_DOOR_TYPES: { NONE: 0, DOOR: 1, SECRET: 2 },
    WALL_DOOR_STATES: { CLOSED: 0, OPEN: 1, LOCKED: 2 },
    CHAT_MESSAGE_STYLES: { OTHER: 0 },
  };

  globalThis.CONFIG = {
    Canvas: {
      polygonBackends: {
        move:  { testCollision: (src, dst) => collides(src, dst) },
        sight: { testCollision: (src, dst) => collides(src, dst) },
      },
    },
  };

  globalThis.canvas = {
    grid: {
      size: gridSize,
      distance: gridDistance,
      diagonals,
      getOffset: ({ x, y }) => ({ i: Math.floor(y / gridSize), j: Math.floor(x / gridSize) }),
      getTopLeftPoint: ({ i, j }) => ({ x: j * gridSize, y: i * gridSize }),
      measurePath: (pts) => {
        let px = 0;
        for (let i = 1; i < pts.length; i++) px += Math.hypot(pts[i].x - pts[i-1].x, pts[i].y - pts[i-1].y);
        return { distance: (px / gridSize) * gridDistance };
      },
    },
    dimensions: { width: sceneCells * gridSize, height: sceneCells * gridSize },
    scene: { grid: { diagonals }, regions: [] },
    tokens: { placeables: tokenObjs, get: (id) => tokenObjs.find(t => t.id === id) },
    walls: { placeables: wallPlaceables, quadtree: { getObjects: () => new Set() } },
    tiles: { placeables: [] },
    regions: { placeables: [] },
    templates: { get: () => null },
    terrain: null,
  };

  globalThis.game = {
    user: { isGM: true, targets: new Set() },
    paused: false,
    combat: combat ? {
      id: "test-combat", started: true, round: combat.round ?? 1, turn: combat.turn ?? 0,
      combatants: { find: () => null, get: () => null, [Symbol.iterator]: function* () {} },
    } : null,
    combats: [],
    actors: { get: () => null },
    scenes: [],
    settings: {
      settings: new Map(),
      get(ns, key) {
        const full = `${ns}.${key}`;
        if (settingsStore.has(full)) return settingsStore.get(full);
        if (key in settingsOverrides) return settingsOverrides[key];
        if (key in defaults) return defaults[key];
        throw new Error(`[mock] unregistered setting read: ${full}`);
      },
      set(ns, key, v) { settingsStore.set(`${ns}.${key}`, v); return Promise.resolve(v); },
      register() {}, registerMenu() {},
    },
    i18n: { localize: (s) => s, format: (s, d) => s.replace(/\{(\w+)\}/g, (_, k) => d?.[k] ?? "") },
    modules: { get: () => ({ active: true, api: {} }) },
    time: { worldTime: 0 },
  };

  globalThis.ui = { notifications: { info() {}, warn() {}, error() {} } };
  globalThis.ChatMessage = { create: async () => ({}), getSpeaker: () => ({}), getWhisperRecipients: () => [] };
  globalThis.PIXI = {
    Rectangle: class { constructor(x, y, w, h) { Object.assign(this, { x, y, width: w, height: h }); } },
    Graphics: class { lineStyle() {} moveTo() {} lineTo() {} destroy() {} },
  };
  globalThis.foundry = {
    utils: {
      mergeObject: (a, b) => ({ ...a, ...b }),
      deepClone: (o) => JSON.parse(JSON.stringify(o ?? null)),
      isEmpty: (o) => !o || Object.keys(o).length === 0,
    },
    applications: { api: { ApplicationV2: class { render() { return this; } } } },
  };
  globalThis.fromUuidSync = () => null;
  globalThis.Dialog = { confirm: async () => true };

  return {
    setSetting: (key, v) => settingsStore.set(`5e-npc-combat-automation.${key}`, v),
    tokens: tokenObjs,
    walls: wallPlaceables,
    fireHook: (name, ...args) => globalThis.Hooks.callAll(name, ...args),
  };
}

// ─── Token factory ────────────────────────────────────────────────────────────

function makeTokenInternal(gridSize, spec) {
  const {
    id, name = id, row, col, width = 1, height = 1,
    disposition = -1, hp = 20, hpMax = 20, hidden = false, defeated = false,
    int = 10, walk = 30, items = [], statuses = [], elevation = 0, flags = {},
  } = spec;

  const x = col * gridSize;
  const y = row * gridSize;
  const actor = {
    id: `actor-${id}`, name, type: spec.actorType ?? "npc",
    hasPlayerOwner: spec.hasPlayerOwner ?? false,
    system: {
      attributes: { hp: { value: hp, max: hpMax }, movement: { walk, swim: spec.swim ?? 0, climb: spec.climb ?? 0 } },
      abilities: { int: { value: int }, wis: { value: 10 } },
      details: { cr: spec.cr ?? 1, type: { value: spec.creatureType ?? "humanoid" } },
      spells: {},
    },
    items,
    effects: [],
    statuses: new Set(statuses),
    getFlag: (ns, key) => flags[key],
    setFlag: async (ns, key, v) => { flags[key] = v; },
    unsetFlag: async (ns, key) => { delete flags[key]; },
    flags: { "5e-npc-combat-automation": flags },
  };

  const doc = {
    id, name, x, y, width, height, elevation, hidden, defeated, disposition,
    getFlag: (ns, key) => (ns === "core" ? undefined : flags[key]),
    actorLink: true,
  };

  return {
    id, name, x, y,
    w: width * gridSize, h: height * gridSize,
    center: { x: x + (width * gridSize) / 2, y: y + (height * gridSize) / 2 },
    document: doc,
    actor,
    bounds: { x, y, width: width * gridSize, height: height * gridSize },
    setTarget() {},
  };
}

export function makeToken(spec) { return spec; } // declarative pass-through for buildWorld
