/**
 * run-tests.mjs — headless regression harness for the module's pure-logic
 * subsystems. Runs in Node with no Foundry installation:
 *
 *   node tools/harness/run-tests.mjs
 *
 * Covers: BFS reachability correctness, wall blocking, the single-flood
 * tier-filtering invariant (Task 1), smart-partial behaviour (Task 2),
 * flanking destination geometry (Task 8/0.18), and targeting persistence,
 * grudge, blacklist and priority flags (Tasks 4–5 + 0.18 per-actor config).
 *
 * Every test rebuilds the world; modules are imported once (their per-combat
 * state is reset via the same deleteCombat hook the live module uses).
 */

import { buildWorld } from "./mock-foundry.mjs";

let passed = 0, failed = 0;
function check(name, cond, detail = "") {
  if (cond) { passed++; console.log(`  ✓ ${name}`); }
  else      { failed++; console.error(`  ✗ ${name}${detail ? " — " + detail : ""}`); }
}
function section(name) { console.log(`\n■ ${name}`); }

// World must exist BEFORE the modules are imported (top-level Hooks.on calls).
buildWorld({ tokens: [] });
const movement  = await import("../../scripts/movement.js");
const targeting = await import("../../scripts/targeting.js");

const resetCombatState = () => {
  globalThis.Hooks.callAll("deleteCombat");   // movement per-combat stores
  globalThis.Hooks.callAll("combatRound");    // CURRENT_TARGET_ASSIGNMENTS
  targeting.clearTargetMemory();              // main.js does these in live play
  targeting.clearDamageLedger();
};

// ─── 1. BFS reachability — open field ────────────────────────────────────────
section("reachableCells: open field");
{
  buildWorld({ tokens: [{ id: "npc", row: 20, col: 20 }], combat: { round: 1 } });
  const npc = globalThis.canvas.tokens.get("npc");
  const { cost } = movement.reachableCells(20, 20, 4, npc);

  check("start cell costs 0", cost.get("20,20") === 0);
  check("orthogonal 4 reachable at cost 4", cost.get("20,24") === 4, `got ${cost.get("20,24")}`);
  check("diagonal 4 reachable at cost 4 (equidistant)", cost.get("24,24") === 4, `got ${cost.get("24,24")}`);
  check("cost 5 cell not reachable", cost.get("20,25") === undefined);
  // Chebyshev disc with equidistant diagonals: (2·4+1)² = 81 cells
  check("flood size = 81 (Chebyshev disc r=4)", cost.size === 81, `got ${cost.size}`);
}

// ─── 2. BFS — wall blocking + routing around ─────────────────────────────────
section("reachableCells: walls");
{
  // Vertical wall east of the NPC spanning rows 17..24 at x=2200 px (col 21/22 boundary)
  buildWorld({
    tokens: [{ id: "npc", row: 20, col: 20 }],
    walls: [{ x1: 2200, y1: 1700, x2: 2200, y2: 2400 }],
    combat: { round: 1 },
  });
  const npc = globalThis.canvas.tokens.get("npc");
  const { cost } = movement.reachableCells(20, 20, 4, npc);

  check("cell directly behind wall unreachable at straight-line cost",
        (cost.get("20,22") ?? Infinity) > 2, `got ${cost.get("20,22")}`);
  check("cells west of wall unaffected", cost.get("20,16") === 4);
  // Route around the wall's south end (row 24): reachable but expensive
  const around = cost.get("20,22");
  check("behind-wall cell either unreachable or via detour (cost > 2)",
        around === undefined || around > 2, `got ${around}`);
}

// ─── 3. Task 1 invariant: tier filtering ≡ direct flood ─────────────────────
section("single-flood tiering invariant (Task 1)");
{
  buildWorld({
    tokens: [{ id: "npc", row: 20, col: 20 }],
    walls: [
      { x1: 2200, y1: 1800, x2: 2200, y2: 2300 },
      { x1: 1700, y1: 2400, x2: 2400, y2: 2400 },
    ],
    combat: { round: 1 },
  });
  const npc = globalThis.canvas.tokens.get("npc");

  const small = movement.reachableCells(20, 20, 5, npc);
  const big   = movement.reachableCells(20, 20, 12, npc);

  // Filter big down to budget 5 (replicates _filterReachTier semantics)
  const filtered = new Map();
  for (const [k, c] of big.cost) if (c <= 5 + 0.001) filtered.set(k, c);

  let identical = filtered.size === small.cost.size;
  if (identical) {
    for (const [k, c] of small.cost) {
      if (Math.abs((filtered.get(k) ?? Infinity) - c) > 0.001) { identical = false; break; }
    }
  }
  check(`filtered(12→5) ≡ direct flood(5): ${small.cost.size} cells`, identical,
        `direct=${small.cost.size} filtered=${filtered.size}`);
}

// ─── 4. Task 2: smart partial advance ────────────────────────────────────────
section("smart partial advance (Task 2)");
{
  // EXACT diagonals: the straight east lane (row 20) strictly dominates by
  // octile distance, so the legacy partial MUST take it — making the smart
  // variant's lane change unambiguous.
  buildWorld({
    tokens: [{ id: "npc", row: 20, col: 20 }],
    combat: { round: 1 },
    diagonals: 1,
    settingsOverrides: { pathfindSmartPartial: true },
  });
  const npc = globalThis.canvas.tokens.get("npc");
  const { cost } = movement.reachableCells(20, 20, 3, npc);

  // Unreachable goal far east; a fake threatFn exposes the direct lane (row 20)
  const goals = [{ row: 20, col: 35 }];
  const threatFn = (r, c) => (r === 20 ? 0.4 : 0);

  const dumb  = movement.pickBestReachable(cost, goals, 20, 20, 20, 35, "t");
  const smart = movement.pickBestReachable(cost, goals, 20, 20, 20, 35, "t",
    { threatFn, npcToken: npc, targetToken: null, preferLOS: null });

  check("legacy partial takes the exposed direct lane", dumb.destRow === 20 && dumb.destCol === 23,
        `got [${dumb.destRow},${dumb.destCol}]`);
  check("legacy partial ignores threat entirely", threatFn(dumb.destRow, dumb.destCol) > 0);
  check("smart partial leaves the exposed lane", smart.destRow !== 20,
        `got [${smart.destRow},${smart.destCol}]`);
  check("smart partial still advances east (max off-lane reach)", smart.destCol >= 22,
        `got col ${smart.destCol}`);
  check("both flagged as partial (reachedGoal=false)", !dumb.reachedGoal && !smart.reachedGoal);
}

// ─── 5. Flanking destination geometry ────────────────────────────────────────
section("findFlankingDestination geometry");
{
  buildWorld({
    tokens: [
      { id: "npc",    row: 20, col: 16, disposition: -1 },
      { id: "ally",   row: 20, col: 19, disposition: -1 },   // engaged west... east of target? target at 20,20; ally at 20,19 = west
      { id: "target", row: 20, col: 20, disposition:  1 },
    ],
    combat: { round: 1 },
  });
  const npc    = globalThis.canvas.tokens.get("npc");
  const ally   = globalThis.canvas.tokens.get("ally");
  const target = globalThis.canvas.tokens.get("target");
  const meleeGoals = [
    { row: 20, col: 19 }, { row: 20, col: 21 },
    { row: 19, col: 20 }, { row: 21, col: 20 },
    { row: 19, col: 19 }, { row: 19, col: 21 },
    { row: 21, col: 19 }, { row: 21, col: 21 },
  ];
  const cell = movement.findFlankingDestination(npc, target, [ally], 30, meleeGoals);
  check("flank cell exists", !!cell);
  check("flank cell is opposite the ally (east of target)", cell && cell.col === 21,
        cell ? `got [${cell.row},${cell.col}]` : "null");
}

// ─── 6. Targeting: persistence (Task 4) ──────────────────────────────────────
section("target persistence (Task 4)");
{
  resetCombatState();
  buildWorld({
    tokens: [
      { id: "npc", row: 20, col: 20, disposition: -1 },
      { id: "pcA", row: 20, col: 26, disposition: 1, actorType: "character", hasPlayerOwner: true },
      { id: "pcB", row: 26, col: 20, disposition: 1, actorType: "character", hasPlayerOwner: true },
    ],
    combat: { round: 1 },
    settingsOverrides: { targetPersistence: true, dispositionTargeting: true },
  });
  const npc = globalThis.canvas.tokens.get("npc");

  const first = targeting.selectTarget(npc, null);
  check("a target was selected", !!first);
  const firstId = first?.id;

  // Equidistant rival — persistence must hold the original.
  let held = true;
  for (let i = 0; i < 3; i++) {
    const next = targeting.selectTarget(npc, null);
    if (next?.id !== firstId) { held = false; break; }
  }
  check("equidistant target held across repeated selections", held);

  // With persistence OFF, pressure (assignment count) pushes selection to
  // alternate — same-id streaks should not be guaranteed.
  resetCombatState();
  buildWorld({
    tokens: [
      { id: "npc", row: 20, col: 20, disposition: -1 },
      { id: "pcA", row: 20, col: 26, disposition: 1, actorType: "character", hasPlayerOwner: true },
      { id: "pcB", row: 26, col: 20, disposition: 1, actorType: "character", hasPlayerOwner: true },
    ],
    combat: { round: 1 },
    settingsOverrides: { targetPersistence: false, dispositionTargeting: true },
  });
  const npc2 = globalThis.canvas.tokens.get("npc");
  const a = targeting.selectTarget(npc2, null);
  const b = targeting.selectTarget(npc2, null);
  check("persistence off: pressure alternates equidistant picks", a?.id !== b?.id,
        `picked ${a?.id} then ${b?.id}`);
}

// ─── 7. Targeting: grudge memory (Task 5) ────────────────────────────────────
section("grudge memory (Task 5)");
{
  resetCombatState();
  buildWorld({
    tokens: [
      { id: "npc", row: 20, col: 20, disposition: -1 },
      { id: "pcNear", row: 20, col: 24, disposition: 1, actorType: "character", hasPlayerOwner: true },
      { id: "pcGrudge", row: 20, col: 26, disposition: 1, actorType: "character", hasPlayerOwner: true },
    ],
    combat: { round: 1 },
    settingsOverrides: { targetPersistence: false, targetGrudgeMemory: true, dispositionTargeting: true },
  });
  const npc = globalThis.canvas.tokens.get("npc");

  // pcGrudge is 10ft farther (score +10) — a 30-damage grudge (capped bonus 12) must flip it.
  targeting.recordDamageTaken(npc.actor.id, "pcGrudge", 30);
  const chosen = targeting.selectTarget(npc, null);
  check("grudge outweighs 10ft of distance", chosen?.id === "pcGrudge", `got ${chosen?.id}`);

  // Cap check: grudge must NOT outweigh 15ft+ (cap is 12)
  resetCombatState();
  buildWorld({
    tokens: [
      { id: "npc", row: 20, col: 20, disposition: -1 },
      { id: "pcNear", row: 20, col: 24, disposition: 1, actorType: "character", hasPlayerOwner: true },
      { id: "pcFar",  row: 20, col: 28, disposition: 1, actorType: "character", hasPlayerOwner: true },
    ],
    combat: { round: 1 },
    settingsOverrides: { targetPersistence: false, targetGrudgeMemory: true, dispositionTargeting: true },
  });
  const npc3 = globalThis.canvas.tokens.get("npc");
  targeting.recordDamageTaken(npc3.actor.id, "pcFar", 999);
  const chosen2 = targeting.selectTarget(npc3, null);
  check("grudge cap (12) cannot beat 20ft of distance", chosen2?.id === "pcNear", `got ${chosen2?.id}`);
}

// ─── 8. Targeting: per-actor flags (0.18) ────────────────────────────────────
section("priority target + blacklist flags");
{
  resetCombatState();
  buildWorld({
    tokens: [
      { id: "npc", row: 20, col: 20, disposition: -1,
        flags: { priorityTargetName: "Wizard" } },
      { id: "near",   name: "Fighter", row: 20, col: 22, disposition: 1, actorType: "character", hasPlayerOwner: true },
      { id: "wizard", name: "Wizard",  row: 20, col: 30, disposition: 1, actorType: "character", hasPlayerOwner: true },
    ],
    combat: { round: 1 },
    settingsOverrides: { dispositionTargeting: true },
  });
  const npc = globalThis.canvas.tokens.get("npc");
  const chosen = targeting.selectTarget(npc, null);
  check("priority flag overrides distance", chosen?.name === "Wizard", `got ${chosen?.name}`);

  resetCombatState();
  buildWorld({
    tokens: [
      { id: "npc", row: 20, col: 20, disposition: -1,
        flags: { targetBlacklist: "Hostage, Fighter" } },
      { id: "fighter", name: "Fighter", row: 20, col: 22, disposition: 1, actorType: "character", hasPlayerOwner: true },
      { id: "rogue",   name: "Rogue",   row: 20, col: 26, disposition: 1, actorType: "character", hasPlayerOwner: true },
    ],
    combat: { round: 1 },
    settingsOverrides: { dispositionTargeting: true },
  });
  const npc2 = globalThis.canvas.tokens.get("npc");
  const chosen2 = targeting.selectTarget(npc2, null);
  check("blacklisted name skipped despite proximity", chosen2?.name === "Rogue", `got ${chosen2?.name}`);
}

// ─── 9. Door opening: proximity vs ray-miss (movement realism fix) ───────────
section("openReachableDoors: diagonal approach (the 'stops with budget' bug)");
{
  // Door is a horizontal leaf just north of the NPC, spanning the cell the NPC
  // wants to step into diagonally. The straight one-cell step ray (centre→centre)
  // grazes the corner and historically missed the leaf, halting the NPC. The
  // proximity opener must open it regardless.
  const gs = 100;
  // NPC at cell (20,20) centre (2050,2050). Door leaf horizontal at y=2000
  // spanning x 2000..2100 — directly north, ~0.5 cell away.
  const world = buildWorld({
    tokens: [{ id: "npc", row: 20, col: 20, disposition: -1 }],
    walls: [{ x1: 2000, y1: 2000, x2: 2100, y2: 2000, door: 1, ds: 0 }],
    combat: { round: 1 },
    settingsOverrides: { npcOpenDoors: true },
  });
  const npc = globalThis.canvas.tokens.get("npc");
  const npcCenter = { x: 2050, y: 2050 };

  // Heading north-east (diagonal) — door is ahead-ish and within reach.
  const opened = await movement.openReachableDoors(npc, npcCenter, 0.5, { x: 2150, y: 1950 });
  check("diagonal-approach door gets opened by proximity", opened === true);
  check("door state is now OPEN", world.walls[0].document.ds === 1);
}

section("openReachableDoors: double-door leaf on diagonal approach (log repro)");
{
  // Reproduces localhost log R1: NPC at [30,24] (centre 2450,3050 with 100px
  // grid), far double-door leaf ~2.1 cells away that the 1.75c reach rejected.
  // With the corrected 2.25c reach + heading toward the doorway, it opens.
  const repro = buildWorld({
    tokens: [{ id: "npc", row: 30, col: 24, disposition: -1 }],
    // Door leaf ~2.05 cells NW of the NPC centre, ahead along the travel vector.
    walls: [{ x1: 2250, y1: 2900, x2: 2350, y2: 2900, door: 1, ds: 0 }],
    combat: { round: 1 },
    settingsOverrides: { npcOpenDoors: true },
  });
  const npcR = globalThis.canvas.tokens.get("npc");
  const npcCenter = npcR.center; // {2450,3050}
  const opened = await movement.openReachableDoors(npcR, npcCenter, 0.5, { x: 2250, y: 2850 });
  check("double-door leaf within corrected reach gets opened", opened === true,
        `door ds=${repro.walls[0].document.ds}`);
}

section("openReachableDoors: respects reach + heading + locked");
{
  // Far door (3 cells north) must NOT be opened.
  const farWorld = buildWorld({
    tokens: [{ id: "npc", row: 20, col: 20 }],
    walls: [{ x1: 2000, y1: 1650, x2: 2100, y2: 1650, door: 1, ds: 0 }], // 4 cells north
    combat: { round: 1 },
    settingsOverrides: { npcOpenDoors: true },
  });
  const npcA = globalThis.canvas.tokens.get("npc");
  const openedFar = await movement.openReachableDoors(npcA, { x: 2050, y: 2050 }, 0.5, { x: 2050, y: 1950 });
  check("out-of-reach door left closed", openedFar === false && farWorld.walls[0].document.ds === 0);

  // Door behind the NPC (heading away) must NOT be opened.
  const behindWorld = buildWorld({
    tokens: [{ id: "npc", row: 20, col: 20 }],
    walls: [{ x1: 2000, y1: 2300, x2: 2100, y2: 2300, door: 1, ds: 0 }], // south leaf, 2.5 cells back
    combat: { round: 1 },
    settingsOverrides: { npcOpenDoors: true },
  });
  const npcB = globalThis.canvas.tokens.get("npc");
  const openedBehind = await movement.openReachableDoors(npcB, { x: 2050, y: 2050 }, 0.5, { x: 2050, y: 1900 }); // heading north
  check("door behind NPC (opposite heading) left closed", behindWorld.walls[0].document.ds === 0,
        `ds=${behindWorld.walls[0].document.ds}`);

  // Locked door must NOT be opened.
  const lockedWorld = buildWorld({
    tokens: [{ id: "npc", row: 20, col: 20 }],
    walls: [{ x1: 2000, y1: 2000, x2: 2100, y2: 2000, door: 1, ds: 2 }], // locked
    combat: { round: 1 },
    settingsOverrides: { npcOpenDoors: true },
  });
  const npcC = globalThis.canvas.tokens.get("npc");
  const openedLocked = await movement.openReachableDoors(npcC, { x: 2050, y: 2050 }, 0.5, { x: 2050, y: 1950 });
  check("locked door stays locked", openedLocked === false && lockedWorld.walls[0].document.ds === 2);
}

// ─── Result ───────────────────────────────────────────────────────────────────
console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
